# MorphZuka (Fabric 1.21.1)

Mod **client-side** para usar modelos de Blockbench como modelo de jugador.

## Compilar
Requiere JDK 21.
```
gradle wrapper --gradle-version 8.10.2   # solo la primera vez (o abre la carpeta en IntelliJ)
./gradlew build
```
El jar queda en `build/libs/morphzuka-1.0.0.jar`.

## Uso
1. Pon tus modelos en `.minecraft/morphzuka/` (tambien lee `.minecraft/player_models/` de CPM):
   - `.morphzuka` (Blockbench, incluye CPM y GeckoLib si los guardas como proyecto) con textura incrustada
   - `.geo.json` (+ `mismo_nombre.png` y `mismo_nombre.animation.json` al lado)
   - `.cpmproject` (si contiene un .morphzuka)
   - Modelos GeckoLib de otros mods / resourcepacks (`assets/<ns>/geo/*.geo.json`) se detectan solos.
2. En el juego pulsa **K** (o `/morphzuka`).
3. Elige modelo -> elige cada hueso y asignale rol (Cabeza, Torso, Brazos, Piernas, Cola/extra; puedes asignar varios huesos al mismo rol).
4. Edita el pivote de cualquier hueso (X Y Z en pixeles) y pulsa "Fijar pivote".
5. Asigna animaciones a IDLE / WALK / SPRINT / SNEAK / AIR.
6. "Aplicar a": Yo / Todos / Jugador (nombre) -> Aplicar.

Config guardada en `config/morphzuka.json`.

## Limitaciones
- Solo client-side: lo ves tu; otros jugadores no ven tu modelo (CPM real sincroniza por servidor).
- Una sola textura por modelo; meshes no soportados (solo cubos).
- Armadura/items/capa siguen renderizandose con el esqueleto vanilla.
- Sin poses de nado/elytra/dormir. Rotaciones de GeckoLib/Bedrock pueden requerir ajustes de signo.

## Interfaz (v1.1)
Menú estilo Material oscuro/transparente con barra lateral: **Modelos**, **Partes**, **Animación**, **Importar**, **Aplicar**.
- **Arrastrar y soltar**: suelta `.morphzuka`, `.geo.json`, `.cpmproject` (y `.png` / `.animation.json` de GeckoLib) sobre la ventana del menú.
- **Importar**: pega un link directo (los links de GitHub `/blob/` se convierten solos a raw) o usa "Pegar Base64 / JSON del portapapeles" (acepta Base64, `data:...;base64,` y JSON plano).

## Editor 3D (v2.3)
Pestaña **Editor 3D** (o botón "Editor 3D" en Partes). Pantalla completa con:
- **Visor orbital**: arrastra en vacío para girar, rueda para zoom, "Centrar vista" para volver.
- **Selector de partes**: lista a la izquierda o clic en los puntos de pivote dentro del visor. La parte elegida se tiñe de naranja.
- **Gizmo**: modos **Mover**, **Rotar** (3 aros), **Escalar** (ejes + cubo central = uniforme) y **Pivote**. Ejes en rojo X, verde Y, azul Z.
- **Campos XYZ** numéricos para cada modo; se sincronizan con el gizmo.
- Deshacer, restaurar parte / todo, ocultar parte. Se guarda al cerrar en `config/morphzuka.json`
  (`offsets`, `rotOffsets`, `scales`, `pivots`); el archivo del modelo no se toca.
Los ejes del gizmo siguen el espacio del hueso padre (en Escalar, el del propio hueso).
