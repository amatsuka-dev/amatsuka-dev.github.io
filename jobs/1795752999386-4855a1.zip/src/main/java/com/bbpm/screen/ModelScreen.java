package com.bbpm.screen;

import com.bbpm.Role;
import com.bbpm.model.BBModel;
import com.bbpm.model.ModelManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ModelScreen extends Screen {
    private static final int ROW = 12;
    private static final String[] MODES = {"Yo", "Todos", "Jugador"};

    private final Screen parent;
    private List<BBModel> models = new ArrayList<>();
    private BBModel cur;
    private String curBone;
    private int mScroll, bScroll, mode;
    private String status = "";

    private ButtonWidget roleBtn, modeBtn;
    private final ButtonWidget[] animBtns = new ButtonWidget[ModelManager.STATES.length];
    private TextFieldWidget fx, fy, fz, fScale, fTarget;

    public ModelScreen(Screen parent) {
        super(Text.literal("BB Player Models"));
        this.parent = parent;
    }

    // layout
    private int lx() { return 10; }
    private int lw() { return 150; }
    private int ly() { return 30; }
    private int lh() { return height - 72; }
    private int bx() { return 170; }
    private int bw() { return 180; }
    private int bh() { return height - 140; }
    private int cx() { return 360; }
    private int rw() { return Math.max(120, width - cx() - 10); }

    @Override
    protected void init() {
        models = new ArrayList<>(ModelManager.MODELS.values());
        if (cur == null || !ModelManager.MODELS.containsKey(cur.id)) {
            cur = models.isEmpty() ? null : models.get(0);
            curBone = null;
        }
        int bx = bx(), cx = cx(), rw = rw();

        roleBtn = addDrawableChild(ButtonWidget.builder(Text.literal(""), b -> cycleRole())
                .dimensions(bx, height - 104, bw(), 18).build());
        fx = field(bx, height - 66, 40, "X");
        fy = field(bx + 46, height - 66, 40, "Y");
        fz = field(bx + 92, height - 66, 40, "Z");
        addDrawableChild(ButtonWidget.builder(Text.literal("Fijar pivote"), b -> setPivot())
                .dimensions(bx, height - 46, 88, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Restaurar"), b -> resetPivot())
                .dimensions(bx + 92, height - 46, 88, 18).build());

        for (int i = 0; i < animBtns.length; i++) {
            final int idx = i;
            animBtns[i] = addDrawableChild(ButtonWidget.builder(Text.literal(""), b -> cycleAnim(idx))
                    .dimensions(cx, 40 + 22 * i, rw, 18).build());
        }
        fScale = field(cx + 50, 154, 50, "Escala");
        fScale.setChangedListener(str -> {
            if (cur == null) return;
            try {
                float v = Float.parseFloat(str.trim());
                if (v > 0) ModelManager.settings(cur).scale = v;
            } catch (Exception ignored) {}
        });

        modeBtn = addDrawableChild(ButtonWidget.builder(Text.literal(""), b -> { mode = (mode + 1) % 3; refresh(); })
                .dimensions(cx, 176, rw, 18).build());
        fTarget = field(cx, 198, rw, "Jugador");
        addDrawableChild(ButtonWidget.builder(Text.literal("Aplicar"), b -> apply())
                .dimensions(cx, 220, rw / 2 - 2, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Quitar"), b -> remove())
                .dimensions(cx + rw / 2 + 2, 220, rw / 2 - 2, 18).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Recargar"), b -> {
            ModelManager.saveConfig();
            ModelManager.reload();
            clearAndInit();
            status = "Modelos recargados: " + ModelManager.MODELS.size();
        }).dimensions(10, height - 34, 72, 18).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Hecho"), b -> close())
                .dimensions(88, height - 34, 72, 18).build());

        refresh();
    }

    private TextFieldWidget field(int x, int y, int w, String name) {
        TextFieldWidget f = new TextFieldWidget(textRenderer, x, y, w, 16, Text.literal(name));
        addDrawableChild(f);
        return f;
    }

    private ModelManager.Settings settings() { return cur == null ? null : ModelManager.settings(cur); }

    private void refresh() {
        ModelManager.Settings s = settings();
        boolean has = s != null;
        boolean bone = has && curBone != null;
        roleBtn.active = bone;
        roleBtn.setMessage(Text.literal(bone ? "Rol de '" + curBone + "': " + Role.of(s.roles.get(curBone)).label
                : "Selecciona un hueso"));
        float[] pv = bone ? (s.pivots.containsKey(curBone) ? s.pivots.get(curBone) : cur.bones.get(curBone).pivot) : new float[3];
        fx.setText(fmt(pv[0])); fy.setText(fmt(pv[1])); fz.setText(fmt(pv[2]));
        for (int i = 0; i < animBtns.length; i++) {
            String a = has ? s.anims.get(ModelManager.STATES[i]) : null;
            animBtns[i].active = has;
            animBtns[i].setMessage(Text.literal(ModelManager.STATES[i] + ": " + (a == null ? "(ninguna)" : trim(a, 22))));
        }
        fScale.setText(has ? fmt(s.scale) : "1");
        modeBtn.setMessage(Text.literal("Aplicar a: " + MODES[mode]));
        fTarget.setVisible(mode == 2);
    }

    private static String fmt(float f) { return f == (long) f ? Long.toString((long) f) : Float.toString(f); }
    private static String trim(String s, int n) { return s.length() <= n ? s : s.substring(0, n - 1) + "~"; }

    private void cycleRole() {
        ModelManager.Settings s = settings();
        if (s == null || curBone == null) return;
        Role r = Role.of(s.roles.get(curBone));
        Role next = Role.values()[(r.ordinal() + 1) % Role.values().length];
        if (next == Role.NONE) s.roles.remove(curBone); else s.roles.put(curBone, next.name());
        refresh();
    }

    private void cycleAnim(int idx) {
        ModelManager.Settings s = settings();
        if (s == null) return;
        List<String> names = new ArrayList<>(cur.anims.keySet());
        String curA = s.anims.get(ModelManager.STATES[idx]);
        int pos = curA == null ? -1 : names.indexOf(curA);
        pos++;
        if (pos >= names.size()) s.anims.remove(ModelManager.STATES[idx]);
        else s.anims.put(ModelManager.STATES[idx], names.get(pos));
        refresh();
    }

    private void setPivot() {
        ModelManager.Settings s = settings();
        if (s == null || curBone == null) return;
        try {
            s.pivots.put(curBone, new float[]{Float.parseFloat(fx.getText().trim()),
                    Float.parseFloat(fy.getText().trim()), Float.parseFloat(fz.getText().trim())});
            status = "Pivote de '" + curBone + "' actualizado";
        } catch (Exception e) { status = "Numeros invalidos"; }
    }

    private void resetPivot() {
        ModelManager.Settings s = settings();
        if (s == null || curBone == null) return;
        s.pivots.remove(curBone);
        refresh();
    }

    private String targetKey() {
        return switch (mode) {
            case 0 -> "@self";
            case 1 -> "*";
            default -> fTarget.getText().trim().toLowerCase();
        };
    }

    private void apply() {
        if (cur == null) return;
        String k = targetKey();
        if (k.isEmpty()) { status = "Escribe el nombre del jugador"; return; }
        ModelManager.CONFIG.assignments.put(k, cur.id);
        ModelManager.saveConfig();
        status = "Modelo aplicado a: " + k;
    }

    private void remove() {
        String k = targetKey();
        ModelManager.CONFIG.assignments.remove(k);
        ModelManager.saveConfig();
        status = "Modelo quitado de: " + k;
    }

    // -------------------------------------------------------------- render

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        super.render(g, mx, my, delta);
        g.drawCenteredTextWithShadow(textRenderer, "BB Player Models", width / 2, 8, 0xFFFFFF);
        g.drawText(textRenderer, "Modelos (" + models.size() + ")", lx(), 20, 0xAAAAAA, false);
        g.drawText(textRenderer, "Huesos / partes", bx(), 20, 0xAAAAAA, false);
        g.drawText(textRenderer, "Animaciones por estado", cx(), 20, 0xAAAAAA, false);
        g.drawText(textRenderer, "Escala:", cx(), 158, 0xFFFFFF, false);
        g.drawText(textRenderer, "Pivote X  Y  Z:", bx(), height - 78, 0xFFFFFF, false);

        // lista de modelos
        g.fill(lx(), ly(), lx() + lw(), ly() + lh(), 0x88000000);
        if (models.isEmpty()) {
            g.drawText(textRenderer, "Pon .bbmodel / .geo.json en", lx() + 2, ly() + 4, 0xFFFF55, false);
            g.drawText(textRenderer, ".minecraft/bbplayermodels/", lx() + 2, ly() + 16, 0xFFFF55, false);
        }
        int rows = lh() / ROW;
        for (int i = 0; i < rows && mScroll + i < models.size(); i++) {
            BBModel m = models.get(mScroll + i);
            int y = ly() + i * ROW;
            if (m == cur) g.fill(lx(), y, lx() + lw(), y + ROW, 0x8855AAFF);
            g.drawText(textRenderer, textRenderer.trimToWidth("[" + m.source + "] " + m.id, lw() - 4), lx() + 2, y + 2, 0xFFFFFF, false);
        }

        // lista de huesos
        g.fill(bx(), ly(), bx() + bw(), ly() + bh(), 0x88000000);
        if (cur != null) {
            List<BBModel.Bone> bones = new ArrayList<>(cur.bones.values());
            ModelManager.Settings s = settings();
            int brows = bh() / ROW;
            for (int i = 0; i < brows && bScroll + i < bones.size(); i++) {
                BBModel.Bone b = bones.get(bScroll + i);
                int y = ly() + i * ROW;
                if (b.name.equals(curBone)) g.fill(bx(), y, bx() + bw(), y + ROW, 0x8855AAFF);
                Role r = Role.of(s.roles.get(b.name));
                String label = b.name + (r != Role.NONE ? "  [" + r.label + "]" : "");
                int color = r != Role.NONE ? 0x55FF55 : 0xFFFFFF;
                g.drawText(textRenderer, textRenderer.trimToWidth(label, bw() - 6 - b.depth * 6), bx() + 2 + b.depth * 6, y + 2, color, false);
            }
        }
        g.drawText(textRenderer, textRenderer.trimToWidth(status, width - cx() - 10), cx(), height - 30, 0x55FF55, false);
        int n = ModelManager.CONFIG.assignments.size();
        g.drawText(textRenderer, "Asignaciones activas: " + n, cx(), 246, 0xAAAAAA, false);
    }

    private boolean in(double x, double y, int rx, int ry, int rw, int rh) {
        return x >= rx && x < rx + rw && y >= ry && y < ry + rh;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (in(mx, my, lx(), ly(), lw(), lh())) {
            int idx = mScroll + (int) ((my - ly()) / ROW);
            if (idx < models.size()) {
                cur = models.get(idx);
                curBone = null;
                bScroll = 0;
                refresh();
            }
            return true;
        }
        if (cur != null && in(mx, my, bx(), ly(), bw(), bh())) {
            int idx = bScroll + (int) ((my - ly()) / ROW);
            List<BBModel.Bone> bones = new ArrayList<>(cur.bones.values());
            if (idx < bones.size()) {
                curBone = bones.get(idx).name;
                refresh();
            }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
        int dir = vAmount > 0 ? -1 : 1;
        if (in(mx, my, lx(), ly(), lw(), lh())) {
            mScroll = Math.max(0, Math.min(Math.max(0, models.size() - lh() / ROW), mScroll + dir));
            return true;
        }
        if (cur != null && in(mx, my, bx(), ly(), bw(), bh())) {
            bScroll = Math.max(0, Math.min(Math.max(0, cur.bones.size() - bh() / ROW), bScroll + dir));
            return true;
        }
        return super.mouseScrolled(mx, my, hAmount, vAmount);
    }

    @Override
    public void close() {
        ModelManager.saveConfig();
        client.setScreen(parent);
    }
}
