package com.bbpm;

import com.bbpm.model.ModelManager;
import com.bbpm.screen.ModelScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class BBPlayerModelsClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        KeyBinding open = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.bbpm.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, "key.categories.bbpm"));

        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            while (open.wasPressed()) c.setScreen(new ModelScreen(c.currentScreen));
        });

        ClientLifecycleEvents.CLIENT_STARTED.register(c -> ModelManager.reload());

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registry) ->
                dispatcher.register(ClientCommandManager.literal("bbmodel").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    mc.send(() -> mc.setScreen(new ModelScreen(null)));
                    return 1;
                })));
    }
}
