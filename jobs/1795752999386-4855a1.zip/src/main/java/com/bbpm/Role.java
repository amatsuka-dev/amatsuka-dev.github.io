package com.bbpm;

import java.util.Locale;

public enum Role {
    NONE("-"), HEAD("Cabeza"), BODY("Torso"), LEFT_ARM("Brazo izq"), RIGHT_ARM("Brazo der"),
    LEFT_LEG("Pierna izq"), RIGHT_LEG("Pierna der"), TAIL("Cola / extra");

    public final String label;
    Role(String l) { this.label = l; }

    public static Role of(String s) {
        if (s == null) return NONE;
        try { return valueOf(s); } catch (Exception e) { return NONE; }
    }

    public static Role guess(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        boolean left = n.contains("left") || n.matches(".*(^|[_\\-. ])l([_\\-. ]|$).*");
        boolean right = n.contains("right") || n.matches(".*(^|[_\\-. ])r([_\\-. ]|$).*");
        if (n.contains("head")) return HEAD;
        if (n.contains("tail")) return TAIL;
        if (n.contains("arm") || n.contains("hand")) return left ? LEFT_ARM : right ? RIGHT_ARM : NONE;
        if (n.contains("leg") || n.contains("foot")) return left ? LEFT_LEG : right ? RIGHT_LEG : NONE;
        if (n.contains("body") || n.contains("torso") || n.contains("chest")) return BODY;
        return NONE;
    }
}
