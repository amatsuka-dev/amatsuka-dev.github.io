package com.bbpm.render;

import com.bbpm.Role;
import com.bbpm.model.BBModel;
import com.bbpm.model.ModelManager;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

public final class BBRenderer {
    private BBRenderer() {}

    private static final float[] ZERO = {0, 0, 0};
    private static final float[] ONE = {1, 1, 1};

    private static final class Ctx {
        BBModel model;
        ModelManager.Settings s;
        BBModel.Anim anim;
        VertexConsumer vc;
        int light, overlay;
        float animTime, time, pitch, headDelta, limbPos, limbSpeed;
    }

    public static void render(AbstractClientPlayerEntity p, float td, MatrixStack m, VertexConsumerProvider vcp,
                              int light, ModelManager.Active a) {
        BBModel mod = a.model();
        ModelManager.Settings s = a.settings();

        float bodyYaw = MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw);
        float headYaw = MathHelper.lerpAngleDegrees(td, p.prevHeadYaw, p.headYaw);

        Ctx c = new Ctx();
        c.model = mod;
        c.s = s;
        c.light = light;
        c.overlay = LivingEntityRenderer.getOverlay(p, 0f);
        c.headDelta = MathHelper.clamp(MathHelper.wrapDegrees(headYaw - bodyYaw), -75f, 75f);
        c.pitch = MathHelper.lerp(td, p.prevPitch, p.getPitch());
        c.limbPos = p.limbAnimator.getPos(td);
        c.limbSpeed = Math.min(1f, p.limbAnimator.getSpeed(td));
        c.time = (p.age + td) / 20f;

        String state;
        if (p.isInSneakingPose()) state = "SNEAK";
        else if (!p.isOnGround() && !p.isTouchingWater()) state = "AIR";
        else if (c.limbSpeed > 0.02f) state = p.isSprinting() ? "SPRINT" : "WALK";
        else state = "IDLE";

        String an = s.anims.get(state);
        if (an == null && state.equals("SPRINT")) an = s.anims.get("WALK");
        if (an == null && state.equals("AIR")) an = s.anims.get("IDLE");
        c.anim = an == null ? null : mod.anims.get(an);
        if (c.anim != null) {
            float len = c.anim.length;
            c.animTime = c.time;
            if (len > 0) c.animTime = c.anim.loop ? c.time % len : Math.min(c.time, len);
        }

        c.vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(mod.texture));

        float sc = s.scale <= 0 ? 1f : s.scale;
        m.push();
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f - bodyYaw));
        m.scale(sc / 16f, sc / 16f, sc / 16f);
        for (BBModel.Bone b : mod.roots) bone(c, b, m);
        m.pop();
    }

    // positivo en X = swing hacia delante (frente del modelo = -Z)
    private static float[] procedural(Ctx c, Role r) {
        float cosA = MathHelper.cos(c.limbPos * 0.6662f);
        float arm = 57.3f * c.limbSpeed, leg = 80f * c.limbSpeed;
        return switch (r) {
            case HEAD -> new float[]{-c.pitch, -c.headDelta, 0};
            case LEFT_ARM -> c.anim == null ? new float[]{arm * cosA, 0, 0} : ZERO;
            case RIGHT_ARM -> c.anim == null ? new float[]{-arm * cosA, 0, 0} : ZERO;
            case LEFT_LEG -> c.anim == null ? new float[]{-leg * cosA, 0, 0} : ZERO;
            case RIGHT_LEG -> c.anim == null ? new float[]{leg * cosA, 0, 0} : ZERO;
            case TAIL -> new float[]{0, MathHelper.sin(c.time * 2.5f) * 10f + cosA * 20f * c.limbSpeed, 0};
            default -> ZERO;
        };
    }

    private static void bone(Ctx c, BBModel.Bone b, MatrixStack m) {
        m.push();
        float[] piv = c.s.pivots.getOrDefault(b.name, b.pivot);
        float rx = b.rot[0], ry = b.rot[1], rz = b.rot[2];
        float[] pos = ZERO, sc = ONE;

        if (c.anim != null) {
            BBModel.BoneAnim ba = c.anim.bones.get(b.name);
            if (ba != null) {
                float[] r = BBModel.sample(ba.rot, c.animTime, ZERO);
                rx += r[0]; ry += r[1]; rz += r[2];
                pos = BBModel.sample(ba.pos, c.animTime, ZERO);
                sc = BBModel.sample(ba.scale, c.animTime, ONE);
            }
        }
        Role role = Role.of(c.s.roles.get(b.name));
        if (role != Role.NONE) {
            float[] pr = procedural(c, role);
            rx += pr[0]; ry += pr[1]; rz += pr[2];
        }

        m.translate(piv[0], piv[1], piv[2]);
        m.translate(pos[0], pos[1], pos[2]);
        m.multiply(new Quaternionf().rotationZ((float) Math.toRadians(rz)));
        m.multiply(new Quaternionf().rotationY((float) Math.toRadians(ry)));
        m.multiply(new Quaternionf().rotationX((float) Math.toRadians(rx)));
        m.scale(Math.max(0.001f, sc[0]), Math.max(0.001f, sc[1]), Math.max(0.001f, sc[2]));
        m.translate(-piv[0], -piv[1], -piv[2]);

        if (b.visible) for (BBModel.Cube cube : b.cubes) cube(c, cube, m);
        for (BBModel.Bone ch : b.children) bone(c, ch, m);
        m.pop();
    }

    private static void cube(Ctx c, BBModel.Cube cu, MatrixStack m) {
        m.push();
        if (cu.rot[0] != 0 || cu.rot[1] != 0 || cu.rot[2] != 0) {
            m.translate(cu.origin[0], cu.origin[1], cu.origin[2]);
            m.multiply(new Quaternionf().rotationZ((float) Math.toRadians(cu.rot[2])));
            m.multiply(new Quaternionf().rotationY((float) Math.toRadians(cu.rot[1])));
            m.multiply(new Quaternionf().rotationX((float) Math.toRadians(cu.rot[0])));
            m.translate(-cu.origin[0], -cu.origin[1], -cu.origin[2]);
        }
        MatrixStack.Entry e = m.peek();
        float i = cu.inflate;
        float x0 = cu.from[0] - i, y0 = cu.from[1] - i, z0 = cu.from[2] - i;
        float x1 = cu.to[0] + i, y1 = cu.to[1] + i, z1 = cu.to[2] + i;

        face(c, cu, "north", e, new float[]{x1, y1, z0, x0, y1, z0, x0, y0, z0, x1, y0, z0}, 0, 0, -1);
        face(c, cu, "south", e, new float[]{x0, y1, z1, x1, y1, z1, x1, y0, z1, x0, y0, z1}, 0, 0, 1);
        face(c, cu, "east", e, new float[]{x1, y1, z1, x1, y1, z0, x1, y0, z0, x1, y0, z1}, 1, 0, 0);
        face(c, cu, "west", e, new float[]{x0, y1, z0, x0, y1, z1, x0, y0, z1, x0, y0, z0}, -1, 0, 0);
        face(c, cu, "up", e, new float[]{x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1}, 0, 1, 0);
        face(c, cu, "down", e, new float[]{x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0}, 0, -1, 0);
        m.pop();
    }

    private static float[] boxUv(BBModel.Cube c, String dir) {
        float w = Math.abs(c.to[0] - c.from[0]), h = Math.abs(c.to[1] - c.from[1]), d = Math.abs(c.to[2] - c.from[2]);
        float u = c.uvOffset[0], v = c.uvOffset[1];
        return switch (dir) {
            case "east" -> new float[]{u, v + d, u + d, v + d + h};
            case "north" -> new float[]{u + d, v + d, u + d + w, v + d + h};
            case "west" -> new float[]{u + d + w, v + d, u + 2 * d + w, v + d + h};
            case "south" -> new float[]{u + 2 * d + w, v + d, u + 2 * d + 2 * w, v + d + h};
            case "up" -> new float[]{u + d, v, u + d + w, v + d};
            default -> new float[]{u + d + w, v, u + d + 2 * w, v + d};
        };
    }

    private static void face(Ctx c, BBModel.Cube cu, String dir, MatrixStack.Entry e, float[] p,
                             float nx, float ny, float nz) {
        float[] uv = cu.boxUv ? boxUv(cu, dir) : cu.faces.get(dir);
        if (uv == null) return;
        float tw = c.model.texW, th = c.model.texH;
        float u1 = uv[0] / tw, v1 = uv[1] / th, u2 = uv[2] / tw, v2 = uv[3] / th;
        Matrix4f mat = e.getPositionMatrix();
        vert(c, e, mat, p, 0, u1, v1, nx, ny, nz);
        vert(c, e, mat, p, 3, u2, v1, nx, ny, nz);
        vert(c, e, mat, p, 6, u2, v2, nx, ny, nz);
        vert(c, e, mat, p, 9, u1, v2, nx, ny, nz);
    }

    private static void vert(Ctx c, MatrixStack.Entry e, Matrix4f mat, float[] p, int o, float u, float v,
                             float nx, float ny, float nz) {
        c.vc.vertex(mat, p[o], p[o + 1], p[o + 2]).color(255, 255, 255, 255).texture(u, v)
                .overlay(c.overlay).light(c.light).normal(e, nx, ny, nz);
    }
}
