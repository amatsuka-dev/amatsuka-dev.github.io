package com.bbpm.model;

import com.bbpm.Role;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public final class ModelManager {
    public static final Logger LOG = LoggerFactory.getLogger("bbplayermodels");
    public static final Map<String, BBModel> MODELS = new LinkedHashMap<>();
    public static Config CONFIG = new Config();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static final String[] STATES = {"IDLE", "WALK", "SPRINT", "SNEAK", "AIR"};

    public static class Settings {
        public Map<String, String> roles = new HashMap<>();     // hueso -> Role
        public Map<String, float[]> pivots = new HashMap<>();   // hueso -> pivote override
        public Map<String, String> anims = new HashMap<>();     // estado -> animacion
        public float scale = 1f;
    }

    public static class Config {
        public Map<String, Settings> settings = new HashMap<>();
        public Map<String, String> assignments = new HashMap<>(); // "@self" | "*" | nombre jugador -> modelId
    }

    public record Active(BBModel model, Settings settings) {}

    public static Path modelsDir() { return FabricLoader.getInstance().getGameDir().resolve("bbplayermodels"); }
    private static Path configFile() { return FabricLoader.getInstance().getConfigDir().resolve("bbplayermodels.json"); }

    public static void reload() {
        MinecraftClient mc = MinecraftClient.getInstance();
        for (BBModel m : MODELS.values())
            if (m.ownsTexture) mc.getTextureManager().destroyTexture(m.texture);
        MODELS.clear();
        try { Files.createDirectories(modelsDir()); } catch (IOException ignored) {}

        ModelLoader.scanFolder(modelsDir(), "", MODELS);
        // Carpeta del mod Custom Player Models (si existe)
        ModelLoader.scanFolder(FabricLoader.getInstance().getGameDir().resolve("player_models"), "cpm/", MODELS);
        // Modelos GeckoLib dentro de mods / resourcepacks
        try { ModelLoader.scanResources(mc.getResourceManager(), MODELS); }
        catch (Throwable t) { LOG.warn("Scan GeckoLib fallo: {}", t.toString()); }

        loadConfig();
        LOG.info("BB Player Models: {} modelos cargados", MODELS.size());
    }

    public static void loadConfig() {
        try {
            if (Files.exists(configFile())) {
                Config c = GSON.fromJson(Files.readString(configFile()), Config.class);
                if (c != null) CONFIG = c;
            }
        } catch (Exception e) { LOG.warn("Config invalida: {}", e.toString()); }
        if (CONFIG.settings == null) CONFIG.settings = new HashMap<>();
        if (CONFIG.assignments == null) CONFIG.assignments = new HashMap<>();
        for (Settings s : CONFIG.settings.values()) {
            if (s.roles == null) s.roles = new HashMap<>();
            if (s.pivots == null) s.pivots = new HashMap<>();
            if (s.anims == null) s.anims = new HashMap<>();
            if (s.scale <= 0) s.scale = 1f;
        }
    }

    public static void saveConfig() {
        try { Files.writeString(configFile(), GSON.toJson(CONFIG)); }
        catch (IOException e) { LOG.warn("No se pudo guardar config: {}", e.toString()); }
    }

    public static Settings settings(BBModel m) {
        Settings s = CONFIG.settings.get(m.id);
        if (s == null) {
            s = new Settings();
            CONFIG.settings.put(m.id, s);
            autoDetect(m, s);
        }
        return s;
    }

    private static void autoDetect(BBModel m, Settings s) {
        for (BBModel.Bone r : m.roots) auto(r, s, EnumSet.noneOf(Role.class));
        String[][] kw = {{"idle"}, {"walk"}, {"run", "sprint"}, {"sneak", "crouch"}, {"jump", "fall", "air"}};
        for (int i = 0; i < STATES.length; i++) {
            outer:
            for (String k : kw[i])
                for (String an : m.anims.keySet())
                    if (an.toLowerCase(Locale.ROOT).contains(k)) { s.anims.put(STATES[i], an); break outer; }
        }
    }

    private static void auto(BBModel.Bone b, Settings s, EnumSet<Role> ancestors) {
        EnumSet<Role> here = EnumSet.copyOf(ancestors.isEmpty() ? EnumSet.noneOf(Role.class) : ancestors);
        Role r = Role.guess(b.name);
        if (r != Role.NONE && !here.contains(r)) {
            s.roles.put(b.name, r.name());
            here.add(r);
        }
        for (BBModel.Bone c : b.children) auto(c, s, here);
    }

    public static Active forPlayer(AbstractClientPlayerEntity p) {
        if (MODELS.isEmpty() || CONFIG.assignments.isEmpty()) return null;
        String id = CONFIG.assignments.get(p.getGameProfile().getName().toLowerCase(Locale.ROOT));
        if (id == null && p == MinecraftClient.getInstance().player) id = CONFIG.assignments.get("@self");
        if (id == null) id = CONFIG.assignments.get("*");
        BBModel m = id == null ? null : MODELS.get(id);
        return m == null ? null : new Active(m, settings(m));
    }
}
