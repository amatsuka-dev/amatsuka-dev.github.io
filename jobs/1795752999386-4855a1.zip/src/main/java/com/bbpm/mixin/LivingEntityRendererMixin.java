package com.bbpm.mixin;

import com.bbpm.model.ModelManager;
import com.bbpm.render.BBRenderer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {

    @Inject(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"))
    private void bbpm$render(LivingEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                             VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        if (entity instanceof AbstractClientPlayerEntity p && !p.isInvisible() && !p.isSpectator()) {
            ModelManager.Active a = ModelManager.forPlayer(p);
            if (a != null) BBRenderer.render(p, tickDelta, matrices, vcp, light, a);
        }
    }

    /** Si el jugador tiene modelo custom, el modelo vanilla no se dibuja (layer null). */
    @Inject(method = "getRenderLayer", at = @At("RETURN"), cancellable = true)
    private void bbpm$hideVanilla(LivingEntity entity, boolean showBody, boolean translucent, boolean showOutline,
                                  CallbackInfoReturnable<RenderLayer> cir) {
        if (entity instanceof AbstractClientPlayerEntity p && ModelManager.forPlayer(p) != null) {
            cir.setReturnValue(null);
        }
    }
}
