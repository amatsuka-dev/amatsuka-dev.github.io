package com.morphzuka;

import com.morphzuka.model.ModelManager;
import com.morphzuka.render.MorphManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

/** Hitbox / altura de ojos personalizadas. Solo del cliente: el servidor sigue usando la caja vanilla. */
public final class HitboxOverride {
    private HitboxOverride() {}

    /** {ancho, alto, altura de ojos} o null si no hay override. */
    public static float[] get(AbstractClientPlayerEntity p) {
        if (p == MinecraftClient.getInstance().player && MorphManager.active()) {
            float[] m = MorphManager.hitbox();
            if (m != null) return m;
        }
        ModelManager.Active a = ModelManager.forPlayer(p);
        if (a == null) return null;
        ModelManager.Settings s = a.settings();
        if (!s.hitboxOn) return null;
        float w = Math.max(0.05f, Math.max(s.hitbox[0], s.hitbox[2])); // la caja de Minecraft es cuadrada: X y Z comparten ancho
        float h = Math.max(0.05f, s.hitbox[1]);
        float eye = s.eye > 0 ? s.eye : h * 0.9f;
        return new float[]{w, h, eye};
    }

    public static int signature() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return 0;
        float[] h = get(mc.player);
        return h == null ? 0 : java.util.Arrays.hashCode(h) + 1;
    }
}
