package com.morphzuka.render;

import com.morphzuka.model.ModelManager;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Morpher (solo cliente): conviertete en cualquier entidad (vanilla o de mod), bloque u otro jugador.
 * Lo ves tu; al ser solo cliente, no lo ven los demas.
 */
public final class MorphManager {
    private MorphManager() {}

    public enum Kind { ENTITY, BLOCK, PLAYER }

    public static final class State {
        public Kind kind;
        public Identifier id;
        public String name = "";
        public BlockState block;
        public Entity entity;
        public float w = 0.6f, h = 1.8f, eye = 1.62f;
    }

    private static State self;
    public static boolean copyHitbox = true;

    public static boolean active() { return self != null; }
    public static State state() { return self; }

    public static String key() {
        if (self == null) return null;
        return self.kind + ":" + (self.kind == Kind.PLAYER ? self.name : String.valueOf(self.id));
    }

    public static void clear() { self = null; }

    /** @return mensaje de error, o null si salio bien */
    public static String morphEntity(Identifier id) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return "No estás en un mundo";
        EntityType<?> t = Registries.ENTITY_TYPE.getOrEmpty(id).orElse(null);
        if (t == null) return "Entidad desconocida: " + id;
        if (t == EntityType.PLAYER) return "Para copiar a un jugador usa la pestaña Jugador";
        Entity e;
        try { e = t.create(mc.world); } catch (Throwable ex) { return "No se pudo crear: " + ex.getMessage(); }
        if (e == null) return "Esa entidad no se puede crear en cliente";
        State s = new State();
        s.kind = Kind.ENTITY;
        s.id = id;
        s.entity = e;
        EntityDimensions d = t.getDimensions();
        s.w = d.width();
        s.h = d.height();
        s.eye = d.eyeHeight();
        self = s;
        return null;
    }

    public static String morphBlock(BlockState st) {
        State s = new State();
        s.kind = Kind.BLOCK;
        s.id = Registries.BLOCK.getId(st.getBlock());
        s.block = st;
        s.w = 0.98f;
        s.h = 0.98f;
        s.eye = 0.5f;
        self = s;
        return null;
    }

    public static String morphBlock(Identifier id) {
        var b = Registries.BLOCK.getOrEmpty(id).orElse(null);
        if (b == null) return "Bloque desconocido: " + id;
        return morphBlock(b.getDefaultState());
    }

    public static String morphPlayer(String name) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.getNetworkHandler() == null) return "No estás en un mundo";
        PlayerListEntry le = mc.getNetworkHandler().getPlayerListEntry(name);
        if (le == null) return "Jugador no encontrado: " + name;
        State s = new State();
        s.kind = Kind.PLAYER;
        s.name = le.getProfile().getName();
        s.entity = new OtherClientPlayerEntity(mc.world, le.getProfile());
        self = s;
        return null;
    }

    /** "Pistola" de copiar: copia lo que tengas en la mira (entidad, jugador o bloque). */
    public static void copyFromCrosshair(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) return;
        HitResult hr = mc.crosshairTarget;
        String err;
        String what = null;
        if (hr instanceof EntityHitResult eh) {
            Entity e = eh.getEntity();
            if (e instanceof PlayerEntity pe) { err = morphPlayer(pe.getGameProfile().getName()); what = pe.getGameProfile().getName(); }
            else { err = morphEntity(Registries.ENTITY_TYPE.getId(e.getType())); what = e.getType().getName().getString(); }
        } else if (hr instanceof BlockHitResult bh && hr.getType() == HitResult.Type.BLOCK) {
            BlockState st = mc.world.getBlockState(bh.getBlockPos());
            if (st.isAir()) err = "Ahí no hay nada";
            else { err = morphBlock(st); what = st.getBlock().getName().getString(); }
        } else err = "Apunta a una entidad, jugador o bloque";
        mc.player.sendMessage(Text.literal(err != null ? "Morph: " + err : "Ahora eres: " + what), true);
    }

    public static void tick(MinecraftClient mc) {
        State s = self;
        if (s == null || mc.player == null || s.entity == null) return;
        if (s.entity instanceof LivingEntity le) {
            double dx = mc.player.getX() - mc.player.prevX, dz = mc.player.getZ() - mc.player.prevZ;
            float f = Math.min((float) Math.sqrt(dx * dx + dz * dz) * 4f, 1f);
            le.limbAnimator.updateLimbs(f, 0.4f);
        }
    }

    /** {ancho, alto, altura de ojos} copiados del morph, o null si no aplica. */
    public static float[] hitbox() {
        State s = self;
        if (s == null || !copyHitbox) return null;
        return new float[]{s.w, s.h, s.eye};
    }

    private static void sync(Entity e, AbstractClientPlayerEntity p) {
        e.setPosition(p.getX(), p.getY(), p.getZ());
        e.prevX = p.prevX; e.prevY = p.prevY; e.prevZ = p.prevZ;
        e.setYaw(p.getYaw());
        e.prevYaw = p.prevYaw;
        e.setPitch(p.getPitch());
        e.prevPitch = p.prevPitch;
        e.age = p.age;
        e.setOnGround(p.isOnGround());
        if (e instanceof LivingEntity le) {
            le.bodyYaw = p.bodyYaw;
            le.prevBodyYaw = p.prevBodyYaw;
            le.headYaw = p.headYaw;
            le.prevHeadYaw = p.prevHeadYaw;
            le.handSwingProgress = p.handSwingProgress;
            le.lastHandSwingProgress = p.lastHandSwingProgress;
        }
        if (e instanceof PlayerEntity pe) {
            pe.setPose(p.getPose());
            pe.setSneaking(p.isSneaking());
            pe.setSprinting(p.isSprinting());
        }
    }

    /** Dibuja el morph en lugar del jugador. Devuelve true si se encargo del render. */
    public static boolean render(AbstractClientPlayerEntity p, float yaw, float td, MatrixStack m, VertexConsumerProvider vcp, int light) {
        State s = self;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (s == null || p != mc.player) return false;
        float sc = Transition.scale();
        m.push();
        try {
            m.scale(sc, sc, sc);
            if (s.kind == Kind.BLOCK) {
                m.translate(-0.5, 0, -0.5);
                mc.getBlockRenderManager().renderBlockAsEntity(s.block, m, vcp, light, OverlayTexture.DEFAULT_UV);
            } else {
                sync(s.entity, p);
                mc.getEntityRenderDispatcher().render(s.entity, 0, 0, 0, yaw, td, m, vcp, light);
            }
            return true;
        } catch (Throwable t) {
            ModelManager.LOG.warn("Morph fallo, se desactiva: {}", t.toString());
            self = null;
            return false;
        } finally {
            m.pop();
        }
    }

    public static List<Identifier> search(Kind kind, String q, int max) {
        String s = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        List<Identifier> out = new ArrayList<>();
        Iterable<Identifier> ids = kind == Kind.BLOCK ? Registries.BLOCK.getIds() : Registries.ENTITY_TYPE.getIds();
        for (Identifier id : ids) {
            if (kind == Kind.ENTITY && id.equals(Registries.ENTITY_TYPE.getId(EntityType.PLAYER))) continue;
            if (s.isEmpty() || id.toString().contains(s)) out.add(id);
        }
        out.sort(Identifier::compareTo);
        return out.size() > max ? out.subList(0, max) : out;
    }
}
