package com.morphzuka.model;

import net.minecraft.util.Identifier;

import java.util.*;

/** Modelo interno comun para .bbmodel, GeckoLib (.geo.json) y CPM. Unidades: pixeles (1/16 bloque), Y arriba, frente = -Z. */
public class BBModel {
    public String id;
    public String source = "bbmodel";
    public Identifier texture = Identifier.of("minecraft", "textures/entity/player/wide/steve.png");
    public boolean ownsTexture;
    public int texW = 64, texH = 64;
    public final List<Bone> roots = new ArrayList<>();
    public final Map<String, Bone> bones = new LinkedHashMap<>();
    public final Map<String, Anim> anims = new LinkedHashMap<>();

    public static class Bone {
        public String name;
        public int depth;
        public boolean visible = true;
        public float[] pivot = new float[3];
        public float[] rot = new float[3]; // grados
        public final List<Bone> children = new ArrayList<>();
        public final List<Cube> cubes = new ArrayList<>();
    }

    public static class Cube {
        public float[] from = new float[3], to = new float[3], origin = new float[3], rot = new float[3];
        public float inflate;
        public boolean boxUv;
        public float[] uvOffset = new float[2];
        public final Map<String, float[]> faces = new HashMap<>(); // north,east,south,west,up,down -> [u1,v1,u2,v2] en pixeles
    }

    public static class Key {
        public float time;
        public float[] v = new float[3];
        public boolean step;
    }

    public static class BoneAnim {
        public final List<Key> rot = new ArrayList<>(), pos = new ArrayList<>(), scale = new ArrayList<>();
    }

    public static class Anim {
        public String name;
        public float length;
        public boolean loop;
        public final Map<String, BoneAnim> bones = new HashMap<>();
    }

    public static float[] sample(List<Key> ks, float t, float[] def) {
        if (ks.isEmpty()) return def;
        if (t <= ks.get(0).time) return ks.get(0).v;
        for (int i = 0; i < ks.size() - 1; i++) {
            Key a = ks.get(i), b = ks.get(i + 1);
            if (t < b.time) {
                if (a.step) return a.v;
                float f = (t - a.time) / Math.max(1e-5f, b.time - a.time);
                return new float[]{a.v[0] + (b.v[0] - a.v[0]) * f, a.v[1] + (b.v[1] - a.v[1]) * f, a.v[2] + (b.v[2] - a.v[2]) * f};
            }
        }
        return ks.get(ks.size() - 1).v;
    }
}
