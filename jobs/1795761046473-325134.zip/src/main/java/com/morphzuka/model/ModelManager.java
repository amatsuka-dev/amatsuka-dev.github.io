package com.morphzuka.model;

import com.morphzuka.Role;
import com.morphzuka.ui.Theme;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public final class ModelManager {
    public static final Logger LOG = LoggerFactory.getLogger("morphzuka");
    public static final Map<String, BBModel> MODELS = new LinkedHashMap<>();
    public static Config CONFIG = new Config();
    private static boolean cfgLoaded;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    /** Biblioteca global de animaciones de jugador (carpeta morphzuka/animations/), usable con cualquier modelo. */
    public static final Map<String, BBModel.Anim> LIB = new LinkedHashMap<>();

    public static final String[] STATES = AnimStates.keys();
    public static final String[] STATE_LABELS = AnimStates.labels();

    public static final String CAT_ATTACK = "ATTACK", CAT_GESTURE = "GESTURE", CAT_SLIDER = "SLIDER";
    public static final String CAT_TOGGLE = "TOGGLE", CAT_POSE = "POSE", CAT_SETUP = "SETUP";
    private static final String[] CATS = {null, CAT_ATTACK, CAT_GESTURE, CAT_SLIDER, CAT_TOGGLE, CAT_POSE, CAT_SETUP};

    public static String catLabel(String c) {
        return switch (c) { case CAT_ATTACK -> "Ataque"; case CAT_GESTURE -> "Gesto"; case CAT_SLIDER -> "Slider"; case CAT_TOGGLE -> "Toggle"; case CAT_POSE -> "Pose"; case CAT_SETUP -> "Inicio"; default -> "-"; };
    }

    public static void cycleCat(Settings s, String anim) {
        String cur = s.animCats.get(anim);
        int i = 0;
        for (int k = 0; k < CATS.length; k++) if (Objects.equals(CATS[k], cur)) i = k;
        String next = CATS[(i + 1) % CATS.length];
        if (next == null) s.animCats.remove(anim); else s.animCats.put(anim, next);
    }

    public static class Settings {
        public Map<String, String> roles = new HashMap<>();     // hueso -> Role
        public Map<String, float[]> pivots = new HashMap<>();   // hueso -> pivote override
        public Map<String, float[]> offsets = new HashMap<>();  // hueso -> desplazamiento (px)
        public Map<String, float[]> rotOffsets = new HashMap<>(); // hueso -> rotacion extra (grados)
        public Set<String> hidden = new HashSet<>();            // huesos ocultos
        public Map<String, String> anims = new HashMap<>();     // estado -> animacion
        public Map<String, String> animCats = new HashMap<>();  // animacion -> ATTACK | GESTURE | SLIDER (ausente = comando)
        public float scale = 1f;
        public boolean followHead = true;   // la cabeza sigue la camara
        public boolean followArms = true;   // los brazos hacen el ataque vanilla
        public boolean hitboxOn;
        public float[] hitbox = {0.6f, 1.8f, 0.6f}; // X, Y, Z
        public float eye;                    // altura de ojos (0 = automatica)
    }

    public static class Config {
        public Map<String, Settings> settings = new HashMap<>();
        public Map<String, String> assignments = new HashMap<>(); // "@self" | "*" | nombre jugador -> modelId
        public Theme.Data theme = new Theme.Data();
    }

    public record Active(BBModel model, Settings settings) {}

    public static Path root() { return FabricLoader.getInstance().getGameDir().resolve("morphzuka"); }
    public static Path modelsDir() { return root(); }
    public static Path animsDir() { return root().resolve("animations"); }
    public static Path bgDir() { return root().resolve("backgrounds"); }
    private static Path configFile() { return FabricLoader.getInstance().getConfigDir().resolve("morphzuka.json"); }

    public static void reload() {
        MinecraftClient mc = MinecraftClient.getInstance();
        for (BBModel m : MODELS.values())
            if (m.ownsTexture) mc.getTextureManager().destroyTexture(m.texture);
        MODELS.clear();
        LIB.clear();
        migrateLegacy();
        try { Files.createDirectories(modelsDir()); Files.createDirectories(animsDir()); Files.createDirectories(bgDir()); } catch (IOException ignored) {}

        ModelLoader.scanFolder(modelsDir(), "", MODELS);
        // Carpeta del mod Custom Player Models (si existe)
        ModelLoader.scanFolder(FabricLoader.getInstance().getGameDir().resolve("player_models"), "cpm/", MODELS);
        // Modelos GeckoLib dentro de mods / resourcepacks
        try { ModelLoader.scanResources(mc.getResourceManager(), MODELS); }
        catch (Throwable t) { LOG.warn("Scan GeckoLib fallo: {}", t.toString()); }

        loadAnimLibrary();
        if (!cfgLoaded) { loadConfig(); cfgLoaded = true; }
        LOG.info("MorphZuka: {} modelos y {} animaciones de biblioteca", MODELS.size(), LIB.size());
    }

    private static void loadAnimLibrary() {
        Path dir = animsDir();
        if (!Files.isDirectory(dir)) return;
        try (java.util.stream.Stream<Path> st = Files.walk(dir)) {
            st.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".json")).sorted().forEach(p -> {
                try {
                    com.google.gson.JsonObject jo = com.google.gson.JsonParser.parseString(Files.readString(p)).getAsJsonObject();
                    BBModel tmp = new BBModel();
                    ModelLoader.geoAnims(tmp, jo);
                    LIB.putAll(tmp.anims);
                } catch (Throwable t) { LOG.warn("Animacion invalida {}: {}", p.getFileName(), t.toString()); }
            });
        } catch (IOException e) { LOG.warn("Error leyendo animaciones: {}", e.toString()); }
    }

    /** Si venias de BB Player Models, copia carpeta y config una sola vez. */
    private static void migrateLegacy() {
        try {
            Path old = FabricLoader.getInstance().getGameDir().resolve("bbplayermodels");
            if (!Files.exists(root()) && Files.isDirectory(old)) {
                Files.createDirectories(root());
                try (java.util.stream.Stream<Path> st = Files.walk(old)) {
                    for (Path p : (Iterable<Path>) st::iterator) {
                        Path t = root().resolve(old.relativize(p).toString());
                        if (Files.isDirectory(p)) Files.createDirectories(t); else Files.copy(p, t);
                    }
                }
            }
            Path oc = FabricLoader.getInstance().getConfigDir().resolve("bbplayermodels.json");
            if (!Files.exists(configFile()) && Files.exists(oc)) Files.copy(oc, configFile());
        } catch (Exception e) { LOG.warn("Migracion fallo: {}", e.toString()); }
    }

    public static void loadConfig() {
        try {
            if (Files.exists(configFile())) {
                Config c = GSON.fromJson(Files.readString(configFile()), Config.class);
                if (c != null) CONFIG = c;
            }
        } catch (Exception e) { LOG.warn("Config invalida: {}", e.toString()); }
        if (CONFIG.settings == null) CONFIG.settings = new HashMap<>();
        if (CONFIG.assignments == null) CONFIG.assignments = new HashMap<>();
        if (CONFIG.theme == null) CONFIG.theme = new Theme.Data();
        Theme.ensure(CONFIG.theme);
        for (Settings s : CONFIG.settings.values()) {
            if (s.roles == null) s.roles = new HashMap<>();
            if (s.pivots == null) s.pivots = new HashMap<>();
            if (s.anims == null) s.anims = new HashMap<>();
            if (s.offsets == null) s.offsets = new HashMap<>();
            if (s.rotOffsets == null) s.rotOffsets = new HashMap<>();
            if (s.hidden == null) s.hidden = new HashSet<>();
            if (s.animCats == null) s.animCats = new HashMap<>();
            if (s.hitbox == null || s.hitbox.length < 3) s.hitbox = new float[]{0.6f, 1.8f, 0.6f};
            if (s.scale <= 0) s.scale = 1f;
            String air = s.anims.remove("AIR"); // compat con BB Player Models
            if (air != null) { s.anims.putIfAbsent("JUMP", air); s.anims.putIfAbsent("FALL", air); }
        }
    }

    public static void saveConfig() {
        try { Files.writeString(configFile(), GSON.toJson(CONFIG)); }
        catch (IOException e) { LOG.warn("No se pudo guardar config: {}", e.toString()); }
    }

    public static Settings settings(BBModel m) {
        Settings s = CONFIG.settings.get(m.id);
        if (s == null) {
            s = new Settings();
            CONFIG.settings.put(m.id, s);
            autoDetect(m, s);
        }
        return s;
    }

    private static void autoDetect(BBModel m, Settings s) {
        for (BBModel.Bone r : m.roots) auto(r, s, EnumSet.noneOf(Role.class));
        for (AnimStates.Def d : AnimStates.ALL) {
            for (String an : m.anims.keySet()) {
                if (AnimStates.match(d, an)) { s.anims.put(d.key(), an); break; }
            }
        }
    }

    private static void auto(BBModel.Bone b, Settings s, EnumSet<Role> ancestors) {
        EnumSet<Role> here = EnumSet.copyOf(ancestors.isEmpty() ? EnumSet.noneOf(Role.class) : ancestors);
        Role r = Role.guess(b.name);
        if (r != Role.NONE && !here.contains(r)) {
            s.roles.put(b.name, r.name());
            here.add(r);
        }
        for (BBModel.Bone c : b.children) auto(c, s, here);
    }

    public static Active forPlayer(AbstractClientPlayerEntity p) {
        if (MODELS.isEmpty() || CONFIG.assignments.isEmpty()) return null;
        String id = CONFIG.assignments.get(p.getGameProfile().getName().toLowerCase(Locale.ROOT));
        if (id == null && p == MinecraftClient.getInstance().player) id = CONFIG.assignments.get("@self");
        if (id == null) id = CONFIG.assignments.get("*");
        BBModel m = id == null ? null : MODELS.get(id);
        return m == null ? null : new Active(m, settings(m));
    }

    public static BBModel.Anim anim(BBModel m, String name) {
        if (name == null) return null;
        BBModel.Anim a = m.anims.get(name);
        return a != null ? a : LIB.get(name);
    }

    public static List<String> allAnimNames(BBModel m) {
        List<String> l = new ArrayList<>(m.anims.keySet());
        for (String k : LIB.keySet()) if (!m.anims.containsKey(k)) l.add(k);
        return l;
    }

    public static List<String> animsWithCat(BBModel m, Settings s, String cat) {
        List<String> r = new ArrayList<>();
        for (String n : allAnimNames(m)) if (cat.equals(s.animCats.get(n))) r.add(n);
        return r;
    }

    /** Animaciones sin categoria: las que se lanzan con /morphzuka anim <nombre>. */
    public static List<String> commandAnims(BBModel m, Settings s) {
        List<String> r = new ArrayList<>();
        for (String n : allAnimNames(m)) if (!s.animCats.containsKey(n)) r.add(n);
        return r;
    }

    public static Active forSelf() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player == null ? null : forPlayer(mc.player);
    }

    public static void assign(String key, String modelId) {
        if (modelId == null) CONFIG.assignments.remove(key); else CONFIG.assignments.put(key, modelId);
        saveConfig();
    }
}
