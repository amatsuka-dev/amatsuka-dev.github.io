package com.morphzuka;

import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelManager;
import net.minecraft.util.Util;

/** Animacion que el jugador lanza a mano (gesto o comando). Solo afecta a tu propio modelo. */
public final class Gestures {
    private Gestures() {}

    public static String current;
    public static boolean loop;
    private static long startMs;

    public static void play(String anim, boolean loop) {
        current = anim;
        Gestures.loop = loop;
        startMs = Util.getMeasuringTimeMs();
        sliderAnim = null;
    }

    public static String pose;                                   // pose personalizada (se mantiene hasta quitarla)
    public static final java.util.Set<String> toggles = new java.util.LinkedHashSet<>(); // capas toggle activas
    public static String setupModel;                             // modelo para el que ya se lanzo la animacion de inicio

    public static String sliderAnim;   // animacion controlada por slider
    public static float sliderT;       // 0..1

    public static void slider(String anim) { sliderAnim = anim; sliderT = 0f; current = null; }

    public static void stop() { current = null; sliderAnim = null; }

    public static boolean toggle(String anim) { return toggles.add(anim) || !toggles.remove(anim); }

    public static float elapsedSec() { return (Util.getMeasuringTimeMs() - startMs) / 1000f; }

    public static void tick(BBModel m) {
        if (current == null || loop || m == null) return;
        BBModel.Anim a = ModelManager.anim(m, current);
        if (a == null || (a.length > 0 && elapsedSec() > a.length)) current = null;
    }
}
