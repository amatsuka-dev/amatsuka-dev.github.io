package com.morphzuka.mixin;

import com.morphzuka.HitboxOverride;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Hitbox personalizada y altura de ojos (vista del jugador). Solo jugadores del cliente. */
@Mixin(PlayerEntity.class)
public abstract class PlayerDimensionsMixin {

    @Inject(method = "getBaseDimensions", at = @At("RETURN"), cancellable = true, require = 0)
    private void morphzuka$dims(EntityPose pose, CallbackInfoReturnable<EntityDimensions> cir) {
        if (!((Object) this instanceof AbstractClientPlayerEntity p)) return;
        float[] hb = HitboxOverride.get(p);
        if (hb == null) return;
        float w = hb[0], h = hb[1], eye = hb[2];
        if (pose == EntityPose.CROUCHING) { h *= 0.8333f; eye *= 0.8333f; }
        else if (pose != EntityPose.STANDING) return;
        cir.setReturnValue(EntityDimensions.changing(w, h).withEyeHeight(eye));
    }
}
