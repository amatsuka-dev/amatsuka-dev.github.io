# BB Player Models

Mod de Fabric generado con el compilador.

- Minecraft 1.21.1, Fabric Loader 0.16.9, Fabric API 0.115.0+1.21.1
- Java 21, mappings Yarn 1.21.1+build.3

## Compilar

Con Gradle 8.12.1 instalado: `gradle build`. El .jar queda en `build/libs/`.
