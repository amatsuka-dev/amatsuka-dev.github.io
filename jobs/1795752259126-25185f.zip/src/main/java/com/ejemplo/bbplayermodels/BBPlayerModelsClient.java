package com.ejemplo.bbplayermodels;

import net.fabricmc.api.ClientModInitializer;

public class BBPlayerModelsClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		// Código que solo corre en el cliente.
	}
}
