package com.ejemplo.bbplayermodels;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BBPlayerModels implements ModInitializer {
	public static final String MOD_ID = "bbplayermodels";

	// Este logger escribe en la consola y en el registro del juego.
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		LOGGER.info("Hola desde BB Player Models!");
	}
}
