package com.morphzuka.render;

import com.morphzuka.Role;
import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelManager;

/**
 * Puntos de anclaje configurables: donde se dibuja lo que el juego pinta con el esqueleto vanilla (items en la mano,
 * y en el paso 26 armadura, elytras, capa y loros). Cada punto es un {@link ModelManager.Prop} de un tipo especial:
 * se vincula a un grupo (por defecto, el grupo con el rol que le toca) y tiene posicion / rotacion / escala propias,
 * relativas al pivote de ese grupo y a la posicion que tendria en vanilla (todo en 0 = como en vanilla).
 */
public final class Anchors {
    private Anchors() {}

    public static final String HAND_R = "HAND_R", HAND_L = "HAND_L";
    public static final String CAPE = "CAPE", ELYTRA = "ELYTRA", PARROT_R = "PARROT_R", PARROT_L = "PARROT_L";

    /** Los que dibuja el propio juego (capa, elytra, loros): se mueven con un mixin, no con un item. */
    public static final String ARMOR_HEAD = "ARMOR_HEAD", ARMOR_BODY = "ARMOR_BODY", ARMOR_ARM_R = "ARMOR_ARM_R",
            ARMOR_ARM_L = "ARMOR_ARM_L", ARMOR_LEG_R = "ARMOR_LEG_R", ARMOR_LEG_L = "ARMOR_LEG_L";
    /** Piezas de armadura: cada una sigue a un grupo y la dibuja el juego con su propio modelo de armadura. */
    public static final String[] ARMOR = {ARMOR_HEAD, ARMOR_BODY, ARMOR_ARM_R, ARMOR_ARM_L, ARMOR_LEG_R, ARMOR_LEG_L};
    public static final String[] FEATURES = {CAPE, ELYTRA, PARROT_R, PARROT_L, ARMOR_HEAD, ARMOR_BODY, ARMOR_ARM_R, ARMOR_ARM_L, ARMOR_LEG_R, ARMOR_LEG_L};

    /** Orden en el selector del editor. */
    public static final String[] ALL = {HAND_R, HAND_L, CAPE, ELYTRA, PARROT_R, PARROT_L,
            ARMOR_HEAD, ARMOR_BODY, ARMOR_ARM_R, ARMOR_ARM_L, ARMOR_LEG_R, ARMOR_LEG_L};

    public static boolean isAnchor(String kind) {
        for (String k : ALL) if (k.equals(kind)) return true;
        return false;
    }

    public static boolean isFeature(String kind) {
        for (String k : FEATURES) if (k.equals(kind)) return true;
        return false;
    }

    public static boolean isArmor(String kind) {
        for (String k : ARMOR) if (k.equals(kind)) return true;
        return false;
    }

    public static boolean isHand(String kind) { return HAND_R.equals(kind) || HAND_L.equals(kind); }

    /** El punto tiene un id de item / objeto de muestra que se puede cambiar. */
    public static boolean hasRef(String kind) { return isHand(kind); }

    public static String label(String kind) {
        return switch (kind == null ? "" : kind) {
            case HAND_R -> "Mano der";
            case HAND_L -> "Mano izq";
            case CAPE -> "Capa";
            case ELYTRA -> "Elytra";
            case PARROT_R -> "Loro der";
            case PARROT_L -> "Loro izq";
            case ARMOR_HEAD -> "Armadura cabeza";
            case ARMOR_BODY -> "Armadura torso";
            case ARMOR_ARM_R -> "Armadura brazo der";
            case ARMOR_ARM_L -> "Armadura brazo izq";
            case ARMOR_LEG_R -> "Armadura pierna der";
            case ARMOR_LEG_L -> "Armadura pierna izq";
            default -> "Punto";
        };
    }

    /** Rol del grupo al que se vincula por defecto. */
    public static Role role(String kind) {
        return switch (kind == null ? "" : kind) {
            case HAND_R -> Role.RIGHT_ARM;
            case HAND_L -> Role.LEFT_ARM;
            case CAPE, ELYTRA, PARROT_R, PARROT_L, ARMOR_BODY -> Role.BODY;
            case ARMOR_HEAD -> Role.HEAD;
            case ARMOR_ARM_R -> Role.RIGHT_ARM;
            case ARMOR_ARM_L -> Role.LEFT_ARM;
            case ARMOR_LEG_R -> Role.RIGHT_LEG;
            case ARMOR_LEG_L -> Role.LEFT_LEG;
            default -> Role.NONE;
        };
    }

    /** Donde estaria el origen vanilla del punto (px, Y arriba) si el modelo no tiene un grupo con ese rol. */
    public static float[] defaultPivot(String kind) {
        return switch (kind == null ? "" : kind) {
            case HAND_R -> new float[]{5f, 22f, 0f};
            case HAND_L -> new float[]{-5f, 22f, 0f};
            case ARMOR_ARM_R -> new float[]{5f, 22f, 0f};
            case ARMOR_ARM_L -> new float[]{-5f, 22f, 0f};
            case ARMOR_LEG_R -> new float[]{1.9f, 12f, 0f};
            case ARMOR_LEG_L -> new float[]{-1.9f, 12f, 0f};
            default -> new float[]{0f, 24f, 0f};
        };
    }

    public static ModelManager.Prop find(ModelManager.Settings s, String kind) {
        for (ModelManager.Prop p : s.props) if (kind.equals(p.kind)) return p;
        return null;
    }

    /** Primer grupo del modelo con el rol por defecto del punto, o null. */
    public static String defaultBone(BBModel mod, ModelManager.Settings s, String kind) {
        Role want = role(kind);
        if (want == Role.NONE) return null;
        for (BBModel.Bone b : mod.bones.values())
            if (Role.of(s.roles.get(b.name)) == want) return b.name;
        return null;
    }

    /** Grupo donde se dibuja el punto: el que eligio el usuario o, si no, el de su rol; null = con el modelo (en su origen vanilla). */
    public static String boneOf(BBModel mod, ModelManager.Settings s, ModelManager.Prop p, String kind) {
        if (p != null && p.bone != null && mod.bones.containsKey(p.bone)) return p.bone;
        return defaultBone(mod, s, kind);
    }

    /** Igual que {@link #boneOf} para cualquier objeto: los puntos usan su regla, los objetos normales su vinculo. */
    public static String boneOf(BBModel mod, ModelManager.Settings s, ModelManager.Prop p) {
        if (isAnchor(p.kind)) return boneOf(mod, s, p, p.kind);
        return p.bone != null && mod.bones.containsKey(p.bone) ? p.bone : null;
    }
}
