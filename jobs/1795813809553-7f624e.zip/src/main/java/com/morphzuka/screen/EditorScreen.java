package com.morphzuka.screen;

import com.morphzuka.Role;
import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelBounds;
import com.morphzuka.model.ModelManager;
import com.morphzuka.render.BBRenderer;
import com.morphzuka.render.PreviewSim;
import com.morphzuka.render.Physics;
import com.morphzuka.ui.Background;
import com.morphzuka.ui.Gfx;
import net.minecraft.util.Util;
import com.morphzuka.ui.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.RotationAxis;
import org.lwjgl.glfw.GLFW;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Editor 3D de partes: visor orbital del modelo, selector de partes (lista o puntos de pivote en el visor),
 * gizmo para mover / rotar / escalar / mover pivote, y campos XYZ numericos.
 * Todo se guarda en los ajustes del modelo (offsets, rotOffsets, scales, pivots), no modifica el archivo original.
 */
public class EditorScreen extends Screen {

    private enum Mode {
        MOVE("Mover"), ROTATE("Rotar"), SCALE("Escalar"), PIVOT("Pivote");
        final String label;
        Mode(String l) { label = l; }
    }

    private static final int[] AXC = {0xFFE04848, 0xFF58C458, 0xFF4880E0};
    private static final String[] AXN = {"X", "Y", "Z"};
    private static final float[] ZERO3 = {0, 0, 0};
    private static final int ROW = 14;

    private static final class Hit { int x, y, w, h; Runnable r; }

    /** Datos del gizmo para el hueso seleccionado, en coordenadas de pantalla. */
    private static final class Gz {
        float ox, oy;                 // origen en pantalla
        float len;                    // largo de los ejes en unidades del modelo
        final float[][] axis = new float[3][2];     // desplazamiento en pantalla de cada eje (len unidades)
        final float[][] ru = new float[3][2], rv = new float[3][2]; // vectores del aro de rotacion de cada eje
    }

    private record Snap(String bone, float[] off, float[] rot, float[] sc, float[] piv) {}

    private final Screen parent;
    private final BBModel model;
    private final ModelManager.Settings s;
    private String sel;
    private Mode mode = Mode.MOVE;

    private float yaw = 25f, pitch = 12f, zoom = 1f;
    private int vx, vy, vw, vh;       // viewport
    private int mx, my;
    private final List<Hit> hits = new ArrayList<>();
    private final Map<String, float[]> dots = new LinkedHashMap<>();
    private final Deque<Snap> undo = new ArrayDeque<>();
    private int listScroll;
    private String selCube;                                      // bloque elegido (clave hueso#indice)
    private final java.util.Set<String> collapsed = new java.util.HashSet<>();
    private final List<Row> rows = new ArrayList<>();
    private boolean rowsDirty = true;
    private boolean pressMoved;
    private boolean boxMode;
    private final TextFieldWidget[] hb = new TextFieldWidget[4];
    private int[] physSl;            // rectangulo del deslizador de intensidad {x, y, ancho}
    private boolean physDrag;
    private TextFieldWidget uvWf, uvHf;
    // ---- reproductor de animaciones del editor (con transicion)
    private String pvName, pvFrom;
    private boolean pvPlaying = true;
    private float pvTime, pvFromTime, pvBlendT = 1f;
    private long pvLastMs;
    // ---- mapa UV
    private boolean uvMode, uvAll, uvDragging, uvPanning;
    private float uvZoom, uvPanX, uvPanY;
    private String uvTarget;
    private float[] uvStart = new float[2];
    private double uvMx0, uvMy0;
    private double pressX, pressY;
    private record Row(BBModel.Bone bone, BBModel.Cube cube) {}
    private String status = "";

    private TextFieldWidget[] f = new TextFieldWidget[3];
    private boolean syncing;

    // estado de arrastre
    private boolean orbit;
    private int dragAxis = -1;
    private Mode dragMode;
    private double dsx, dsy;
    private float[] startVal;
    private float dax, day, dLen, dGox, dGoy, rotSign, rotLast, rotAcc;

    public EditorScreen(Screen parent, BBModel model, String bone) {
        super(Text.literal("Editor 3D"));
        this.parent = parent;
        this.model = model;
        this.s = ModelManager.settings(model);
        this.sel = bone != null && model.bones.containsKey(bone) ? bone : null;
    }

    // ================================================================ init

    @Override
    protected void init() {
        for (int i = 0; i < 3; i++) {
            final int k = i;
            TextFieldWidget t = new TextFieldWidget(textRenderer, 0, 0, 50, 12, Text.literal(AXN[i]));
            t.setDrawsBackground(false);
            t.setMaxLength(12);
            t.setEditableColor(Theme.c("text"));
            t.setPlaceholder(Text.literal(AXN[i]).formatted(Formatting.DARK_GRAY));
            t.setChangedListener(str -> onField(k, str));
            addDrawableChild(t);
            f[i] = t;
        }
        String[] hn = {"X", "Alto", "Z", "Ojos"};
        for (int i = 0; i < 4; i++) {
            final int k = i;
            hb[i] = uvField(hn[i]);
            hb[i].setMaxLength(6);
            hb[i].setTextPredicate(str -> str.matches("\\d{0,2}(\\.\\d{0,3})?"));
            hb[i].setChangedListener(str -> onHb(k, str));
        }
        uvWf = uvField("W");
        uvHf = uvField("H");
        syncUv();
        pvLastMs = Util.getMeasuringTimeMs();
        syncFields();
    }

    private TextFieldWidget uvField(String ph) {
        TextFieldWidget t = new TextFieldWidget(textRenderer, 0, 0, 40, 12, Text.literal(ph));
        t.setDrawsBackground(false);
        t.setMaxLength(4);
        t.setEditableColor(Theme.c("text"));
        t.setTextPredicate(str -> str.matches("\\d{0,4}"));
        t.setPlaceholder(Text.literal(ph).formatted(Formatting.DARK_GRAY));
        t.setVisible(false);
        addDrawableChild(t);
        return t;
    }

    private void syncUv() {
        if (uvWf == null) return;
        if (!uvWf.isFocused()) uvWf.setText(Integer.toString(effW()));
        if (!uvHf.isFocused()) uvHf.setText(Integer.toString(effH()));
    }

    private void applyUvFields() {
        try {
            int w = Integer.parseInt(uvWf.getText().trim()), h = Integer.parseInt(uvHf.getText().trim());
            if (w < 1 || h < 1) throw new NumberFormatException();
            setFocused(null);
            applyUvRes(w, h);
            uvWf.setText(Integer.toString(effW()));
            uvHf.setText(Integer.toString(effH()));
        } catch (Exception e) { status = "Escribe números válidos (1 a 8192)"; }
    }

    private void onField(int i, String str) {
        if (syncing || sel == null) return;
        try {
            float v = Float.parseFloat(str.trim());
            float[] cur = get(mode, sel).clone();
            cur[i] = v;
            set(mode, sel, cur);
        } catch (Exception ignored) {}
    }

    private void syncFields() {
        syncing = true;
        for (int i = 0; i < 3; i++) f[i].setText(sel == null ? "" : fmt(get(mode, sel)[i]));
        syncing = false;
    }

    // ================================================================ datos

    private float[] get(Mode m, String b) {
        return switch (m) {
            case MOVE -> s.offsets.getOrDefault(b, ZERO3);
            case ROTATE -> s.rotOffsets.getOrDefault(b, ZERO3);
            case SCALE -> s.scales.getOrDefault(b, new float[]{1, 1, 1});
            case PIVOT -> s.pivots.containsKey(b) ? s.pivots.get(b) : model.bones.get(b).pivot;
        };
    }

    private void set(Mode m, String b, float[] v) {
        switch (m) {
            case MOVE -> s.offsets.put(b, v);
            case ROTATE -> s.rotOffsets.put(b, v);
            case SCALE -> s.scales.put(b, v);
            case PIVOT -> s.pivots.put(b, v);
        }
    }

    private float[] pivotOf(BBModel.Bone b) { return s.pivots.containsKey(b.name) ? s.pivots.get(b.name) : b.pivot; }

    private static float[] cp(float[] a) { return a == null ? null : a.clone(); }

    private void snapshot() {
        if (sel == null) return;
        undo.push(new Snap(sel, cp(s.offsets.get(sel)), cp(s.rotOffsets.get(sel)), cp(s.scales.get(sel)), cp(s.pivots.get(sel))));
        if (undo.size() > 60) undo.removeLast();
    }

    private static void put(Map<String, float[]> m, String k, float[] v) { if (v == null) m.remove(k); else m.put(k, v); }

    private void restore() {
        Snap k = undo.poll();
        if (k == null) { status = "Nada que deshacer"; return; }
        put(s.offsets, k.bone(), k.off());
        put(s.rotOffsets, k.bone(), k.rot());
        put(s.scales, k.bone(), k.sc());
        put(s.pivots, k.bone(), k.piv());
        sel = k.bone();
        syncFields();
        status = "Deshecho";
    }

    private void resetBone() {
        if (sel == null) return;
        snapshot();
        s.offsets.remove(sel); s.rotOffsets.remove(sel); s.scales.remove(sel); s.pivots.remove(sel);
        syncFields();
        status = "Parte restaurada";
    }

    private void resetAll() {
        s.offsets.clear(); s.rotOffsets.clear(); s.scales.clear(); s.pivots.clear();
        undo.clear();
        syncFields();
        status = "Todo restaurado";
    }

    private void setRole(Role r) {
        if (sel == null) return;
        if (r == Role.NONE) s.roles.remove(sel); else s.roles.put(sel, r.name());
        status = r == Role.NONE ? "Rol quitado" : "Rol: " + r.label;
    }

    private void select(String name) {
        sel = name;
        selCube = null;
        syncFields();
        scrollToSelection();
    }

    private void selectCube(BBModel.Bone b, BBModel.Cube c) {
        sel = b.name;
        selCube = c.key;
        syncFields();
        for (BBModel.Bone p : pathTo(b.name)) if (collapsed.remove(p.name)) rowsDirty = true;   // abre los grupos plegados
        scrollToSelection();
    }

    private void buildRows() {
        rows.clear();
        for (BBModel.Bone r : model.roots) addRows(r);
        rowsDirty = false;
    }

    private void addRows(BBModel.Bone b) {
        rows.add(new Row(b, null));
        if (collapsed.contains(b.name)) return;
        for (BBModel.Cube c : b.cubes) rows.add(new Row(b, c));
        for (BBModel.Bone ch : b.children) addRows(ch);
    }

    private void scrollToSelection() {
        if (rowsDirty) buildRows();
        int idx = -1;
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            boolean hit = selCube != null ? r.cube() != null && r.cube().key.equals(selCube) : r.cube() == null && r.bone().name.equals(sel);
            if (hit) { idx = i; break; }
        }
        if (idx < 0) return;
        int vr = visibleRows();
        if (idx < listScroll) listScroll = idx;
        else if (idx >= listScroll + vr) listScroll = idx - vr + 1;
    }

    private static String fmt(float v) {
        float r = Math.round(v * 100f) / 100f;
        return r == (long) r ? Long.toString((long) r) : Float.toString(r);
    }

    // ================================================================ matematicas del visor

    private float pxPerBlock() { return zoom * Math.min(vh, vw) / 2.3f; }

    private float scaleK() { return pxPerBlock() * (s.scale <= 0 ? 1f : s.scale) / 16f; } // px de pantalla por unidad del modelo

    /** Matriz modelo(px) -> pantalla. Igual que la cadena de MatrixStack usada al dibujar. */
    private Matrix4f view() {
        float S = pxPerBlock();
        float sc = s.scale <= 0 ? 1f : s.scale;
        return new Matrix4f()
                .translate(vx + vw / 2f, vy + vh / 2f, 0f)
                .scale(S, S, -S)
                .rotateZ((float) Math.PI)
                .rotateX((float) Math.toRadians(pitch))
                .rotateY((float) Math.toRadians(yaw))
                .translate(0f, -1f, 0f)
                .scale(sc / 16f, sc / 16f, sc / 16f);
    }

    /** Aplica la transformacion de un hueso, igual que BBRenderer.bone (sin animacion). */
    private void apply(Matrix4f m, BBModel.Bone b, boolean withScale) {
        float[] piv = pivotOf(b);
        float[] off = s.offsets.getOrDefault(b.name, ZERO3);
        float[] ro = s.rotOffsets.getOrDefault(b.name, ZERO3);
        float[] sc = s.scales.get(b.name);
        m.translate(piv[0] + off[0], piv[1] + off[1], piv[2] + off[2]);
        m.rotateZ((float) Math.toRadians(b.rot[2] + ro[2]));
        m.rotateY((float) Math.toRadians(b.rot[1] + ro[1]));
        m.rotateX((float) Math.toRadians(b.rot[0] + ro[0]));
        if (withScale && sc != null) m.scale(Math.max(0.001f, sc[0]), Math.max(0.001f, sc[1]), Math.max(0.001f, sc[2]));
        m.translate(-piv[0], -piv[1], -piv[2]);
    }

    private List<BBModel.Bone> pathTo(String name) {
        List<BBModel.Bone> out = new ArrayList<>();
        for (BBModel.Bone r : model.roots) if (dfs(r, name, out)) break;
        return out;
    }

    private boolean dfs(BBModel.Bone b, String name, List<BBModel.Bone> out) {
        out.add(b);
        if (b.name.equals(name)) return true;
        for (BBModel.Bone c : b.children) if (dfs(c, name, out)) return true;
        out.remove(out.size() - 1);
        return false;
    }

    private static Vector3f unit(int i) { return new Vector3f(i == 0 ? 1 : 0, i == 1 ? 1 : 0, i == 2 ? 1 : 0); }

    private Gz gizmo() {
        if (sel == null) return null;
        List<BBModel.Bone> p = pathTo(sel);
        if (p.isEmpty()) return null;
        Matrix4f m = view();
        for (int i = 0; i < p.size() - 1; i++) apply(m, p.get(i), true);
        BBModel.Bone b = p.get(p.size() - 1);
        float[] piv = pivotOf(b);
        float[] off = s.offsets.getOrDefault(sel, ZERO3);
        Vector3f o = m.transformPosition(new Vector3f(piv[0] + off[0], piv[1] + off[1], piv[2] + off[2]));
        Gz g = new Gz();
        g.ox = o.x;
        g.oy = o.y;
        float k = Math.max(0.0001f, scaleK());
        g.len = 70f / k;
        float ring = 55f / k;
        Matrix4f dm = m;
        if (mode == Mode.SCALE) { dm = new Matrix4f(m); apply(dm, b, false); }
        for (int i = 0; i < 3; i++) {
            Vector3f d = dm.transformDirection(unit(i), new Vector3f());
            g.axis[i][0] = d.x * g.len;
            g.axis[i][1] = d.y * g.len;
            Vector3f u = m.transformDirection(unit((i + 1) % 3), new Vector3f());
            Vector3f v = m.transformDirection(unit((i + 2) % 3), new Vector3f());
            g.ru[i][0] = u.x * ring; g.ru[i][1] = u.y * ring;
            g.rv[i][0] = v.x * ring; g.rv[i][1] = v.y * ring;
        }
        return g;
    }

    private void collectDots(BBModel.Bone b, Matrix4f parentM) {
        float[] piv = pivotOf(b);
        float[] off = s.offsets.getOrDefault(b.name, ZERO3);
        Vector3f v = parentM.transformPosition(new Vector3f(piv[0] + off[0], piv[1] + off[1], piv[2] + off[2]));
        dots.put(b.name, new float[]{v.x, v.y});
        Matrix4f m = new Matrix4f(parentM);
        apply(m, b, true);
        for (BBModel.Bone c : b.children) collectDots(c, m);
    }

    private static double segDist(double px, double py, double ax, double ay, double bx, double by) {
        double dx = bx - ax, dy = by - ay;
        double l2 = dx * dx + dy * dy;
        double t = l2 < 1e-6 ? 0 : Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / l2));
        double cx = ax + t * dx, cy = ay + t * dy;
        return Math.hypot(px - cx, py - cy);
    }

    private static final int RING_N = 36;

    private float[] ringPoint(Gz g, int i, int n) {
        double a = Math.PI * 2 * n / RING_N;
        float c = (float) Math.cos(a), sn = (float) Math.sin(a);
        return new float[]{g.ox + g.ru[i][0] * c + g.rv[i][0] * sn, g.oy + g.ru[i][1] * c + g.rv[i][1] * sn};
    }

    /** 0..2 = eje, 3 = escala uniforme, -1 = nada. */
    private int pick(Gz g, double x, double y) {
        double best = 7;
        int res = -1;
        if (mode == Mode.ROTATE) {
            for (int i = 0; i < 3; i++) {
                float[] prev = ringPoint(g, i, 0);
                for (int n = 1; n <= RING_N; n++) {
                    float[] cur = ringPoint(g, i, n);
                    double d = segDist(x, y, prev[0], prev[1], cur[0], cur[1]);
                    if (d < best) { best = d; res = i; }
                    prev = cur;
                }
            }
            return res;
        }
        if (mode == Mode.SCALE && Math.hypot(x - g.ox, y - g.oy) < 8) return 3;
        for (int i = 0; i < 3; i++) {
            double d = Math.min(segDist(x, y, g.ox, g.oy, g.ox + g.axis[i][0], g.oy + g.axis[i][1]),
                    Math.hypot(x - (g.ox + g.axis[i][0]), y - (g.oy + g.axis[i][1])) - 2);
            if (d < best) { best = d; res = i; }
        }
        return res;
    }

    // ================================================================ dibujo

    private static void rr(DrawContext g, int x, int y, int w, int h, int r, int c) { Gfx.rr(g, x, y, w, h, r, c); }

    private void line(DrawContext g, float x0, float y0, float x1, float y1, int c, int t) { Gfx.line(g, x0, y0, x1, y1, t, c); }

    private boolean over(int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    private void hit(int x, int y, int w, int h, Runnable r) {
        Hit t = new Hit();
        t.x = x; t.y = y; t.w = w; t.h = h; t.r = r;
        hits.add(t);
    }

    private void button(DrawContext g, int x, int y, int w, String label, boolean primary, boolean on, Runnable r) {
        boolean hov = over(x, y, w, 18);
        int bg = on ? Theme.c("primary") : primary ? Theme.c("pill") : hov ? Theme.c("surfaceHi") : Theme.c("surface");
        rr(g, x, y, w, 18, 9, bg);
        int tc = on ? Theme.c("onPrimary") : Theme.c("text");
        g.drawText(textRenderer, label, x + w / 2 - textRenderer.getWidth(label) / 2, y + 5, tc, false);
        hit(x, y, w, 18, r);
    }

    private int visibleRows() { return Math.max(1, (height - 16 - 36) / ROW); }

    @Override
    public void render(DrawContext g, int mouseX, int mouseY, float delta) {
        mx = mouseX;
        my = mouseY;
        hits.clear();
        advancePv();
        physSl = null;
        if (s.physicsOn) Physics.stepPreview(s, Math.min(0.1f, delta / 20f), s.physBones);
        uvWf.setVisible(false);
        uvHf.setVisible(false);
        for (TextFieldWidget t : hb) t.setVisible(false);
        int panel = Theme.c("panel"), text = Theme.c("text"), muted = Theme.c("muted"), prim = Theme.c("primary");

        Gfx.fill(g, 0, 0, width, height, 0xFF0B0808);
        Background.draw(g, width, height);

        int lx = 8, lw = 176, rw = 186, rx = width - 8 - rw;
        vx = lx + lw + 8;
        vw = Math.max(40, rx - 8 - vx);
        vy = 8;
        vh = height - 16;

        // ---------------------------------------------------- panel izquierdo: grupos y bloques con sus nombres originales
        rr(g, lx, 8, lw, height - 16, 10, panel);
        g.drawText(textRenderer, Text.literal("Partes").formatted(Formatting.BOLD), lx + 10, 15, text, false);
        int cbx = lx + lw - 10 - 30;
        button(g, cbx, 11, 14, "-", false, false, () -> { for (BBModel.Bone bb : model.bones.values()) if (!bb.children.isEmpty() || !bb.cubes.isEmpty()) collapsed.add(bb.name); rowsDirty = true; });
        button(g, cbx + 16, 11, 14, "+", false, false, () -> { collapsed.clear(); rowsDirty = true; });
        if (rowsDirty) buildRows();
        int vr = visibleRows();
        listScroll = Math.max(0, Math.min(Math.max(0, rows.size() - vr), listScroll));
        int ly = 34;
        for (int r = 0; r < vr && listScroll + r < rows.size(); r++) {
            Row row = rows.get(listScroll + r);
            BBModel.Bone b = row.bone();
            int ry = ly + r * ROW;
            boolean isCube = row.cube() != null;
            boolean on = isCube ? row.cube().key.equals(selCube) : (selCube == null && b.name.equals(sel));
            if (on) rr(g, lx + 4, ry, lw - 8, ROW - 1, 6, Theme.c("pill"));
            else if (over(lx + 4, ry, lw - 8, ROW - 1)) rr(g, lx + 4, ry, lw - 8, ROW - 1, 6, Theme.c("line"));
            int indent = (isCube ? b.depth + 1 : b.depth) * 6;
            if (isCube) {
                String lab = textRenderer.trimToWidth(ModelManager.cubeLabel(s, row.cube()), lw - 26 - indent);
                g.drawText(textRenderer, lab, lx + 16 + indent, ry + 3, on ? prim : muted, false);
                final BBModel.Bone bb = b;
                final BBModel.Cube cc = row.cube();
                hit(lx + 4, ry, lw - 8, ROW - 1, () -> selectCube(bb, cc));
            } else {
                boolean has = !b.children.isEmpty() || !b.cubes.isEmpty();
                final String nn = b.name;
                if (has) {
                    g.drawText(textRenderer, collapsed.contains(b.name) ? "+" : "-", lx + 8 + indent, ry + 3, muted, false);
                }
                boolean hid = s.hidden.contains(b.name);
                Role role = Role.of(s.roles.get(b.name));
                String lab = textRenderer.trimToWidth((hid ? "(x) " : "") + ModelManager.boneLabel(s, b) + (role == Role.NONE ? "" : " [" + role.label + "]"), lw - 28 - indent);
                g.drawText(textRenderer, lab, lx + 16 + indent, ry + 3, hid ? muted : (on || nn.equals(sel)) ? prim : role != Role.NONE ? prim : text, false);
                hit(lx + 16 + indent, ry, lw - 24 - indent, ROW - 1, () -> select(nn));
                if (has) hit(lx + 4 + indent, ry, 12, ROW - 1, () -> { if (!collapsed.remove(nn)) collapsed.add(nn); rowsDirty = true; });
            }
        }
        if (rows.size() > vr) {
            int area = vr * ROW;
            int th = Math.max(12, area * vr / rows.size());
            int ty = ly + (area - th) * listScroll / Math.max(1, rows.size() - vr);
            rr(g, lx + lw - 6, ty, 2, th, 1, 0x80E8C2BA);
        }

        // ---------------------------------------------------- viewport 3D
        rr(g, vx, vy, vw, vh, 10, 0x50000000);
        g.enableScissor(vx, vy, vx + vw, vy + vh);
        if (uvMode) drawUv(g); else {

        // suelo (rejilla 8 px del modelo, de -24 a 24)
        Matrix4f V = view();
        int gridCol = 0x28FFFFFF;
        for (int i = -24; i <= 24; i += 8) {
            Vector3f a = V.transformPosition(new Vector3f(i, 0, -24)), b = V.transformPosition(new Vector3f(i, 0, 24));
            line(g, a.x, a.y, b.x, b.y, i == 0 ? 0x50FFFFFF : gridCol, 1);
            Vector3f c = V.transformPosition(new Vector3f(-24, 0, i)), d = V.transformPosition(new Vector3f(24, 0, i));
            line(g, c.x, c.y, d.x, d.y, i == 0 ? 0x50FFFFFF : gridCol, 1);
        }

        // modelo
        MatrixStack ms = g.getMatrices();
        ms.push();
        float S = pxPerBlock();
        ms.translate(vx + vw / 2f, vy + vh / 2f, 150f);
        ms.scale(S, S, -S);
        ms.multiply(new Quaternionf().rotationZ((float) Math.PI));
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));
        ms.translate(0f, -1f, 0f);
        BBRenderer.renderPreview(model, s, ms, g.getVertexConsumers(), 15728880, sel, selCube, PreviewSim.active, buildPv());
        ms.pop();
        g.draw();

        // superposicion (por delante del modelo)
        ms.push();
        ms.translate(0f, 0f, 400f);
        dots.clear();
        for (BBModel.Bone r : model.roots) collectDots(r, V);
        for (Map.Entry<String, float[]> e : dots.entrySet()) {
            if (e.getKey().equals(sel)) continue;
            int x = Math.round(e.getValue()[0]), y = Math.round(e.getValue()[1]);
            boolean hv = Math.hypot(mx - x, my - y) < 7;
            Gfx.fill(g, x - 2, y - 2, x + 3, y + 3, hv ? 0xFFFFFFFF : 0xA0E8C2BA);
        }
        Gz gz = gizmo();
        if (gz != null) drawGizmo(g, gz);
        if (boxMode) drawHitbox(g);
        g.drawText(textRenderer, trimTo("Arrastra en vacío: orbitar   Rueda: zoom   Clic en un punto: elegir parte", vw - 20), vx + 10, vy + vh - 14, muted, false);
        drawAnimBar(g);
        if (boxMode) drawBoxBar(g); else drawPhysBar(g);
        button(g, vx + vw - 96, vy + 30, 88, boxMode ? "Ocultar hitbox" : "Hitbox", false, boxMode, () -> { boxMode = !boxMode; setFocused(null); });
        ms.pop();
        }
        button(g, vx + vw - 96, vy + 8, 88, uvMode ? "Ver modelo" : "Mapa UV", false, uvMode, () -> { uvMode = !uvMode; uvDragging = false; uvPanning = false; setFocused(null); });
        g.disableScissor();

        // ---------------------------------------------------- panel derecho
        rr(g, rx, 8, rw, height - 16, 10, panel);
        int px = rx + 10, pw = rw - 20, y = 15;
        g.drawText(textRenderer, Text.literal("Editor 3D").formatted(Formatting.BOLD), px, y, text, false);
        y += 14;
        BBModel.Bone sb = sel == null ? null : model.bones.get(sel);
        g.drawText(textRenderer, textRenderer.trimToWidth(sb == null ? "Haz clic en el modelo" : ModelManager.boneLabel(s, sb), pw), px, y, sb == null ? muted : prim, false);
        y += 11;
        if (selCube != null) {
            String cn = "";
            for (BBModel.Cube cc : sb.cubes) if (cc.key.equals(selCube)) cn = ModelManager.cubeLabel(s, cc);
            g.drawText(textRenderer, textRenderer.trimToWidth("bloque: " + cn, pw), px, y, text, false);
        } else if (sb != null) {
            g.drawText(textRenderer, textRenderer.trimToWidth(sb.cubes.size() + " bloques, " + sb.children.size() + " subgrupos", pw), px, y, muted, false);
        }
        y += 12;
        if (sb != null) {   // rol: qué parte del cuerpo es este grupo
            Role cur = Role.of(s.roles.get(sel));
            Role[] rs = Role.values();
            int ri = cur.ordinal();
            button(g, px, y, 18, "<", false, false, () -> setRole(rs[(ri + rs.length - 1) % rs.length]));
            button(g, px + pw - 18, y, 18, ">", false, false, () -> setRole(rs[(ri + 1) % rs.length]));
            String rl = "Rol: " + (cur == Role.NONE ? "ninguno" : cur.label);
            rr(g, px + 20, y, pw - 40, 18, 9, cur == Role.NONE ? Theme.c("surface") : Theme.c("primary"));
            g.drawText(textRenderer, textRenderer.trimToWidth(rl, pw - 46), px + 20 + (pw - 40) / 2 - textRenderer.getWidth(textRenderer.trimToWidth(rl, pw - 46)) / 2, y + 5, cur == Role.NONE ? text : Theme.c("onPrimary"), false);
        }
        y += 24;
        int cw = (pw - 4) / 2;
        Mode[] ms2 = Mode.values();
        for (int i = 0; i < 4; i++) {
            final Mode mm = ms2[i];
            button(g, px + (i % 2) * (cw + 4), y + (i / 2) * 22, cw, mm.label, false, mode == mm, () -> { mode = mm; syncFields(); });
        }
        y += 50;
        String unit = switch (mode) { case MOVE -> "Posición X Y Z (px)"; case ROTATE -> "Rotación extra X Y Z (°)"; case SCALE -> "Escala X Y Z"; case PIVOT -> "Pivote X Y Z (px)"; };
        g.drawText(textRenderer, unit, px, y, muted, false);
        y += 11;
        int fw = (pw - 8) / 3;
        for (int i = 0; i < 3; i++) {
            int fx = px + i * (fw + 4);
            rr(g, fx, y, fw, 18, 5, Theme.c("surface"));
            Gfx.fill(g, fx + 1, y + 17, fx + fw - 1, y + 18, f[i].isFocused() ? prim : 0x90E8C2BA);
            Gfx.fill(g, fx, y, fx + 2, y + 18, AXC[i]);
            f[i].setX(fx + 7);
            f[i].setY(y + 5);
            f[i].setWidth(fw - 10);
        }
        y += 28;
        button(g, px, y, pw, "Restaurar parte", false, false, this::resetBone);
        y += 22;
        boolean hid = sel != null && s.hidden.contains(sel);
        button(g, px, y, pw, hid ? "Mostrar parte" : "Ocultar parte", false, false, () -> {
            if (sel == null) return;
            if (!s.hidden.remove(sel)) s.hidden.add(sel);
        });
        y += 22;
        button(g, px, y, cw, "Deshacer", false, false, this::restore);
        button(g, px + cw + 4, y, cw, "Restaurar todo", false, false, this::resetAll);
        y += 22;
        button(g, px, y, pw, "Centrar vista", false, false, () -> { yaw = 25f; pitch = 12f; zoom = 1f; });
        y += 22;
        button(g, px, y, pw, PreviewSim.active ? "Detener simulación" : "Simular ataque y cabeza", false, PreviewSim.active, PreviewSim::toggle);
        y += 30;
        if (!status.isEmpty()) g.drawText(textRenderer, textRenderer.trimToWidth(status, pw), px, y, prim, false);
        button(g, px, height - 8 - 10 - 18, pw, "Guardar y cerrar", true, false, this::close);

        for (TextFieldWidget t : f) t.render(g, mouseX, mouseY, delta);
        if (uvMode) { uvWf.render(g, mouseX, mouseY, delta); uvHf.render(g, mouseX, mouseY, delta); }
        for (TextFieldWidget t : hb) t.render(g, mouseX, mouseY, delta);
    }

    private void drawGizmo(DrawContext g, Gz gz) {
        int hov = (dragAxis >= 0) ? dragAxis : pick(gz, mx, my);
        float ox = gz.ox, oy = gz.oy;
        if (mode == Mode.ROTATE) {
            for (int i = 0; i < 3; i++) {
                boolean h = hov == i;
                float[] prev = ringPoint(gz, i, 0);
                for (int n = 1; n <= RING_N; n++) {
                    float[] cur = ringPoint(gz, i, n);
                    line(g, prev[0], prev[1], cur[0], cur[1], h ? 0xFFFFFFFF : AXC[i], h ? 3 : 2);
                    prev = cur;
                }
            }
            Gfx.fill(g, Math.round(ox) - 2, Math.round(oy) - 2, Math.round(ox) + 3, Math.round(oy) + 3, 0xFFFFFFFF);
            return;
        }
        for (int i = 0; i < 3; i++) {
            boolean h = hov == i;
            float tx = ox + gz.axis[i][0], ty = oy + gz.axis[i][1];
            int col = h ? 0xFFFFFFFF : AXC[i];
            line(g, ox, oy, tx, ty, col, h ? 3 : 2);
            int cx = Math.round(tx), cy = Math.round(ty);
            switch (mode) {
                case SCALE -> Gfx.fill(g, cx - 4, cy - 4, cx + 5, cy + 5, col);
                case PIVOT -> { for (int k = 0; k < 5; k++) Gfx.fill(g, cx - 4 + k, cy - k, cx + 5 - k, cy - k + 1, col); for (int k = 1; k < 5; k++) Gfx.fill(g, cx - 4 + k, cy + k, cx + 5 - k, cy + k + 1, col); }
                default -> rr(g, cx - 4, cy - 4, 9, 9, 4, col);
            }
            g.drawText(textRenderer, AXN[i], cx + 6, cy - 4, AXC[i], false);
        }
        int cc = hov == 3 ? 0xFFFFFFFF : 0xFFE8E8E8;
        if (mode == Mode.SCALE) Gfx.fill(g, Math.round(ox) - 4, Math.round(oy) - 4, Math.round(ox) + 5, Math.round(oy) + 5, cc);
        else rr(g, Math.round(ox) - 3, Math.round(oy) - 3, 7, 7, 3, cc);
    }

    // ================================================================ entrada

    private boolean inViewport(double x, double y) { return x >= vx && x < vx + vw && y >= vy && y < vy + vh; }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        if (button == 0 && physSl != null && x >= physSl[0] - 4 && x <= physSl[0] + physSl[2] + 4 && y >= physSl[1] && y < physSl[1] + 16) {
            physDrag = true;
            setPhysFromX(x);
            return true;
        }
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (x >= h.x && x < h.x + h.w && y >= h.y && y < h.y + h.h) {
                setFocused(null);
                if (button == 0) h.r.run();
                return true;
            }
        }
        if (inViewport(x, y)) {
            setFocused(null);
            if (uvMode) {
                if (button == 0) {
                    BBModel.Bone[] ob = new BBModel.Bone[1];
                    BBModel.Cube c = uvPickAt(x, y, ob);
                    if (c != null) {
                        if (!c.key.equals(selCube)) selectCube(ob[0], c);
                        uvDragging = true;
                        uvTarget = c.key;
                        float[] sh0 = s.uvShift.get(c.key);
                        uvStart = sh0 == null ? new float[2] : sh0.clone();
                        uvMx0 = x;
                        uvMy0 = y;
                        return true;
                    }
                }
                uvPanning = true;
                return true;
            }
            if (button == 0 && sel != null) {
                Gz gz = gizmo();
                int h = gz == null ? -1 : pick(gz, x, y);
                if (h >= 0) { startDrag(gz, h, x, y); return true; }
            }
            pressX = x;
            pressY = y;
            pressMoved = false;
            orbit = true;
            return true;
        }
        return super.mouseClicked(x, y, button);
    }

    // ---- seleccion por clic sobre el modelo: proyecta las 6 caras de cada bloque y elige la mas cercana a la camara

    private static final int[][] FACE_IDX = {{0, 2, 6, 4}, {1, 3, 7, 5}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 1, 3, 2}, {4, 5, 7, 6}};
    private static final Vector3f[] CORN = new Vector3f[8];
    static { for (int i = 0; i < 8; i++) CORN[i] = new Vector3f(); }
    private float bestZ;
    private BBModel.Bone bestBone;
    private BBModel.Cube bestCube;

    private static boolean inTri(double px, double py, Vector3f a, Vector3f b, Vector3f c) {
        double d1 = (px - b.x) * (a.y - b.y) - (a.x - b.x) * (py - b.y);
        double d2 = (px - c.x) * (b.y - c.y) - (b.x - c.x) * (py - c.y);
        double d3 = (px - a.x) * (c.y - a.y) - (c.x - a.x) * (py - a.y);
        boolean neg = d1 < 0 || d2 < 0 || d3 < 0, pos = d1 > 0 || d2 > 0 || d3 > 0;
        return !(neg && pos);
    }

    private void clickSelect(double x, double y) {
        String near = null;                               // punto de pivote muy cerca: tiene prioridad
        double bd = 5;
        for (Map.Entry<String, float[]> e : dots.entrySet()) {
            double d = Math.hypot(x - e.getValue()[0], y - e.getValue()[1]);
            if (d < bd) { bd = d; near = e.getKey(); }
        }
        if (near != null) { select(near); return; }
        bestZ = -Float.MAX_VALUE;
        bestBone = null;
        bestCube = null;
        Matrix4f base = view();
        for (BBModel.Bone r : model.roots) pickWalk(r, base, x, y);
        if (bestCube != null) { selectCube(bestBone, bestCube); return; }
        bd = 9;
        for (Map.Entry<String, float[]> e : dots.entrySet()) {
            double d = Math.hypot(x - e.getValue()[0], y - e.getValue()[1]);
            if (d < bd) { bd = d; near = e.getKey(); }
        }
        if (near != null) select(near);
    }

    private void pickWalk(BBModel.Bone b, Matrix4f parent, double px, double py) {
        Matrix4f m = new Matrix4f(parent);
        apply(m, b, true);
        if (b.visible && !s.hidden.contains(b.name)) {
            for (BBModel.Cube c : b.cubes) {
                Matrix4f cm = new Matrix4f(m);
                if (c.rot[0] != 0 || c.rot[1] != 0 || c.rot[2] != 0) {
                    cm.translate(c.origin[0], c.origin[1], c.origin[2]);
                    cm.rotateZ((float) Math.toRadians(c.rot[2]));
                    cm.rotateY((float) Math.toRadians(c.rot[1]));
                    cm.rotateX((float) Math.toRadians(c.rot[0]));
                    cm.translate(-c.origin[0], -c.origin[1], -c.origin[2]);
                }
                float i = c.inflate;
                for (int k = 0; k < 8; k++) {
                    CORN[k].set((k & 1) == 0 ? c.from[0] - i : c.to[0] + i, (k & 2) == 0 ? c.from[1] - i : c.to[1] + i, (k & 4) == 0 ? c.from[2] - i : c.to[2] + i);
                    cm.transformPosition(CORN[k]);
                }
                for (int[] fi : FACE_IDX) {
                    Vector3f a = CORN[fi[0]], bb = CORN[fi[1]], cc = CORN[fi[2]], d = CORN[fi[3]];
                    if (inTri(px, py, a, bb, cc) || inTri(px, py, a, cc, d)) {
                        float z = (a.z + bb.z + cc.z + d.z) / 4f;     // en el GUI, z mayor = mas cerca de la camara
                        if (z > bestZ) { bestZ = z; bestBone = b; bestCube = c; }
                    }
                }
            }
        }
        for (BBModel.Bone ch : b.children) pickWalk(ch, m, px, py);
    }

    private void startDrag(Gz gz, int h, double x, double y) {
        snapshot();
        dragAxis = h;
        dragMode = mode;
        dsx = x;
        dsy = y;
        startVal = get(mode, sel).clone();
        dLen = gz.len;
        dGox = gz.ox;
        dGoy = gz.oy;
        if (h < 3) {
            dax = gz.axis[h][0];
            day = gz.axis[h][1];
            if (mode == Mode.ROTATE) {
                float cross = gz.ru[h][0] * gz.rv[h][1] - gz.ru[h][1] * gz.rv[h][0];
                rotSign = cross >= 0 ? 1f : -1f;
                rotLast = (float) Math.toDegrees(Math.atan2(y - dGoy, x - dGox));
                rotAcc = 0f;
            }
        }
    }

    private static float r2(float v) { return Math.round(v * 100f) / 100f; }

    private void updateDrag(double x, double y) {
        double mdx = x - dsx, mdy = y - dsy;
        float[] v = startVal.clone();
        int a = dragAxis;
        switch (dragMode) {
            case MOVE, PIVOT -> {
                float la2 = dax * dax + day * day;
                if (la2 < 16f) return; // eje casi de frente a la camara: gira la vista
                v[a] = r2(startVal[a] + (float) ((mdx * dax + mdy * day) / la2) * dLen);
            }
            case SCALE -> {
                if (a == 3) {
                    float fct = Math.max(0.01f, 1f + (float) mdx / 90f);
                    for (int i = 0; i < 3; i++) v[i] = r2(startVal[i] * fct);
                } else {
                    float la = (float) Math.hypot(dax, day);
                    if (la < 4f) return;
                    float t = (float) ((mdx * dax + mdy * day) / la);
                    v[a] = r2(startVal[a] * Math.max(0.01f, 1f + t / la));
                }
            }
            case ROTATE -> {
                float ang = (float) Math.toDegrees(Math.atan2(y - dGoy, x - dGox));
                float dd = ang - rotLast;
                while (dd > 180f) dd -= 360f;
                while (dd < -180f) dd += 360f;
                rotAcc += dd;
                rotLast = ang;
                v[a] = r2(startVal[a] + rotSign * rotAcc);
            }
        }
        set(dragMode, sel, v);
        syncFields();
    }

    @Override
    public boolean mouseDragged(double x, double y, int button, double dx, double dy) {
        if (physDrag) { setPhysFromX(x); return true; }
        if (Math.abs(x - pressX) > 3 || Math.abs(y - pressY) > 3) pressMoved = true;
        if (uvDragging && uvTarget != null) {
            float z = uvZ();
            setShift(uvTarget, uvStart[0] + Math.round((x - uvMx0) / z), uvStart[1] + Math.round((y - uvMy0) / z));
            return true;
        }
        if (uvPanning) { uvPanX += (float) dx; uvPanY += (float) dy; return true; }
        if (dragAxis >= 0 && sel != null) { updateDrag(x, y); return true; }
        if (orbit) {
            yaw += (float) dx * 0.6f;
            pitch = Math.max(-89f, Math.min(89f, pitch + (float) dy * 0.5f));
            return true;
        }
        return super.mouseDragged(x, y, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double x, double y, int button) {
        if (orbit && !pressMoved && button == 0 && inViewport(x, y)) clickSelect(x, y);
        dragAxis = -1;
        physDrag = false;
        orbit = false;
        uvDragging = false;
        uvPanning = false;
        return super.mouseReleased(x, y, button);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double hAmount, double vAmount) {
        if (inViewport(x, y)) {
            if (uvMode) uvZoom = Math.max(0.5f, Math.min(64f, uvZ() * (vAmount > 0 ? 1.15f : 1f / 1.15f)));
            else zoom = Math.max(0.3f, Math.min(4f, zoom * (vAmount > 0 ? 1.1f : 1f / 1.1f)));
            return true;
        }
        if (x < vx) {
            listScroll -= (int) Math.signum(vAmount) * 3;
            return true;
        }
        return super.mouseScrolled(x, y, hAmount, vAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        boolean typing = getFocused() instanceof TextFieldWidget tf && tf.isFocused();
        if (typing && uvMode && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) && (uvWf.isFocused() || uvHf.isFocused())) { applyUvFields(); return true; }
        if (!typing && uvMode && selCube != null) {      // flechas: mover el UV del bloque 1 px (Mayus = 8)
            int step = (modifiers & GLFW.GLFW_MOD_SHIFT) != 0 ? 8 : 1;
            int dx = keyCode == GLFW.GLFW_KEY_LEFT ? -step : keyCode == GLFW.GLFW_KEY_RIGHT ? step : 0;
            int dy = keyCode == GLFW.GLFW_KEY_UP ? -step : keyCode == GLFW.GLFW_KEY_DOWN ? step : 0;
            if (dx != 0 || dy != 0) {
                float[] sh = s.uvShift.get(selCube);
                setShift(selCube, (sh == null ? 0 : sh[0]) + dx, (sh == null ? 0 : sh[1]) + dy);
                return true;
            }
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    // ================================================================ mapa UV

    private int effW() { return BBRenderer.uvW(model, s); }

    private int effH() { return BBRenderer.uvH(model, s); }

    private float uvZ() {
        if (uvZoom > 0f) return uvZoom;
        return Math.max(0.5f, Math.min((vw - 24f) / effW(), (vh - 150f) / effH()));
    }

    private List<BBModel.Bone> uvScope() {
        List<BBModel.Bone> l = new ArrayList<>();
        BBModel.Bone sb = sel == null ? null : model.bones.get(sel);
        if (uvAll || sb == null) l.addAll(model.bones.values()); else l.add(sb);
        return l;
    }

    private void setShift(String key, float du, float dv) {
        if (du == 0f && dv == 0f) s.uvShift.remove(key); else s.uvShift.put(key, new float[]{du, dv});
    }

    private void applyUvRes(int w, int h) {
        w = Math.max(1, Math.min(8192, w));
        h = Math.max(1, Math.min(8192, h));
        if (s.uvKeep) {                                   // los desplazamientos siguen en la misma posicion visual
            float rx2 = w / (float) effW(), ry2 = h / (float) effH();
            for (Map.Entry<String, float[]> e : s.uvShift.entrySet()) {
                float[] v = e.getValue();
                e.setValue(new float[]{Math.round(v[0] * rx2), Math.round(v[1] * ry2)});
            }
        }
        if (w == model.texW && h == model.texH) { s.uvW = 0; s.uvH = 0; } else { s.uvW = w; s.uvH = h; }
        status = "Resolución UV: " + w + " x " + h;
    }

    private BBModel.Cube uvPickAt(double px, double py, BBModel.Bone[] outBone) {
        int W = effW(), H = effH();
        float z = uvZ();
        float kx = BBRenderer.uvKx(model, s), ky = BBRenderer.uvKy(model, s);
        float ox = vx + vw / 2f + uvPanX - W * z / 2f, oy = vy + vh / 2f + 41 + uvPanY - H * z / 2f;
        float u = (float) ((px - ox) / z), v = (float) ((py - oy) / z);
        float[] r = new float[4];
        BBModel.Cube found = null;
        BBModel.Bone fb = null;
        for (BBModel.Bone b : uvScope()) {
            for (BBModel.Cube c : b.cubes) {
                float[] sh = s.uvShift.get(c.key);
                for (int d = 0; d < 6; d++) {
                    if (!BBRenderer.uvRect(c, d, kx, ky, sh, r)) continue;
                    if (u >= Math.min(r[0], r[2]) && u <= Math.max(r[0], r[2]) && v >= Math.min(r[1], r[3]) && v <= Math.max(r[1], r[3])) {
                        if (c.key.equals(selCube)) { outBone[0] = b; return c; }   // el ya elegido tiene prioridad
                        found = c;
                        fb = b;
                    }
                }
            }
        }
        outBone[0] = fb;
        return found;
    }

    private void drawUv(DrawContext g) {
        int muted = Theme.c("muted"), text = Theme.c("text");
        int W = effW(), H = effH();
        float z = uvZ();
        float kx = BBRenderer.uvKx(model, s), ky = BBRenderer.uvKy(model, s);
        int ox = Math.round(vx + vw / 2f + uvPanX - W * z / 2f), oy = Math.round(vy + vh / 2f + 41 + uvPanY - H * z / 2f);
        int pw = Math.round(W * z), ph = Math.round(H * z);
        Gfx.fill(g, ox, oy, ox + pw, oy + ph, 0xFF1A1514);
        g.draw();
        int iw = Math.max(1, model.imgW), ih = Math.max(1, model.imgH);
        g.drawTexture(model.texture, ox, oy, pw, ph, 0f, 0f, iw, ih, iw, ih);
        g.draw();
        if (z >= 4f) {                                    // cuadricula por pixel UV
            int step = z >= 10f ? 1 : z >= 6f ? 2 : 4;
            for (int i = 0; i <= W; i += step) Gfx.fill(g, ox + Math.round(i * z), oy, ox + Math.round(i * z) + 1, oy + ph, i % 8 == 0 ? 0x30FFFFFF : 0x14FFFFFF);
            for (int j = 0; j <= H; j += step) Gfx.fill(g, ox, oy + Math.round(j * z), ox + pw, oy + Math.round(j * z) + 1, j % 8 == 0 ? 0x30FFFFFF : 0x14FFFFFF);
        }
        Gfx.box(g, ox - 1, oy - 1, ox + pw + 1, oy + ph + 1, 0xA0E8C2BA);

        float[] r = new float[4];
        for (BBModel.Bone b : uvScope()) {
            boolean inBone = b.name.equals(sel);
            for (BBModel.Cube c : b.cubes) {
                boolean isSel = c.key.equals(selCube);
                float[] sh = s.uvShift.get(c.key);
                for (int d = 0; d < 6; d++) {
                    if (!BBRenderer.uvRect(c, d, kx, ky, sh, r)) continue;
                    int x1 = ox + Math.round(Math.min(r[0], r[2]) * z), x2 = ox + Math.round(Math.max(r[0], r[2]) * z);
                    int y1 = oy + Math.round(Math.min(r[1], r[3]) * z), y2 = oy + Math.round(Math.max(r[1], r[3]) * z);
                    if (x2 <= x1) x2 = x1 + 1;
                    if (y2 <= y1) y2 = y1 + 1;
                    if (isSel) Gfx.fill(g, x1, y1, x2, y2, 0x30FFA040);
                    Gfx.box(g, x1, y1, x2, y2, isSel ? 0xFFFFA040 : inBone ? 0xC04CF0FF : 0x60FFFFFF);
                }
            }
        }

        // barra de controles (arriba del mapa)
        g.drawText(textRenderer, trimTo(W + " x " + H + " px   zoom " + fmt(z) + "x   imagen " + model.imgW + "x" + model.imgH + "   archivo " + model.texW + "x" + model.texH, vw - 110), vx + 10, vy + 12, muted, false);
        int bx = vx + 8, by = vy + 28;
        int[] pres = {16, 32, 64, 128, 256};
        syncUv();
        for (int p : pres) {
            String lab = p + "x" + p;
            int bw = textRenderer.getWidth(lab) + 12;
            boolean cur = W == p && H == p;
            button(g, bx, by, bw, lab, false, cur, () -> applyUvRes(p, p));
            bx += bw + 3;
        }
        by += 21;
        g.drawText(textRenderer, "Resolución:", vx + 10, by + 5, muted, false);
        int fx0 = vx + 10 + textRenderer.getWidth("Resolución:") + 6;
        for (int i = 0; i < 2; i++) {
            TextFieldWidget tf = i == 0 ? uvWf : uvHf;
            int fx = fx0 + i * 58;
            Gfx.rr(g, fx, by, 44, 18, 5, Theme.c("surface"));
            Gfx.fill(g, fx + 1, by + 17, fx + 43, by + 18, tf.isFocused() ? Theme.c("primary") : 0x90E8C2BA);
            tf.setX(fx + 5);
            tf.setY(by + 5);
            tf.setWidth(36);
            tf.setVisible(true);
            final TextFieldWidget tff = tf;
            hit(fx, by, 44, 18, () -> setFocused(tff));
        }
        g.drawText(textRenderer, "x", fx0 + 48, by + 5, muted, false);
        bx = uvBtn(g, fx0 + 106, by, "Aplicar", true, this::applyUvFields);
        by += 21;
        bx = vx + 8;
        bx = uvBtn(g, bx, by, "Archivo", false, () -> applyUvRes(model.texW, model.texH));
        bx = uvBtn(g, bx, by, "Imagen", false, () -> applyUvRes(model.imgW, model.imgH));
        bx = uvBtn(g, bx, by, "x2", false, () -> applyUvRes(effW() * 2, effH() * 2));
        bx = uvBtn(g, bx, by, "÷2", false, () -> applyUvRes(Math.max(1, effW() / 2), Math.max(1, effH() / 2)));
        bx = uvBtn(g, bx, by, uvAll ? "Mostrando: todo" : "Mostrando: parte", false, () -> uvAll = !uvAll);
        bx = uvBtn(g, bx, by, s.uvKeep ? "Mapa: se reescala" : "Mapa: se mantiene px", s.uvKeep, () -> s.uvKeep = !s.uvKeep);
        by += 21;
        BBModel.Cube cu = null;
        BBModel.Bone sb = sel == null ? null : model.bones.get(sel);
        if (sb != null && selCube != null) for (BBModel.Cube cc : sb.cubes) if (cc.key.equals(selCube)) cu = cc;
        final BBModel.Cube cuf = cu;
        if (cu != null) {
            float[] sh = s.uvShift.get(cu.key);
            g.drawText(textRenderer, trimTo("bloque: " + cu.name + "   desplazado: " + (sh == null ? "0, 0" : fmt(sh[0]) + ", " + fmt(sh[1])) + (cu.boxUv ? "   (box UV)" : "   (caras)"), vw - 220), vx + 10, by + 5, text, false);
            bx = vx + vw - 8;
            int w1 = textRenderer.getWidth("Reiniciar este bloque") + 14;
            button(g, bx - w1, by, w1, "Reiniciar este bloque", false, false, () -> s.uvShift.remove(cuf.key));
        } else {
            g.drawText(textRenderer, "Clic en un bloque del mapa (o de la lista) y arrástralo. Flechas: 1 px, Mayús: 8 px", vx + 10, by + 5, muted, false);
        }
        g.drawText(textRenderer, trimTo("Rueda: zoom   Arrastra el fondo: mover vista", vw - 150), vx + 10, vy + vh - 14, muted, false);
        int rw2 = textRenderer.getWidth("Reiniciar todos los UV") + 14;
        button(g, vx + vw - 8 - rw2, vy + vh - 26, rw2, "Reiniciar todos los UV", false, false, () -> s.uvShift.clear());
    }

    // ================================================================ reproductor de animaciones (con transicion)

    private void setPv(String name) {
        if (java.util.Objects.equals(name, pvName)) return;
        pvFrom = pvName;
        pvFromTime = pvTime;
        pvName = name;
        pvTime = 0f;
        pvBlendT = 0f;
        pvPlaying = true;
    }

    private void cyclePv(int dir) {
        List<String> names = new ArrayList<>();
        names.add(null);
        names.addAll(ModelManager.allAnimNames(model));
        int i = Math.max(0, names.indexOf(pvName));
        setPv(names.get(Math.floorMod(i + dir, names.size())));
    }

    private void advancePv() {
        long now = Util.getMeasuringTimeMs();
        float dt = Math.min(0.1f, Math.max(0f, (now - pvLastMs) / 1000f));
        pvLastMs = now;
        if (pvPlaying) { pvTime += dt; pvFromTime += dt; }
        if (pvBlendT < 1e8f) pvBlendT += dt;
        if (pvFrom != null && (s.blend <= 0f || pvBlendT >= s.blend)) pvFrom = null;
    }

    private BBRenderer.Pv buildPv() {
        BBModel.Anim a = pvName == null ? null : ModelManager.anim(model, pvName);
        BBModel.Anim from = pvFrom == null ? null : ModelManager.anim(model, pvFrom);
        if (a == null && from == null) return null;
        float t = 0f, ft = 0f;
        if (a != null) {
            ModelManager.LoopMode lm = ModelManager.loopMode(s, a, false);
            t = ModelManager.timeFor(a, pvTime, lm);
            if (ModelManager.finished(a, pvTime, lm)) { a = null; t = 0f; }   // "Una vez": ya termino, vuelve a la pose base
        }
        if (from != null) ft = ModelManager.timeFor(from, pvFromTime, ModelManager.loopMode(s, from, true));
        float w = from == null || s.blend <= 0f ? 1f : Math.min(1f, pvBlendT / s.blend);
        w = w * w * (3f - 2f * w);
        return new BBRenderer.Pv(a, t, from, ft, w);
    }

    private void drawAnimBar(DrawContext g) {
        int muted = Theme.c("muted"), text = Theme.c("text");
        if (ModelManager.allAnimNames(model).isEmpty()) return;
        int y1 = vy + vh - 56, y2 = vy + vh - 36, x = vx + 8;
        g.drawText(textRenderer, "Animación:", x + 2, y1 - 11, muted, false);
        button(g, x, y1, 18, "<", false, false, () -> cyclePv(-1));
        int nw = Math.max(60, Math.min(170, vw - 140));
        Gfx.rr(g, x + 20, y1, nw, 18, 9, Theme.c("surface"));
        String nm = textRenderer.trimToWidth(pvName == null ? "(ninguna: pose base)" : pvName, nw - 10);
        g.drawText(textRenderer, nm, x + 20 + nw / 2 - textRenderer.getWidth(nm) / 2, y1 + 5, pvName == null ? muted : text, false);
        button(g, x + 22 + nw, y1, 18, ">", false, false, () -> cyclePv(1));
        button(g, x + 42 + nw, y1, 58, pvPlaying ? "Pausa" : "Play", false, pvPlaying, () -> pvPlaying = !pvPlaying);
        BBModel.Anim a = pvName == null ? null : ModelManager.anim(model, pvName);
        int bx = x;
        if (a != null) {
            ModelManager.LoopMode lm = ModelManager.loopMode(s, a, false);
            String lab = "Modo: " + lm.shortLabel;
            int lw2 = textRenderer.getWidth(lab) + 14;
            button(g, bx, y2, lw2, lab, false, false, () -> { ModelManager.cycleLoopMode(s, a); pvTime = 0f; pvPlaying = true; });
            bx += lw2 + 6;
        }
        String bl = s.blend <= 0f ? "Transición: brusca" : String.format(java.util.Locale.ROOT, "Transición: %.2f s", s.blend);
        button(g, bx, y2, 18, "-", false, false, () -> s.blend = Math.max(0f, Math.round((s.blend - 0.05f) * 100f) / 100f));
        g.drawText(textRenderer, bl, bx + 24, y2 + 5, text, false);
        button(g, bx + 28 + textRenderer.getWidth(bl), y2, 18, "+", false, false, () -> s.blend = Math.min(1.5f, Math.round((s.blend + 0.05f) * 100f) / 100f));
    }

    // ================================================================ fisicas de rebote

    // ================================================================ hitbox

    private float[] boxValues() {
        if (s.hitboxAuto) { ModelBounds.Box b = ModelBounds.of(model, s); return new float[]{b.width(), b.height(), b.width(), b.eye()}; }
        if (s.hitboxOn) return new float[]{s.hitbox[0], s.hitbox[1], s.hitbox[2], s.eye > 0 ? s.eye : s.hitbox[1] * 0.9f};
        return new float[]{0.6f, 1.8f, 0.6f, 1.62f};   // vanilla
    }

    private void onHb(int i, String str) {
        if (syncing) return;
        try {
            float v = Float.parseFloat(str.trim());
            if (v <= 0f) return;
            float[] cur = boxValues();
            if (s.hitboxAuto || !s.hitboxOn) { s.hitbox = new float[]{cur[0], cur[1], cur[2]}; s.eye = cur[3]; }
            if (i < 3) s.hitbox[i] = v; else s.eye = v;
            s.hitboxOn = true;
            s.hitboxAuto = false;
        } catch (Exception ignored) {}
    }

    private void drawBoxBar(DrawContext g) {
        int muted = Theme.c("muted"), text = Theme.c("text");
        int x = vx + 8, y = vy + 8;
        boolean active = s.hitboxOn || s.hitboxAuto;
        button(g, x, y, 128, active ? "Hitbox personalizada: ON" : "Hitbox personalizada: OFF", false, active, () -> {
            boolean on = !(s.hitboxOn || s.hitboxAuto);
            s.hitboxOn = on;
            if (!on) s.hitboxAuto = false;
        });
        button(g, x + 132, y, 90, s.hitboxAuto ? "Auto: sí" : "Auto: no", false, s.hitboxAuto, () -> { s.hitboxAuto = !s.hitboxAuto; if (s.hitboxAuto) s.hitboxOn = true; });
        int y2 = y + 22;
        float[] bv = boxValues();
        String[] lab = {"Ancho X", "Alto", "Ancho Z", "Ojos"};
        int[] accent = {AXC[0], AXC[1], AXC[2], 0xFFFFD84A};
        for (int i = 0; i < 4; i++) {
            int fx = x + i * 54;
            g.drawText(textRenderer, lab[i], fx + 2, y2, muted, false);
            Gfx.rr(g, fx, y2 + 10, 50, 18, 5, Theme.c("surface"));
            Gfx.fill(g, fx + 1, y2 + 27, fx + 49, y2 + 28, hb[i].isFocused() ? Theme.c("primary") : 0x90E8C2BA);
            Gfx.fill(g, fx, y2 + 10, fx + 2, y2 + 28, accent[i]);
            hb[i].setX(fx + 6);
            hb[i].setY(y2 + 15);
            hb[i].setWidth(42);
            hb[i].setVisible(true);
            final TextFieldWidget tf = hb[i];
            hit(fx, y2 + 10, 50, 18, () -> setFocused(tf));
            if (!hb[i].isFocused()) {
                String v = fmt(bv[i]);
                if (!hb[i].getText().equals(v)) { syncing = true; hb[i].setText(v); syncing = false; }
            }
        }
        int y3 = y2 + 34;
        ModelBounds.Box mb = ModelBounds.of(model, s);
        g.drawText(textRenderer, trimTo("El modelo mide " + ModelBounds.describe(mb) + " bloques", vw - 20), vx + 10, y3, text, false);
        y3 += 12;
        button(g, x, y3, 110, "Medir el modelo", true, false, () -> {
            ModelBounds.Box b = ModelBounds.compute(model, s);
            s.hitbox = new float[]{b.width(), b.height(), b.width()};
            s.eye = b.eye();
            s.hitboxOn = true;
            s.hitboxAuto = false;
            status = "Hitbox = tamaño real del modelo";
        });
        button(g, x + 114, y3, 90, "Vanilla", false, false, () -> { s.hitboxOn = false; s.hitboxAuto = false; s.eye = 0f; s.hitbox = new float[]{0.6f, 1.8f, 0.6f}; });
        g.drawText(textRenderer, trimTo("Verde: colisión. Amarillo: ojos. Si no cabe de pie, el jugador gatea solo.", vw - 20), vx + 10, y3 + 24, muted, false);
        g.drawText(textRenderer, trimTo("Mundo propio: colisiona de verdad. En servidores ajenos el servidor usa la caja vanilla.", vw - 20), vx + 10, y3 + 35, muted, false);
    }

    /** Caja de colision (verde) y altura de ojos (amarillo) sobre el modelo, en bloques desde los pies. */
    private void drawHitbox(DrawContext g) {
        float[] bv = boxValues();
        float w = Math.max(bv[0], bv[2]), h = bv[1], eye = bv[3];
        boolean active = s.hitboxOn || s.hitboxAuto;
        float sc = s.scale <= 0 ? 1f : s.scale;
        Matrix4f B = new Matrix4f(view()).scale(16f / sc);        // bloques -> pantalla
        float hw = w / 2f;
        Vector3f[] p = new Vector3f[8];
        for (int i = 0; i < 8; i++)
            p[i] = B.transformPosition(new Vector3f((i & 1) == 0 ? -hw : hw, (i & 2) == 0 ? 0 : h, (i & 4) == 0 ? -hw : hw));
        int col = active ? 0xFF58E068 : 0x80AAAAAA;
        int[][] edges = {{0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
        for (int[] e : edges) Gfx.line(g, p[e[0]].x, p[e[0]].y, p[e[1]].x, p[e[1]].y, 1.5f, col);
        Vector3f a = B.transformPosition(new Vector3f(-hw, eye, -hw)), b = B.transformPosition(new Vector3f(hw, eye, -hw));
        Vector3f c = B.transformPosition(new Vector3f(hw, eye, hw)), d = B.transformPosition(new Vector3f(-hw, eye, hw));
        int ec = 0xFFFFD84A;
        Gfx.line(g, a.x, a.y, b.x, b.y, 1f, ec); Gfx.line(g, b.x, b.y, c.x, c.y, 1f, ec);
        Gfx.line(g, c.x, c.y, d.x, d.y, 1f, ec); Gfx.line(g, d.x, d.y, a.x, a.y, 1f, ec);
    }

    private void setPhysFromX(double x) {
        if (physSl == null) return;
        float fr = (float) Math.max(0, Math.min(1, (x - physSl[0]) / (double) physSl[2]));
        s.physicsIntensity = Math.round(fr * 3f * 20f) / 20f;      // 0 a 3 en pasos de 0,05
    }

    private void drawPhysBar(DrawContext g) {
        int muted = Theme.c("muted"), text = Theme.c("text");
        int x = vx + 8, y = vy + 8;
        button(g, x, y, 100, s.physicsOn ? "Físicas: ON" : "Físicas: OFF", false, s.physicsOn, () -> s.physicsOn = !s.physicsOn);
        int sw = Math.max(40, Math.min(90, vw - 8 - 104 - 104 - 40));
        int sx = x + 108;
        float fr = Math.max(0f, Math.min(1f, s.physicsIntensity / 3f));
        Gfx.rr(g, sx, y + 6, sw, 4, 2, Theme.c("surfaceHi"));
        int fw = Math.round((sw - 8) * fr);
        Gfx.rr(g, sx, y + 6, fw + 4, 4, 2, Theme.c("primary"));
        Gfx.rr(g, sx + fw, y + 3, 8, 10, 4, Theme.c("text"));
        physSl = new int[]{sx, y, sw};
        g.drawText(textRenderer, String.format(java.util.Locale.ROOT, "%.2f", s.physicsIntensity), sx + sw + 6, y + 5, s.physicsOn ? text : muted, false);
        int y2 = y + 20;
        BBModel.Bone sb = sel == null ? null : model.bones.get(sel);
        if (sb != null) {
            boolean on = s.physBones.contains(sb.name);
            String lab = on ? "Esta parte rebota: sí" : "Esta parte rebota: no";
            int bw = textRenderer.getWidth(lab) + 14;
            button(g, x, y2, bw, lab, false, on, () -> { if (!s.physBones.remove(sel)) s.physBones.add(sel); });
            x += bw + 4;
        }
        String pb = "Probar rebote";
        button(g, x, y2, textRenderer.getWidth(pb) + 14, pb, false, false, () -> { if (!s.physicsOn) s.physicsOn = true; Physics.kick(Physics.PREVIEW, s.physBones, 1f); });
        if (s.physicsOn && s.physBones.isEmpty())
            g.drawText(textRenderer, trimTo("Marca partes con 'Esta parte rebota' (cola, pelo, orejas...)", vw - 20), vx + 10, y2 + 24, muted, false);
    }

    private int uvBtn(DrawContext g, int x, int y, String label, boolean on, Runnable r) {
        int bw = textRenderer.getWidth(label) + 14;
        button(g, x, y, bw, label, false, on, r);
        return x + bw + 3;
    }

    private String trimTo(String t, int px) { return textRenderer.trimToWidth(t, Math.max(0, px)); }

    @Override
    public void close() {
        PreviewSim.stop();
        ModelManager.saveConfig();
        client.setScreen(parent);
        if (parent instanceof ModelScreen ms) ms.refreshFromEditor(model, sel);
    }
}
