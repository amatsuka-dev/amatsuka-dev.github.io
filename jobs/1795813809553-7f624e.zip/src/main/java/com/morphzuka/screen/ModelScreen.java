package com.morphzuka.screen;

import com.morphzuka.Role;
import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelImporter;
import com.morphzuka.model.ModelManager;
import com.morphzuka.render.MorphManager;
import com.morphzuka.render.PreviewSim;
import com.morphzuka.ui.Background;
import com.morphzuka.ui.MorphPreview;
import com.morphzuka.ui.Theme;
import net.minecraft.util.Identifier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Util;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.*;

/** UI minimalista estilo Material 3 oscuro con transparencias. Todo dibujado a mano (hit-regions por frame). */
public class ModelScreen extends Screen {

    // ---- paleta
    private static int PANEL = 0xD0181212;
    private static int RAIL = 0xE0100B0B;
    private static int SURFACE = 0x66463C3A;
    private static int SURFACE_HI = 0xB0594B49;
    private static int HOVER = 0x30FFFFFF;
    private static int PILL = 0xFF4F3F3D;
    private static int PRIMARY = 0xFFE8C2BA;
    private static int PRIMARY_HOVER = 0xFFF4D6D0;
    private static int ON_PRIMARY = 0xFF442926;
    private static int TEXT = 0xFFEDE0DD;
    private static int MUTED = 0xFF9D8F8C;
    private static int ERROR = 0xFFFFB4AB;

    /** Copia los colores personalizados del tema a la paleta de esta pantalla. */
    private static void applyTheme() {
        PANEL = Theme.c("panel"); RAIL = Theme.c("rail"); SURFACE = Theme.c("surface"); SURFACE_HI = Theme.c("surfaceHi");
        HOVER = Theme.c("line"); PILL = Theme.c("pill"); PRIMARY = Theme.c("primary"); ON_PRIMARY = Theme.c("onPrimary");
        TEXT = Theme.c("text"); MUTED = Theme.c("muted"); ERROR = Theme.c("error");
        int a = (PRIMARY >>> 24) & 255, r = (PRIMARY >> 16) & 255, g = (PRIMARY >> 8) & 255, b = PRIMARY & 255;
        PRIMARY_HOVER = (a << 24) | (Math.min(255, r + 28) << 16) | (Math.min(255, g + 28) << 8) | Math.min(255, b + 28);
    }

    private enum Tab {
        MODELS("Modelos"), PARTS("Partes"), EDITOR("Editor 3D"), ANIMS("Animación"), MORPH("Morph"), THEME("Tema"), IMPORT("Importar"), APPLY("Aplicar");
        final String label;
        Tab(String l) { label = l; }
    }

    private static final class Hit { int x, y, w, h; int[] clip; Runnable r; boolean field; }
    private static final class Area { String key; int x, y, w, h, content, max; }

    private final Screen parent;
    private final List<Hit> hits = new ArrayList<>();
    private final List<Area> areas = new ArrayList<>();
    private final Map<String, Integer> scroll = new HashMap<>();
    private int[] clip;
    private Area lastArea;
    private int mx, my;

    private Tab tab = Tab.MODELS;
    private BBModel cur;
    private String curBone;
    private int animState = 0;
    private int applyMode = 0; // 0 yo, 1 todos, 2 jugador
    private String status = "";
    private boolean statusErr;

    private TextFieldWidget fUrl, fName, fx, fy, fz, fScale, fPlayer, fSearch, fBg;
    private final Map<String, TextFieldWidget> themeFields = new LinkedHashMap<>();
    private int morphKind = 0;
    private float pvYaw, pvAuto;          // giro de la vista previa del morph (arrastrar) y giro automatico
    private boolean pvDrag, pvTouched;
    private String mlKey = "";
    private List<String> mlist = List.of();
    private List<TextFieldWidget> fields = new ArrayList<>();

    public ModelScreen(Screen parent) {
        super(Text.literal("MorphZuka"));
        this.parent = parent;
    }

    // ================================================================ init

    @Override
    protected void init() {
        applyTheme();
        String oUrl = fUrl == null ? "" : fUrl.getText();
        String oName = fName == null ? "" : fName.getText();
        String oPlayer = fPlayer == null ? "" : fPlayer.getText();

        fUrl = mk("https://...", 2048);
        fName = mk("nombre", 48);
        fx = mk("X", 16);
        fy = mk("Y", 16);
        fz = mk("Z", 16);
        fScale = mk("1", 8);
        fPlayer = mk("jugador", 32);
        fSearch = mk("buscar...", 64);
        fBg = mk("imagen.png / fondo.gif / video.mp4", 260);
        themeFields.clear();
        for (String k : Theme.KEYS) {
            TextFieldWidget tf = mk("RRGGBB / AARRGGBB", 9);
            tf.setChangedListener(str -> { if (Theme.valid(str)) { Theme.set(k, str); applyTheme(); } });
            themeFields.put(k, tf);
        }
        fields = new ArrayList<>(List.of(fUrl, fName, fx, fy, fz, fScale, fPlayer, fSearch, fBg));
        fields.addAll(themeFields.values());
        syncTheme();
        fScale.setChangedListener(str -> {
            if (cur == null) return;
            try {
                float v = Float.parseFloat(str.trim());
                if (v > 0) ModelManager.settings(cur).scale = v;
            } catch (Exception ignored) {}
        });
        fUrl.setText(oUrl);
        fName.setText(oName);
        fPlayer.setText(oPlayer);

        if (cur != null) cur = ModelManager.MODELS.get(cur.id);
        if (cur == null && !ModelManager.MODELS.isEmpty()) cur = ModelManager.MODELS.values().iterator().next();
        if (cur == null || curBone != null && !cur.bones.containsKey(curBone)) curBone = null;
        syncFields();
    }

    private TextFieldWidget mk(String placeholder, int max) {
        TextFieldWidget f = new TextFieldWidget(textRenderer, 0, 0, 100, 12, Text.literal(placeholder));
        f.setDrawsBackground(false);
        f.setMaxLength(max);
        f.setEditableColor(TEXT);
        f.setPlaceholder(Text.literal(placeholder).formatted(Formatting.DARK_GRAY));
        f.setVisible(false);
        addDrawableChild(f);
        return f;
    }

    private void syncFields() {
        ModelManager.Settings s = cur == null ? null : ModelManager.settings(cur);
        if (s != null && curBone != null && cur.bones.containsKey(curBone)) {
            float[] pv = s.pivots.containsKey(curBone) ? s.pivots.get(curBone) : cur.bones.get(curBone).pivot;
            fx.setText(fmt(pv[0])); fy.setText(fmt(pv[1])); fz.setText(fmt(pv[2]));
        } else {
            fx.setText(""); fy.setText(""); fz.setText("");
        }
        fScale.setText(s == null ? "1" : fmt(s.scale));
    }

    private static String fmt(float f) { return f == (long) f ? Long.toString((long) f) : Float.toString(f); }

    // ================================================================ helpers de dibujo

    private static void rr(DrawContext g, int x, int y, int w, int h, int r, int c) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < h; i++) {
            int d = 0;
            int k = i < r ? i : (i >= h - r ? h - 1 - i : -1);
            if (k >= 0) {
                double dy = r - k - 0.5;
                d = r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
            }
            g.fill(x + d, y + i, x + w - d, y + i + 1, c);
        }
    }

    private void txt(DrawContext g, String s, int x, int y, int c) { g.drawText(textRenderer, s, x, y, c, false); }

    private void ctxt(DrawContext g, String s, int cx, int y, int c) {
        g.drawText(textRenderer, s, cx - textRenderer.getWidth(s) / 2, y, c, false);
    }

    private void bold(DrawContext g, String s, int x, int y, int c) {
        g.drawText(textRenderer, Text.literal(s).formatted(Formatting.BOLD), x, y, c, false);
    }

    private void muted(DrawContext g, String s, int x, int y) { txt(g, s, x, y, MUTED); }

    private String trim(String s, int px) { return textRenderer.trimToWidth(s, Math.max(0, px)); }

    private boolean hover(int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h
                && (clip == null || (mx >= clip[0] && mx < clip[2] && my >= clip[1] && my < clip[3]));
    }

    private void hit(int x, int y, int w, int h, boolean field, Runnable r) {
        Hit t = new Hit();
        t.x = x; t.y = y; t.w = w; t.h = h; t.r = r; t.field = field;
        t.clip = clip == null ? null : clip.clone();
        hits.add(t);
    }

    /** style 0 = primario (relleno), 1 = tonal. Devuelve el ancho. */
    private int btnW(DrawContext g, int x, int y, int w, int h, String label, int style, boolean enabled, Runnable r) {
        boolean hov = enabled && hover(x, y, w, h);
        int bg = !enabled ? 0x30FFFFFF : style == 0 ? (hov ? PRIMARY_HOVER : PRIMARY) : (hov ? 0xD0705F5C : SURFACE_HI);
        rr(g, x, y, w, h, h / 2, bg);
        int tc = !enabled ? MUTED : style == 0 ? ON_PRIMARY : TEXT;
        ctxt(g, trim(label, w - 8), x + w / 2, y + (h - 8) / 2, tc);
        if (enabled) hit(x, y, w, h, false, r);
        return w;
    }

    private int btn(DrawContext g, int x, int y, String label, int style, Runnable r) {
        return btnW(g, x, y, textRenderer.getWidth(label) + 26, 20, label, style, true, r);
    }

    private void chip(DrawContext g, int x, int y, int w, String label, boolean sel, Runnable r) {
        boolean hov = hover(x, y, w, 16);
        rr(g, x, y, w, 16, 8, sel ? PRIMARY : (hov ? 0xA0705F5C : SURFACE));
        ctxt(g, label, x + w / 2, y + 4, sel ? ON_PRIMARY : TEXT);
        hit(x, y, w, 16, false, r);
    }

    private void radio(DrawContext g, int x, int y, boolean sel, String label, Runnable r) {
        rr(g, x, y, 12, 12, 6, sel ? PRIMARY : MUTED);
        rr(g, x + 1, y + 1, 10, 10, 5, 0xFF1E1716);
        if (sel) rr(g, x + 3, y + 3, 6, 6, 3, PRIMARY);
        txt(g, label, x + 18, y + 2, TEXT);
        hit(x, y, 18 + textRenderer.getWidth(label), 14, false, r);
    }

    /** Campo de texto con fondo tonal y subrayado de acento. */
    private void field(DrawContext g, TextFieldWidget f, int x, int y, int w, int h) {
        rr(g, x, y, w, h, 5, SURFACE);
        g.fill(x + 1, y + h - (f.isFocused() ? 2 : 1), x + w - 1, y + h, f.isFocused() ? PRIMARY : 0x90E8C2BA);
        f.setX(x + 6);
        f.setY(y + (h - 8) / 2);
        f.setWidth(w - 12);
        f.setVisible(true);
        hit(x, y, w, h, true, () -> setFocused(f));
    }

    private int beginScroll(DrawContext g, String key, int x, int y, int w, int h, int content) {
        Area a = new Area();
        a.key = key; a.x = x; a.y = y; a.w = w; a.h = h; a.content = content;
        a.max = Math.max(0, content - h);
        int s = Math.max(0, Math.min(a.max, scroll.getOrDefault(key, 0)));
        scroll.put(key, s);
        areas.add(a);
        lastArea = a;
        g.enableScissor(x, y, x + w, y + h);
        clip = new int[]{x, y, x + w, y + h};
        return s;
    }

    private void endScroll(DrawContext g) {
        g.disableScissor();
        clip = null;
        Area a = lastArea;
        if (a != null && a.max > 0) {
            int th = Math.max(12, a.h * a.h / a.content);
            int ty = a.y + (a.h - th) * scroll.get(a.key) / a.max;
            rr(g, a.x + a.w - 3, ty, 2, th, 1, 0x80E8C2BA);
        }
    }

    private void dropzone(DrawContext g, int x, int y, int w) {
        rr(g, x, y, w, 46, 10, SURFACE);
        int d = 0x90E8C2BA;
        for (int i = x + 12; i < x + w - 12; i += 8) { g.fill(i, y + 2, i + 4, y + 3, d); g.fill(i, y + 43, i + 4, y + 44, d); }
        for (int j = y + 10; j < y + 36; j += 8) { g.fill(x + 2, j, x + 3, j + 4, d); g.fill(x + w - 3, j, x + w - 2, j + 4, d); }
        String t = "Arrastra y suelta tus modelos aquí";
        g.drawText(textRenderer, Text.literal(t).formatted(Formatting.BOLD), x + w / 2 - textRenderer.getWidth(Text.literal(t).formatted(Formatting.BOLD)) / 2, y + 10, TEXT, false);
        ctxt(g, trim(".bbmodel  .geo.json  .cpmproject  (+ .png / .animation.json)", w - 16), x + w / 2, y + 25, MUTED);
    }

    // ================================================================ render

    @Override
    public void render(DrawContext g, int mouseX, int mouseY, float delta) {
        this.mx = mouseX;
        this.my = mouseY;
        hits.clear();
        areas.clear();
        clip = null;
        for (TextFieldWidget f : fields) f.setVisible(false);

        renderBackground(g, mouseX, mouseY, delta);
        Background.draw(g, width, height);

        // rail
        int railW = 96;
        g.fill(0, 0, railW, height, RAIL);
        g.fill(railW, 0, railW + 1, height, 0x30FFFFFF);
        ctxt(g, "MorphZuka", railW / 2, 14, PRIMARY);
        int ty = 38;
        for (Tab t : Tab.values()) {
            boolean sel = t == tab;
            boolean hov = hover(8, ty, railW - 16, 22);
            if (sel) rr(g, 8, ty, railW - 16, 22, 11, PILL);
            else if (hov) rr(g, 8, ty, railW - 16, 22, 11, HOVER);
            ctxt(g, t.label, railW / 2, ty + 7, sel ? TEXT : MUTED);
            final Tab tt = t;
            hit(8, ty, railW - 16, 22, false, () -> tab = tt);
            ty += 28;
        }
        btnW(g, 10, height - 32, railW - 20, 20, "Cerrar", 1, true, this::close);

        // panel
        int px = railW + 12, py = 14, pw = width - px - 14, ph = height - 28;
        rr(g, px, py, pw, ph, 10, PANEL);
        int ix = px + 14, iy = py + 12, iw = pw - 28;
        bold(g, tab.label, ix, iy, TEXT);
        if (cur != null && tab != Tab.MODELS && tab != Tab.IMPORT && tab != Tab.MORPH && tab != Tab.THEME)
            txt(g, trim(cur.id, iw - 80), ix + textRenderer.getWidth(tab.label) + 14, iy, MUTED);
        int cy = iy + 18;
        int ch = ph - 18 - 12 - 16 - 8;
        switch (tab) {
            case MODELS -> drawModels(g, ix, cy, iw, ch);
            case PARTS -> drawParts(g, ix, cy, iw, ch);
            case EDITOR -> drawEditor(g, ix, cy, iw, ch);
            case ANIMS -> drawAnims(g, ix, cy, iw, ch);
            case IMPORT -> drawImport(g, ix, cy, iw, ch);
            case APPLY -> drawApply(g, ix, cy, iw, ch);
            case MORPH -> drawMorph(g, ix, cy, iw, ch);
            case THEME -> drawTheme(g, ix, cy, iw, ch);
        }
        if (!status.isEmpty())
            txt(g, trim(status, iw), ix, py + ph - 16, statusErr ? ERROR : PRIMARY);

        for (TextFieldWidget f : fields) if (f.visible) f.render(g, mouseX, mouseY, delta);
    }

    // ---------------------------------------------------------------- MODELOS

    private void drawModels(DrawContext g, int x, int y, int w, int h) {
        dropzone(g, x, y, w);
        int by = y + 54, bx = x;
        bx += btn(g, bx, by, "Abrir carpeta", 0, this::openFolder) + 6;
        bx += btn(g, bx, by, "Recargar", 1, this::reloadAll) + 6;
        btn(g, bx, by, "Link / Base64", 1, () -> tab = Tab.IMPORT);

        int ly = by + 28, lh = y + h - ly;
        List<BBModel> list = new ArrayList<>(ModelManager.MODELS.values());
        if (list.isEmpty()) {
            ctxt(g, "Aún no hay modelos. Arrastra un archivo a esta ventana.", x + w / 2, ly + 14, MUTED);
            return;
        }
        Set<String> used = new HashSet<>(ModelManager.CONFIG.assignments.values());
        int rowH = 32;
        int sc = beginScroll(g, "models", x, ly, w, lh, list.size() * rowH);
        for (int i = 0; i < list.size(); i++) {
            int ry = ly + i * rowH - sc;
            if (ry + rowH < ly || ry > ly + lh) continue;
            final BBModel m = list.get(i);
            int rw = w - 8;
            boolean sel = m == cur;
            rr(g, x, ry, rw, rowH - 4, 8, sel ? PILL : hover(x, ry, rw, rowH - 4) ? HOVER : SURFACE);
            if (sel) rr(g, x + 4, ry + 6, 3, rowH - 16, 1, PRIMARY);
            String chipTxt = m.source;
            int cw = textRenderer.getWidth(chipTxt) + 12;
            final String animLab = "Animaciones";
            int abw = textRenderer.getWidth(animLab) + 14;
            txt(g, trim(m.id, rw - cw - abw - 40), x + 14, ry + 5, TEXT);
            muted(g, m.bones.size() + " huesos  -  " + m.anims.size() + " animaciones" + (used.contains(m.id) ? "  -  en uso" : ""), x + 14, ry + 16);
            rr(g, x + rw - cw - 8, ry + 6, cw, 14, 7, 0x60E8C2BA);
            ctxt(g, chipTxt, x + rw - cw / 2 - 8, ry + 9, TEXT);
            hit(x, ry, rw, rowH - 4, false, () -> { cur = m; curBone = null; syncFields(); });
            int abx = x + rw - cw - 14 - abw;
            btnW(g, abx, ry + 5, abw, 16, animLab, 1, true, () -> { cur = m; curBone = null; syncFields(); ModelManager.saveConfig(); client.setScreen(new AnimConfigScreen(this, m)); });
        }
        endScroll(g);
    }

    // ---------------------------------------------------------------- PARTES

    private void drawParts(DrawContext g, int x, int y, int w, int h) {
        if (cur == null) { muted(g, "Elige un modelo primero (pestaña Modelos).", x, y + 4); return; }
        ModelManager.Settings s = ModelManager.settings(cur);
        int lw = Math.min(w * 45 / 100, 210);
        muted(g, "Huesos", x, y);
        int ly = y + 12, lh = h - 12;
        rr(g, x, ly, lw, lh, 8, 0x40000000);
        List<BBModel.Bone> bones = new ArrayList<>(cur.bones.values());
        int rowH = 15;
        int sc = beginScroll(g, "bones", x + 3, ly + 3, lw - 6, lh - 6, bones.size() * rowH);
        for (int i = 0; i < bones.size(); i++) {
            int ry = ly + 3 + i * rowH - sc;
            if (ry + rowH < ly || ry > ly + lh) continue;
            final BBModel.Bone b = bones.get(i);
            boolean sel = b.name.equals(curBone);
            if (sel) rr(g, x + 3, ry, lw - 10, rowH - 1, 6, PILL);
            else if (hover(x + 3, ry, lw - 10, rowH - 1)) rr(g, x + 3, ry, lw - 10, rowH - 1, 6, HOVER);
            Role r = Role.of(s.roles.get(b.name));
            String rl = r == Role.NONE ? "" : r.label;
            int rlw = rl.isEmpty() ? 0 : textRenderer.getWidth(rl) + 6;
            txt(g, trim(b.label(), lw - 22 - b.depth * 8 - rlw), x + 9 + b.depth * 8, ry + 3, r != Role.NONE ? PRIMARY : TEXT);
            if (!rl.isEmpty()) muted(g, rl, x + lw - 10 - rlw + 4, ry + 3);
            hit(x + 3, ry, lw - 10, rowH - 1, false, () -> { curBone = b.name; syncFields(); });
        }
        endScroll(g);

        int rx = x + lw + 14, rw = w - lw - 14, cy = y;
        if (curBone == null) {
            muted(g, "Selecciona un hueso de la lista", rx, cy + 2);
            cy += 20;
        } else {
            bold(g, trim(cur.bones.get(curBone).label(), rw), rx, cy, TEXT);
            cy += 14;
            muted(g, "Rol (qué parte del cuerpo controla)", rx, cy);
            cy += 11;
            int cxp = rx;
            Role curRole = Role.of(s.roles.get(curBone));
            for (Role r : Role.values()) {
                String lab = r == Role.NONE ? "Ninguno" : r.label;
                int cw = textRenderer.getWidth(lab) + 14;
                if (cxp + cw > rx + rw) { cxp = rx; cy += 19; }
                final Role rr0 = r;
                chip(g, cxp, cy, cw, lab, curRole == r, () -> {
                    if (rr0 == Role.NONE) s.roles.remove(curBone); else s.roles.put(curBone, rr0.name());
                });
                cxp += cw + 4;
            }
            cy += 24;
            muted(g, "Pivote X  Y  Z (píxeles)", rx, cy);
            cy += 11;
            int fw = (rw - 8) / 3;
            field(g, fx, rx, cy, fw, 18);
            field(g, fy, rx + fw + 4, cy, fw, 18);
            field(g, fz, rx + 2 * (fw + 4), cy, fw, 18);
            cy += 24;
            int bw = btn(g, rx, cy, "Fijar pivote", 0, this::setPivot);
            int bw2 = btn(g, rx + bw + 6, cy, "Restaurar", 1, () -> { s.pivots.remove(curBone); syncFields(); });
            btn(g, rx + bw + bw2 + 12, cy, "Editor 3D", 1, this::openEditor);
            cy += 28;
        }
        muted(g, "Escala del modelo", rx, cy);
        field(g, fScale, rx, cy + 11, 70, 18);
        btn(g, rx + 80, cy + 10, "Simular ataque", 1, () -> { PreviewSim.start(); openEditor(); });
        btn(g, rx, cy + 36, s.physicsOn ? "Físicas: ON" : "Físicas: OFF", s.physicsOn ? 0 : 1, () -> { s.physicsOn = !s.physicsOn; ModelManager.saveConfig(); });
        btnW(g, rx + 100, cy + 36, 22, 20, "-", 1, true, () -> s.physicsIntensity = Math.max(0f, Math.round((s.physicsIntensity - 0.1f) * 10f) / 10f));
        txt(g, String.format(Locale.ROOT, "%.1f", s.physicsIntensity), rx + 128, cy + 42, TEXT);
        btnW(g, rx + 152, cy + 36, 22, 20, "+", 1, true, () -> s.physicsIntensity = Math.min(3f, Math.round((s.physicsIntensity + 0.1f) * 10f) / 10f));
    }

    // ---------------------------------------------------------------- EDITOR 3D

    private void drawEditor(DrawContext g, int x, int y, int w, int h) {
        if (cur == null) { muted(g, "Elige un modelo primero (pestaña Modelos).", x, y + 4); return; }
        muted(g, "Visor orbital con selector de partes y gizmo.", x, y + 2);
        muted(g, "Mover, rotar y escalar con coordenadas XYZ y pivote editable.", x, y + 14);
        muted(g, "Los cambios se guardan en los ajustes del modelo, no en el archivo.", x, y + 26);
        btn(g, x, y + 46, "Abrir editor 3D", 0, this::openEditor);
    }

    private void openEditor() {
        if (cur == null) return;
        ModelManager.saveConfig();
        client.setScreen(new EditorScreen(this, cur, curBone));
    }

    /** Llamado al cerrar el editor 3D para refrescar la seleccion y los campos de pivote. */
    public void refreshFromEditor(BBModel m, String bone) {
        cur = m;
        curBone = bone != null && m.bones.containsKey(bone) ? bone : null;
        syncFields();
    }

    private void setPivot() {
        if (cur == null || curBone == null) return;
        try {
            ModelManager.settings(cur).pivots.put(curBone, new float[]{
                    Float.parseFloat(fx.getText().trim()), Float.parseFloat(fy.getText().trim()), Float.parseFloat(fz.getText().trim())});
            say("Pivote de '" + curBone + "' actualizado", false);
        } catch (Exception e) { say("Números inválidos en el pivote", true); }
    }

    // ---------------------------------------------------------------- ANIMACION

    private void drawAnims(DrawContext g, int x, int y, int w, int h) {
        if (cur == null) { muted(g, "Elige un modelo primero (pestaña Modelos).", x, y + 4); return; }
        ModelManager.Settings s = ModelManager.settings(cur);
        int lw = Math.min(w * 38 / 100, 180);
        muted(g, "Estado del jugador", x, y);
        int stH = h - 12, stRow = 28;
        int stSc = beginScroll(g, "states", x, y + 12, lw, stH, ModelManager.STATES.length * stRow);
        for (int i = 0; i < ModelManager.STATES.length; i++) {
            int ry = y + 12 + i * stRow - stSc;
            if (ry + 26 < y + 12 || ry > y + 12 + stH) continue;
            final int idx = i;
            String a = s.anims.get(ModelManager.STATES[i]);
            boolean sel = i == animState;
            rr(g, x, ry, lw - 8, 26, 8, sel ? PILL : hover(x, ry, lw - 8, 26) ? HOVER : SURFACE);
            if (sel) rr(g, x + 4, ry + 5, 3, 16, 1, PRIMARY);
            txt(g, ModelManager.STATE_LABELS[i], x + 14, ry + 4, TEXT);
            muted(g, trim(a == null ? "(ninguna)" : a, lw - 32), x + 14, ry + 14);
            hit(x, ry, lw - 8, 26, false, () -> animState = idx);
        }
        endScroll(g);
        int rx = x + lw + 14, rw = w - lw - 14;
        muted(g, "Animación para: " + ModelManager.STATE_LABELS[animState] + "   (chips: modo Bucle/1 vez/Pausa y categoría)", rx, y);
        int ly = y + 12, lh = h - 12;
        rr(g, rx, ly, rw, lh, 8, 0x40000000);
        List<String> names = new ArrayList<>();
        names.add(null);
        names.addAll(ModelManager.allAnimNames(cur));
        String assigned = s.anims.get(ModelManager.STATES[animState]);
        int rowH = 18;
        int sc = beginScroll(g, "anims", rx + 3, ly + 3, rw - 6, lh - 6, names.size() * rowH);
        for (int i = 0; i < names.size(); i++) {
            int ry = ly + 3 + i * rowH - sc;
            if (ry + rowH < ly || ry > ly + lh) continue;
            final String n = names.get(i);
            boolean sel = Objects.equals(n, assigned);
            if (sel) rr(g, rx + 3, ry, rw - 12, rowH - 2, 6, PRIMARY);
            else if (hover(rx + 3, ry, rw - 12, rowH - 2)) rr(g, rx + 3, ry, rw - 12, rowH - 2, 6, HOVER);
            txt(g, trim(n == null ? "(ninguna)" : n, rw - 170), rx + 10, ry + 5, sel ? ON_PRIMARY : TEXT);
            if (n != null) {
                final BBModel.Anim an0 = ModelManager.anim(cur, n);
                if (an0 != null) {
                    ModelManager.LoopMode lm = ModelManager.loopMode(s, an0, false);
                    int mx0 = rx + rw - 134, mw = 56;
                    rr(g, mx0, ry + 1, mw, rowH - 4, 6, s.animModes.containsKey(an0.name) ? PILL : SURFACE);
                    txt(g, lm.shortLabel, mx0 + 6, ry + 5, s.animModes.containsKey(an0.name) ? TEXT : MUTED);
                    hit(mx0, ry + 1, mw, rowH - 4, false, () -> ModelManager.cycleLoopMode(s, an0));
                }
                String cat = s.animCats.get(n);
                String lab = cat == null ? "-" : ModelManager.catLabel(cat);
                int cx = rx + rw - 72, cw = 56;
                rr(g, cx, ry + 1, cw, rowH - 4, 6, cat == null ? SURFACE : PILL);
                txt(g, lab, cx + 6, ry + 5, cat == null ? MUTED : TEXT);
                hit(cx, ry + 1, cw, rowH - 4, false, () -> ModelManager.cycleCat(s, n));
            }
            hit(rx + 3, ry, rw - 140, rowH - 2, false, () -> {
                if (n == null) s.anims.remove(ModelManager.STATES[animState]);
                else s.anims.put(ModelManager.STATES[animState], n);
            });
        }
        endScroll(g);
        if (names.size() <= 1) ctxt(g, "Este modelo no tiene animaciones", rx + rw / 2, ly + 26, MUTED);
    }

    // ---------------------------------------------------------------- COMANDO

    private void copyCommand() {
        if (cur == null) { say("Elige un modelo primero", true); return; }
        String k = targetKey();
        String cmd = "/morphzuka apply " + (k.isEmpty() ? "<jugador>" : k) + " " + cur.id;
        client.keyboard.setClipboard(cmd);
        say("Copiado: " + cmd, false);
    }

    // ---------------------------------------------------------------- MORPH

    private void drawMorph(DrawContext g, int x, int y, int w, int h) {
        // ---- columna derecha: lo que llevas puesto + vista previa 3D + boton Animaciones
        int pvW = Math.max(96, Math.min(170, w * 34 / 100));
        int lw = w - pvW - 10;
        int rx = x + lw + 10;
        MorphManager.State st = MorphManager.state();

        muted(g, "Puesto ahora", rx, y);
        String nm = st == null ? "Forma normal" : st.kind == MorphManager.Kind.PLAYER ? st.name : String.valueOf(st.id);
        txt(g, trim(nm, pvW), rx, y + 11, TEXT);
        String sub = st == null ? "tu skin / modelo"
                : (st.kind == MorphManager.Kind.ENTITY ? "Entidad" : st.kind == MorphManager.Kind.BLOCK ? "Bloque" : "Jugador")
                + "  " + fmt1(st.w) + " x " + fmt1(st.h);
        muted(g, trim(sub, pvW), rx, y + 22);

        int btnH = 20;
        int pvY = y + 34, pvH = h - 34 - btnH - 6;
        rr(g, rx, pvY, pvW, Math.max(0, pvH), 8, 0x40000000);
        pvAuto = (net.minecraft.util.Util.getMeasuringTimeMs() / 30L) % 360L;
        float yawNow = pvTouched ? pvYaw : pvAuto;
        boolean drew = pvH > 30 && MorphPreview.draw(g, st, rx, pvY, pvW, pvH, yawNow, 1f, false, false, false);
        if (!drew) ctxt(g, "Sin vista previa", rx + pvW / 2, pvY + Math.max(4, pvH / 2 - 4), MUTED);
        hit(rx, pvY, pvW, Math.max(0, pvH), false, () -> { if (!pvTouched) { pvYaw = pvAuto; pvTouched = true; } pvDrag = true; });
        boolean canAnim = st != null && st.kind != MorphManager.Kind.BLOCK && st.entity != null;
        btnW(g, rx, y + h - btnH, pvW, btnH, "Animaciones", 0, canAnim, () -> client.setScreen(new EntityAnimScreen(this)));

        // ---- columna izquierda: tipo, busqueda, ajustes y lista
        String[] kn = {"Entidad", "Bloque", "Jugador"};
        int cw = Math.max(40, Math.min(64, (lw - 8) / 3));
        int cx = x;
        for (int i = 0; i < 3; i++) {
            final int ii = i;
            chip(g, cx, y, cw, kn[i], morphKind == i, () -> { morphKind = ii; mlKey = ""; });
            cx += cw + 4;
        }
        int sy = y + 22;
        field(g, fSearch, x, sy, lw, 18);
        int by = sy + 24;
        int bx = x + btn(g, x, by, "Forma normal", 1, () -> { MorphManager.clear(); say("Forma normal", false); }) + 8;
        int ry2;
        if (lw >= 330) {
            radio(g, bx, by + 4, MorphManager.copyHitbox, "Copiar hitbox", () -> MorphManager.copyHitbox = !MorphManager.copyHitbox);
            ry2 = by + 26;
        } else {
            radio(g, x, by + 26, MorphManager.copyHitbox, "Copiar hitbox", () -> MorphManager.copyHitbox = !MorphManager.copyHitbox);
            ry2 = by + 44;
        }
        radio(g, x, ry2, ModelManager.CONFIG.cubeEffect, "Efecto de cubos al transformarse", () -> {
            ModelManager.CONFIG.cubeEffect = !ModelManager.CONFIG.cubeEffect;
            ModelManager.saveConfig();
        });

        String key = morphKind + ":" + fSearch.getText().trim().toLowerCase(Locale.ROOT);
        if (!key.equals(mlKey)) {
            mlKey = key;
            String q = fSearch.getText().trim().toLowerCase(Locale.ROOT);
            List<String> l = new ArrayList<>();
            if (morphKind == 2) {
                if (client.getNetworkHandler() != null)
                    client.getNetworkHandler().getPlayerList().forEach(e -> {
                        String n = e.getProfile().getName();
                        if (q.isEmpty() || n.toLowerCase(Locale.ROOT).contains(q)) l.add(n);
                    });
            } else {
                for (Identifier id : MorphManager.search(morphKind == 0 ? MorphManager.Kind.ENTITY : MorphManager.Kind.BLOCK, q, 400)) l.add(id.toString());
            }
            mlist = l;
        }
        int ly = ry2 + 20, lh = y + h - ly;
        if (lh < 24) return;
        rr(g, x, ly, lw, lh, 8, 0x40000000);
        if (mlist.isEmpty()) { ctxt(g, trim(morphKind == 2 ? "Solo jugadores del servidor actual" : "Sin resultados", lw - 8), x + lw / 2, ly + 10, MUTED); return; }
        int rowH = 18;
        int sc = beginScroll(g, "morph", x + 3, ly + 3, lw - 6, lh - 6, mlist.size() * rowH);
        for (int i = 0; i < mlist.size(); i++) {
            int ry = ly + 3 + i * rowH - sc;
            if (ry + rowH < ly || ry > ly + lh) continue;
            final String id = mlist.get(i);
            if (hover(x + 3, ry, lw - 12, rowH - 2)) rr(g, x + 3, ry, lw - 12, rowH - 2, 6, HOVER);
            txt(g, trim(id, lw - 30), x + 10, ry + 5, TEXT);
            hit(x + 3, ry, lw - 12, rowH - 2, false, () -> {
                Identifier ident = Identifier.tryParse(id);
                String err = morphKind == 2 ? MorphManager.morphPlayer(id)
                        : ident == null ? "Id inválido" : morphKind == 0 ? MorphManager.morphEntity(ident) : MorphManager.morphBlock(ident);
                say(err == null ? "Ahora eres: " + id : err, err != null);
            });
        }
        endScroll(g);
    }

    private static String fmt1(float f) { return String.format(Locale.ROOT, "%.1f", f); }

    // ---------------------------------------------------------------- TEMA

    private void syncTheme() {
        for (Map.Entry<String, TextFieldWidget> e : themeFields.entrySet()) e.getValue().setText(Theme.hex(e.getKey()));
        if (fBg != null) fBg.setText(Theme.data.bgFile);
    }

    private void openBgFolder() {
        try {
            Files.createDirectories(ModelManager.bgDir());
            Util.getOperatingSystem().open(ModelManager.bgDir().toFile());
        } catch (Throwable t) { say("No se pudo abrir la carpeta: " + ModelManager.bgDir(), true); }
    }

    private void drawTheme(DrawContext g, int x, int y, int w, int h) {
        muted(g, "Preajustes", x, y + 2);
        int cx = x + 66;
        for (String pr : Theme.PRESETS) {
            final String pn = pr;
            int cw = textRenderer.getWidth(pr) + 18;
            chip(g, cx, y - 1, cw, pr, false, () -> { Theme.preset(pn); syncTheme(); applyTheme(); });
            cx += cw + 4;
        }
        int top = y + 20, colW = Math.max(200, w / 2), fw = Math.min(90, colW - 128);
        for (int i = 0; i < Theme.KEYS.length; i++) {
            int fx = x + (i / 7) * colW, fy = top + (i % 7) * 22;
            String k = Theme.KEYS[i];
            txt(g, trim(Theme.LABELS[i], 100), fx, fy + 5, TEXT);
            rr(g, fx + 104, fy + 1, 16, 16, 4, 0xFF000000 | (Theme.c(k) & 0xFFFFFF));
            field(g, themeFields.get(k), fx + 124, fy, fw, 18);
        }
        int by = top + 7 * 22 + 6;
        muted(g, "Fondo: imagen (png/jpg), gif o video (mp4/mov). Archivo en la carpeta backgrounds o ruta completa", x, by);
        field(g, fBg, x, by + 12, Math.min(w, 320), 18);
        int bb = by + 36, bx = x;
        bx += btn(g, bx, bb, "Aplicar", 0, () -> { Theme.data.bgFile = fBg.getText().trim(); ModelManager.saveConfig(); Background.load(Theme.data.bgFile); }) + 6;
        bx += btn(g, bx, bb, "Quitar", 1, () -> { Theme.data.bgFile = ""; fBg.setText(""); ModelManager.saveConfig(); Background.clear(); }) + 6;
        bx += btn(g, bx, bb, "Abrir carpeta", 1, this::openBgFolder) + 6;
        btn(g, bx, bb, "Restablecer colores", 1, () -> { Theme.reset(); syncTheme(); applyTheme(); });
        int ay = bb + 26;
        txt(g, "Transparencia del fondo: " + Math.round(Theme.data.bgAlpha * 100) + "%", x, ay + 6, TEXT);
        int ax = x + textRenderer.getWidth("Transparencia del fondo: 100%") + 10;
        btnW(g, ax, ay, 22, 20, "-", 1, true, () -> Theme.data.bgAlpha = Math.max(0f, Theme.data.bgAlpha - 0.05f));
        btnW(g, ax + 26, ay, 22, 20, "+", 1, true, () -> Theme.data.bgAlpha = Math.min(1f, Theme.data.bgAlpha + 0.05f));
        String msg = Background.message();
        if (!msg.isEmpty()) muted(g, trim(msg, w), x, ay + 26);
    }

    // ---------------------------------------------------------------- IMPORTAR

    private void drawImport(DrawContext g, int x, int y, int w, int h) {
        int cy = y;
        dropzone(g, x, cy, w);
        cy += 56;
        muted(g, "Link directo (.bbmodel / .geo.json / texto Base64)", x, cy);
        cy += 11;
        int bw = 96;
        field(g, fUrl, x, cy, w - bw - 6, 20);
        btnW(g, x + w - bw, cy, bw, 20, "Importar link", 0, true, this::importLink);
        cy += 30;
        muted(g, "Nombre (opcional)", x, cy);
        cy += 11;
        field(g, fName, x, cy, Math.min(w, 220), 20);
        cy += 32;
        btn(g, x, cy, "Pegar Base64 / JSON del portapapeles", 0, this::importClipboard);
        cy += 26;
        muted(g, trim("Copia el Base64 del modelo y pulsa el botón. Acepta también data:...;base64,", w), x, cy);
    }

    private String nameHint() { return fName.getText().trim(); }

    private void importLink() {
        String url = fUrl.getText().trim();
        if (url.isEmpty()) { say("Escribe un link primero", true); return; }
        say("Descargando...", false);
        ModelImporter.fromUrl(url, nameHint(), r -> client.execute(() -> finishImport(r)));
    }

    private void importClipboard() {
        String clip = client.keyboard.getClipboard();
        if (clip == null || clip.isBlank()) { say("El portapapeles está vacío", true); return; }
        finishImport(ModelImporter.fromText(clip, nameHint()));
    }

    private void finishImport(ModelImporter.Result r) {
        if (r.error() != null) { say("Error: " + r.error(), true); return; }
        reloadAll();
        BBModel m = ModelManager.MODELS.get(r.file());
        if (m != null) { cur = m; curBone = null; syncFields(); tab = Tab.PARTS; }
        say("Importado: " + r.file(), false);
    }

    // ---------------------------------------------------------------- APLICAR

    private String targetKey() {
        return switch (applyMode) {
            case 0 -> "@self";
            case 1 -> "*";
            default -> fPlayer.getText().trim().toLowerCase(Locale.ROOT);
        };
    }

    private void drawApply(DrawContext g, int x, int y, int w, int h) {
        int cy = y;
        muted(g, "Modelo seleccionado", x, cy);
        cy += 11;
        txt(g, cur == null ? "ninguno" : trim(cur.id, w), x, cy, cur == null ? ERROR : PRIMARY);
        cy += 18;
        muted(g, "Aplicar a", x, cy);
        cy += 12;
        radio(g, x, cy, applyMode == 0, "Yo", () -> applyMode = 0);
        cy += 18;
        radio(g, x, cy, applyMode == 1, "Todos los jugadores", () -> applyMode = 1);
        cy += 18;
        radio(g, x, cy, applyMode == 2, "Jugador:", () -> applyMode = 2);
        if (applyMode == 2) field(g, fPlayer, x + 24 + textRenderer.getWidth("Jugador:"), cy - 4, Math.min(160, w - 100), 18);
        cy += 26;
        int bw = btn(g, x, cy, "Aplicar", 0, this::applyModel);
        int qw = btn(g, x + bw + 6, cy, "Quitar", 1, () -> { ModelManager.CONFIG.assignments.remove(targetKey()); ModelManager.saveConfig(); say("Quitado de: " + targetKey(), false); });
        btn(g, x + bw + 6 + qw + 6, cy, "Copiar comando", 1, this::copyCommand);
        cy += 30;
        muted(g, "Asignaciones activas", x, cy);
        int ly = cy + 12, lh = y + h - ly;
        rr(g, x, ly, w, lh, 8, 0x40000000);
        List<Map.Entry<String, String>> es = new ArrayList<>(ModelManager.CONFIG.assignments.entrySet());
        if (es.isEmpty()) { ctxt(g, "Ninguna todavía", x + w / 2, ly + 10, MUTED); return; }
        int rowH = 20;
        int sc = beginScroll(g, "assign", x + 3, ly + 3, w - 6, lh - 6, es.size() * rowH);
        for (int i = 0; i < es.size(); i++) {
            int ry = ly + 3 + i * rowH - sc;
            if (ry + rowH < ly || ry > ly + lh) continue;
            final String key = es.get(i).getKey();
            String shown = key.equals("@self") ? "Yo" : key.equals("*") ? "Todos" : key;
            txt(g, trim(shown + "  >  " + es.get(i).getValue(), w - 50), x + 10, ry + 5, TEXT);
            btnW(g, x + w - 30, ry + 1, 20, 16, "x", 1, true, () -> { ModelManager.CONFIG.assignments.remove(key); ModelManager.saveConfig(); });
        }
        endScroll(g);
    }

    private void applyModel() {
        if (cur == null) { say("Elige un modelo primero", true); return; }
        String k = targetKey();
        if (k.isEmpty()) { say("Escribe el nombre del jugador", true); return; }
        ModelManager.CONFIG.assignments.put(k, cur.id);
        ModelManager.saveConfig();
        say("Modelo aplicado a: " + (k.equals("@self") ? "ti" : k), false);
    }

    // ================================================================ acciones

    private void say(String s, boolean err) { status = s; statusErr = err; }

    private void openFolder() {
        try {
            Files.createDirectories(ModelManager.modelsDir());
            Util.getOperatingSystem().open(ModelManager.modelsDir().toFile());
        } catch (Throwable t) { say("No se pudo abrir la carpeta: " + ModelManager.modelsDir(), true); }
    }

    private void reloadAll() {
        ModelManager.saveConfig();
        String id = cur == null ? null : cur.id;
        ModelManager.reload();
        cur = id == null ? null : ModelManager.MODELS.get(id);
        if (cur == null && !ModelManager.MODELS.isEmpty()) cur = ModelManager.MODELS.values().iterator().next();
        curBone = null;
        syncFields();
        say("Modelos cargados: " + ModelManager.MODELS.size(), false);
    }

    /** Arrastrar y soltar archivos sobre la ventana. */
    @Override
    public void filesDragged(List<Path> paths) {
        int ok = 0, bad = 0;
        String first = null;
        try {
            Path dir = ModelManager.modelsDir();
            Files.createDirectories(dir);
            for (Path p : paths) {
                String fn = p.getFileName().toString();
                String l = fn.toLowerCase(Locale.ROOT);
                boolean model = l.endsWith(".bbmodel") || l.endsWith(".morphzuka") || l.endsWith(".geo.json") || l.endsWith(".cpmproject");
                boolean extra = l.endsWith(".png") || l.endsWith(".animation.json");
                if (!model && !extra) { bad++; continue; }
                try {
                    Files.copy(p, dir.resolve(fn), StandardCopyOption.REPLACE_EXISTING);
                    ok++;
                    if (model && first == null) first = fn;
                } catch (Exception e) { bad++; }
            }
        } catch (Exception e) {
            say("Error copiando archivos: " + e.getMessage(), true);
            return;
        }
        if (ok > 0) {
            reloadAll();
            if (first != null && ModelManager.MODELS.containsKey(first)) {
                cur = ModelManager.MODELS.get(first);
                curBone = null;
                syncFields();
                tab = Tab.PARTS;
            }
            say("Importados " + ok + " archivo(s)" + (bad > 0 ? " (" + bad + " ignorados)" : ""), false);
        } else {
            say("Formato no soportado (usa .bbmodel, .geo.json, .cpmproject)", true);
        }
    }

    // ================================================================ input

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        if (button == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (x >= h.x && x < h.x + h.w && y >= h.y && y < h.y + h.h
                        && (h.clip == null || (x >= h.clip[0] && x < h.clip[2] && y >= h.clip[1] && y < h.clip[3]))) {
                    if (!h.field) setFocused(null);
                    h.r.run();
                    return true;
                }
            }
            setFocused(null);
        }
        return super.mouseClicked(x, y, button);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double hAmount, double vAmount) {
        for (int i = areas.size() - 1; i >= 0; i--) {
            Area a = areas.get(i);
            if (x >= a.x && x < a.x + a.w && y >= a.y && y < a.y + a.h) {
                int s = scroll.getOrDefault(a.key, 0) - (int) Math.signum(vAmount) * 16;
                scroll.put(a.key, Math.max(0, Math.min(a.max, s)));
                return true;
            }
        }
        return super.mouseScrolled(x, y, hAmount, vAmount);
    }

    @Override
    public boolean mouseDragged(double x, double y, int button, double dx, double dy) {
        if (pvDrag && button == 0) { pvYaw += (float) dx * 1.6f; return true; }
        return super.mouseDragged(x, y, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double x, double y, int button) {
        pvDrag = false;
        return super.mouseReleased(x, y, button);
    }

    @Override
    public void removed() {
        MorphPreview.stop();
        super.removed();
    }

    @Override
    public void close() {
        ModelManager.saveConfig();
        client.setScreen(parent);
    }
}
