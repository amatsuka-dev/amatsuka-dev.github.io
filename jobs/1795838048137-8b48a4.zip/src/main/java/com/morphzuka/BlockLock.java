package com.morphzuka;

import com.morphzuka.model.ModelManager;
import com.morphzuka.render.MorphManager;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Jugador-bloque: QUIETO en el suelo (agachado, o simplemente de pie si el anclaje automatico esta activo) se va llenando una barra sobre la hotbar; al llenarse te centras en la casilla de bloque
 * y no puedes moverte mientras sigas agachado, como un bloque colocado. Al soltar la tecla hay un enfriamiento antes de poder anclarte otra vez.
 * Solo cuando vas transformado en bloque. El bloqueo de teclas lo hace KeyboardInputMixin (lee {@link #locked}).
 */
public final class BlockLock {
    private BlockLock() {}

    /** Ticks quieto y agachado hasta anclarse / ticks de enfriamiento tras soltarse (20 ticks = 1 s). */
    public static final int CHARGE = 30, COOLDOWN = 60;

    /** Enfriamiento corto tras soltarse con una tecla de movimiento (anclaje automatico): no estorba al andar. */
    public static final int AUTO_COOLDOWN = 10;

    public static volatile boolean locked;
    public static int charge, cooldown;
    /** true = te anclaste agachado (se suelta al soltar la tecla); false = anclaje automatico por quedarte quieto (se suelta al moverte). */
    private static boolean bySneak;

    public static void tick(MinecraftClient c) {
        ClientPlayerEntity p = c.player;
        MorphManager.State s = MorphManager.state();
        if (p == null || s == null || s.kind != MorphManager.Kind.BLOCK || p.isSpectator()) { reset(); return; }
        boolean grounded = p.isOnGround() && !p.getAbilities().flying && !p.hasVehicle();
        boolean sneakKey = c.options.sneakKey.isPressed();
        boolean sneak = c.currentScreen == null && sneakKey && grounded;
        boolean idle = ModelManager.CONFIG.autoAnchor && c.currentScreen == null && !sneakKey && grounded;   // de pie, sin agacharte
        boolean keys = c.options.forwardKey.isPressed() || c.options.backKey.isPressed() || c.options.leftKey.isPressed()
                || c.options.rightKey.isPressed() || c.options.jumpKey.isPressed();

        if (locked) {
            if (bySneak) {
                if (sneak) { snap(p); return; }
                locked = false;                  // solto la tecla: se libera y empieza el enfriamiento
                cooldown = COOLDOWN;
                charge = 0;
                return;
            }
            // anclaje automatico: se mantiene mientras no toques ninguna tecla de movimiento ni te agaches
            if (!keys && !sneakKey && grounded && ModelManager.CONFIG.autoAnchor) { snap(p); return; }
            locked = false;
            cooldown = AUTO_COOLDOWN;
            charge = 0;
            return;
        }
        if (cooldown > 0) { cooldown--; charge = 0; return; }

        boolean still = !keys && Math.hypot(p.getX() - p.prevX, p.getZ() - p.prevZ) < 0.01;
        if ((sneak || idle) && still) {
            if (++charge >= CHARGE) { charge = CHARGE; locked = true; bySneak = sneak; snap(p); }
        } else if (charge > 0) {
            charge = sneak ? 0 : Math.max(0, charge - 3);   // moverte la vacia; soltar la tecla la baja rapido
        }
    }

    private static void reset() { locked = false; charge = 0; cooldown = 0; bySneak = false; }

    /** Se acomoda en 2-3 ticks al centro de la casilla, sin salto brusco. */
    private static void snap(ClientPlayerEntity p) {
        double cx = Math.floor(p.getX()) + 0.5, cz = Math.floor(p.getZ()) + 0.5;
        double nx = p.getX(), nz = p.getZ();
        if (Math.abs(cx - nx) < 0.01 && Math.abs(cz - nz) < 0.01) { nx = cx; nz = cz; }
        else { nx = MathHelper.lerp(0.6, nx, cx); nz = MathHelper.lerp(0.6, nz, cz); }
        p.setPosition(nx, p.getY(), nz);
        Vec3d v = p.getVelocity();
        p.setVelocity(0, v.y, 0);
    }

    // ------------------------------------------------------------ barra sobre la hotbar

    public static void registerHud() {
        HudRenderCallback.EVENT.register((g, tick) -> draw(g));
    }

    private static void draw(DrawContext g) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        if (!locked && charge <= 0 && cooldown <= 0) return;
        float f;
        int col;
        String label;
        if (locked) { f = 1f; col = 0xFF58D68D; label = "Anclado"; }
        else if (cooldown > 0) { f = cooldown / (float) COOLDOWN; col = 0xFF8A8F98; label = "Enfriando"; }
        else { f = charge / (float) CHARGE; col = 0xFFF5B041; label = "Quieto..."; }
        int w = 90, h = 6;
        int x = g.getScaledWindowWidth() / 2 - w / 2;
        int y = g.getScaledWindowHeight() - 66;
        g.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xC0000000);
        g.fill(x, y, x + w, y + h, 0xFF2B2B2B);
        g.fill(x, y, x + Math.round(w * MathHelper.clamp(f, 0f, 1f)), y + h, col);
        g.drawCenteredTextWithShadow(mc.textRenderer, label, g.getScaledWindowWidth() / 2, y - 10, 0xFFFFFFFF);
    }
}
