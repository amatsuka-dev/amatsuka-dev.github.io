package com.morphzuka.render;

import com.morphzuka.model.ModelManager;
import com.morphzuka.net.ClientNet;
import com.morphzuka.net.Payloads;
import com.morphzuka.net.Payloads.MorphPayload;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import io.netty.buffer.Unpooled;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Morpher: conviertete en cualquier entidad (vanilla o de mod), bloque u otro jugador.
 * Lo que elijas se manda al servidor (si tiene el mod), que lo valida y lo retransmite: los demas jugadores con el mod
 * te ven con esa forma. Sin el mod en el servidor solo lo ves tu.
 */
public final class MorphManager {
    private MorphManager() {}

    public enum Kind { ENTITY, BLOCK, PLAYER }

    public static final class State {
        public Kind kind;
        public Identifier id;
        public String name = "";
        public BlockState block;
        public Entity entity;
        public float w = 0.6f, h = 1.8f, eye = 1.62f;
        /** Datos sincronizados de la entidad copiada (especie, variante, color...). null = entidad generica. */
        public byte[] data;
        /** Solo bloques: giro en pasos de 90 grados (0..3) hacia donde quiere el jugador (paso 39). */
        public int rot;
    }

    private static State self;
    public static boolean copyHitbox = true;

    public static boolean active() { return self != null; }

    /** Forma actual de ese jugador (la tuya o la que dijo el servidor), o null si va con su aspecto normal. */
    public static State stateOf(AbstractClientPlayerEntity p) {
        return p == MinecraftClient.getInstance().player ? self : remote(p.getUuid());
    }
    public static State state() { return self; }

    public static String key() { return self == null ? null : keyOf(self); }

    private static String keyOf(State s) {
        return s.kind + ":" + (s.kind == Kind.PLAYER ? s.name : String.valueOf(s.id));
    }

    /** Hay alguna forma (la tuya o la de otro jugador) con entidad propia que dibujar. */
    public static boolean hasMorphEntities() { return self != null || !REMOTE_BUILT.isEmpty(); }

    /** Clave de ajustes ({@link EntityCfg}) de la forma a la que pertenece esa entidad, o null si no es de un morph. */
    public static String keyOfEntity(Entity e) {
        State s = self;
        if (s != null && s.entity == e) return keyOf(s);
        for (State r : REMOTE_BUILT.values()) if (r.entity == e) return keyOf(r);
        return null;
    }

    /** Morphs de otros jugadores (lo que dijo el servidor) y su entidad ya construida para dibujarla. */
    private static final Map<UUID, MorphPayload> REMOTE_REQ = new HashMap<>();
    private static final Map<UUID, State> REMOTE_BUILT = new HashMap<>();

    public static void clear() { self = null; publish(); }

    /** Avisa al servidor de la forma actual (o de que volviste a la normal). No hace nada si el servidor no tiene el mod. */
    private static void publish() {
        State s = self;
        if (s == null) ClientNet.sendMorph(Payloads.KIND_NONE, "", null);
        else ClientNet.sendMorph(kindByte(s.kind), s.kind == Kind.PLAYER ? s.name : String.valueOf(s.id),
                s.kind == Kind.BLOCK ? new byte[]{(byte) (s.rot & 3)} : s.data);   // en un bloque, los datos son su giro
    }

    /** Gira tu bloque 90 grados (steps = 1 a la derecha, -1 a la izquierda) y avisa a los demas. Devuelve false si no vas de bloque. */
    public static boolean rotateBlock(int steps) {
        State s = self;
        if (s == null || s.kind != Kind.BLOCK) return false;
        s.rot = (s.rot + steps) & 3;
        publish();
        return true;
    }

    /** Al entrar a un servidor: volver a decir quien eres. */
    public static void republish() { if (self != null) publish(); }

    private static byte kindByte(Kind k) {
        return switch (k) { case ENTITY -> Payloads.KIND_ENTITY; case BLOCK -> Payloads.KIND_BLOCK; case PLAYER -> Payloads.KIND_PLAYER; };
    }

    /** Respuesta del servidor. Para otros jugadores guarda su forma; para ti solo vale si el servidor la RECHAZO. */
    public static void setRemote(MorphPayload p) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.player.getUuid().equals(p.who())) {
            if (p.kind() == Payloads.KIND_NONE && self != null) {
                self = null;   // el servidor no permite morph: vuelves a la forma normal (sin volver a avisar)
                mc.player.sendMessage(Text.literal("El servidor no permite transformarse"), true);
            }
            return;
        }
        REMOTE_BUILT.remove(p.who());
        if (p.kind() == Payloads.KIND_NONE) REMOTE_REQ.remove(p.who());
        else REMOTE_REQ.put(p.who(), p);
    }

    public static void clearRemotes() { REMOTE_REQ.clear(); REMOTE_BUILT.clear(); FROZEN.clear(); }

    private static State remote(UUID u) {
        MorphPayload r = REMOTE_REQ.get(u);
        if (r == null) return null;
        State s = REMOTE_BUILT.get(u);
        if (s == null) {
            s = buildRemote(r);
            if (s == null) { REMOTE_REQ.remove(u); return null; }
            REMOTE_BUILT.put(u, s);
        }
        return s;
    }

    private static State buildRemote(MorphPayload r) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return null;
        try {
            switch (r.kind()) {
                case Payloads.KIND_ENTITY: {
                    Identifier id = Identifier.tryParse(r.id());
                    EntityType<?> t = id == null ? null : Registries.ENTITY_TYPE.getOrEmpty(id).orElse(null);
                    if (t == null || t == EntityType.PLAYER) return null;
                    State st = entityState(mc, t, id);
                    if (st != null && r.data().length > 0) { applyData(st.entity, r.data()); refreshDims(st, st.entity); st.data = r.data(); }
                    return st;
                }
                case Payloads.KIND_BLOCK: {
                    Identifier id = Identifier.tryParse(r.id());
                    var b = id == null ? null : Registries.BLOCK.getOrEmpty(id).orElse(null);
                    if (b == null) return null;
                    State bs = blockState(b.getDefaultState());
                    if (bs != null && r.data().length > 0) bs.rot = r.data()[0] & 3;   // el giro que eligio ese jugador
                    return bs;
                }
                case Payloads.KIND_PLAYER: {
                    PlayerListEntry le = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(r.id());
                    return le == null ? null : playerState(mc, le);
                }
                default: return null;
            }
        } catch (Throwable t) {
            ModelManager.LOG.warn("No se pudo construir el morph remoto {}: {}", r.id(), t.toString());
            return null;
        }
    }

    private static State entityState(MinecraftClient mc, EntityType<?> t, Identifier id) {
        Entity e = t.create(mc.world);
        if (e == null) return null;
        State s = new State();
        s.kind = Kind.ENTITY;
        s.id = id;
        s.entity = e;
        EntityDimensions d = t.getDimensions();
        s.w = d.width();
        s.h = d.height();
        s.eye = d.eyeHeight();
        return s;
    }

    private static final int MAX_DATA = Payloads.MAX_MORPH_DATA;

    /** Tamano segun la propia entidad: depende de la especie / tamano / bebe, no solo del tipo. */
    private static void refreshDims(State s, Entity src) {
        try {
            EntityDimensions d = src.getDimensions(EntityPose.STANDING);
            s.w = d.width(); s.h = d.height(); s.eye = d.eyeHeight();
        } catch (Throwable ignored) {}
    }

    /**
     * Copia los datos sincronizados de la entidad (los mismos que el servidor le manda al cliente), salvo los comunes de
     * Entity (invisible, en llamas, pose...) para no heredar estados del bicho. Funciona con cualquier mod, p. ej. Cobblemon
     * guarda ahi la especie y los aspectos del Pokemon.
     */
    private static byte[] captureData(Entity e) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            List<DataTracker.SerializedEntry<?>> list = e.getDataTracker().getChangedEntries();
            if (mc.world == null || list == null || list.isEmpty()) return null;
            RegistryByteBuf buf = new RegistryByteBuf(Unpooled.buffer(), mc.world.getRegistryManager());
            for (DataTracker.SerializedEntry<?> en : list) if (en.id() >= 8) en.write(buf);
            buf.writeByte(255);
            if (buf.readableBytes() > MAX_DATA) return null;   // demasiado grande para mandarlo: se queda como entidad generica
            byte[] out = new byte[buf.readableBytes()];
            buf.readBytes(out);
            return out;
        } catch (Throwable t) {
            ModelManager.LOG.warn("No se pudieron leer los datos de la entidad: {}", t.toString());
            return null;
        }
    }

    private static void applyData(Entity e, byte[] data) {
        MinecraftClient mc = MinecraftClient.getInstance();
        RegistryByteBuf buf = new RegistryByteBuf(Unpooled.wrappedBuffer(data), mc.world.getRegistryManager());
        List<DataTracker.SerializedEntry<?>> list = new ArrayList<>();
        int i;
        while ((i = buf.readUnsignedByte()) != 255) list.add(DataTracker.SerializedEntry.fromBuf(buf, i));
        e.getDataTracker().writeUpdatedEntries(list);   // igual que al recibir un EntityTrackerUpdate: dispara onTrackedDataSet
    }

    private static State blockState(BlockState st) {
        State s = new State();
        s.kind = Kind.BLOCK;
        s.id = Registries.BLOCK.getId(st.getBlock());
        s.block = st;
        s.w = 0.98f;
        s.h = 0.98f;
        s.eye = 0.5f;
        return s;
    }

    private static State playerState(MinecraftClient mc, PlayerListEntry le) {
        State s = new State();
        s.kind = Kind.PLAYER;
        s.name = le.getProfile().getName();
        s.entity = new OtherClientPlayerEntity(mc.world, le.getProfile());
        return s;
    }

    /** @return mensaje de error, o null si salio bien */
    public static String morphEntity(Identifier id) { return morphEntity(id, null); }

    /** Con 'template' (una entidad real del mundo) copia tambien sus datos: asi un Pokemon de Cobblemon sale con su especie. */
    public static String morphEntity(Identifier id, Entity template) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return "No estás en un mundo";
        EntityType<?> t = Registries.ENTITY_TYPE.getOrEmpty(id).orElse(null);
        if (t == null) return "Entidad desconocida: " + id;
        if (t == EntityType.PLAYER) return "Para copiar a un jugador usa la pestaña Jugador";
        State s;
        try { s = entityState(mc, t, id); } catch (Throwable ex) { return "No se pudo crear: " + ex.getMessage(); }
        if (s == null) return "Esa entidad no se puede crear en cliente";
        if (template != null) {
            byte[] d = captureData(template);
            if (d != null) {
                try { applyData(s.entity, d); s.data = d; }
                catch (Throwable ex) { ModelManager.LOG.warn("No se pudieron copiar los datos de {}: {}", id, ex.toString()); }
            }
            refreshDims(s, template);
        }
        self = s;
        publish();
        return null;
    }

    public static String morphBlock(BlockState st) {
        self = blockState(st);
        publish();
        return null;
    }

    public static String morphBlock(Identifier id) {
        var b = Registries.BLOCK.getOrEmpty(id).orElse(null);
        if (b == null) return "Bloque desconocido: " + id;
        return morphBlock(b.getDefaultState());
    }

    public static String morphPlayer(String name) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.getNetworkHandler() == null) return "No estás en un mundo";
        PlayerListEntry le = mc.getNetworkHandler().getPlayerListEntry(name);
        if (le == null) return "Jugador no encontrado: " + name;
        self = playerState(mc, le);
        publish();
        return null;
    }

    /** Te conviertes en la entidad o jugador indicado (lo usa la RoZuka). */
    public static void copyEntity(MinecraftClient mc, Entity e) {
        if (mc.player == null || mc.world == null) return;
        String err, what;
        if (e instanceof PlayerEntity pe) { err = morphPlayer(pe.getGameProfile().getName()); what = pe.getGameProfile().getName(); }
        else { err = morphEntity(Registries.ENTITY_TYPE.getId(e.getType()), e); what = e.getType().getName().getString(); }
        mc.player.sendMessage(Text.literal(err != null ? "Morph: " + err : "Ahora eres: " + what), true);
    }

    /** Te conviertes en el bloque de esa posicion (lo usa la RoZuka). */
    public static void copyBlock(MinecraftClient mc, BlockPos pos) {
        if (mc.player == null || mc.world == null) return;
        BlockState st = mc.world.getBlockState(pos);
        if (st.isAir()) { mc.player.sendMessage(Text.literal("Morph: ahí no hay nada"), true); return; }
        String err = morphBlock(st);
        mc.player.sendMessage(Text.literal(err != null ? "Morph: " + err : "Ahora eres: " + st.getBlock().getName().getString()), true);
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null) return;
        State s = self;
        if (s != null) tickLimbs(s, mc.player);
        if (mc.world == null) return;
        for (Map.Entry<UUID, State> e : REMOTE_BUILT.entrySet()) {
            PlayerEntity p = mc.world.getPlayerByUuid(e.getKey());
            if (p != null) tickLimbs(e.getValue(), p);
        }
    }

    private static void tickLimbs(State s, PlayerEntity p) {
        if (com.morphzuka.ui.MorphPreview.simWalk) return;   // la vista previa mueve las patas mientras prueba "Caminar"
        if (s.entity instanceof LivingEntity le) {
            double dx = p.getX() - p.prevX, dz = p.getZ() - p.prevZ;
            float f = Math.min((float) Math.sqrt(dx * dx + dz * dz) * 4f, 1f);
            le.limbAnimator.updateLimbs(f, 0.4f);
        }
        // animacion propia del mob (salto de conejo, aleteo, golpe de golem...): el muneco no esta en el mundo, lo ejecutamos aqui
        if (s.kind == Kind.ENTITY && s.entity != null) MorphAnim.tickFor(s.entity, p, EntityCfg.of(keyOf(s)).nativeAnim);
    }

    /** {ancho, alto, altura de ojos} copiados del morph, o null si no aplica. */
    public static float[] hitbox() {
        State s = self;
        if (s == null || !copyHitbox) return null;
        return new float[]{s.w, s.h, s.eye};
    }

    private static void sync(Entity e, AbstractClientPlayerEntity p) {
        e.setPosition(p.getX(), p.getY(), p.getZ());
        e.prevX = p.prevX; e.prevY = p.prevY; e.prevZ = p.prevZ;
        e.setYaw(p.getYaw());
        e.prevYaw = p.prevYaw;
        e.setPitch(p.getPitch());
        e.prevPitch = p.prevPitch;
        e.age = p.age;
        e.setOnGround(p.isOnGround());
        if (e instanceof LivingEntity le) {
            le.bodyYaw = p.bodyYaw;
            le.prevBodyYaw = p.prevBodyYaw;
            le.headYaw = p.headYaw;
            le.prevHeadYaw = p.prevHeadYaw;
            le.handSwingProgress = p.handSwingProgress;
            le.lastHandSwingProgress = p.lastHandSwingProgress;
        }
        if (e instanceof PlayerEntity pe) {
            pe.setPose(p.getPose());
            pe.setSneaking(p.isSneaking());
            pe.setSprinting(p.isSprinting());
        }
    }

    // ---- color de bioma fijado mientras estas anclado (paso 38)
    private static final class Frozen {
        final BlockPos pos; final BlockState st; final int grass, foliage, water;
        Frozen(BlockPos pos, BlockState st, int grass, int foliage, int water) { this.pos = pos; this.st = st; this.grass = grass; this.foliage = foliage; this.water = water; }
    }
    private static final Map<UUID, Frozen> FROZEN = new HashMap<>();

    /** Al anclarte se toma el color de bioma (cesped, hojas, agua) de tu casilla y se mantiene tal cual hasta que te muevas. */
    private static Frozen freeze(AbstractClientPlayerEntity p, BlockState st, BlockPos pos) {
        Frozen f = FROZEN.get(p.getUuid());
        if (f != null && f.pos.equals(pos) && f.st == st) return f;
        var w = p.getWorld();
        f = new Frozen(pos, st,
                w.getColor(pos, net.minecraft.client.color.world.BiomeColors.GRASS_COLOR),
                w.getColor(pos, net.minecraft.client.color.world.BiomeColors.FOLIAGE_COLOR),
                w.getColor(pos, net.minecraft.client.color.world.BiomeColors.WATER_COLOR));
        FROZEN.put(p.getUuid(), f);
        return f;
    }

    /** Colores de bioma de la casilla donde estas ahora mismo (se recalculan cada fotograma mientras te mueves). */
    private static Frozen live(AbstractClientPlayerEntity p, BlockState st, BlockPos pos) {
        var w = p.getWorld();
        return new Frozen(pos, st,
                w.getColor(pos, net.minecraft.client.color.world.BiomeColors.GRASS_COLOR),
                w.getColor(pos, net.minecraft.client.color.world.BiomeColors.FOLIAGE_COLOR),
                w.getColor(pos, net.minecraft.client.color.world.BiomeColors.WATER_COLOR));
    }

    /**
     * El mundo, pero con los colores de bioma fijos. Se detecta el metodo por sus tipos (BlockPos, ColorResolver) -> int y no por nombre,
     * porque fuera del modo desarrollo los nombres de Minecraft estan ofuscados. Todo lo demas (luz, bloques vecinos) sigue siendo el mundo real.
     */
    private static net.minecraft.world.BlockRenderView frozenView(net.minecraft.world.BlockRenderView real, Frozen f) {
        return (net.minecraft.world.BlockRenderView) java.lang.reflect.Proxy.newProxyInstance(
                net.minecraft.world.BlockRenderView.class.getClassLoader(),
                new Class<?>[]{net.minecraft.world.BlockRenderView.class},
                (proxy, method, args) -> {
                    Class<?>[] pt = method.getParameterTypes();
                    if (pt.length == 2 && pt[1] == net.minecraft.world.biome.ColorResolver.class && method.getReturnType() == int.class) {
                        Object r = args[1];
                        if (r == net.minecraft.client.color.world.BiomeColors.GRASS_COLOR) return f.grass;
                        if (r == net.minecraft.client.color.world.BiomeColors.FOLIAGE_COLOR) return f.foliage;
                        if (r == net.minecraft.client.color.world.BiomeColors.WATER_COLOR) return f.water;
                    }
                    try { return method.invoke(real, args); }
                    catch (java.lang.reflect.InvocationTargetException e) { throw e.getCause(); }
                });
    }

    /** Anclado = quieto y agachado como bloque. Tu propio estado es exacto; el de los demas se deduce (en el suelo y sin moverse). */
    private static boolean anchored(AbstractClientPlayerEntity p, MinecraftClient mc) {
        if (p == mc.player) return com.morphzuka.BlockLock.locked;
        return p.isOnGround() && Math.hypot(p.getX() - p.prevX, p.getZ() - p.prevZ) < 0.01;
    }

    /**
     * Bloque dibujado como uno colocado en el mundo: luz suave por cara (tomada de las casillas vecinas, con sombras de oclusion) y color
     * del bioma (cesped, hojas, agua...), igual que FallingBlockEntityRenderer. Los bloques que no son un modelo normal (cofres,
     * camas...) usan la luz de la casilla.
     */
    private static void renderWorldBlock(AbstractClientPlayerEntity p, BlockState st, MatrixStack m, VertexConsumerProvider vcp, int light, boolean anchored) {
        MinecraftClient mc = MinecraftClient.getInstance();
        var world = p.getWorld();
        BlockPos pos = BlockPos.ofFloored(p.getX(), p.getY() + 0.001, p.getZ());
        try {
            if (st.getRenderType() == net.minecraft.block.BlockRenderType.MODEL) {
                var brm = mc.getBlockRenderManager();
                brm.getModelRenderer().render(frozenView(world, anchored ? freeze(p, st, pos) : live(p, st, pos)), brm.getModel(st), st, pos, m,
                        vcp.getBuffer(net.minecraft.client.render.RenderLayers.getMovingBlockLayer(st)), false,
                        net.minecraft.util.math.random.Random.create(), st.getRenderingSeed(pos), OverlayTexture.DEFAULT_UV);
                return;
            }
            if (anchored) light = net.minecraft.client.render.WorldRenderer.getLightmapCoordinates(world, pos);   // en movimiento se usa la luz suave de la entidad
        } catch (Throwable t) {
            ModelManager.LOG.warn("Bloque con luz de mundo fallo, se usa el dibujo simple: {}", t.toString());
        }
        mc.getBlockRenderManager().renderBlockAsEntity(st, m, vcp, light, OverlayTexture.DEFAULT_UV);
    }

    /** Dibuja el morph en lugar del jugador. Devuelve true si se encargo del render. */
    public static boolean render(AbstractClientPlayerEntity p, float yaw, float td, MatrixStack m, VertexConsumerProvider vcp, int light) {
        MinecraftClient mc = MinecraftClient.getInstance();
        State s = p == mc.player ? self : remote(p.getUuid());
        if (s == null) return false;
        float sc = Transition.scale(p.getUuid());
        m.push();
        try {
            m.scale(sc, sc, sc);
            if (s.kind == Kind.BLOCK) {
                if (s.rot != 0) m.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(90f * s.rot));   // giro elegido, alrededor del centro
                m.translate(-0.5, 0, -0.5);
                boolean anch = anchored(p, mc);
                if (!anch) FROZEN.remove(p.getUuid());   // te moviste: el color de bioma fijado se suelta
                renderWorldBlock(p, s.block, m, vcp, light, anch);   // siempre con el color del bioma (cesped, hojas, agua...); anclado ademas fija luz y color
            } else {
                sync(s.entity, p);
                float lift = MorphAnim.lift(s.entity, td);          // el conejo sube al saltar (solo visual)
                if (lift != 0f) m.translate(0f, lift, 0f);
                mc.getEntityRenderDispatcher().render(s.entity, 0, 0, 0, yaw, td, m, vcp, light);
            }
            return true;
        } catch (Throwable t) {
            ModelManager.LOG.warn("Morph fallo, se desactiva: {}", t.toString());
            if (p == mc.player) clear(); else { REMOTE_REQ.remove(p.getUuid()); REMOTE_BUILT.remove(p.getUuid()); }
            return false;
        } finally {
            m.pop();
        }
    }

    public static List<Identifier> search(Kind kind, String q, int max) {
        String s = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        List<Identifier> out = new ArrayList<>();
        Iterable<Identifier> ids = kind == Kind.BLOCK ? Registries.BLOCK.getIds() : Registries.ENTITY_TYPE.getIds();
        for (Identifier id : ids) {
            if (kind == Kind.ENTITY && id.equals(Registries.ENTITY_TYPE.getId(EntityType.PLAYER))) continue;
            if (s.isEmpty() || id.toString().contains(s)) out.add(id);
        }
        out.sort(Identifier::compareTo);
        return out.size() > max ? out.subList(0, max) : out;
    }
}
