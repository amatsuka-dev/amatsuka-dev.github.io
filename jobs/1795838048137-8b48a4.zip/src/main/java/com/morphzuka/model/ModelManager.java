package com.morphzuka.model;

import com.morphzuka.Role;
import com.morphzuka.ui.Theme;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public final class ModelManager {
    public static final Logger LOG = LoggerFactory.getLogger("morphzuka");
    public static final Map<String, BBModel> MODELS = new LinkedHashMap<>();
    public static Config CONFIG = new Config();
    private static boolean cfgLoaded;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    /** Biblioteca global de animaciones de jugador (carpeta morphzuka/animations/), usable con cualquier modelo. */
    public static final Map<String, BBModel.Anim> LIB = new LinkedHashMap<>();

    public static final String[] STATES = AnimStates.keys();
    public static final String[] STATE_LABELS = AnimStates.labels();

    public static final String CAT_ATTACK = "ATTACK", CAT_GESTURE = "GESTURE", CAT_SLIDER = "SLIDER";
    public static final String CAT_TOGGLE = "TOGGLE", CAT_POSE = "POSE", CAT_SETUP = "SETUP";
    private static final String[] CATS = {null, CAT_ATTACK, CAT_GESTURE, CAT_SLIDER, CAT_TOGGLE, CAT_POSE, CAT_SETUP};

    public static String catLabel(String c) {
        return switch (c) { case CAT_ATTACK -> "Ataque"; case CAT_GESTURE -> "Gesto"; case CAT_SLIDER -> "Slider"; case CAT_TOGGLE -> "Toggle"; case CAT_POSE -> "Pose"; case CAT_SETUP -> "Inicio"; default -> "-"; };
    }

    public static void cycleCat(Settings s, String anim) {
        String cur = s.animCats.get(anim);
        int i = 0;
        for (int k = 0; k < CATS.length; k++) if (Objects.equals(CATS[k], cur)) i = k;
        String next = CATS[(i + 1) % CATS.length];
        if (next == null) s.animCats.remove(anim); else s.animCats.put(anim, next);
    }

    /** Objeto de ejemplo (bloque, espada o item) vinculado a un grupo, solo para previsualizar en el Editor 3D. */
    public static class Prop {
        public String id = "objeto1";
        public String kind = "ITEM";                 // BLOCK | SWORD | ITEM
        public String ref = "minecraft:apple";       // id del bloque (BLOCK) o del item (SWORD / ITEM)
        public String bone;                          // grupo al que esta vinculado (null = el modelo)
        public float[] pos = {0, 0, 0};              // px, relativo al pivote del grupo
        public float[] rot = {0, 0, 0};              // grados
        public float[] scale = {1, 1, 1};            // 1 = 16 px de lado
        public boolean visible = true;
        public boolean gripPivot = true;             // solo manos: rotar / escalar gira alrededor del agarre del item (false = alrededor del pivote del grupo, como antes)
        public transient Object cache;               // BlockState / ItemStack ya resuelto (no se guarda)
        public transient String cacheKey;
    }

    public static class Settings {
        public List<Prop> props = new ArrayList<>();            // objetos de ejemplo vinculados a grupos
        public Map<String, String> roles = new HashMap<>();     // hueso -> Role
        public Map<String, float[]> pivots = new HashMap<>();   // hueso -> pivote override
        public Map<String, float[]> offsets = new HashMap<>();  // hueso -> desplazamiento (px)
        public Map<String, float[]> rotOffsets = new HashMap<>(); // hueso -> rotacion extra (grados)
        public Map<String, float[]> scales = new HashMap<>();    // hueso -> escala XYZ (1 = normal), editor 3D
        public Set<String> hidden = new HashSet<>();            // huesos ocultos
        // ---- nombres propios (solo en los ajustes: el archivo del modelo no se toca)
        public Map<String, String> names = new HashMap<>();      // hueso -> nombre elegido
        public Map<String, String> cubeNames = new HashMap<>();  // bloque (hueso#indice) -> nombre elegido
        // ---- edicion por bloque (misma idea que por parte; la clave es hueso#indice)
        public Map<String, float[]> cubeOffsets = new HashMap<>(); // desplazamiento (px)
        public Map<String, float[]> cubeRots = new HashMap<>();    // rotacion extra (grados)
        public Map<String, float[]> cubeScales = new HashMap<>();  // escala XYZ (1 = normal)
        public Map<String, float[]> cubePivots = new HashMap<>();  // pivote propio del bloque (px)
        public Map<String, String> anims = new HashMap<>();     // estado -> animacion
        public Map<String, String> animCats = new HashMap<>();  // animacion -> ATTACK | GESTURE | SLIDER (ausente = comando)
        public float scale = 1f;
        public boolean followHead = true;   // la cabeza sigue la camara
        public boolean followArms = true;   // los brazos hacen el ataque vanilla
        public boolean hitboxOn;
        public boolean hitboxAuto;           // la hitbox se calcula sola a partir del modelo real
        public float[] hitbox = {0.6f, 1.8f, 0.6f}; // X, Y, Z
        public float eye;                    // altura de ojos (0 = automatica)
        public Map<String, String> animModes = new HashMap<>(); // animacion -> LOOP | ONCE | HOLD (ausente = segun el archivo)

        public float blend = 0.2f;           // segundos de transicion suave entre animaciones (0 = brusco)

        // ---- fisicas de rebote
        public boolean physicsOn;
        public float physicsIntensity = 1f;
        public boolean physicsBody;          // el cuerpo entero hace squash/stretch al saltar y aterrizar (apagado por defecto: las fisicas son solo de las partes elegidas)
        public Integer physVer;              // null = ajustes anteriores al paso 22
        public Set<String> physBones = new HashSet<>();
        public boolean physInit;

        // ---- UV
        // ---- textura por parte: hueso -> "MODEL" | "SKIN" (skin del jugador) | "FILE:nombre.png" (morphzuka/skins/); ausente = hereda del grupo padre
        public Map<String, String> partTex = new HashMap<>();

        public int uvW, uvH;                 // resolucion UV elegida (0 = la del archivo)
        public boolean uvKeep = true;        // al cambiar la resolucion, el mapa se reescala para verse igual
        public Map<String, float[]> uvShift = new HashMap<>(); // bloque (hueso#indice) -> desplazamiento en pixeles UV de la resolucion elegida
    }

    public enum LoopMode {
        LOOP("Repetir", "Bucle"), ONCE("Una vez", "1 vez"), HOLD("Pausar al final", "Pausa");
        public final String label, shortLabel;
        LoopMode(String l, String sl) { label = l; shortLabel = sl; }
    }

    /** Modo de reproduccion efectivo: el elegido por el usuario o, si no hay, el que dice el archivo. */
    public static LoopMode loopMode(Settings s, BBModel.Anim a, boolean pose) {
        String o = s.animModes.get(a.name);
        if (o != null) { try { return LoopMode.valueOf(o); } catch (Exception ignored) {} }
        return a.loop ? LoopMode.LOOP : pose ? LoopMode.HOLD : LoopMode.ONCE;
    }

    /** Igual pero con un modo por defecto propio cuando el usuario no eligio ninguno. */
    public static LoopMode loopModeOr(Settings s, BBModel.Anim a, LoopMode def) {
        String o = s.animModes.get(a.name);
        if (o != null) { try { return LoopMode.valueOf(o); } catch (Exception ignored) {} }
        return def;
    }

    public static void cycleLoopMode(Settings s, BBModel.Anim a) {
        LoopMode next = LoopMode.values()[(loopMode(s, a, false).ordinal() + 1) % LoopMode.values().length];
        s.animModes.put(a.name, next.name());
    }

    /** Tiempo de la animacion segun el modo (Repetir = modulo, Una vez / Pausar = se queda en el ultimo fotograma). */
    public static float timeFor(BBModel.Anim a, float t, LoopMode mode) {
        if (a.length <= 0) return t;
        return mode == LoopMode.LOOP ? t % a.length : Math.min(t, a.length);
    }

    /** "Una vez" ya termino: la animacion deja de aplicarse. */
    public static boolean finished(BBModel.Anim a, float t, LoopMode mode) {
        return mode == LoopMode.ONCE && a.length > 0 && t > a.length;
    }

    public static class Config {
        public Map<String, Settings> settings = new HashMap<>();
        public Map<String, String> assignments = new HashMap<>(); // "@self" | "*" | nombre jugador -> modelId
        public Theme.Data theme = new Theme.Data();
        public boolean cubeEffect = true; // efecto de transformacion por cubos/particulas (ON/OFF)
        public boolean autoAnchor = true; // como bloque, quedarte quieto (sin agacharte) tambien te ancla; se suelta al moverte
        public boolean showRemote = true; // ver el modelo que cada jugador comparte por el servidor (paso 33)
    }

    public record Active(BBModel model, Settings settings) {}

    public static Path root() { return FabricLoader.getInstance().getGameDir().resolve("morphzuka"); }
    public static Path modelsDir() { return root(); }
    public static Path animsDir() { return root().resolve("animations"); }
    public static Path bgDir() { return root().resolve("backgrounds"); }
    private static Path configFile() { return FabricLoader.getInstance().getConfigDir().resolve("morphzuka.json"); }

    public static void reload() {
        MinecraftClient mc = MinecraftClient.getInstance();
        for (BBModel m : MODELS.values())
            if (m.ownsTexture) mc.getTextureManager().destroyTexture(m.texture);
        MODELS.clear();
        LIB.clear();
        com.morphzuka.render.PartTex.reload();
        migrateLegacy();
        try { Files.createDirectories(modelsDir()); Files.createDirectories(animsDir()); Files.createDirectories(bgDir()); } catch (IOException ignored) {}

        ModelLoader.scanFolder(modelsDir(), "", MODELS);
        // Carpeta del mod Custom Player Models (si existe)
        ModelLoader.scanFolder(FabricLoader.getInstance().getGameDir().resolve("player_models"), "cpm/", MODELS);
        // Modelos GeckoLib dentro de mods / resourcepacks
        try { ModelLoader.scanResources(mc.getResourceManager(), MODELS); }
        catch (Throwable t) { LOG.warn("Scan GeckoLib fallo: {}", t.toString()); }

        loadAnimLibrary();
        if (!cfgLoaded) { loadConfig(); cfgLoaded = true; AnimConfig.apply(); com.morphzuka.render.EntityCfg.load(); }
        LOG.info("MorphZuka: {} modelos y {} animaciones de biblioteca", MODELS.size(), LIB.size());
        RemoteModels.refreshRefs();                // los modelos de mod / resourcepack de los demas apuntan a tus modelos recien cargados
        com.morphzuka.net.ModelSync.markDirty();   // puede haber cambiado el archivo de tu modelo: se vuelve a comprobar si hay que compartirlo
    }

    private static void loadAnimLibrary() {
        Path dir = animsDir();
        if (!Files.isDirectory(dir)) return;
        try (java.util.stream.Stream<Path> st = Files.walk(dir)) {
            st.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".json")).sorted().forEach(p -> {
                try {
                    com.google.gson.JsonObject jo = com.google.gson.JsonParser.parseString(Files.readString(p)).getAsJsonObject();
                    BBModel tmp = new BBModel();
                    ModelLoader.geoAnims(tmp, jo);
                    LIB.putAll(tmp.anims);
                } catch (Throwable t) { LOG.warn("Animacion invalida {}: {}", p.getFileName(), t.toString()); }
            });
        } catch (IOException e) { LOG.warn("Error leyendo animaciones: {}", e.toString()); }
    }

    /** Si venias de BB Player Models, copia carpeta y config una sola vez. */
    private static void migrateLegacy() {
        try {
            Path old = FabricLoader.getInstance().getGameDir().resolve("bbplayermodels");
            if (!Files.exists(root()) && Files.isDirectory(old)) {
                Files.createDirectories(root());
                try (java.util.stream.Stream<Path> st = Files.walk(old)) {
                    for (Path p : (Iterable<Path>) st::iterator) {
                        Path t = root().resolve(old.relativize(p).toString());
                        if (Files.isDirectory(p)) Files.createDirectories(t); else Files.copy(p, t);
                    }
                }
            }
            Path oc = FabricLoader.getInstance().getConfigDir().resolve("bbplayermodels.json");
            if (!Files.exists(configFile()) && Files.exists(oc)) Files.copy(oc, configFile());
        } catch (Exception e) { LOG.warn("Migracion fallo: {}", e.toString()); }
    }

    public static void loadConfig() {
        try {
            if (Files.exists(configFile())) {
                Config c = GSON.fromJson(Files.readString(configFile()), Config.class);
                if (c != null) CONFIG = c;
            }
        } catch (Exception e) { LOG.warn("Config invalida: {}", e.toString()); }
        if (CONFIG.settings == null) CONFIG.settings = new HashMap<>();
        if (CONFIG.assignments == null) CONFIG.assignments = new HashMap<>();
        if (CONFIG.theme == null) CONFIG.theme = new Theme.Data();
        Theme.ensure(CONFIG.theme);
        for (Settings s : CONFIG.settings.values()) normalize(s);
    }

    /** Rellena lo que falte en unos ajustes (config antigua o recibida por red) para que nunca haya nulls. */
    public static void normalize(Settings s) {
        if (s.roles == null) s.roles = new HashMap<>();
        if (s.pivots == null) s.pivots = new HashMap<>();
        if (s.anims == null) s.anims = new HashMap<>();
        if (s.offsets == null) s.offsets = new HashMap<>();
        if (s.rotOffsets == null) s.rotOffsets = new HashMap<>();
        if (s.scales == null) s.scales = new HashMap<>();
        if (s.hidden == null) s.hidden = new HashSet<>();
        if (s.names == null) s.names = new HashMap<>();
        if (s.cubeNames == null) s.cubeNames = new HashMap<>();
        if (s.cubeOffsets == null) s.cubeOffsets = new HashMap<>();
        if (s.cubeRots == null) s.cubeRots = new HashMap<>();
        if (s.cubeScales == null) s.cubeScales = new HashMap<>();
        if (s.cubePivots == null) s.cubePivots = new HashMap<>();
        if (s.animCats == null) s.animCats = new HashMap<>();
        if (s.animModes == null) s.animModes = new HashMap<>();
        if (s.uvShift == null) s.uvShift = new HashMap<>();
        if (s.partTex == null) s.partTex = new HashMap<>();
        if (s.props == null) s.props = new ArrayList<>();
        s.props.removeIf(Objects::isNull);
        for (Prop pr : s.props) {
            if (pr.id == null) pr.id = "objeto";
            if (pr.kind == null) pr.kind = "ITEM";
            if (pr.ref == null) pr.ref = "minecraft:apple";
            if (pr.pos == null || pr.pos.length < 3) pr.pos = new float[3];
            if (pr.rot == null || pr.rot.length < 3) pr.rot = new float[3];
            if (pr.scale == null || pr.scale.length < 3) pr.scale = new float[]{1, 1, 1};
        }
        if (s.blend < 0) s.blend = 0.2f;
        if (s.physBones == null) s.physBones = new HashSet<>();
        if (s.physVer == null) { s.physicsBody = false; s.physVer = 2; }   // paso 22: el rebote del cuerpo entero ya no va encendido por defecto
        if (s.physicsIntensity < 0) s.physicsIntensity = 1f;
        if (s.hitbox == null || s.hitbox.length < 3) s.hitbox = new float[]{0.6f, 1.8f, 0.6f};
        if (s.scale <= 0) s.scale = 1f;
        String air = s.anims.remove("AIR"); // compat con BB Player Models
        if (air != null) { s.anims.putIfAbsent("JUMP", air); s.anims.putIfAbsent("FALL", air); }
    }

    public static void saveConfig() {
        try { Files.writeString(configFile(), GSON.toJson(CONFIG)); }
        catch (IOException e) { LOG.warn("No se pudo guardar config: {}", e.toString()); }
        AnimConfig.save();
        com.morphzuka.render.EntityCfg.save();
        com.morphzuka.net.ModelSync.markDirty();   // cambio de modelo o de ajustes: se vuelve a compartir (con espera, y solo si el paquete cambio)
    }

    /** Nombre que se muestra de un grupo: el que le pusiste o, si no hay, el del archivo. */
    public static String boneLabel(Settings s, BBModel.Bone b) {
        String n = s.names.get(b.name);
        return n != null && !n.isBlank() ? n : b.label();
    }

    /** Nombre que se muestra de un bloque: el que le pusiste o, si no hay, el del archivo. */
    public static String cubeLabel(Settings s, BBModel.Cube c) {
        String n = s.cubeNames.get(c.key);
        return n != null && !n.isBlank() ? n : c.name;
    }

    /** Guarda el nombre de un grupo (vacio = volver al original). */
    public static void renameBone(Settings s, BBModel.Bone b, String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty() || n.equals(b.label())) s.names.remove(b.name); else s.names.put(b.name, n);
    }

    /** Guarda el nombre de un bloque (vacio = volver al original). */
    public static void renameCube(Settings s, BBModel.Cube c, String name) {
        String n = name == null ? "" : name.trim();
        if (n.isEmpty() || n.equals(c.name)) s.cubeNames.remove(c.key); else s.cubeNames.put(c.key, n);
    }

    public static Settings settings(BBModel m) {
        Settings s = CONFIG.settings.get(m.id);
        if (s == null) {
            s = new Settings();
            s.physVer = 2;
            CONFIG.settings.put(m.id, s);
            autoDetect(m, s);
        }
        if (!s.physInit) detectPhysics(m, s);
        return s;
    }

    /** Las fisicas son solo de las partes que tu elijas: ya no se marca ninguna sola (antes se adivinaba por el nombre). */
    public static void detectPhysics(BBModel m, Settings s) {
        s.physInit = true;
    }

    private static void autoDetect(BBModel m, Settings s) {
        for (BBModel.Bone r : m.roots) auto(r, s, EnumSet.noneOf(Role.class));
        for (AnimStates.Def d : AnimStates.ALL) {
            for (String an : m.anims.keySet()) {
                if (AnimStates.match(d, an)) { s.anims.put(d.key(), an); break; }
            }
        }
    }

    private static void auto(BBModel.Bone b, Settings s, EnumSet<Role> ancestors) {
        EnumSet<Role> here = EnumSet.copyOf(ancestors.isEmpty() ? EnumSet.noneOf(Role.class) : ancestors);
        Role r = Role.guess(b.name);
        if (r != Role.NONE && !here.contains(r)) {
            s.roles.put(b.name, r.name());
            here.add(r);
        }
        for (BBModel.Bone c : b.children) auto(c, s, here);
    }

    /**
     * Modelo con el que se dibuja a un jugador. Orden:
     *  1. lo que TU le asignaste por su nombre (o @self si eres tu),
     *  2. el modelo que ese jugador comparte por el servidor (paso 33; si "Ver modelos de los demas" esta activo),
     *  3. "Todos los jugadores" (*).
     */
    public static Active forPlayer(AbstractClientPlayerEntity p) {
        Map<String, String> as = CONFIG.assignments;
        boolean self = p == MinecraftClient.getInstance().player;
        if (!MODELS.isEmpty() && !as.isEmpty()) {
            String id = as.get(p.getGameProfile().getName().toLowerCase(Locale.ROOT));
            if (id == null && self) id = as.get("@self");
            BBModel m = id == null ? null : MODELS.get(id);
            if (m != null) return new Active(m, settings(m));
        }
        if (!self && CONFIG.showRemote) {
            Active r = RemoteModels.get(p.getUuid());
            if (r != null) return r;
        }
        if (!MODELS.isEmpty() && !as.isEmpty()) {
            String id = as.get("*");
            BBModel m = id == null ? null : MODELS.get(id);
            if (m != null) return new Active(m, settings(m));
        }
        return null;
    }

    /** Id del modelo que TU compartes con los demas: el que te pusiste a ti (por tu nombre o @self), no el de "Todos". Null = ninguno. */
    public static String selfShareId() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return null;
        String id = CONFIG.assignments.get(mc.player.getGameProfile().getName().toLowerCase(Locale.ROOT));
        if (id == null) id = CONFIG.assignments.get("@self");
        return id != null && MODELS.containsKey(id) ? id : null;
    }

    /** Ajustes por defecto de un modelo, sin guardarlos en tu config (para un modelo ajeno que llego sin ajustes). */
    public static Settings autoSettings(BBModel m) {
        Settings s = new Settings();
        s.physVer = 2;
        autoDetect(m, s);
        normalize(s);
        return s;
    }

    private static boolean finite(float[] v) { for (float f : v) if (!Float.isFinite(f)) return false; return true; }

    private static void clean(Map<String, float[]> m, int len) { m.values().removeIf(v -> v == null || v.length < len || !finite(v)); }

    /**
     * Ajustes que llegan de otro jugador (no son de fiar): se quita lo que pudiera romper el dibujo en TU cliente
     * (arrays cortos, NaN, nulls) y se limitan la escala y la fisica. Ya pasaron por normalize().
     */
    public static void sanitizeRemote(Settings s) {
        clean(s.pivots, 3); clean(s.offsets, 3); clean(s.rotOffsets, 3); clean(s.scales, 3);
        clean(s.cubeOffsets, 3); clean(s.cubeRots, 3); clean(s.cubeScales, 3); clean(s.cubePivots, 3);
        clean(s.uvShift, 2);
        s.hidden.removeIf(Objects::isNull);
        s.names.values().removeIf(Objects::isNull);
        s.cubeNames.values().removeIf(Objects::isNull);
        s.anims.values().removeIf(Objects::isNull);
        s.animCats.values().removeIf(Objects::isNull);
        s.animModes.values().removeIf(Objects::isNull);
        s.partTex.values().removeIf(Objects::isNull);
        s.physBones.removeIf(Objects::isNull);
        if (!Float.isFinite(s.scale)) s.scale = 1f;
        s.scale = Math.max(0.05f, Math.min(32f, s.scale));
        if (!Float.isFinite(s.blend)) s.blend = 0.2f;
        s.blend = Math.max(0f, Math.min(5f, s.blend));
        if (!Float.isFinite(s.physicsIntensity)) s.physicsIntensity = 1f;
        s.physicsIntensity = Math.max(0f, Math.min(3f, s.physicsIntensity));
        if (!finite(s.hitbox)) s.hitbox = new float[]{0.6f, 1.8f, 0.6f};
        if (!Float.isFinite(s.eye)) s.eye = 0f;
        if (s.props.size() > 64) s.props.subList(64, s.props.size()).clear();
        for (Prop pr : s.props) {
            if (!finite(pr.pos)) pr.pos = new float[3];
            if (!finite(pr.rot)) pr.rot = new float[3];
            if (!finite(pr.scale)) pr.scale = new float[]{1, 1, 1};
        }
    }

    public static BBModel.Anim anim(BBModel m, String name) {
        if (name == null) return null;
        BBModel.Anim a = m.anims.get(name);
        return a != null ? a : LIB.get(name);
    }

    public static List<String> allAnimNames(BBModel m) {
        List<String> l = new ArrayList<>(m.anims.keySet());
        for (String k : LIB.keySet()) if (!m.anims.containsKey(k)) l.add(k);
        return l;
    }

    public static List<String> animsWithCat(BBModel m, Settings s, String cat) {
        List<String> r = new ArrayList<>();
        for (String n : allAnimNames(m)) if (cat.equals(s.animCats.get(n))) r.add(n);
        return r;
    }

    /** Animaciones sin categoria: las que se lanzan con /morphzuka anim <nombre>. */
    public static List<String> commandAnims(BBModel m, Settings s) {
        List<String> r = new ArrayList<>();
        for (String n : allAnimNames(m)) if (!s.animCats.containsKey(n)) r.add(n);
        return r;
    }

    public static Active forSelf() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc.player == null ? null : forPlayer(mc.player);
    }

    public static void assign(String key, String modelId) {
        if (modelId == null) CONFIG.assignments.remove(key); else CONFIG.assignments.put(key, modelId);
        saveConfig();
    }
}
