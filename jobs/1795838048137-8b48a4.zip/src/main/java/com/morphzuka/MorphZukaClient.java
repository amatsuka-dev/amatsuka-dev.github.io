package com.morphzuka;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.FloatArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.morphzuka.model.AnimIO;
import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelBounds;
import com.morphzuka.model.ModelManager;
import com.morphzuka.net.ClientNet;
import com.morphzuka.render.CubeSwarm;
import com.morphzuka.render.MorphManager;
import com.morphzuka.render.Transition;
import com.morphzuka.screen.ModelScreen;
import com.morphzuka.screen.RadialScreen;
import com.morphzuka.ui.Background;
import com.morphzuka.ui.Theme;
import net.minecraft.util.Identifier;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MorphZukaClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // modelo 3D de la RoZuka (se usa en la mano; el icono 2D es el modelo normal del item)
        net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin.register(ctx ->
                ctx.addModels(net.minecraft.util.Identifier.of("morphzuka", "item/brochazuka_3d")));
        KeyBinding open = reg("key.morphzuka.open", GLFW.GLFW_KEY_K);
        KeyBinding keyModels = reg("key.morphzuka.models", GLFW.GLFW_KEY_B);
        KeyBinding keyGestures = reg("key.morphzuka.gestures", GLFW.GLFW_KEY_G);
        KeyBinding unmorph = reg("key.morphzuka.unmorph", GLFW.GLFW_KEY_UNKNOWN);
        KeyBinding rotate = reg("key.morphzuka.rotate", GLFW.GLFW_KEY_R);

        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            if (ClientNet.menuLocked) ClientNet.closeModScreens(c);   // el servidor bloqueo el menu: se cierra si estaba abierto
            while (open.wasPressed()) { if (ClientNet.denyMenu(c)) continue; c.setScreen(new ModelScreen(c.currentScreen)); }
            while (keyModels.wasPressed()) if (c.currentScreen == null && c.player != null && !ClientNet.denyMenu(c)) c.setScreen(new RadialScreen(RadialScreen.Mode.MODELS, keyModels));
            while (keyGestures.wasPressed()) if (c.currentScreen == null && c.player != null && !ClientNet.denyMenu(c)) c.setScreen(new RadialScreen(RadialScreen.Mode.GESTURES, keyGestures));
            while (unmorph.wasPressed()) { MorphManager.clear(); if (c.player != null) c.player.sendMessage(Text.literal("Forma normal"), true); }
            while (rotate.wasPressed()) {
                if (c.currentScreen != null || c.player == null) continue;
                if (MorphManager.rotateBlock(1)) c.player.sendMessage(Text.literal("Bloque girado 90°"), true);
            }
            if (c.player == null) return;
            MorphManager.tick(c);
            BlockLock.tick(c);
            ClientNet.tickModels(c);   // comparte tu modelo y baja los de los demas (paso 33)
            ModelManager.Active a = ModelManager.forSelf();
            String mk = MorphManager.key();
            if (mk == null) mk = a == null ? "none" : "model:" + a.model().id;
            com.morphzuka.render.Forms.tick(c);   // antes de Transition: asi el efecto sabe de donde sale y a donde llega
            Transition.check(mk, c.player);
            Gestures.tick(a == null ? null : a.model());
            if (HitboxOverride.refresh()) c.player.calculateDimensions();   // y manda la caja al servidor (HitboxOverride)
        });

        BlockLock.registerHud();
        MorpherGun.register();
        MorpherGun.registerCreativeTab();
        HitboxOverride.install();
        ClientNet.register();
        WorldRenderEvents.AFTER_ENTITIES.register(CubeSwarm::render);
        WorldRenderEvents.AFTER_ENTITIES.register(com.morphzuka.render.MorphTarget::render);   // contorno de lo que vas a copiar con la RoZuka

        ClientLifecycleEvents.CLIENT_STARTED.register(c -> {
            ModelManager.reload();
            Background.load(Theme.data.bgFile);
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registry) -> {
            var root = ClientCommandManager.literal("morphzuka").executes(ctx -> openScreen());

            root.then(ClientCommandManager.literal("apply")
                    .then(ClientCommandManager.argument("player", StringArgumentType.word())
                            .suggests((ctx, b) -> CommandSource.suggestMatching(playerNames(), b))
                            .then(ClientCommandManager.argument("model", StringArgumentType.greedyString())
                                    .suggests((ctx, b) -> CommandSource.suggestMatching(ModelManager.MODELS.keySet(), b))
                                    .executes(this::apply))));
            root.then(ClientCommandManager.literal("remove")
                    .then(ClientCommandManager.argument("player", StringArgumentType.word())
                            .suggests((ctx, b) -> CommandSource.suggestMatching(playerNames(), b))
                            .executes(ctx -> {
                                String key = key(StringArgumentType.getString(ctx, "player"));
                                ModelManager.assign(key, null);
                                return say(ctx, "Quitado el modelo de: " + key);
                            })));
            root.then(ClientCommandManager.literal("anim")
                    .then(ClientCommandManager.literal("stop").executes(ctx -> { Gestures.stop(); return say(ctx, "Animación detenida"); }))
                    .then(ClientCommandManager.argument("name", StringArgumentType.greedyString())
                            .suggests((ctx, b) -> {
                                ModelManager.Active a = ModelManager.forSelf();
                                return CommandSource.suggestMatching(a == null ? List.<String>of() : ModelManager.commandAnims(a.model(), a.settings()), b);
                            })
                            .executes(this::anim)));
            root.then(ClientCommandManager.literal("pose")
                    .then(ClientCommandManager.literal("off").executes(ctx -> { Gestures.pose = null; return say(ctx, "Pose personalizada quitada"); }))
                    .then(ClientCommandManager.argument("name", StringArgumentType.greedyString())
                            .suggests((ctx, b) -> CommandSource.suggestMatching(catAnims(ModelManager.CAT_POSE), b))
                            .executes(ctx -> catCommand(ctx, ModelManager.CAT_POSE))));
            root.then(ClientCommandManager.literal("toggle")
                    .then(ClientCommandManager.literal("off").executes(ctx -> { Gestures.toggles.clear(); return say(ctx, "Capas toggle apagadas"); }))
                    .then(ClientCommandManager.argument("name", StringArgumentType.greedyString())
                            .suggests((ctx, b) -> CommandSource.suggestMatching(catAnims(ModelManager.CAT_TOGGLE), b))
                            .executes(ctx -> catCommand(ctx, ModelManager.CAT_TOGGLE))));
            root.then(ClientCommandManager.literal("morph")
                    .then(ClientCommandManager.literal("entity").then(ClientCommandManager.argument("id", StringArgumentType.greedyString())
                            .suggests((ctx, b) -> CommandSource.suggestMatching(ids(MorphManager.Kind.ENTITY), b))
                            .executes(ctx -> result(ctx, MorphManager.morphEntity(id(ctx, "id")), "Ahora eres esa entidad"))))
                    .then(ClientCommandManager.literal("block").then(ClientCommandManager.argument("id", StringArgumentType.greedyString())
                            .suggests((ctx, b) -> CommandSource.suggestMatching(ids(MorphManager.Kind.BLOCK), b))
                            .executes(ctx -> result(ctx, MorphManager.morphBlock(id(ctx, "id")), "Ahora eres ese bloque"))))
                    .then(ClientCommandManager.literal("player").then(ClientCommandManager.argument("name", StringArgumentType.word())
                            .suggests((ctx, b) -> CommandSource.suggestMatching(playerNames(), b))
                            .executes(ctx -> result(ctx, MorphManager.morphPlayer(StringArgumentType.getString(ctx, "name")), "Ahora te ves como ese jugador"))))
                    .then(ClientCommandManager.literal("look").executes(ctx -> {
                        MinecraftClient mc = MinecraftClient.getInstance();
                        Entity t = mc.targetedEntity;
                        if (t == null) return fail(ctx, "No estás mirando a ninguna entidad");
                        MorphManager.copyEntity(mc, t);   // copia tambien sus datos (especie de Pokemon, variante, color...)
                        return say(ctx, "Copiada: " + t.getType().getName().getString());
                    }))
                    .then(ClientCommandManager.literal("off").executes(ctx -> { MorphManager.clear(); return say(ctx, "Forma normal"); })));
            root.then(ClientCommandManager.literal("gun").executes(ctx -> say(ctx, MorpherGun.give(MinecraftClient.getInstance()))));
            root.then(ClientCommandManager.literal("animscan").executes(ctx -> say(ctx, com.morphzuka.render.ClassAnimScan.scanAll())));
            root.then(ClientCommandManager.literal("rozuka").executes(ctx -> say(ctx, MorpherGun.give(MinecraftClient.getInstance()))));
            root.then(ClientCommandManager.literal("brocha").executes(ctx -> say(ctx, MorpherGun.give(MinecraftClient.getInstance()))));
            root.then(ClientCommandManager.literal("export")
                    .then(ClientCommandManager.argument("portable", BoolArgumentType.bool())
                            .then(ClientCommandManager.argument("name", StringArgumentType.greedyString())
                                    .suggests((ctx, b) -> {
                                        ModelManager.Active a = ModelManager.forSelf();
                                        return CommandSource.suggestMatching(a == null ? List.<String>of() : ModelManager.allAnimNames(a.model()), b);
                                    })
                                    .executes(this::export))));
            root.then(ClientCommandManager.literal("hitbox")
                    .then(ClientCommandManager.literal("off").executes(ctx -> hitboxOff(ctx)))
                    .then(ClientCommandManager.literal("auto").executes(ctx -> hitboxAuto(ctx)))
                    .then(ClientCommandManager.argument("x", FloatArgumentType.floatArg(0.05f, 16f))
                            .then(ClientCommandManager.argument("y", FloatArgumentType.floatArg(0.05f, 16f))
                                    .then(ClientCommandManager.argument("z", FloatArgumentType.floatArg(0.05f, 16f))
                                            .executes(ctx -> hitbox(ctx, 0))
                                            .then(ClientCommandManager.argument("eye", FloatArgumentType.floatArg(0.05f, 16f))
                                                    .executes(ctx -> hitbox(ctx, 1)))))));
            root.then(ClientCommandManager.literal("physics")
                    .then(ClientCommandManager.argument("on", BoolArgumentType.bool()).executes(ctx -> physics(ctx, true)))
                    .then(ClientCommandManager.literal("intensity").then(ClientCommandManager.argument("value", FloatArgumentType.floatArg(0f, 3f))
                            .executes(ctx -> physics(ctx, false)))));
            root.then(ClientCommandManager.literal("follow")
                    .then(ClientCommandManager.literal("head").then(ClientCommandManager.argument("on", BoolArgumentType.bool())
                            .executes(ctx -> follow(ctx, true))))
                    .then(ClientCommandManager.literal("arms").then(ClientCommandManager.argument("on", BoolArgumentType.bool())
                            .executes(ctx -> follow(ctx, false)))));
            root.then(ClientCommandManager.literal("anchor")
                    .then(ClientCommandManager.argument("auto", BoolArgumentType.bool()).executes(ctx -> {
                        boolean on = BoolArgumentType.getBool(ctx, "auto");
                        ModelManager.CONFIG.autoAnchor = on;
                        ModelManager.saveConfig();
                        return say(ctx, on ? "Anclaje automático: ON (quieto como bloque = te anclas; te sueltas al moverte)"
                                : "Anclaje automático: OFF (solo te anclas agachado)");
                    })));
            root.then(ClientCommandManager.literal("net")
                    .executes(ctx -> {
                        for (String line : com.morphzuka.net.ModelSync.report()) ctx.getSource().sendFeedback(Text.literal(line));
                        return 1;
                    })
                    .then(ClientCommandManager.literal("resend").executes(ctx -> {
                        com.morphzuka.net.ModelSync.forceResend();
                        return say(ctx, "Se volverá a subir tu modelo al servidor en un momento");
                    })));
            root.then(ClientCommandManager.literal("reload").executes(ctx -> {
                ModelManager.reload();
                return say(ctx, "Modelos recargados: " + ModelManager.MODELS.size());
            }));
            dispatcher.register(root);
            dispatcher.register(ClientCommandManager.literal("bbmodel").executes(ctx -> openScreen())); // alias heredado
        });
    }

    private static KeyBinding reg(String id, int key) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(id, InputUtil.Type.KEYSYM, key, "key.categories.morphzuka"));
    }

    private static int result(CommandContext<FabricClientCommandSource> ctx, String err, String ok) {
        ctx.getSource().sendFeedback(Text.literal(err == null ? ok : err));
        return err == null ? 1 : 0;
    }

    private static Identifier id(CommandContext<FabricClientCommandSource> ctx, String arg) {
        String s = StringArgumentType.getString(ctx, arg).trim().toLowerCase(Locale.ROOT);
        Identifier i = Identifier.tryParse(s.contains(":") ? s : "minecraft:" + s);
        return i == null ? Identifier.of("minecraft", "air") : i;
    }

    private static List<String> ids(MorphManager.Kind kind) {
        List<String> r = new ArrayList<>();
        for (Identifier i : MorphManager.search(kind, "", 5000)) r.add(i.toString());
        return r;
    }

    private static int openScreen() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (ClientNet.denyMenu(mc)) return 0;
        mc.send(() -> mc.setScreen(new ModelScreen(null)));
        return 1;
    }

    private static int say(CommandContext<FabricClientCommandSource> ctx, String s) {
        ctx.getSource().sendFeedback(Text.literal(s));
        return 1;
    }

    private static int fail(CommandContext<FabricClientCommandSource> ctx, String s) {
        ctx.getSource().sendFeedback(Text.literal(s));
        return 0;
    }

    private static List<String> playerNames() {
        List<String> r = new ArrayList<>(List.of("@self", "*"));
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getNetworkHandler() != null)
            mc.getNetworkHandler().getPlayerList().forEach(e -> r.add(e.getProfile().getName()));
        return r;
    }

    /** yo / @self -> "@self", todos / * -> "*", cualquier otro nombre en minusculas. */
    public static String key(String who) {
        String w = who.trim().toLowerCase(Locale.ROOT);
        return switch (w) {
            case "@self", "yo", "me", "self" -> "@self";
            case "*", "todos", "all", "@a" -> "*";
            default -> w;
        };
    }

    private int apply(CommandContext<FabricClientCommandSource> ctx) {
        String who = key(StringArgumentType.getString(ctx, "player"));
        String model = StringArgumentType.getString(ctx, "model").trim();
        if (!ModelManager.MODELS.containsKey(model)) return fail(ctx, "No tienes ese modelo cargado: " + model);
        ModelManager.assign(who, model);
        return say(ctx, "Modelo '" + model + "' aplicado a " + who + " (solo en tu cliente)");
    }

    private int anim(CommandContext<FabricClientCommandSource> ctx) {
        String name = StringArgumentType.getString(ctx, "name").trim();
        ModelManager.Active a = ModelManager.forSelf();
        if (a == null) return fail(ctx, "No tienes un modelo aplicado");
        BBModel.Anim an = ModelManager.anim(a.model(), name);
        if (an == null) return fail(ctx, "Animación no encontrada: " + name);
        if (a.settings().animCats.containsKey(name))
            return fail(ctx, "'" + name + "' tiene categoría; quítasela en la pestaña Animación para usarla por comando");
        Gestures.play(a.model(), a.settings(), name);
        return say(ctx, "Reproduciendo: " + name + " (" + Gestures.mode.label + ")" + (Gestures.mode != ModelManager.LoopMode.ONCE ? " - /morphzuka anim stop para detener" : ""));
    }

    private static List<String> catAnims(String cat) {
        ModelManager.Active a = ModelManager.forSelf();
        return a == null ? List.<String>of() : ModelManager.animsWithCat(a.model(), a.settings(), cat);
    }

    private int catCommand(CommandContext<FabricClientCommandSource> ctx, String cat) {
        String name = StringArgumentType.getString(ctx, "name").trim();
        ModelManager.Active a = ModelManager.forSelf();
        if (a == null) return fail(ctx, "No tienes un modelo aplicado");
        if (ModelManager.anim(a.model(), name) == null) return fail(ctx, "Animación no encontrada: " + name);
        if (!cat.equals(a.settings().animCats.get(name)))
            return fail(ctx, "'" + name + "' no tiene la categoría " + ModelManager.catLabel(cat) + " (se asigna en la pestaña Animación)");
        if (cat.equals(ModelManager.CAT_POSE)) { Gestures.pose = name; return say(ctx, "Pose: " + name + " (/morphzuka pose off para quitarla)"); }
        boolean on = Gestures.toggle(name);
        return say(ctx, name + (on ? ": activada" : ": desactivada"));
    }

    private int export(CommandContext<FabricClientCommandSource> ctx) {
        ModelManager.Active a = ModelManager.forSelf();
        if (a == null) return fail(ctx, "No tienes un modelo aplicado");
        try {
            String f = AnimIO.export(a.model(), a.settings(), StringArgumentType.getString(ctx, "name").trim(),
                    BoolArgumentType.getBool(ctx, "portable"));
            return say(ctx, "Exportada a morphzuka/animations/" + f);
        } catch (Exception e) {
            return fail(ctx, "No se pudo exportar: " + e.getMessage());
        }
    }

    private int hitbox(CommandContext<FabricClientCommandSource> ctx, int withEye) {
        ModelManager.Active a = ModelManager.forSelf();
        if (a == null) return fail(ctx, "No tienes un modelo aplicado");
        ModelManager.Settings s = a.settings();
        s.hitbox = new float[]{FloatArgumentType.getFloat(ctx, "x"), FloatArgumentType.getFloat(ctx, "y"), FloatArgumentType.getFloat(ctx, "z")};
        s.eye = withEye == 1 ? FloatArgumentType.getFloat(ctx, "eye") : 0f;
        s.hitboxOn = true;
        s.hitboxAuto = false;
        ModelManager.saveConfig();
        return say(ctx, "Hitbox X/Y/Z = " + s.hitbox[0] + " / " + s.hitbox[1] + " / " + s.hitbox[2] + hitboxNote());
    }

    /** Aclara hasta donde llega la hitbox segun si el servidor tiene el mod. */
    private static String hitboxNote() {
        return ClientNet.serverHasMod() ? " (validada y sincronizada por el servidor)" : " (solo cliente: este servidor no tiene MorphZuka)";
    }

    private int hitboxAuto(CommandContext<FabricClientCommandSource> ctx) {
        ModelManager.Active a = ModelManager.forSelf();
        if (a == null) return fail(ctx, "No tienes un modelo aplicado");
        ModelManager.Settings s = a.settings();
        s.hitboxAuto = true;
        s.hitboxOn = true;
        ModelManager.saveConfig();
        ModelBounds.Box b = ModelBounds.of(a.model(), s);
        return say(ctx, "Hitbox automática según el modelo: " + b.width() + " x " + b.height() + " (ojos " + b.eye() + ")" + hitboxNote());
    }

    private int hitboxOff(CommandContext<FabricClientCommandSource> ctx) {
        ModelManager.Active a = ModelManager.forSelf();
        if (a == null) return fail(ctx, "No tienes un modelo aplicado");
        a.settings().hitboxOn = false;
        a.settings().hitboxAuto = false;
        ModelManager.saveConfig();
        return say(ctx, "Hitbox vanilla");
    }

    private int physics(CommandContext<FabricClientCommandSource> ctx, boolean toggle) {
        ModelManager.Active a = ModelManager.forSelf();
        if (a == null) return fail(ctx, "No tienes un modelo aplicado");
        ModelManager.Settings s = a.settings();
        if (toggle) s.physicsOn = BoolArgumentType.getBool(ctx, "on");
        else s.physicsIntensity = FloatArgumentType.getFloat(ctx, "value");
        ModelManager.saveConfig();
        return say(ctx, "Físicas de rebote: " + (s.physicsOn ? "ON" : "OFF") + " (intensidad " + s.physicsIntensity + ")");
    }

    private int follow(CommandContext<FabricClientCommandSource> ctx, boolean head) {
        ModelManager.Active a = ModelManager.forSelf();
        if (a == null) return fail(ctx, "No tienes un modelo aplicado");
        boolean on = BoolArgumentType.getBool(ctx, "on");
        if (head) a.settings().followHead = on; else a.settings().followArms = on;
        ModelManager.saveConfig();
        return say(ctx, (head ? "Cabeza sigue la cámara: " : "Ataque vanilla en brazos: ") + on);
    }
}
