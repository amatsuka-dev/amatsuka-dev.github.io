# MorphZuka (Fabric 1.21.1)

Mod para usar modelos de Blockbench como modelo de jugador. Funciona **en cliente solo** (mundo propio, o servidores sin el mod) y, si lo instalas tambien en el **servidor**, la hitbox, el morph y el efecto de cubos se validan y se ven en multijugador.

## Compilar
Requiere JDK 21.
```
gradle wrapper --gradle-version 8.10.2   # solo la primera vez (o abre la carpeta en IntelliJ)
./gradlew build
```
El jar queda en `build/libs/morphzuka-1.0.0.jar`.

## Uso
1. Pon tus modelos en `.minecraft/morphzuka/` (tambien lee `.minecraft/player_models/` de CPM):
   - `.morphzuka` (Blockbench, incluye CPM y GeckoLib si los guardas como proyecto) con textura incrustada
   - `.geo.json` (+ `mismo_nombre.png` y `mismo_nombre.animation.json` al lado)
   - `.cpmproject` (si contiene un .morphzuka)
   - Modelos GeckoLib de otros mods / resourcepacks (`assets/<ns>/geo/*.geo.json`) se detectan solos.
2. En el juego pulsa **K** (o `/morphzuka`).
3. Elige modelo -> elige cada hueso y asignale rol (Cabeza, Torso, Brazos, Piernas, Cola/extra; puedes asignar varios huesos al mismo rol).
4. Edita el pivote de cualquier hueso (X Y Z en pixeles) y pulsa "Fijar pivote".
5. Asigna animaciones a IDLE / WALK / SPRINT / SNEAK / AIR.
6. "Aplicar a": Yo / Todos / Jugador (nombre) -> Aplicar.

Config guardada en `config/morphzuka.json`.

## Limitaciones
- Los **modelos .bbmodel** siguen siendo locales: los demas no ven tu modelo (hace falta transferirlo; no incluido). Si ven tu **morph** (entidad/bloque/jugador), tu **hitbox** y el **efecto de cubos**.
- Una sola textura por modelo; meshes no soportados (solo cubos).
- Armadura/items/capa siguen renderizandose con el esqueleto vanilla.
- Sin poses de nado/elytra/dormir. Rotaciones de GeckoLib/Bedrock pueden requerir ajustes de signo.

## Interfaz (v1.1)
Menú estilo Material oscuro/transparente con barra lateral: **Modelos**, **Partes**, **Animación**, **Importar**, **Aplicar**.
- **Arrastrar y soltar**: suelta `.morphzuka`, `.geo.json`, `.cpmproject` (y `.png` / `.animation.json` de GeckoLib) sobre la ventana del menú.
- **Importar**: pega un link directo (los links de GitHub `/blob/` se convierten solos a raw) o usa "Pegar Base64 / JSON del portapapeles" (acepta Base64, `data:...;base64,` y JSON plano).

## Editor 3D (v2.3)
Pestaña **Editor 3D** (o botón "Editor 3D" en Partes). Pantalla completa con:
- **Visor orbital**: arrastra en vacío para girar, rueda para zoom, "Centrar vista" para volver.
- **Selector de partes**: lista a la izquierda o clic en los puntos de pivote dentro del visor. La parte elegida se tiñe de naranja.
- **Gizmo**: modos **Mover**, **Rotar** (3 aros), **Escalar** (ejes + cubo central = uniforme) y **Pivote**. Ejes en rojo X, verde Y, azul Z.
- **Campos XYZ** numéricos para cada modo; se sincronizan con el gizmo.
- Deshacer, restaurar parte / todo, ocultar parte. Se guarda al cerrar en `config/morphzuka.json`
  (`offsets`, `rotOffsets`, `scales`, `pivots`); el archivo del modelo no se toca.
Los ejes del gizmo siguen el espacio del hueso padre (en Escalar, el del propio hueso).

## Morpher Gun (recursos, paso 1)
Item `carrot_on_a_stick` con `custom_model_data=7001`. Modelo: `assets/morphzuka/models/item/morpher_item/morphergun.json`,
enganchado desde `assets/minecraft/models/item/carrot_on_a_stick.json`. Recarga recursos con F3+T.

## Multijugador (v2.4: pasos 12 y 13)
Instala el jar en el cliente **y** en el servidor (Fabric API en ambos). Sin el mod en el servidor todo sigue funcionando solo en tu cliente.

**Hitbox real (paso 12)**: el cliente manda su caja {ancho, alto, ojos}; el servidor la valida contra limites, la aplica a tu
`ServerPlayerEntity` (colisiones y validacion de movimiento reales, por postura: de pie / agachado / nadando) y la retransmite
a todos. Mixin comun `PlayerDimensionsMixin` + `HitboxRegistry`.

**Cube form (v2.5, con texturas)**: al transformarte, tu forma anterior (skin vanilla, modelo propio, bloque o entidad) se convierte en
~260 cubos pequenos pegados a su superficie, **cada uno con el trocito de textura que le toca ahi**. Los cubos despegan (los de arriba
primero), dan una vuelta y se colocan sobre la superficie de la forma nueva, formando su silueta. Ya colocados, **cambian poco a poco
a la textura del morph** (entidad, bloque, skin del jugador o modelo) y al final la forma real aparece con rebote mientras los cubos
se encogen dentro de ella. Clases: `Form` (que forma es), `Surface` (puntos y UV de su piel), `Forms` (forma actual/anterior de cada
jugador), `CubeSwarm` (simulacion y dibujo). El servidor sigue retransmitiendo (quien, tamanos, bloque, semilla); cada cliente reconstruye
las formas con lo que ya sabe del jugador (su morph, su modelo, su skin). Si no puede, usa una caja de colores. Se desactiva en Ajustes
("Efecto de cubos al transformarse"). Notas: entidades y modelos con texturas que el juego no deja leer se tratan como opacas; las
entidades usan un parche de textura al azar entre sus pixeles opacos (su mapa UV no es accesible).

**Edicion por bloque y nombres (v2.5, modelo de datos + render)**: los ajustes de cada modelo guardan ahora `names` / `cubeNames`
(nombre propio de grupos y bloques) y `cubeOffsets` / `cubeRots` / `cubeScales` / `cubePivots` (clave `hueso#indice`). El renderer
(`BBRenderer.cube`), el calculo de la caja (`ModelBounds`) y el efecto de cubos aplican lo mismo a traves de `CubeXform`. El archivo del
modelo no se toca. Sin pivote propio, un bloque sin rotacion ni origen gira y escala alrededor de su centro. Pendiente: panel del
editor para renombrar / editar por bloque y las 4 herramientas sobre bloques.

**Morpher Gun**: sigue siendo `carrot_on_a_stick` con `custom_model_data=7001` (no se registra ningun item: no rompe la sincronizacion
de registros y los clientes sin el mod no fallan). El servidor la entrega con `/mz gun [jugadores]` y, con ella en la mano, bloquea
la interaccion vanilla (cofres, puertas...).

### Config del servidor: `config/morphzuka-server.json`
| campo | por defecto | efecto |
|---|---|---|
| allowHitbox | true | aceptar hitbox personalizada |
| allowMorph | true | aceptar morph y mostrarlo a los demas |
| allowEffects | true | retransmitir el efecto de cubos |
| opsOnly | false | solo operadores pueden usar hitbox/morph |
| minSize / maxWidth / maxHeight | 0.1 / 4 / 8 | limites de la caja aceptada |

Comandos (nivel 2): `/mz gun [jugadores]`, `/mz reload`, `/mz status`.

### Paquetes
`morphzuka:hitbox` (C2S), `hitbox_sync` (S2C), `morph` (C2S/S2C), `cube_fx` (C2S/S2C). Solo se envian si el otro lado los tiene registrados.

## Entidades de otros mods (Cobblemon, etc.)
Los Pokemon de Cobblemon son un unico tipo de entidad (`cobblemon:pokemon`) y la especie va en sus datos sincronizados. Por eso
ahora, al copiar una entidad **real** (Morpher Gun clic derecho sobre ella, o `/morphzuka morph look` mirandola), tambien se copian
esos datos (especie, aspectos, variante, color, bebe...) y el tamano real de esa entidad; se mandan al servidor y los demas te ven igual.
Sirve para cualquier mob de cualquier mod. Las entidades de la lista del menu/`/morphzuka morph entity <id>` se crean sin datos
(un `cobblemon:pokemon` asi sale vacio): para Pokemon usa la gun o `look`. Limite de datos: 16 KB por entidad.

## Pestaña Morph: vista previa y Animaciones (v2.6)
- **Vista previa 3D** a la derecha de la pestaña Morph: muestra lo que llevas puesto (entidad, bloque, jugador o tu forma normal),
  con nombre y tamaño. Arrastra para girarla (si no la tocas, gira sola).
- **Botón "Animaciones"** debajo de la vista previa (activo si llevas una entidad o jugador). Abre una ventana con:
  - **Vista previa grande** con pruebas: *Caminar*, *Golpear* (el golpe de Minecraft cada ~1 s) y *Cabeza* (mira de lado a lado). Rueda = zoom.
  - **Animaciones**: las poses (Quieto/idle, Caminar, Golpear, Girar cabeza) y, si la entidad trae archivos `.animation.json`
    (GeckoLib/Bedrock de mods o resourcepacks), todas las animaciones que contienen. Si hay un modelo cargado con el mismo nombre,
    un botón abre su configuración de animaciones (la misma de la pestaña Modelos).
  - **Partes**: lista las partes del modelo de esa entidad (`head`, `right_arm`, `left_leg`...) y deja asignar a cada una un rol
    (Cabeza, Torso, Brazo der/izq, Pierna der/izq, Cola). *Autodetectar* los asigna por nombre.
    Con roles asignados: la cabeza gira con la cámara, el brazo da el golpe de Minecraft y brazos/piernas balancean al caminar.
  - **Idle**: preset en reposo (Ninguno, Minecraft, Respirar, Balanceo), intensidad, y si la cabeza sigue la cámara, golpe de Minecraft,
    balanceo al caminar y mano que golpea (diestro/zurdo).
- Se guarda al instante en `config/morphzuka_entities.json` (una entrada por entidad, p. ej. `ENTITY:minecraft:zombie`).
- Clases nuevas: `EntityAnimScreen`, `EntityCfg` (ajustes + aplicación al modelo), `PartTree` (lista de partes), `MorphPreview` (visor),
  `AnimScan` (busca animaciones), y los mixins `ModelPartMixin` / `ModelPartAccessor`. `LivingEntityRendererMixin` aplica los roles justo
  después de que el juego coloque el modelo y los devuelve al terminar.
- Limitación: solo modelos hechos de `ModelPart` (vanilla y la mayoría de mods). Modelos con su propio sistema (p. ej. Pokémon de Cobblemon)
  no listan partes; se mueven con sus propias animaciones.


## Paso 16
- **Importar .geo**: al soltar (o importar por link) un `.geo.json`, aparece un asistente que pide la **textura (.png)** y las **animaciones (.animation.json)**. Se sueltan sobre la ventana; se guardan con el nombre del .geo. "Cargar así" lo abre sin ellas; si llegan las dos, se carga solo.
- **.bbmodel**: los grupos se leen mejor: los elementos que el outliner no menciona van a su grupo (o a `root`), grupos con nombre vacio, entradas raras en el outliner.
- **Roles automaticos**: `Autodetectar` entiende camelCase (`LeftArm`, `ArmL`, `LArm`) y espanol (`brazo_izq`, `pierna_der`, `cabeza`...), y ya no confunde `armor` con un brazo.
- **Efecto de cubos**: las entidades usan la **forma real de su modelo** (cabeza, patas, orejas...) en vez de una caja, y los bloques usan sus quads reales (escaleras, losas, vallas...). Si algo falla, vuelve a la caja de antes.

## Paso 17
- **Pestaña creativa "MorphZuka"** con la Morpher Gun (solo cliente; el icono es la propia pistola).

## Paso 18
- **Renombrar grupos y bloques**: en Partes hay un campo "Nombre del grupo" (Renombrar / Original, o Enter); en el Editor 3D, el campo bajo el titulo renombra el grupo elegido o, si hay un bloque elegido, el bloque. Es solo visual (se guarda en config/morphzuka.json): el archivo del modelo y las animaciones no cambian.

## Paso 19
- Corregido el recolector de vertices del efecto de cubos (vertex con float).


## Textura por parte (paso 21)
Editor 3D -> **Mapa UV**: bajo la barra de resolución hay dos filas para elegir, **por grupo y sus subgrupos**, de dónde sale la textura:
**Modelo** (por defecto), **Skin del jugador** (la skin real de quien lleva el modelo, también en multijugador) o **Skin propia**
(cualquier `.png` de `.minecraft/morphzuka/skins/`; `<` `>` para elegir, "Recargar skins" tras añadir archivos).
Un subgrupo puede elegir otra distinta que su padre; "Heredar" quita su elección. "Esta textura a todo el modelo" la copia a todos.
Los UV se leen como fracción de la imagen: una parte con el mapa de la skin de Minecraft (64x64) coincide con cualquier skin.
Se guarda en `config/morphzuka.json` (`partTex`).


## Físicas por parte (paso 22)
Las físicas ya **no** mueven todo el modelo: solo las partes que marques con **"Esta parte rebota"** (Editor 3D, barra de físicas, o pestaña Partes).
Ya no se marca ninguna sola por el nombre. Cada parte simula su punta (la de ella y sus subgrupos) como una masa en un resorte, en coordenadas del mundo,
así que reacciona a **caminar, saltar, girar el cuerpo y a cualquier animación** (bailes, gestos, gacha...), porque usa la pose final del hueso.
Un subgrupo marcado dentro de otro marcado hace cadena. Botones del editor: **Modelo se mueve** (pasea, gira y salta solo para probar sin jugador),
**Cuerpo entero** (el squash/stretch de antes, apagado por defecto; los ajustes viejos lo apagan una vez), **Quitar todas**.
Limitación: no compensa las poses de nadar / elytra / dormir (usa solo el giro del cuerpo).


## Paso 23: eliminar modelos
- **Importar** ahora tiene dos sub-pestañas: **Añadir modelo** (arrastrar, link, Base64) y **Mis modelos (N)**.
  En *Mis modelos* cada modelo de la carpeta `morphzuka/` tiene su botón **Eliminar** (pulsa dos veces para confirmar; borra el archivo,
  su `.png` / `.animation.json` si era `.geo.json`, sus ajustes y sus asignaciones). Los de CPM / GeckoLib de otros mods salen como "Solo lectura".
  Antes la lista iba debajo del formulario y desaparecía cuando la ventana era pequeña.


## Paso 24: jugador-bloque sólido
Cuando te transformas en **bloque**, ahora tienes **colisión** como un bloque real: los demás jugadores y los mobs chocan con tu caja,
pueden **saltar y subirse encima de ti**, y no te empujan (no eres "empujable").
- Clases: `BlockMorphRegistry` (quién va de bloque; el servidor lo rellena al aceptar el morph y el cliente lo deduce de tu forma y de las que
  retransmite el servidor), y los mixins comunes `EntityCollidableMixin` (`Entity.isCollidable` = true) y `LivingPushableMixin` (`isPushable` = false).
- La caja de colisión es la hitbox del morph (0,98 x 0,98), así que **deja activado "Copiar hitbox"** en la pestaña Morph; con ella apagada
  sigues siendo sólido pero con la caja normal de jugador.
- Hace falta el mod **también en el servidor** (en mundo propio ya va incluido). Sin el mod en el servidor, la colisión solo se predice
  en los clientes que lo tienen y el servidor la corregirá (se sentirá a tirones).
- Los espectadores y los jugadores muertos no son sólidos. Volver a tu forma normal quita la colisión al instante.
