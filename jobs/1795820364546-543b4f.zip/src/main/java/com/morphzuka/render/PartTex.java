package com.morphzuka.render;

import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;

/**
 * Textura por parte. Cada grupo puede usar la textura del modelo (por defecto), la skin del jugador que lo lleva
 * puesto o una skin propia (png en .minecraft/morphzuka/skins/). La eleccion de un grupo vale para sus subgrupos
 * mientras un subgrupo no elija otra. Los UV del modelo se leen como fraccion de la textura, asi que una parte
 * hecha con el mapa de la skin de Minecraft (64x64) coincide con cualquier skin.
 */
public final class PartTex {
    private PartTex() {}

    public static final String MODEL = "MODEL", SKIN = "SKIN", FILE = "FILE:";

    private static final Identifier STEVE = Identifier.of("minecraft", "textures/entity/player/wide/steve.png");

    private record Tex(Identifier id, int w, int h) {}
    private static final Map<String, Tex> CUSTOM = new HashMap<>();
    private static final Set<String> MISSING = new HashSet<>();

    public static Path dir() { return ModelManager.root().resolve("skins"); }

    private static List<String> listCache;

    /** Nombres (con .png) de las skins propias disponibles. Se lee la carpeta una vez; "Recargar skins" la vuelve a leer. */
    public static List<String> list() {
        if (listCache != null) return listCache;
        List<String> r = new ArrayList<>();
        Path d = dir();
        if (Files.isDirectory(d)) {
            try (Stream<Path> st = Files.list(d)) {
                st.map(p -> p.getFileName().toString()).filter(n -> n.toLowerCase(Locale.ROOT).endsWith(".png")).sorted().forEach(r::add);
            } catch (IOException ignored) {}
        }
        listCache = r;
        return r;
    }

    /** Olvida las skins cargadas (al recargar modelos o tras cambiar archivos). */
    public static void reload() {
        MinecraftClient mc = MinecraftClient.getInstance();
        for (Tex t : CUSTOM.values()) mc.getTextureManager().destroyTexture(t.id());
        CUSTOM.clear();
        MISSING.clear();
        listCache = null;
    }

    private static Tex custom(String file) {
        Tex t = CUSTOM.get(file);
        if (t != null) return t;
        if (MISSING.contains(file)) return null;
        try {
            Path root = dir().toAbsolutePath().normalize();
            Path f = root.resolve(file).normalize();
            if (!f.startsWith(root) || !Files.isRegularFile(f)) { MISSING.add(file); return null; }
            try (InputStream in = Files.newInputStream(f)) {
                NativeImage img = NativeImage.read(in);
                Identifier id = Identifier.of("morphzuka", "skins/" + file.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9/._-]", "_"));
                MinecraftClient.getInstance().getTextureManager().registerTexture(id, new NativeImageBackedTexture(img));
                t = new Tex(id, img.getWidth(), img.getHeight());
                CUSTOM.put(file, t);
                return t;
            }
        } catch (Throwable e) {
            ModelManager.LOG.warn("Skin propia no válida {}: {}", file, e.toString());
            MISSING.add(file);
            return null;
        }
    }

    /** Skin del jugador que se esta dibujando (o la del propio jugador / Steve en el editor). */
    public static Identifier skinOf(AbstractClientPlayerEntity p) {
        try {
            if (p != null) return p.getSkinTextures().texture();
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null) return mc.player.getSkinTextures().texture();
        } catch (Throwable ignored) {}
        return STEVE;
    }

    /** Textura final de una eleccion. Si el archivo no existe cae a la textura del modelo. */
    public static Identifier resolve(String key, BBModel m, Identifier skin) {
        if (key == null || key.equals(MODEL)) return m.texture;
        if (key.equals(SKIN)) return skin == null ? STEVE : skin;
        if (key.startsWith(FILE)) {
            Tex t = custom(key.substring(FILE.length()));
            return t == null ? m.texture : t.id();
        }
        return m.texture;
    }

    /** Tamano en pixeles de la imagen que se ve con esa eleccion (para dibujar el mapa UV). */
    public static int[] size(String key, BBModel m) {
        if (key != null && key.equals(SKIN)) return new int[]{64, 64};
        if (key != null && key.startsWith(FILE)) {
            Tex t = custom(key.substring(FILE.length()));
            if (t != null) return new int[]{t.w(), t.h()};
        }
        return new int[]{Math.max(1, m.imgW), Math.max(1, m.imgH)};
    }

    private static boolean path(BBModel.Bone b, String target, Deque<BBModel.Bone> acc) {
        acc.addLast(b);
        if (b.name.equals(target)) return true;
        for (BBModel.Bone c : b.children) if (path(c, target, acc)) return true;
        acc.removeLast();
        return false;
    }

    /** Eleccion que le toca a un grupo: la suya, la del ancestro mas cercano que haya elegido, o MODEL. */
    public static String effective(BBModel m, ModelManager.Settings s, String bone) {
        if (bone == null || s.partTex.isEmpty()) return MODEL;
        Deque<BBModel.Bone> acc = new ArrayDeque<>();
        for (BBModel.Bone r : m.roots) if (path(r, bone, acc)) break;
        Iterator<BBModel.Bone> it = acc.descendingIterator();
        while (it.hasNext()) {
            String k = s.partTex.get(it.next().name);
            if (k != null) return k;
        }
        return MODEL;
    }

    /** Eleccion heredada de los ancestros (sin contar el propio grupo). */
    public static String inherited(BBModel m, ModelManager.Settings s, String bone) {
        if (bone == null || s.partTex.isEmpty()) return MODEL;
        Deque<BBModel.Bone> acc = new ArrayDeque<>();
        for (BBModel.Bone r : m.roots) if (path(r, bone, acc)) break;
        if (!acc.isEmpty()) acc.removeLast();
        Iterator<BBModel.Bone> it = acc.descendingIterator();
        while (it.hasNext()) {
            String k = s.partTex.get(it.next().name);
            if (k != null) return k;
        }
        return MODEL;
    }

    /** Fija la textura de un grupo. MODEL sin nada que heredar borra la entrada. */
    public static void set(BBModel m, ModelManager.Settings s, String bone, String key) {
        if (bone == null) return;
        if (key == null || (key.equals(MODEL) && inherited(m, s, bone).equals(MODEL))) s.partTex.remove(bone);
        else s.partTex.put(bone, key);
    }

    /** Pone la misma textura a todos los grupos (borra las elecciones individuales). */
    public static void setAll(BBModel m, ModelManager.Settings s, String key) {
        s.partTex.clear();
        if (key != null && !key.equals(MODEL)) for (BBModel.Bone r : m.roots) s.partTex.put(r.name, key);
    }

    public static String label(String key) {
        if (key == null || key.equals(MODEL)) return "Textura del modelo";
        if (key.equals(SKIN)) return "Skin del jugador";
        if (key.startsWith(FILE)) return "Skin propia: " + key.substring(FILE.length());
        return key;
    }
}
