package com.morphzuka.render;

import com.morphzuka.Gestures;
import com.morphzuka.Role;
import com.morphzuka.model.AnimStates;
import com.morphzuka.model.BBModel;
import com.morphzuka.model.CubeXform;
import com.morphzuka.voice.VoiceState;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.BlockItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.UseAction;
import com.morphzuka.model.ModelManager;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityPose;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;
import org.joml.Quaternionf;

import java.util.ArrayList;
import java.util.List;

public final class BBRenderer {
    private BBRenderer() {}

    private static final float[] ZERO = {0, 0, 0};
    private static final float[] ONE = {1, 1, 1};

    private static final class Ctx {
        BBModel model;
        ModelManager.Settings s;
        BBModel.Anim anim;
        VertexConsumer vc;
        VertexConsumerProvider vcp;   // para cambiar de textura por parte (skin del jugador / skin propia)
        net.minecraft.util.Identifier skin;
        String curTex = PartTex.MODEL;
        int light, overlay;
        float animTime, time, pitch, headDelta, limbPos, limbSpeed;
        float swing;
        String highlight;      // hueso resaltado (editor 3D)
        String highlightCube;  // bloque resaltado (editor 3D)
        boolean tinted, tintedCube;
        float uvW, uvH, uvKx, uvKy;   // resolucion UV efectiva y escala del mapa del archivo
        Role swingArm = Role.NONE;
        final List<Layer> layers = new ArrayList<>();
        // transicion suave entre animaciones (crossfade)
        BBModel.Anim prevAnim;
        float prevTime;
        float blendW = 1f;     // peso de la animacion actual (0..1); la anterior pesa 1 - blendW
        float animMix;         // cuanto manda la animacion sobre el movimiento procedural (0..1)
        java.util.UUID physId;
        boolean physics;
        Matrix4f mm;           // espejo de la pila de matrices en espacio del modelo (px); solo si hay partes con fisicas
    }

    private record Layer(BBModel.Anim anim, float time) {}

    /** Prepara el dibujo con la textura del modelo; las partes con otra textura la cambian en {@link #bone}. */
    private static void initTex(Ctx c, VertexConsumerProvider vcp, net.minecraft.util.Identifier skin) {
        c.vcp = vcp;
        c.skin = skin;
        c.curTex = PartTex.MODEL;
        c.vc = vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(c.model.texture));
    }

    private static void useTex(Ctx c, String key) {
        c.curTex = key;
        c.vc = c.vcp.getBuffer(RenderLayer.getEntityCutoutNoCull(PartTex.resolve(key, c.model, c.skin)));
    }

    private static final class Track {
        String state = "";
        float start, jumpStart = -10f;
        boolean wasGround = true;
        float lastT = Float.NaN;
        BBModel.Anim curAnim, fromAnim;      // animacion actual y la que se esta apagando
        float curTime, fromTime, blendT;
        final java.util.Map<String, Float> starts = new java.util.HashMap<>();
    }
    private static final java.util.Map<java.util.UUID, Track> TRACKS = new java.util.HashMap<>();

    public static void render(AbstractClientPlayerEntity p, float td, MatrixStack m, VertexConsumerProvider vcp,
                              int light, ModelManager.Active a) {
        BBModel mod = a.model();
        ModelManager.Settings s = a.settings();

        float bodyYaw = MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw);
        float headYaw = MathHelper.lerpAngleDegrees(td, p.prevHeadYaw, p.headYaw);

        Ctx c = new Ctx();
        c.model = mod;
        c.s = s;
        c.light = light;
        c.overlay = LivingEntityRenderer.getOverlay(p, 0f);
        c.headDelta = MathHelper.clamp(MathHelper.wrapDegrees(headYaw - bodyYaw), -75f, 75f);
        c.pitch = MathHelper.lerp(td, p.prevPitch, p.getPitch());
        c.limbPos = p.limbAnimator.getPos(td);
        c.limbSpeed = Math.min(1f, p.limbAnimator.getSpeed(td));
        c.time = (p.age + td) / 20f;

        c.swing = p.getHandSwingProgress(td);
        Arm swingArm = p.preferredHand == Hand.MAIN_HAND ? p.getMainArm() : p.getMainArm().getOpposite();
        c.swingArm = swingArm == Arm.RIGHT ? Role.RIGHT_ARM : Role.LEFT_ARM;
        chooseAnimation(p, c, p == MinecraftClient.getInstance().player);

        c.physId = p.getUuid();
        c.physics = s.physicsOn;
        float bounce = 0f;
        float scPhys = (s.scale <= 0 ? 1f : s.scale) * Transition.scale(p.getUuid());
        if (s.physicsOn) {
            net.minecraft.util.math.Vec3d pos = p.getLerpedPos(td);
            // update solo mueve el cuerpo entero (squash/stretch); las partes se simulan una a una en bone()
            Physics.update(p.getUuid(), pos.x, pos.y, pos.z, bodyYaw, c.time, s, java.util.List.of());
            if (s.physicsBody) bounce = Physics.bounce(p.getUuid());
            if (!s.physBones.isEmpty()) {
                Physics.beginFrame(p.getUuid(), pos.x, pos.y, pos.z, bodyYaw, scPhys / 16f, c.time, s.physicsIntensity);
                c.mm = new Matrix4f();
            }
        }

        initTex(c, vcp, PartTex.skinOf(p));

        float sc = s.scale <= 0 ? 1f : s.scale;
        sc *= Transition.scale(p.getUuid());
        m.push();
        applyPoseTransform(p, td, m, bodyYaw);
        float kk = sc / 16f;
        m.scale(kk * (1f - bounce * 0.5f), kk * (1f + bounce), kk * (1f - bounce * 0.5f));
        for (BBModel.Bone b : mod.roots) bone(c, b, m);
        m.pop();
        Physics.endFrame();
    }

    /** Animacion en vista previa del editor: la actual, la que se apaga y el peso del fundido. */
    public record Pv(BBModel.Anim anim, float time, BBModel.Anim from, float fromTime, float w) {}

    /** Dibuja el modelo en pose estatica (sin jugador ni animacion) para el editor 3D. Unidades de salida: bloques. */
    public static void renderPreview(BBModel mod, ModelManager.Settings s, MatrixStack m, VertexConsumerProvider vcp,
                                     int light, String highlight) {
        renderPreview(mod, s, m, vcp, light, highlight, null, false, null);
    }

    /** sim = true: simula el ataque (brazo) y el seguimiento de cabeza con {@link PreviewSim}. */
    public static void renderPreview(BBModel mod, ModelManager.Settings s, MatrixStack m, VertexConsumerProvider vcp,
                                     int light, String highlight, String highlightCube, boolean sim, Pv pv) {
        Ctx c = new Ctx();
        c.model = mod;
        c.s = s;
        c.light = light;
        c.overlay = OverlayTexture.DEFAULT_UV;
        c.highlight = highlight;
        c.highlightCube = highlightCube;
        if (pv != null) {
            c.anim = pv.anim();
            c.animTime = pv.time();
            c.prevAnim = pv.from();
            c.prevTime = pv.fromTime();
            c.blendW = pv.w();
            c.animMix = (pv.anim() != null ? pv.w() : 0f) + (pv.from() != null ? 1f - pv.w() : 0f);
        }
        if (sim) {
            c.time = PreviewSim.time();
            c.swing = PreviewSim.swing();
            c.swingArm = Role.RIGHT_ARM;
            c.pitch = PreviewSim.pitch();
            c.headDelta = PreviewSim.headDelta();
            if (c.swing > 0f && s.followArms) {              // si el modelo trae animacion de ataque, se usa esa
                List<String> atk = ModelManager.animsWithCat(mod, s, ModelManager.CAT_ATTACK);
                BBModel.Anim an = atk.isEmpty() ? null : ModelManager.anim(mod, atk.get(0));
                if (an != null) { c.anim = an; c.animTime = c.swing * Math.max(0.0001f, an.length); c.swing = 0f; c.blendW = 1f; c.prevAnim = null; c.animMix = 1f; }
            }
        }
        c.physId = Physics.PREVIEW;
        c.physics = s.physicsOn;
        initTex(c, vcp, PartTex.skinOf(null));
        float sc = s.scale <= 0 ? 1f : s.scale;
        float bounce = s.physicsOn && s.physicsBody ? Physics.bounce(Physics.PREVIEW) : 0f;
        m.push();
        float kk = sc / 16f;
        m.scale(kk * (1f - bounce * 0.5f), kk * (1f + bounce), kk * (1f - bounce * 0.5f));
        if (s.physicsOn && !s.physBones.isEmpty()) {
            // sin jugador: el modelo puede "pasear, girar y saltar" solo para probar las fisicas
            float pt = Physics.clock();
            double ex = 0, ey = 0, ez = 0;
            float yaw = 0f;
            if (Physics.previewMove) {
                ex = Math.sin(pt * 1.1) * 1.4;
                ez = Math.cos(pt * 0.7) * 0.8;
                ey = Math.abs(Math.sin(pt * 2.3)) * 0.45;
                yaw = (float) Math.sin(pt * 0.9) * 70f;
            }
            Physics.beginFrame(Physics.PREVIEW, ex, ey, ez, yaw, kk, pt, s.physicsIntensity);
            c.mm = new Matrix4f();
        }
        for (BBModel.Bone b : mod.roots) bone(c, b, m);
        m.pop();
        Physics.endFrame();
    }

    private static void applyPoseTransform(AbstractClientPlayerEntity p, float td, MatrixStack m, float bodyYaw) {
        if (p.isInPose(EntityPose.SLEEPING)) {
            Direction d = p.getSleepingDirection();
            float k = d == null ? bodyYaw : switch (d) {
                case SOUTH -> 90f;
                case WEST -> 0f;
                case NORTH -> 270f;
                case EAST -> 180f;
                default -> 0f;
            };
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(k));
            m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(90f));
            m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(270f));
            return;
        }
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f - bodyYaw));
        float pitch = MathHelper.lerp(td, p.prevPitch, p.getPitch());
        if (p.isFallFlying()) {
            float t = p.getFallFlyingTicks() + td;
            float i = MathHelper.clamp(t * t / 100f, 0f, 1f);
            m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(i * (-90f - pitch)));
        } else {
            float lean = p.getLeaningPitch(td);
            if (lean > 0f) {
                float target = p.isTouchingWater() ? -90f - pitch : -90f;
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(MathHelper.lerp(lean, 0f, target)));
                if (p.isInSwimmingPose()) m.translate(0f, -1f, 0.3f);
            }
        }
    }

    // ------------------------------------------------------------ helpers de estado

    private static BBModel.Anim assigned(BBModel mod, ModelManager.Settings s, String key) {
        String n = s.anims.get(key);
        return n == null ? null : ModelManager.anim(mod, n);
    }

    private static Arm activeArm(AbstractClientPlayerEntity p) {
        return p.getActiveHand() == Hand.MAIN_HAND ? p.getMainArm() : p.getMainArm().getOpposite();
    }

    private static ItemStack handStack(AbstractClientPlayerEntity p, Arm arm) {
        return arm == p.getMainArm() ? p.getMainHandStack() : p.getOffHandStack();
    }

    private static boolean using(AbstractClientPlayerEntity p, Arm arm, UseAction... acts) {
        if (!p.isUsingItem() || activeArm(p) != arm) return false;
        UseAction ua = p.getActiveItem().getUseAction();
        for (UseAction a : acts) if (a == ua) return true;
        return false;
    }

    private static boolean layerActive(String k, AbstractClientPlayerEntity p, Ctx c, boolean self) {
        MinecraftClient mc = MinecraftClient.getInstance();
        return switch (k) {
            case "GLOBAL" -> true;
            case "SWING_L" -> c.swing > 0f && c.swingArm == Role.LEFT_ARM;
            case "SWING_R" -> c.swing > 0f && c.swingArm == Role.RIGHT_ARM;
            case "EAT_L" -> using(p, Arm.LEFT, UseAction.EAT, UseAction.DRINK);
            case "EAT_R" -> using(p, Arm.RIGHT, UseAction.EAT, UseAction.DRINK);
            case "ARMOR_HEAD" -> !p.getEquippedStack(EquipmentSlot.HEAD).isEmpty();
            case "ARMOR_BODY" -> !p.getEquippedStack(EquipmentSlot.CHEST).isEmpty();
            case "ARMOR_LEGS" -> !p.getEquippedStack(EquipmentSlot.LEGS).isEmpty();
            case "ARMOR_BOOTS" -> !p.getEquippedStack(EquipmentSlot.FEET).isEmpty();
            case "ELYTRA_WEAR" -> p.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
            case "BOW_L" -> using(p, Arm.LEFT, UseAction.BOW);
            case "BOW_R" -> using(p, Arm.RIGHT, UseAction.BOW);
            case "XBOW_HOLD_L" -> CrossbowItem.isCharged(handStack(p, Arm.LEFT));
            case "XBOW_HOLD_R" -> CrossbowItem.isCharged(handStack(p, Arm.RIGHT));
            case "XBOW_LOAD_L" -> using(p, Arm.LEFT, UseAction.CROSSBOW);
            case "XBOW_LOAD_R" -> using(p, Arm.RIGHT, UseAction.CROSSBOW);
            case "TRIDENT_L" -> using(p, Arm.LEFT, UseAction.SPEAR);
            case "TRIDENT_R" -> using(p, Arm.RIGHT, UseAction.SPEAR);
            case "TRIDENT_SPIN" -> p.isUsingRiptide();
            case "SPYGLASS_L" -> using(p, Arm.LEFT, UseAction.SPYGLASS);
            case "SPYGLASS_R" -> using(p, Arm.RIGHT, UseAction.SPYGLASS);
            case "HOLD_L" -> !handStack(p, Arm.LEFT).isEmpty();
            case "HOLD_R" -> !handStack(p, Arm.RIGHT).isEmpty();
            case "SKULL" -> p.getEquippedStack(EquipmentSlot.HEAD).getItem() instanceof BlockItem bi && bi.getBlock() instanceof AbstractSkullBlock;
            case "BLOCK_L" -> using(p, Arm.LEFT, UseAction.BLOCK);
            case "BLOCK_R" -> using(p, Arm.RIGHT, UseAction.BLOCK);
            case "PARROT_L" -> !p.getShoulderEntityLeft().isEmpty();
            case "PARROT_R" -> !p.getShoulderEntityRight().isEmpty();
            case "HURT" -> p.hurtTime > 0;
            case "ON_FIRE" -> p.isOnFire();
            case "FREEZING" -> p.getFrozenTicks() > 0;
            case "SPEAKING" -> VoiceState.isSpeaking(p.getUuid());
            case "VOICE_MUTED" -> self && VoiceState.muted;
            case "HORN_L" -> using(p, Arm.LEFT, UseAction.TOOT_HORN);
            case "HORN_R" -> using(p, Arm.RIGHT, UseAction.TOOT_HORN);
            case "BRUSH_L" -> using(p, Arm.LEFT, UseAction.BRUSH);
            case "BRUSH_R" -> using(p, Arm.RIGHT, UseAction.BRUSH);
            case "CONTAINER" -> self && mc.currentScreen instanceof HandledScreen<?>;
            case "FP_VIEW" -> self && mc.options.getPerspective().isFirstPerson();
            default -> false; // FP_HAND se aplica solo al dibujar la mano en primera persona
        };
    }

    private static float value(String k, AbstractClientPlayerEntity p, Ctx c) {
        return switch (k) {
            case "HEALTH" -> p.getHealth() / Math.max(1f, p.getMaxHealth());
            case "HUNGER" -> p.getHungerManager().getFoodLevel() / 20f;
            case "AIR" -> p.getAir() / (float) Math.max(1, p.getMaxAir());
            case "LIGHT" -> p.getWorld().getLightLevel(p.getBlockPos()) / 15f;
            case "HEAD_YAW" -> (c.headDelta + 75f) / 150f;
            case "HEAD_PITCH" -> (c.pitch + 90f) / 180f;
            default -> 0f;
        };
    }

    private static float animTimeOf(BBModel.Anim a, float t, ModelManager.LoopMode mode) {
        return ModelManager.timeFor(a, t, mode);
    }

    private static float smooth(float w) {
        w = Math.max(0f, Math.min(1f, w));
        return w * w * (3f - 2f * w);
    }

    /**
     * Elige la animacion (pickAnimation) y la funde con la anterior: durante s.blend segundos la vieja baja y la nueva sube
     * (interpolacion de rotaciones, posiciones y escalas hueso a hueso). Si no hay animacion, el movimiento procedural
     * (brazos y piernas al caminar) tambien entra y sale con suavidad.
     */
    private static void chooseAnimation(AbstractClientPlayerEntity p, Ctx c, boolean self) {
        pickAnimation(p, c, self);
        Track tr = TRACKS.computeIfAbsent(p.getUuid(), k -> new Track());
        float dt = Float.isNaN(tr.lastT) ? 0f : Math.max(0f, Math.min(0.1f, c.time - tr.lastT));
        tr.lastT = c.time;
        BBModel.Anim pa = c.anim;
        if (pa != tr.curAnim) {
            tr.fromAnim = tr.curAnim;
            tr.fromTime = tr.curTime;
            tr.blendT = 0f;
            tr.curAnim = pa;
        }
        tr.curTime = c.animTime;
        float w = 1f;
        float blend = c.s.blend;
        if (tr.fromAnim != null) {
            if (blend <= 0f) tr.fromAnim = null;
            else {
                tr.blendT += dt;
                w = Math.min(1f, tr.blendT / blend);
                if (w >= 1f) tr.fromAnim = null;
                else tr.fromTime = ModelManager.timeFor(tr.fromAnim, tr.fromTime + dt, ModelManager.loopMode(c.s, tr.fromAnim, true));
            }
        } else if (pa != null && tr.blendT < blend) {     // de "sin animacion" a una animacion: sube desde 0
            tr.blendT += dt;
            w = blend <= 0f ? 1f : Math.min(1f, tr.blendT / blend);
        }
        w = smooth(w);
        c.prevAnim = tr.fromAnim;
        c.prevTime = tr.fromTime;
        c.blendW = w;
        c.animMix = (pa != null ? w : 0f) + (tr.fromAnim != null ? 1f - w : 0f);
    }

    private static void pickAnimation(AbstractClientPlayerEntity p, Ctx c, boolean self) {
        BBModel mod = c.model;
        ModelManager.Settings s = c.s;
        Track tr = TRACKS.computeIfAbsent(p.getUuid(), k -> new Track());
        boolean ground = p.isOnGround();
        if (tr.wasGround && !ground && p.getVelocity().y > 0.1) tr.jumpStart = c.time;
        tr.wasGround = ground;

        // ---- animacion de inicio (categoria SETUP): una vez cuando el modelo aparece en tu jugador
        if (self && !mod.id.equals(Gestures.setupModel)) {
            Gestures.setupModel = mod.id;
            List<String> st = ModelManager.animsWithCat(mod, s, ModelManager.CAT_SETUP);
            if (!st.isEmpty()) Gestures.play(mod, s, st.get(0));
        }

        // ---- capas y capas de valor: todas las activas se suman
        for (AnimStates.Def d : AnimStates.ALL) {
            if (d.kind() == AnimStates.Kind.POSE) continue;
            BBModel.Anim a = assigned(mod, s, d.key());
            if (a == null) continue;
            float len = Math.max(0.0001f, a.length);
            if (d.kind() == AnimStates.Kind.VALUE) {
                c.layers.add(new Layer(a, MathHelper.clamp(value(d.key(), p, c), 0f, 1f) * len));
                continue;
            }
            if (!layerActive(d.key(), p, c, self)) { tr.starts.remove(d.key()); continue; }
            if (d.key().startsWith("SWING_")) {
                c.layers.add(new Layer(a, c.swing * len));
                c.swing = 0f; // el golpe lo hace la animacion, no el vanilla
                continue;
            }
            Float st = tr.starts.get(d.key());
            if (st == null) { st = c.time; tr.starts.put(d.key(), st); }
            ModelManager.LoopMode lm = ModelManager.loopMode(s, a, true);
            if (ModelManager.finished(a, c.time - st, lm)) continue;   // "Una vez": ya termino
            c.layers.add(new Layer(a, animTimeOf(a, c.time - st, lm)));
        }
        // capas toggle del jugador (categoria TOGGLE)
        if (self) {
            for (String n : Gestures.toggles) {
                BBModel.Anim a = ModelManager.anim(mod, n);
                if (a != null) c.layers.add(new Layer(a, animTimeOf(a, c.time, ModelManager.loopModeOr(s, a, ModelManager.LoopMode.LOOP))));
            }
        }

        // ---- animacion principal
        if (self && Gestures.sliderAnim != null) {                 // slider
            BBModel.Anim an = ModelManager.anim(mod, Gestures.sliderAnim);
            if (an != null) { c.anim = an; c.animTime = Gestures.sliderT * Math.max(0.0001f, an.length); return; }
        }
        if (self && Gestures.current != null) {                    // gesto o comando
            BBModel.Anim an = ModelManager.anim(mod, Gestures.current);
            if (an != null) {
                float t = Gestures.elapsedSec();
                c.anim = an;
                c.animTime = animTimeOf(an, t, Gestures.mode);
                return;
            }
        }
        if (self && Gestures.pose != null) {                       // pose personalizada
            BBModel.Anim an = ModelManager.anim(mod, Gestures.pose);
            if (an != null) { c.anim = an; c.animTime = animTimeOf(an, c.time, ModelManager.loopModeOr(s, an, ModelManager.LoopMode.LOOP)); return; }
        }
        if (c.swing > 0f && s.followArms) {                        // animacion con categoria ATTACK
            List<String> atk = ModelManager.animsWithCat(mod, s, ModelManager.CAT_ATTACK);
            if (!atk.isEmpty()) {
                BBModel.Anim an = ModelManager.anim(mod, atk.get(0));
                if (an != null) { c.anim = an; c.animTime = c.swing * Math.max(0.0001f, an.length); c.swing = 0f; return; }
            }
        }

        boolean moving = c.limbSpeed > 0.02f;
        boolean air = !ground && !p.isTouchingWater() && !p.isClimbing();
        boolean swimPose = p.isInSwimmingPose();
        List<String> el = new ArrayList<>(12);
        if (p.deathTime > 0 || p.isDead()) el.add("DYING");
        if (p.isSleeping()) el.add("SLEEP");
        if (p.isFallFlying()) el.add("ELYTRA");
        if (p.getAbilities().flying && !ground) el.add("CREATIVE_FLY");
        if (swimPose) { if (p.isTouchingWater()) el.add("SWIM"); el.add("CRAWL"); if (!p.isTouchingWater()) el.add("SWIM"); }
        if (p.hasVehicle()) el.add("RIDE");
        if (p.isClimbing()) { boolean vert = Math.abs(p.getVelocity().y) > 0.01; el.add(vert ? "CLIMB" : "LADDER_STAND"); el.add(vert ? "LADDER_STAND" : "CLIMB"); }
        if (p.isInSneakingPose()) { if (moving) el.add("SNEAK_WALK"); el.add("SNEAK"); }
        if (air) {
            boolean up = p.getVelocity().y > 0 && c.time - tr.jumpStart < 0.5f;
            el.add(up ? "JUMP" : "FALL");
            el.add(up ? "FALL" : "JUMP");
        }
        if (p.isTouchingWater()) el.add("WATER");
        if (moving && p.isSprinting()) el.add("SPRINT");
        if (moving) el.add("WALK");
        el.add("IDLE");

        String chosen = null;
        BBModel.Anim found = null;
        for (String st : el) {
            BBModel.Anim a = assigned(mod, s, st);
            if (a != null) { chosen = st; found = a; break; }
        }
        if (found == null) return;
        if (!chosen.equals(tr.state)) { tr.state = chosen; tr.start = c.time; }
        ModelManager.LoopMode lm = ModelManager.loopMode(s, found, true);
        float t = c.time - tr.start;
        if (ModelManager.finished(found, t, lm)) return;   // "Una vez": termino, vuelve al movimiento normal
        c.anim = found;
        c.animTime = animTimeOf(found, t, lm);
    }

    /** Mano del modelo en primera persona: dibuja el hueso con rol de brazo en lugar del brazo vanilla. */
    public static boolean renderFirstPersonArm(AbstractClientPlayerEntity p, MatrixStack m, VertexConsumerProvider vcp,
                                               int light, boolean right, ModelManager.Active a) {
        BBModel mod = a.model();
        ModelManager.Settings s = a.settings();
        Role want = right ? Role.RIGHT_ARM : Role.LEFT_ARM;
        BBModel.Bone arm = null;
        for (BBModel.Bone b : mod.bones.values())
            if (Role.of(s.roles.get(b.name)) == want) { arm = b; break; }
        if (arm == null) return false;
        Ctx c = new Ctx();
        c.model = mod;
        c.s = s;
        c.light = light;
        c.overlay = OverlayTexture.DEFAULT_UV;
        initTex(c, vcp, PartTex.skinOf(p));
        float[] piv = s.pivots.getOrDefault(arm.name, arm.pivot);
        for (String k : new String[]{"FP_HAND", "FP_VIEW"}) {
            BBModel.Anim fa = assigned(mod, s, k);
            if (fa != null) c.layers.add(new Layer(fa, fa.length > 0 ? ((p.age) / 20f) % fa.length : 0f));
        }
        String inh = PartTex.inherited(mod, s, arm.name);   // la mano se dibuja sola: hereda la textura de sus grupos padre
        if (!inh.equals(PartTex.MODEL)) useTex(c, inh);
        m.push();
        m.scale(1f / 16f, 1f / 16f, 1f / 16f);
        m.translate(0f, 24f, 0f);
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(180f));
        m.translate((right ? 5f : -5f) - piv[0], 22f - piv[1], -piv[2]);
        bone(c, arm, m);
        m.pop();
        return true;
    }

    // positivo en X = swing hacia delante (frente del modelo = -Z)
    private static final float[] PR = new float[3];

    private static void procedural(Ctx c, Role r, float[] res) {
        res[0] = res[1] = res[2] = 0f;
        float cosA = MathHelper.cos(c.limbPos * 0.6662f);
        float arm = 57.3f * c.limbSpeed, leg = 80f * c.limbSpeed;
        float mix = 1f - Math.max(0f, Math.min(1f, c.animMix));   // si hay animacion manda ella (con fundido)
        switch (r) {
            case HEAD -> { if (c.s.followHead) { res[0] = -c.pitch; res[1] = -c.headDelta; } }
            case LEFT_ARM -> res[0] = arm * cosA * mix;
            case RIGHT_ARM -> res[0] = -arm * cosA * mix;
            case LEFT_LEG -> res[0] = -leg * cosA * mix;
            case RIGHT_LEG -> res[0] = leg * cosA * mix;
            case TAIL -> res[1] = MathHelper.sin(c.time * 2.5f) * 10f + cosA * 20f * c.limbSpeed;
            default -> {}
        }
        if (c.swing > 0f && c.s.followArms && r == c.swingArm) { // golpe vanilla
            float f = 1f - c.swing;
            f = 1f - f * f * f * f;
            float hp = (float) Math.toRadians(c.pitch);
            float a = MathHelper.sin(f * (float) Math.PI) * 1.2f + MathHelper.sin(c.swing * (float) Math.PI) * (-(hp - 0.7f)) * 0.75f;
            res[0] += (float) Math.toDegrees(a);
        }
    }

    // buffers reutilizables (el render va en un solo hilo): evitan miles de objetos por frame
    private static final float[] S1 = new float[3], S2 = new float[3], S3 = new float[3];
    private static final float[] ROT = new float[3], POS = new float[3], SCL = new float[3];
    private static final Quaternionf Q = new Quaternionf();
    private static final float[] PH = new float[2];
    private static final float[] CPV = new float[3];

    private static void applyAnim(BBModel.Anim a, float t, float w, BBModel.Bone b, Role role, float[] rot, float[] pos, float[] sc) {
        if (a == null || w <= 0f) return;
        BBModel.BoneAnim ba = a.bones.get(b.name);
        if (ba == null && role != Role.NONE) ba = a.bones.get(role.alias); // animaciones portables
        if (ba == null) return;
        BBModel.sampleInto(ba.rot, t, S1, 0, 0, 0);
        BBModel.sampleInto(ba.pos, t, S2, 0, 0, 0);
        BBModel.sampleInto(ba.scale, t, S3, 1, 1, 1);
        for (int i = 0; i < 3; i++) { rot[i] += S1[i] * w; pos[i] += S2[i] * w; sc[i] *= 1f + (S3[i] - 1f) * w; }
    }

    private static void bone(Ctx c, BBModel.Bone b, MatrixStack m) {
        m.push();
        Matrix4f parentMM = c.mm;
        if (parentMM != null) c.mm = new Matrix4f(parentMM);
        String prevTex = c.curTex;
        if (!c.s.partTex.isEmpty()) {
            String pk = c.s.partTex.get(b.name);
            if (pk != null && !pk.equals(c.curTex)) useTex(c, pk);
        }
        float[] piv = c.s.pivots.getOrDefault(b.name, b.pivot);
        float[] rot = ROT, pos = POS, sc = SCL;
        rot[0] = b.rot[0]; rot[1] = b.rot[1]; rot[2] = b.rot[2];
        pos[0] = pos[1] = pos[2] = 0f;
        sc[0] = sc[1] = sc[2] = 1f;
        float[] off = c.s.offsets.get(b.name);
        if (off != null) { pos[0] += off[0]; pos[1] += off[1]; pos[2] += off[2]; }
        float[] ro = c.s.rotOffsets.get(b.name);
        if (ro != null) { rot[0] += ro[0]; rot[1] += ro[1]; rot[2] += ro[2]; }
        float[] bs = c.s.scales.get(b.name);
        if (bs != null) { sc[0] *= bs[0]; sc[1] *= bs[1]; sc[2] *= bs[2]; }
        Role role = Role.of(c.s.roles.get(b.name));
        if (c.prevAnim != null) applyAnim(c.prevAnim, c.prevTime, 1f - c.blendW, b, role, rot, pos, sc);
        applyAnim(c.anim, c.animTime, c.blendW, b, role, rot, pos, sc);
        for (int i = 0; i < c.layers.size(); i++) {
            Layer l = c.layers.get(i);
            applyAnim(l.anim(), l.time(), 1f, b, role, rot, pos, sc);
        }
        if (role != Role.NONE) {
            procedural(c, role, PR);
            rot[0] += PR[0]; rot[1] += PR[1]; rot[2] += PR[2];
        }
        // fisicas: solo las partes marcadas; giro extra en el marco del padre (la punta de la parte sigue a su masa)
        Quaternionf qp = null;
        if (parentMM != null && c.physics && c.s.physBones.contains(b.name)) qp = Physics.solve(b, parentMM, piv, pos, rot, sc);
        m.translate(piv[0] + pos[0], piv[1] + pos[1], piv[2] + pos[2]);
        if (c.mm != null) c.mm.translate(piv[0] + pos[0], piv[1] + pos[1], piv[2] + pos[2]);
        if (qp != null) { m.multiply(qp); c.mm.rotate(qp); }
        if (rot[0] != 0f || rot[1] != 0f || rot[2] != 0f) {
            Q.rotationZYX((float) Math.toRadians(rot[2]), (float) Math.toRadians(rot[1]), (float) Math.toRadians(rot[0]));
            m.multiply(Q);
            if (c.mm != null) c.mm.rotate(Q);
        }
        if (sc[0] != 1f || sc[1] != 1f || sc[2] != 1f) {
            m.scale(Math.max(0.001f, sc[0]), Math.max(0.001f, sc[1]), Math.max(0.001f, sc[2]));
            if (c.mm != null) c.mm.scale(Math.max(0.001f, sc[0]), Math.max(0.001f, sc[1]), Math.max(0.001f, sc[2]));
        }
        m.translate(-piv[0], -piv[1], -piv[2]);
        if (c.mm != null) c.mm.translate(-piv[0], -piv[1], -piv[2]);

        if (b.visible && !c.s.hidden.contains(b.name)) {
            c.tinted = c.highlight != null && c.highlight.equals(b.name);
            for (int i = 0; i < b.cubes.size(); i++) {
                BBModel.Cube cu = b.cubes.get(i);
                c.tintedCube = c.highlightCube != null && c.highlightCube.equals(cu.key);
                cube(c, cu, m);
            }
            c.tinted = false;
            c.tintedCube = false;
        }
        for (int i = 0; i < b.children.size(); i++) bone(c, b.children.get(i), m);
        c.mm = parentMM;
        if (!c.curTex.equals(prevTex)) useTex(c, prevTex);   // vuelve a la textura del grupo padre para los hermanos
        m.pop();
    }

    /** Resolucion UV efectiva (la del archivo o la elegida en el editor). */
    public static int uvW(BBModel m, ModelManager.Settings s) { return Math.max(1, s.uvW > 0 ? s.uvW : m.texW); }

    public static int uvH(BBModel m, ModelManager.Settings s) { return Math.max(1, s.uvH > 0 ? s.uvH : m.texH); }

    public static float uvKx(BBModel m, ModelManager.Settings s) { return s.uvKeep ? uvW(m, s) / (float) Math.max(1, m.texW) : 1f; }

    public static float uvKy(BBModel m, ModelManager.Settings s) { return s.uvKeep ? uvH(m, s) / (float) Math.max(1, m.texH) : 1f; }

    private static void setupUv(Ctx c) {
        c.uvW = uvW(c.model, c.s);
        c.uvH = uvH(c.model, c.s);
        c.uvKx = uvKx(c.model, c.s);
        c.uvKy = uvKy(c.model, c.s);
    }

    private static final String[] DIRS = {"north", "south", "east", "west", "up", "down"};
    private static final float[] UV = new float[4];

    private static void cube(Ctx c, BBModel.Cube cu, MatrixStack m) {
        m.push();
        if (CubeXform.needs(cu, c.s)) {   // rotacion del archivo + edicion por bloque (mover / rotar / escalar / pivote)
            CubeXform.pivotInto(cu, c.s, CPV);
            float[] off = c.s.cubeOffsets.get(cu.key), ro = c.s.cubeRots.get(cu.key), sc = c.s.cubeScales.get(cu.key);
            m.translate(CPV[0] + (off == null ? 0f : off[0]), CPV[1] + (off == null ? 0f : off[1]), CPV[2] + (off == null ? 0f : off[2]));
            float rx = cu.rot[0] + (ro == null ? 0f : ro[0]), ry = cu.rot[1] + (ro == null ? 0f : ro[1]), rz = cu.rot[2] + (ro == null ? 0f : ro[2]);
            if (rx != 0f || ry != 0f || rz != 0f) {
                Q.rotationZYX((float) Math.toRadians(rz), (float) Math.toRadians(ry), (float) Math.toRadians(rx));
                m.multiply(Q);
            }
            if (sc != null) m.scale(Math.max(0.001f, sc[0]), Math.max(0.001f, sc[1]), Math.max(0.001f, sc[2]));
            m.translate(-CPV[0], -CPV[1], -CPV[2]);
        }
        MatrixStack.Entry e = m.peek();
        Matrix4f mat = e.getPositionMatrix();
        float i = cu.inflate;
        float x0 = cu.from[0] - i, y0 = cu.from[1] - i, z0 = cu.from[2] - i;
        float x1 = cu.to[0] + i, y1 = cu.to[1] + i, z1 = cu.to[2] + i;
        if (c.uvW == 0f) setupUv(c);
        float[] sh = c.s.uvShift.isEmpty() ? null : c.s.uvShift.get(cu.key);

        if (uvRect(cu, 0, c.uvKx, c.uvKy, sh, UV)) quad(c, e, mat, UV, x1, y1, z0, x0, y1, z0, x0, y0, z0, x1, y0, z0, 0, 0, -1);
        if (uvRect(cu, 1, c.uvKx, c.uvKy, sh, UV)) quad(c, e, mat, UV, x0, y1, z1, x1, y1, z1, x1, y0, z1, x0, y0, z1, 0, 0, 1);
        if (uvRect(cu, 2, c.uvKx, c.uvKy, sh, UV)) quad(c, e, mat, UV, x1, y1, z1, x1, y1, z0, x1, y0, z0, x1, y0, z1, 1, 0, 0);
        if (uvRect(cu, 3, c.uvKx, c.uvKy, sh, UV)) quad(c, e, mat, UV, x0, y1, z0, x0, y1, z1, x0, y0, z1, x0, y0, z0, -1, 0, 0);
        if (uvRect(cu, 4, c.uvKx, c.uvKy, sh, UV)) quad(c, e, mat, UV, x0, y1, z0, x1, y1, z0, x1, y1, z1, x0, y1, z1, 0, 1, 0);
        if (uvRect(cu, 5, c.uvKx, c.uvKy, sh, UV)) quad(c, e, mat, UV, x0, y0, z1, x1, y0, z1, x1, y0, z0, x0, y0, z0, 0, -1, 0);
        m.pop();
    }

    /**
     * Rectangulo UV [u1,v1,u2,v2] de una cara (0 north, 1 south, 2 east, 3 west, 4 up, 5 down) en pixeles de la resolucion UV
     * efectiva: coordenadas del archivo * escala + desplazamiento. Lo comparten el renderer y el editor de UV.
     */
    public static boolean uvRect(BBModel.Cube cu, int dir, float kx, float ky, float[] shift, float[] out) {
        if (!uvRaw(cu, dir, out)) return false;
        float du = shift == null ? 0f : shift[0], dv = shift == null ? 0f : shift[1];
        out[0] = out[0] * kx + du; out[2] = out[2] * kx + du;
        out[1] = out[1] * ky + dv; out[3] = out[3] * ky + dv;
        return true;
    }

    private static boolean uvRaw(BBModel.Cube cu, int dir, float[] out) {
        if (cu.boxUv) {
            float w = Math.abs(cu.to[0] - cu.from[0]), h = Math.abs(cu.to[1] - cu.from[1]), d = Math.abs(cu.to[2] - cu.from[2]);
            float u = cu.uvOffset[0], v = cu.uvOffset[1];
            switch (dir) {
                case 2 -> { out[0] = u; out[1] = v + d; out[2] = u + d; out[3] = v + d + h; }
                case 0 -> { out[0] = u + d; out[1] = v + d; out[2] = u + d + w; out[3] = v + d + h; }
                case 3 -> { out[0] = u + d + w; out[1] = v + d; out[2] = u + 2 * d + w; out[3] = v + d + h; }
                case 1 -> { out[0] = u + 2 * d + w; out[1] = v + d; out[2] = u + 2 * d + 2 * w; out[3] = v + d + h; }
                case 4 -> { out[0] = u + d; out[1] = v; out[2] = u + d + w; out[3] = v + d; }
                default -> { out[0] = u + d + w; out[1] = v; out[2] = u + d + 2 * w; out[3] = v + d; }
            }
            return true;
        }
        float[] f = cu.faces.get(DIRS[dir]);
        if (f == null) return false;
        out[0] = f[0]; out[1] = f[1]; out[2] = f[2]; out[3] = f[3];
        return true;
    }

    private static void quad(Ctx c, MatrixStack.Entry e, Matrix4f mat, float[] uv,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz,
                             float nx, float ny, float nz) {
        float u1 = uv[0] / c.uvW, v1 = uv[1] / c.uvH, u2 = uv[2] / c.uvW, v2 = uv[3] / c.uvH;
        int r = c.tintedCube ? 120 : 255, g = c.tintedCube ? 235 : c.tinted ? 190 : 255, bl = c.tintedCube ? 255 : c.tinted ? 90 : 255;
        VertexConsumer vc = c.vc;
        vc.vertex(mat, ax, ay, az).color(r, g, bl, 255).texture(u1, v1).overlay(c.overlay).light(c.light).normal(e, nx, ny, nz);
        vc.vertex(mat, bx, by, bz).color(r, g, bl, 255).texture(u2, v1).overlay(c.overlay).light(c.light).normal(e, nx, ny, nz);
        vc.vertex(mat, cx, cy, cz).color(r, g, bl, 255).texture(u2, v2).overlay(c.overlay).light(c.light).normal(e, nx, ny, nz);
        vc.vertex(mat, dx, dy, dz).color(r, g, bl, 255).texture(u1, v2).overlay(c.overlay).light(c.light).normal(e, nx, ny, nz);
    }
}
