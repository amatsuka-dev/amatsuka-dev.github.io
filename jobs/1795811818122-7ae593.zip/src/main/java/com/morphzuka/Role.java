package com.morphzuka;

import java.util.Locale;

public enum Role {
    NONE("-", "none"), HEAD("Cabeza", "head"), BODY("Torso", "body"), LEFT_ARM("Brazo izq", "left_arm"), RIGHT_ARM("Brazo der", "right_arm"),
    LEFT_LEG("Pierna izq", "left_leg"), RIGHT_LEG("Pierna der", "right_leg"), TAIL("Cola / extra", "tail");

    public final String label;
    /** Nombre portable usado en animaciones exportadas (sirve para cualquier modelo que tenga ese rol). */
    public final String alias;
    Role(String l, String a) { this.label = l; this.alias = a; }

    public static Role of(String s) {
        if (s == null) return NONE;
        try { return valueOf(s); } catch (Exception e) { return NONE; }
    }

    public static Role guess(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        boolean left = n.contains("left") || n.matches(".*(^|[_\\-. ])l([_\\-. ]|$).*");
        boolean right = n.contains("right") || n.matches(".*(^|[_\\-. ])r([_\\-. ]|$).*");
        if (n.contains("head")) return HEAD;
        if (n.contains("tail")) return TAIL;
        if (n.contains("arm") || n.contains("hand")) return left ? LEFT_ARM : right ? RIGHT_ARM : NONE;
        if (n.contains("leg") || n.contains("foot")) return left ? LEFT_LEG : right ? RIGHT_LEG : NONE;
        if (n.contains("body") || n.contains("torso") || n.contains("chest")) return BODY;
        return NONE;
    }
}
