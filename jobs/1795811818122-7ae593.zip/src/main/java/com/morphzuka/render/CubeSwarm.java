package com.morphzuka.render;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * Efecto "Cube form": al transformarte, tu forma anterior se rompe en un enjambre de cubos que sale en LOTES
 * (cada lote despega un instante despues del anterior), da una vuelta en espiral y se funde dentro de la forma nueva.
 *
 * Cada cubo es un bloque real dibujado muy pequeno (concreto de colores, o el bloque en el que te conviertes), y todos
 * los de un enjambre se dibujan seguidos en el mismo VertexConsumerProvider del mundo, asi que el motor los agrupa por
 * capa de render en un solo lote de vertices. El enjambre se simula solo con el reloj (sin entidades ni estado de
 * servidor), por eso el servidor solo tiene que retransmitir "quien, tamanos, bloque, semilla": con la misma semilla
 * todos los clientes dibujan exactamente el mismo enjambre.
 */
public final class CubeSwarm {
    private CubeSwarm() {}

    public static final int BATCHES = 6, PER_BATCH = 14, COUNT = BATCHES * PER_BATCH;
    private static final float GAP_MS = 55f;       // retraso entre lotes
    private static final float FLIGHT_MS = 520f;   // duracion del vuelo de cada cubo
    private static final float TOTAL_MS = (BATCHES - 1) * GAP_MS + FLIGHT_MS;
    private static final int MAX_SWARMS = 16;

    private static final Block[] PALETTE = {
            Blocks.CYAN_CONCRETE, Blocks.LIGHT_BLUE_CONCRETE, Blocks.PURPLE_CONCRETE,
            Blocks.MAGENTA_CONCRETE, Blocks.WHITE_CONCRETE, Blocks.LIME_CONCRETE
    };

    // indices de Swarm.d[i]
    private static final int SX = 0, CX = 3, TX = 6, SIZE = 9, SPIN = 10, PHASE = 11;

    private static final class Swarm {
        final UUID who;
        final long start = Util.getMeasuringTimeMs();
        final float[][] d = new float[COUNT][12];
        final BlockState[] state = new BlockState[COUNT];
        double ox, oy, oz;
        boolean havePos;
        Swarm(UUID who) { this.who = who; }
    }

    private static final List<Swarm> ACTIVE = new ArrayList<>();

    public static void clear() { ACTIVE.clear(); }

    /**
     * @param ow,oh   ancho y alto de la forma anterior (donde nacen los cubos)
     * @param nw,nh   ancho y alto de la forma nueva (donde terminan)
     * @param blockId id de bloque del registro o -1 para la paleta de colores
     */
    public static void spawn(UUID who, float ow, float oh, float nw, float nh, int blockId, long seed) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        ACTIVE.removeIf(s -> s.who.equals(who));
        if (ACTIVE.size() >= MAX_SWARMS) ACTIVE.remove(0);

        BlockState forced = null;
        if (blockId >= 0) {
            Block b = Registries.BLOCK.get(blockId);
            if (b != Blocks.AIR) forced = b.getDefaultState();
        }

        Random r = new Random(seed);
        Swarm s = new Swarm(who);
        int base = r.nextInt(PALETTE.length);
        float scale = MathHelper.clamp((float) Math.sqrt(Math.max(Math.max(nh, oh), 0.3f) / 1.8f), 0.5f, 3f);
        float reach = Math.max(0.6f, Math.max(ow, oh) * 0.5f);

        for (int i = 0; i < COUNT; i++) {
            float[] d = s.d[i];
            // inicio: dentro del volumen de la forma anterior
            d[SX] = (r.nextFloat() - 0.5f) * ow;
            d[SX + 1] = r.nextFloat() * oh;
            d[SX + 2] = (r.nextFloat() - 0.5f) * ow;
            // fin: dentro del volumen de la forma nueva
            d[TX] = (r.nextFloat() - 0.5f) * nw;
            d[TX + 1] = r.nextFloat() * nh;
            d[TX + 2] = (r.nextFloat() - 0.5f) * nw;
            // punto de control de la curva: hacia fuera desde el centro de la forma anterior y un poco hacia arriba
            float dx = d[SX], dy = d[SX + 1] - oh * 0.5f, dz = d[SX + 2];
            float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (len < 0.01f) { dx = r.nextFloat() - 0.5f; dy = r.nextFloat() - 0.5f; dz = r.nextFloat() - 0.5f; len = Math.max(0.01f, (float) Math.sqrt(dx * dx + dy * dy + dz * dz)); }
            float push = (0.5f + r.nextFloat() * 0.9f) * reach / len;
            d[CX] = d[SX] + dx * push;
            d[CX + 1] = d[SX + 1] + dy * push + 0.4f + r.nextFloat() * 0.8f;
            d[CX + 2] = d[SX + 2] + dz * push;

            d[SIZE] = (0.10f + r.nextFloat() * 0.12f) * scale;
            d[SPIN] = (180f + r.nextFloat() * 360f) * (r.nextBoolean() ? 1 : -1);
            d[PHASE] = r.nextFloat() * 360f;
            s.state[i] = forced != null ? forced
                    : PALETTE[r.nextFloat() < 0.7f ? base : (base + 1 + r.nextInt(2)) % PALETTE.length].getDefaultState();
        }

        PlayerEntity p = mc.world.getPlayerByUuid(who);
        if (p != null) { s.ox = p.getX(); s.oy = p.getY(); s.oz = p.getZ(); s.havePos = true; }
        ACTIVE.add(s);
    }

    /** Se engancha a WorldRenderEvents.AFTER_ENTITIES. */
    public static void render(WorldRenderContext ctx) {
        if (ACTIVE.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld w = mc.world;
        VertexConsumerProvider vcp = ctx.consumers();
        MatrixStack m = ctx.matrixStack();
        if (w == null || vcp == null || m == null) { if (w == null) ACTIVE.clear(); return; }

        Vec3d cam = ctx.camera().getPos();
        float td = mc.getRenderTickCounter().getTickDelta(false);
        long now = Util.getMeasuringTimeMs();

        Iterator<Swarm> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Swarm s = it.next();
            float age = now - s.start;
            if (age > TOTAL_MS + 40f) { it.remove(); continue; }
            PlayerEntity p = w.getPlayerByUuid(s.who);
            if (p != null) {   // el enjambre acompana a quien se transforma
                s.ox = MathHelper.lerp(td, p.prevX, p.getX());
                s.oy = MathHelper.lerp(td, p.prevY, p.getY());
                s.oz = MathHelper.lerp(td, p.prevZ, p.getZ());
                s.havePos = true;
            }
            if (!s.havePos) { it.remove(); continue; }

            for (int i = 0; i < COUNT; i++) {
                float[] d = s.d[i];
                int batch = i / PER_BATCH;
                float u = MathHelper.clamp((age - batch * GAP_MS) / FLIGHT_MS, 0f, 1f);
                float e = u * u * (3f - 2f * u);           // smoothstep
                float a = 1f - e, b = 2f * e * a, c = e * e; // curva de Bezier cuadratica inicio -> control -> fin
                double x = s.ox + a * d[SX] + b * d[CX] + c * d[TX];
                double y = s.oy + a * d[SX + 1] + b * d[CX + 1] + c * d[TX + 1];
                double z = s.oz + a * d[SX + 2] + b * d[CX + 2] + c * d[TX + 2];
                // aparecen creciendo, y al llegar se encogen hasta desaparecer dentro de la forma nueva
                float size = d[SIZE] * Math.min(1f, 0.25f + age / 140f) * (1f - 0.85f * e * e * e);
                if (size < 0.01f) continue;
                float rot = d[PHASE] + d[SPIN] * (age / 1000f);

                m.push();
                m.translate(x - cam.x, y - cam.y, z - cam.z);
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(rot));
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rot * 0.6f));
                m.scale(size, size, size);
                m.translate(-0.5, -0.5, -0.5);
                mc.getBlockRenderManager().renderBlockAsEntity(s.state[i], m, vcp, LightmapTextureManager.MAX_LIGHT_COORDINATE, OverlayTexture.DEFAULT_UV);
                m.pop();
            }
        }
    }
}
