package com.morphzuka.render;

import com.morphzuka.model.ModelBounds;
import com.morphzuka.model.ModelManager;
import com.morphzuka.net.ClientNet;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.Registries;
import net.minecraft.util.Util;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Animacion de transformacion: el modelo "salta" desde cero con rebote, sale una nube de particulas y, si el efecto
 * esta activado, tu forma anterior se rompe en un enjambre de cubos ({@link CubeSwarm}).
 * Lo de tu jugador se calcula aqui y se manda al servidor para que los demas lo vean; el efecto de los demas llega
 * por red ({@link ClientNet}) y entra por {@link #startFor}.
 */
public final class Transition {
    private Transition() {}

    private static String key;
    private static float[] lastBox = {0.6f, 1.8f};
    private static final Map<UUID, Long> STARTS = new HashMap<>();
    private static final float DURATION_MS = 550f;

    /** {ancho, alto} de la forma actual, para saber de donde salen y a donde van los cubos. */
    private static float[] visualBox(ClientPlayerEntity p) {
        MorphManager.State ms = MorphManager.state();
        if (ms != null) return new float[]{ms.w, ms.h};
        ModelManager.Active a = ModelManager.forPlayer(p);
        if (a != null) {
            ModelBounds.Box b = ModelBounds.of(a.model(), a.settings());
            return new float[]{b.width(), b.height()};
        }
        return new float[]{0.6f, 1.8f};
    }

    public static void check(String newKey, ClientPlayerEntity p) {
        float[] now = visualBox(p);
        if (key == null) { key = newKey; lastBox = now; return; }
        if (key.equals(newKey)) { lastBox = now; return; }
        key = newKey;
        float[] old = lastBox;
        lastBox = now;

        startFor(p.getUuid());
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || !ModelManager.CONFIG.cubeEffect) return;

        for (int i = 0; i < 10; i++) {
            double ox = (mc.world.random.nextDouble() - 0.5) * 1.2;
            double oy = mc.world.random.nextDouble() * 1.8;
            double oz = (mc.world.random.nextDouble() - 0.5) * 1.2;
            mc.world.addParticle(i % 3 == 0 ? ParticleTypes.CLOUD : ParticleTypes.POOF, p.getX() + ox, p.getY() + oy, p.getZ() + oz, 0, 0.03, 0);
        }

        MorphManager.State ms = MorphManager.state();
        int block = ms != null && ms.block != null ? Registries.BLOCK.getRawId(ms.block.getBlock()) : -1;
        long seed = mc.world.random.nextLong();
        CubeSwarm.spawn(p.getUuid(), old[0], old[1], now[0], now[1], block, seed);
        ClientNet.sendEffect(old[0], old[1], now[0], now[1], block, seed);   // el servidor lo retransmite a quien te tenga a la vista
    }

    /** Arranca el rebote de escala de ese jugador (tu o uno que acaba de transformarse). */
    public static void startFor(UUID who) { STARTS.put(who, Util.getMeasuringTimeMs()); }

    /** 1 normalmente; durante la transformacion crece de 0 con rebote (easeOutBack). */
    public static float scale(UUID who) {
        Long st = STARTS.get(who);
        if (st == null) return 1f;
        float t = (Util.getMeasuringTimeMs() - st) / DURATION_MS;
        if (t >= 1f) { STARTS.remove(who); return 1f; }
        float c1 = 1.70158f, c3 = c1 + 1f, u = t - 1f;
        return Math.max(0.01f, 1f + c3 * u * u * u + c1 * u * u);
    }
}
