package com.morphzuka;

import com.morphzuka.net.ClientNet;
import com.morphzuka.render.MorphManager;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;

/**
 * Morpher Gun: el objeto con el que te transformas (ya no hay tecla).
 * Es un item vanilla (carrot_on_a_stick) con custom_model_data = 7001: no hay que registrar nada en el servidor.
 * El servidor con el mod lo entrega con /mz gun y bloquea la interaccion vanilla (ver MorphZuka.registerGunGuards).
 * Su modelo esta en assets/morphzuka/models/item/morpher_item/morphergun.json y se engancha mediante
 * assets/minecraft/models/item/carrot_on_a_stick.json.
 *
 * Clic derecho en un bloque = te conviertes en ese bloque; en una entidad o jugador = te conviertes en ellos;
 * agachado + clic derecho = vuelves a la forma normal.
 */
public final class MorpherGun {
    private MorpherGun() {}

    /** La logica comun del item (isGun / create) vive en {@link GunItem}, que tambien carga el servidor. */
    public static boolean isGun(ItemStack st) { return GunItem.isGun(st); }

    private static void unmorph(MinecraftClient mc) {
        MorphManager.clear();
        if (mc.player != null) mc.player.sendMessage(Text.literal("Forma normal"), true);
    }

    public static void register() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.isClient || hand != Hand.MAIN_HAND || !isGun(player.getStackInHand(hand))) return ActionResult.PASS;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player != mc.player) return ActionResult.PASS;
            if (player.isSneaking()) unmorph(mc);
            else MorphManager.copyBlock(mc, hit.getBlockPos());
            return ActionResult.SUCCESS;
        });
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!world.isClient || hand != Hand.MAIN_HAND || !isGun(player.getStackInHand(hand))) return ActionResult.PASS;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player != mc.player) return ActionResult.PASS;
            if (player.isSneaking()) unmorph(mc);
            else MorphManager.copyEntity(mc, entity);
            return ActionResult.SUCCESS;
        });
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack st = player.getStackInHand(hand);
            if (!world.isClient || hand != Hand.MAIN_HAND || !isGun(st)) return TypedActionResult.pass(st);
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player != mc.player) return TypedActionResult.pass(st);
            if (player.isSneaking()) { unmorph(mc); return TypedActionResult.success(st); }
            player.sendMessage(Text.literal("Morpher Gun: clic derecho en un bloque, entidad o jugador. Agachado + clic = forma normal"), true);
            return TypedActionResult.success(st);
        });
    }

    /** Pone la Morpher Gun en tu mano: directo en creativo; si no, /mz gun (servidor con el mod) o /give (necesitan permisos). */
    public static String give(MinecraftClient mc) {
        if (mc.player == null) return "No estás en un mundo";
        if (mc.player.isCreative() && mc.interactionManager != null) {
            mc.interactionManager.clickCreativeStack(GunItem.create(), 36 + mc.player.getInventory().selectedSlot);
            return "Morpher Gun entregada en tu mano";
        }
        if (mc.getNetworkHandler() != null) {
            boolean mod = ClientNet.serverHasMod();
            mc.getNetworkHandler().sendChatCommand(mod ? "mz gun" : GunItem.GIVE_COMMAND);
            return mod ? "Se envió /mz gun (hace falta permiso de operador; en creativo se entrega sola)"
                    : "Se envió /give (hace falta permiso de operador; en creativo se entrega sola)";
        }
        return "No se pudo entregar";
    }
}
