package com.morphzuka.net;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.UUID;

/**
 * Paquetes del mod. Solo usan clases comunes (nada de cliente) para poder cargarse en un servidor dedicado.
 * Todos se leen con limites: el servidor nunca se fia de lo que manda un cliente.
 */
public final class Payloads {
    private Payloads() {}

    // ---- hitbox: cliente -> servidor (la caja que quiere tener). w <= 0 = quitar override.
    public record HitboxPayload(float w, float h, float eye) implements CustomPayload {
        public static final CustomPayload.Id<HitboxPayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "hitbox"));
        public static final PacketCodec<RegistryByteBuf, HitboxPayload> CODEC = PacketCodec.of(
                (v, b) -> { b.writeFloat(v.w); b.writeFloat(v.h); b.writeFloat(v.eye); },
                b -> new HitboxPayload(b.readFloat(), b.readFloat(), b.readFloat()));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    // ---- hitbox: servidor -> todos (la caja ya validada de un jugador). w <= 0 = sin override.
    public record HitboxSyncPayload(UUID who, float w, float h, float eye) implements CustomPayload {
        public static final CustomPayload.Id<HitboxSyncPayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "hitbox_sync"));
        public static final PacketCodec<RegistryByteBuf, HitboxSyncPayload> CODEC = PacketCodec.of(
                (v, b) -> { b.writeUuid(v.who); b.writeFloat(v.w); b.writeFloat(v.h); b.writeFloat(v.eye); },
                b -> new HitboxSyncPayload(b.readUuid(), b.readFloat(), b.readFloat(), b.readFloat()));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    // ---- morph: en ambos sentidos. Cliente -> servidor (who se ignora y se pone el remitente real); servidor -> clientes.
    public static final byte KIND_NONE = 0, KIND_ENTITY = 1, KIND_BLOCK = 2, KIND_PLAYER = 3;

    public record MorphPayload(UUID who, byte kind, String id) implements CustomPayload {
        public static final CustomPayload.Id<MorphPayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "morph"));
        public static final PacketCodec<RegistryByteBuf, MorphPayload> CODEC = PacketCodec.of(
                (v, b) -> { b.writeUuid(v.who); b.writeByte(v.kind); b.writeString(v.id, 128); },
                b -> new MorphPayload(b.readUuid(), b.readByte(), b.readString(128)));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    // ---- efecto "cube form": en ambos sentidos, igual que el morph. blockId = id de bloque del registro o -1 (paleta).
    public record CubeFxPayload(UUID who, float oldW, float oldH, float newW, float newH, int blockId, long seed) implements CustomPayload {
        public static final CustomPayload.Id<CubeFxPayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "cube_fx"));
        public static final PacketCodec<RegistryByteBuf, CubeFxPayload> CODEC = PacketCodec.of(
                (v, b) -> {
                    b.writeUuid(v.who);
                    b.writeFloat(v.oldW); b.writeFloat(v.oldH); b.writeFloat(v.newW); b.writeFloat(v.newH);
                    b.writeVarInt(v.blockId + 1);
                    b.writeLong(v.seed);
                },
                b -> new CubeFxPayload(b.readUuid(), b.readFloat(), b.readFloat(), b.readFloat(), b.readFloat(), b.readVarInt() - 1, b.readLong()));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }
}
