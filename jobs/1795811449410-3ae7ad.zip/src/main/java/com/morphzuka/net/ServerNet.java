package com.morphzuka.net;

import com.morphzuka.HitboxRegistry;
import com.morphzuka.MzServerConfig;
import com.morphzuka.net.Payloads.CubeFxPayload;
import com.morphzuka.net.Payloads.HitboxPayload;
import com.morphzuka.net.Payloads.HitboxSyncPayload;
import com.morphzuka.net.Payloads.MorphPayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Logica de servidor: valida lo que piden los clientes, lo aplica al ServerPlayerEntity (colisiones reales) y lo
 * retransmite a los demas. Se registra en ambos lados porque los tipos de paquete deben conocerse en los dos.
 */
public final class ServerNet {
    private ServerNet() {}

    private static final Map<UUID, MorphPayload> MORPHS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_FX = new ConcurrentHashMap<>();
    private static final long FX_MIN_GAP_MS = 400;

    public static void register() {
        PayloadTypeRegistry.playC2S().register(HitboxPayload.ID, HitboxPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(HitboxSyncPayload.ID, HitboxSyncPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MorphPayload.ID, MorphPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(MorphPayload.ID, MorphPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(CubeFxPayload.ID, CubeFxPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(CubeFxPayload.ID, CubeFxPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(HitboxPayload.ID, (pl, ctx) -> onHitbox(pl, ctx.player(), ctx.server()));
        ServerPlayNetworking.registerGlobalReceiver(MorphPayload.ID, (pl, ctx) -> onMorph(pl, ctx.player(), ctx.server()));
        ServerPlayNetworking.registerGlobalReceiver(CubeFxPayload.ID, (pl, ctx) -> onFx(pl, ctx.player()));

        // Al entrar: el nuevo jugador recibe las cajas y morphs que ya existen.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity me = handler.getPlayer();
            HitboxRegistry.allServer().forEach((u, b) -> send(me, new HitboxSyncPayload(u, b[0], b[1], b[2])));
            MORPHS.values().forEach(m -> send(me, m));
        });

        // Al salir: se borra todo lo suyo y se avisa a los demas.
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayerEntity gone = handler.getPlayer();
            UUID u = gone.getUuid();
            boolean hadBox = HitboxRegistry.getServer(u) != null;
            boolean hadMorph = MORPHS.remove(u) != null;
            HitboxRegistry.setServer(u, null);
            LAST_FX.remove(u);
            for (ServerPlayerEntity o : PlayerLookup.all(server)) {
                if (o == gone) continue;
                if (hadBox) send(o, new HitboxSyncPayload(u, 0, 0, 0));
                if (hadMorph) send(o, new MorphPayload(u, Payloads.KIND_NONE, ""));
            }
        });

        ServerLifecycleEvents.SERVER_STOPPED.register(s -> {   // en mundo propio el JVM sigue vivo: no arrastrar estado al siguiente mundo
            HitboxRegistry.allServer().clear();
            MORPHS.clear();
            LAST_FX.clear();
        });
    }

    // ------------------------------------------------------------------ helpers

    private static boolean may(ServerPlayerEntity p, boolean feature) {
        if (!feature) return false;
        if (!MzServerConfig.INSTANCE.opsOnly) return true;
        MinecraftServer s = p.getServer();
        return s != null && s.getPlayerManager().isOperator(p.getGameProfile());
    }

    private static void send(ServerPlayerEntity to, CustomPayload pl) {
        if (ServerPlayNetworking.canSend(to, pl.getId())) ServerPlayNetworking.send(to, pl);
    }

    private static void broadcast(MinecraftServer srv, CustomPayload pl) {
        for (ServerPlayerEntity o : PlayerLookup.all(srv)) send(o, pl);
    }

    // ------------------------------------------------------------------ hitbox

    private static void onHitbox(HitboxPayload pl, ServerPlayerEntity sp, MinecraftServer srv) {
        UUID u = sp.getUuid();
        float[] box = null;
        if (pl.w() > 0 && may(sp, MzServerConfig.INSTANCE.allowHitbox))
            box = MzServerConfig.INSTANCE.clampBox(pl.w(), pl.h(), pl.eye());
        HitboxRegistry.setServer(u, box);
        sp.calculateDimensions();   // el servidor ya usa la caja nueva: colisiones, validacion de movimiento, golpes
        broadcast(srv, box == null ? new HitboxSyncPayload(u, 0, 0, 0) : new HitboxSyncPayload(u, box[0], box[1], box[2]));
    }

    // ------------------------------------------------------------------ morph

    private static boolean validMorph(byte kind, String id) {
        if (id == null || id.isEmpty() || id.length() > 100) return false;
        return switch (kind) {
            case Payloads.KIND_ENTITY -> { Identifier i = Identifier.tryParse(id); yield i != null && Registries.ENTITY_TYPE.containsId(i); }
            case Payloads.KIND_BLOCK -> { Identifier i = Identifier.tryParse(id); yield i != null && Registries.BLOCK.containsId(i); }
            case Payloads.KIND_PLAYER -> id.length() <= 16;
            default -> false;
        };
    }

    private static void onMorph(MorphPayload pl, ServerPlayerEntity sp, MinecraftServer srv) {
        UUID u = sp.getUuid();
        MorphPayload clean;
        if (pl.kind() != Payloads.KIND_NONE && may(sp, MzServerConfig.INSTANCE.allowMorph) && validMorph(pl.kind(), pl.id())) {
            clean = new MorphPayload(u, pl.kind(), pl.id());
            MORPHS.put(u, clean);
        } else {
            clean = new MorphPayload(u, Payloads.KIND_NONE, "");   // tambien sirve de respuesta si el servidor lo rechaza
            MORPHS.remove(u);
        }
        broadcast(srv, clean);   // incluye al remitente: si fue rechazado, su cliente vuelve a la forma normal
    }

    // ------------------------------------------------------------------ efecto de cubos

    private static boolean sane(float v) { return Float.isFinite(v) && v > 0.01f && v < 64f; }

    private static void onFx(CubeFxPayload pl, ServerPlayerEntity sp) {
        if (!may(sp, MzServerConfig.INSTANCE.allowEffects)) return;
        if (!sane(pl.oldW()) || !sane(pl.oldH()) || !sane(pl.newW()) || !sane(pl.newH())) return;
        UUID u = sp.getUuid();
        long now = Util.getMeasuringTimeMs();
        Long last = LAST_FX.get(u);
        if (last != null && now - last < FX_MIN_GAP_MS) return;   // antiflood
        LAST_FX.put(u, now);
        int block = pl.blockId() >= 0 && pl.blockId() < Registries.BLOCK.size() ? pl.blockId() : -1;
        CubeFxPayload out = new CubeFxPayload(u, pl.oldW(), pl.oldH(), pl.newW(), pl.newH(), block, pl.seed());
        for (ServerPlayerEntity o : PlayerLookup.tracking(sp)) send(o, out);   // solo quienes lo tienen a la vista
    }
}
