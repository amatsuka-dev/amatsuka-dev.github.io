# MorphZuka (Fabric 1.21.1)

Mod para usar modelos de Blockbench como modelo de jugador. Funciona **en cliente solo** (mundo propio, o servidores sin el mod) y, si lo instalas tambien en el **servidor**, la hitbox, el morph y el efecto de cubos se validan y se ven en multijugador.

## Compilar
Requiere JDK 21.
```
gradle wrapper --gradle-version 8.10.2   # solo la primera vez (o abre la carpeta en IntelliJ)
./gradlew build
```
El jar queda en `build/libs/morphzuka-1.0.0.jar`.

## Uso
1. Pon tus modelos en `.minecraft/morphzuka/` (tambien lee `.minecraft/player_models/` de CPM):
   - `.morphzuka` (Blockbench, incluye CPM y GeckoLib si los guardas como proyecto) con textura incrustada
   - `.geo.json` (+ `mismo_nombre.png` y `mismo_nombre.animation.json` al lado)
   - `.cpmproject` (si contiene un .morphzuka)
   - Modelos GeckoLib de otros mods / resourcepacks (`assets/<ns>/geo/*.geo.json`) se detectan solos.
2. En el juego pulsa **K** (o `/morphzuka`).
3. Elige modelo -> elige cada hueso y asignale rol (Cabeza, Torso, Brazos, Piernas, Cola/extra; puedes asignar varios huesos al mismo rol).
4. Edita el pivote de cualquier hueso (X Y Z en pixeles) y pulsa "Fijar pivote".
5. Asigna animaciones a IDLE / WALK / SPRINT / SNEAK / AIR.
6. "Aplicar a": Yo / Todos / Jugador (nombre) -> Aplicar.

Config guardada en `config/morphzuka.json`.

## Limitaciones
- Los **modelos .bbmodel** siguen siendo locales: los demas no ven tu modelo (hace falta transferirlo; no incluido). Si ven tu **morph** (entidad/bloque/jugador), tu **hitbox** y el **efecto de cubos**.
- Una sola textura por modelo; meshes no soportados (solo cubos).
- Armadura/items/capa siguen renderizandose con el esqueleto vanilla.
- Sin poses de nado/elytra/dormir. Rotaciones de GeckoLib/Bedrock pueden requerir ajustes de signo.

## Interfaz (v1.1)
Menú estilo Material oscuro/transparente con barra lateral: **Modelos**, **Partes**, **Animación**, **Importar**, **Aplicar**.
- **Arrastrar y soltar**: suelta `.morphzuka`, `.geo.json`, `.cpmproject` (y `.png` / `.animation.json` de GeckoLib) sobre la ventana del menú.
- **Importar**: pega un link directo (los links de GitHub `/blob/` se convierten solos a raw) o usa "Pegar Base64 / JSON del portapapeles" (acepta Base64, `data:...;base64,` y JSON plano).

## Editor 3D (v2.3)
Pestaña **Editor 3D** (o botón "Editor 3D" en Partes). Pantalla completa con:
- **Visor orbital**: arrastra en vacío para girar, rueda para zoom, "Centrar vista" para volver.
- **Selector de partes**: lista a la izquierda o clic en los puntos de pivote dentro del visor. La parte elegida se tiñe de naranja.
- **Gizmo**: modos **Mover**, **Rotar** (3 aros), **Escalar** (ejes + cubo central = uniforme) y **Pivote**. Ejes en rojo X, verde Y, azul Z.
- **Campos XYZ** numéricos para cada modo; se sincronizan con el gizmo.
- Deshacer, restaurar parte / todo, ocultar parte. Se guarda al cerrar en `config/morphzuka.json`
  (`offsets`, `rotOffsets`, `scales`, `pivots`); el archivo del modelo no se toca.
Los ejes del gizmo siguen el espacio del hueso padre (en Escalar, el del propio hueso).

## Morpher Gun (recursos, paso 1)
Item `carrot_on_a_stick` con `custom_model_data=7001`. Modelo: `assets/morphzuka/models/item/morpher_item/morphergun.json`,
enganchado desde `assets/minecraft/models/item/carrot_on_a_stick.json`. Recarga recursos con F3+T.

## Multijugador (v2.4: pasos 12 y 13)
Instala el jar en el cliente **y** en el servidor (Fabric API en ambos). Sin el mod en el servidor todo sigue funcionando solo en tu cliente.

**Hitbox real (paso 12)**: el cliente manda su caja {ancho, alto, ojos}; el servidor la valida contra limites, la aplica a tu
`ServerPlayerEntity` (colisiones y validacion de movimiento reales, por postura: de pie / agachado / nadando) y la retransmite
a todos. Mixin comun `PlayerDimensionsMixin` + `HitboxRegistry`.

**Cube form (paso 13)**: al transformarte tu forma anterior se rompe en un enjambre de 84 cubos que sale en 6 lotes y se funde
en la forma nueva (`CubeSwarm`). El servidor retransmite (quien, tamanos, bloque, semilla) a los jugadores que te tienen a la vista;
con la misma semilla todos dibujan el mismo enjambre. Se desactiva en Ajustes ("Efecto de cubos al transformarse").

**Morpher Gun**: sigue siendo `carrot_on_a_stick` con `custom_model_data=7001` (no se registra ningun item: no rompe la sincronizacion
de registros y los clientes sin el mod no fallan). El servidor la entrega con `/mz gun [jugadores]` y, con ella en la mano, bloquea
la interaccion vanilla (cofres, puertas...).

### Config del servidor: `config/morphzuka-server.json`
| campo | por defecto | efecto |
|---|---|---|
| allowHitbox | true | aceptar hitbox personalizada |
| allowMorph | true | aceptar morph y mostrarlo a los demas |
| allowEffects | true | retransmitir el efecto de cubos |
| opsOnly | false | solo operadores pueden usar hitbox/morph |
| minSize / maxWidth / maxHeight | 0.1 / 4 / 8 | limites de la caja aceptada |

Comandos (nivel 2): `/mz gun [jugadores]`, `/mz reload`, `/mz status`.

### Paquetes
`morphzuka:hitbox` (C2S), `hitbox_sync` (S2C), `morph` (C2S/S2C), `cube_fx` (C2S/S2C). Solo se envian si el otro lado los tiene registrados.
