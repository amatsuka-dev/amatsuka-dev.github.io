package com.morphzuka.render;

import com.morphzuka.Role;
import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelManager;

/**
 * Puntos de anclaje configurables: donde se dibuja lo que el juego pinta con el esqueleto vanilla (items en la mano,
 * y en el paso 26 armadura, elytras, capa y loros). Cada punto es un {@link ModelManager.Prop} de un tipo especial:
 * se vincula a un grupo (por defecto, el grupo con el rol que le toca) y tiene posicion / rotacion / escala propias,
 * relativas al pivote de ese grupo y a la posicion que tendria en vanilla (todo en 0 = como en vanilla).
 */
public final class Anchors {
    private Anchors() {}

    public static final String HAND_R = "HAND_R", HAND_L = "HAND_L";

    /** Orden en el selector del editor. */
    public static final String[] ALL = {HAND_R, HAND_L};

    public static boolean isAnchor(String kind) {
        for (String k : ALL) if (k.equals(kind)) return true;
        return false;
    }

    public static boolean isHand(String kind) { return HAND_R.equals(kind) || HAND_L.equals(kind); }

    /** El punto tiene un id de item / objeto de muestra que se puede cambiar. */
    public static boolean hasRef(String kind) { return isHand(kind); }

    public static String label(String kind) {
        return switch (kind == null ? "" : kind) {
            case HAND_R -> "Mano der";
            case HAND_L -> "Mano izq";
            default -> "Punto";
        };
    }

    /** Rol del grupo al que se vincula por defecto. */
    public static Role role(String kind) {
        return switch (kind == null ? "" : kind) {
            case HAND_R -> Role.RIGHT_ARM;
            case HAND_L -> Role.LEFT_ARM;
            default -> Role.NONE;
        };
    }

    /** Donde estaria el origen vanilla del punto (px, Y arriba) si el modelo no tiene un grupo con ese rol. */
    public static float[] defaultPivot(String kind) {
        return switch (kind == null ? "" : kind) {
            case HAND_R -> new float[]{-5f, 22f, 0f};
            case HAND_L -> new float[]{5f, 22f, 0f};
            default -> new float[]{0f, 24f, 0f};
        };
    }

    public static ModelManager.Prop find(ModelManager.Settings s, String kind) {
        for (ModelManager.Prop p : s.props) if (kind.equals(p.kind)) return p;
        return null;
    }

    /** Primer grupo del modelo con el rol por defecto del punto, o null. */
    public static String defaultBone(BBModel mod, ModelManager.Settings s, String kind) {
        Role want = role(kind);
        if (want == Role.NONE) return null;
        for (BBModel.Bone b : mod.bones.values())
            if (Role.of(s.roles.get(b.name)) == want) return b.name;
        return null;
    }

    /** Grupo donde se dibuja el punto: el que eligio el usuario o, si no, el de su rol; null = con el modelo (en su origen vanilla). */
    public static String boneOf(BBModel mod, ModelManager.Settings s, ModelManager.Prop p, String kind) {
        if (p != null && p.bone != null && mod.bones.containsKey(p.bone)) return p.bone;
        return defaultBone(mod, s, kind);
    }

    /** Igual que {@link #boneOf} para cualquier objeto: los puntos usan su regla, los objetos normales su vinculo. */
    public static String boneOf(BBModel mod, ModelManager.Settings s, ModelManager.Prop p) {
        if (isAnchor(p.kind)) return boneOf(mod, s, p, p.kind);
        return p.bone != null && mod.bones.containsKey(p.bone) ? p.bone : null;
    }
}
