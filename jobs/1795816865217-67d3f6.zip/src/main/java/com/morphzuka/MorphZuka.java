package com.morphzuka;

import com.mojang.brigadier.arguments.FloatArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;

/**
 * Entrada comun (cliente y servidor dedicado). Aqui no puede haber ninguna referencia a clases de cliente.
 */
public class MorphZuka implements ModInitializer {
    public static final Logger LOG = LoggerFactory.getLogger("morphzuka");

    @Override
    public void onInitialize() {
        MzServerConfig.load();
        com.morphzuka.net.ServerNet.register();
        registerGunGuards();
        registerCommands();
    }

    /**
     * Con la Morpher Gun en la mano el servidor no debe abrir cofres, puertas ni montar animales: el morph lo resuelve
     * el cliente (necesita sus propias clases de entidad), pero la interaccion vanilla llega igualmente al servidor.
     */
    private static void registerGunGuards() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) ->
                !world.isClient && hand == Hand.MAIN_HAND && GunItem.isGun(player.getStackInHand(hand)) ? ActionResult.SUCCESS : ActionResult.PASS);
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) ->
                !world.isClient && hand == Hand.MAIN_HAND && GunItem.isGun(player.getStackInHand(hand)) ? ActionResult.SUCCESS : ActionResult.PASS);
    }

    private static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, env) -> {
            dispatcher.register(CommandManager.literal("mz")
                    .requires(src -> src.hasPermissionLevel(2))
                    .then(CommandManager.literal("gun")
                            .executes(ctx -> give(ctx.getSource(), java.util.List.of(ctx.getSource().getPlayerOrThrow())))
                            .then(CommandManager.argument("targets", EntityArgumentType.players())
                                    .executes(ctx -> give(ctx.getSource(), EntityArgumentType.getPlayers(ctx, "targets")))))
                    .then(CommandManager.literal("reload").executes(ctx -> {
                        MzServerConfig.load();
                        ctx.getSource().sendFeedback(() -> Text.literal("MorphZuka: configuración del servidor recargada"), true);
                        return 1;
                    }))
                    .then(CommandManager.literal("status").executes(ctx -> status(ctx.getSource()))));
        });
    }

    private static int give(ServerCommandSource src, Collection<ServerPlayerEntity> targets) {
        for (ServerPlayerEntity p : targets) p.getInventory().offerOrDrop(GunItem.create());
        src.sendFeedback(() -> Text.literal("Morpher Gun entregada a " + targets.size() + " jugador(es)"), true);
        return targets.size();
    }

    private static int status(ServerCommandSource src) {
        MzServerConfig c = MzServerConfig.INSTANCE;
        src.sendFeedback(() -> Text.literal(String.format("MorphZuka: hitbox=%s morph=%s efectos=%s opsOnly=%s límites %.2f..%.1f x %.1f",
                c.allowHitbox, c.allowMorph, c.allowEffects, c.opsOnly, c.minSize, c.maxWidth, c.maxHeight)), false);
        int n = 0;
        for (Map.Entry<UUID, float[]> e : HitboxRegistry.allServer().entrySet()) {
            ServerPlayerEntity p = src.getServer().getPlayerManager().getPlayer(e.getKey());
            float[] b = e.getValue();
            String line = String.format("  %s: %.2f x %.2f (ojos %.2f)", p == null ? e.getKey() : p.getName().getString(), b[0], b[1], b[2]);
            src.sendFeedback(() -> Text.literal(line), false);
            n++;
        }
        if (n == 0) src.sendFeedback(() -> Text.literal("  Ningún jugador tiene hitbox personalizada"), false);
        return n;
    }
}
