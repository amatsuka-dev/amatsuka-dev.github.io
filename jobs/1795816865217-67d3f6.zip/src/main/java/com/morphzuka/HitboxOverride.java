package com.morphzuka;

import com.morphzuka.model.ModelBounds;
import com.morphzuka.model.ModelManager;
import com.morphzuka.net.ClientNet;
import com.morphzuka.render.MorphManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;

import java.util.UUID;

/**
 * Lado cliente de la hitbox / altura de ojos personalizadas.
 * La caja sale del modelo real (modo auto, ver {@link ModelBounds}) o de los numeros que pongas a mano.
 *
 * Con el mod en el servidor (o en mundo propio): se la mandas al servidor, que la valida, la aplica a tu
 * ServerPlayerEntity (colisiones reales) y la retransmite a todos. Sin el mod en el servidor: solo cambia lo que ve y
 * predice tu cliente y el servidor sigue validando con la caja vanilla.
 * Los mapas estan en {@link HitboxRegistry}; el mixin PlayerDimensionsMixin los lee en ambos lados.
 */
public final class HitboxOverride {
    private HitboxOverride() {}

    private static int last;

    /** Se llama una vez al arrancar el cliente: caja calculada localmente para jugadores sin dato del servidor. */
    public static void install() {
        HitboxRegistry.clientProvider = p -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            // tu propia caja va en el registro (se actualiza en refresh); aqui solo los demas, p. ej. un modelo asignado a mano
            return p instanceof AbstractClientPlayerEntity cp && cp != mc.player ? get(cp) : null;
        };
    }

    /** {ancho, alto, altura de ojos} segun el modelo / morph de ese jugador, o null si no hay override. */
    public static float[] get(AbstractClientPlayerEntity p) {
        if (p == MinecraftClient.getInstance().player && MorphManager.active()) {
            float[] m = MorphManager.hitbox();
            if (m != null) return m;
        }
        ModelManager.Active a = ModelManager.forPlayer(p);
        if (a == null) return null;
        ModelManager.Settings s = a.settings();
        if (s.hitboxAuto) {
            ModelBounds.Box b = ModelBounds.of(a.model(), s);
            return new float[]{Math.max(0.05f, b.width()), Math.max(0.05f, b.height()), b.eye()};
        }
        if (!s.hitboxOn) return null;
        float w = Math.max(0.05f, Math.max(s.hitbox[0], s.hitbox[2])); // la caja de Minecraft es cuadrada: X y Z comparten ancho
        float h = Math.max(0.05f, s.hitbox[1]);
        float eye = s.eye > 0 ? s.eye : h * 0.9f;
        return new float[]{w, h, Math.min(eye, h)};
    }

    /** Olvida lo ultimo enviado para que se vuelva a mandar (al entrar a un servidor). */
    public static void reset() { last = 0; }

    /** Se llama cada tick del cliente. Devuelve true si cambio tu caja (hay que recalcular dimensiones). */
    public static boolean refresh() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) { last = 0; return false; }
        float[] h = get(mc.player);
        int sig = h == null ? 0 : java.util.Arrays.hashCode(h) + 1;
        if (sig == last) return false;
        last = sig;
        UUID me = mc.player.getUuid();
        HitboxRegistry.setClient(me, h);   // prediccion inmediata; el servidor puede corregirla (limites) y su respuesta la reemplaza
        ClientNet.sendHitbox(h);
        return true;
    }
}
