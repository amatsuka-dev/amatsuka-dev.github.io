package com.morphzuka.compat;

import com.morphzuka.voice.VoiceState;
import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.events.ClientReceiveSoundEvent;
import de.maxhenkel.voicechat.api.events.ClientSoundEvent;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import net.minecraft.client.MinecraftClient;

/** Plugin de Simple Voice Chat: marca cuando hablas (microfono) o cuando oyes a otro jugador. */
public class SvcPlugin implements VoicechatPlugin {
    private static final float THRESHOLD = 0.012f;

    @Override
    public String getPluginId() { return "morphzuka"; }

    @Override
    public void initialize(VoicechatApi api) {}

    private static float rms(short[] pcm) {
        if (pcm == null || pcm.length == 0) return 0;
        double sum = 0;
        for (short s : pcm) sum += (double) s * s;
        return (float) (Math.sqrt(sum / pcm.length) / 32768.0);
    }

    @Override
    public void registerEvents(EventRegistration reg) {
        reg.registerEvent(ClientSoundEvent.class, e -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player != null && rms(e.getRawAudio()) > THRESHOLD) VoiceState.markSpeaking(mc.player.getUuid());
        });
        reg.registerEvent(ClientReceiveSoundEvent.EntitySound.class, e -> {
            if (rms(e.getRawAudio()) > THRESHOLD) VoiceState.markSpeaking(e.getId());
        });
    }
}
