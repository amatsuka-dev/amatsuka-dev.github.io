package com.morphzuka.screen;

import com.morphzuka.model.AnimConfig;
import com.morphzuka.model.AnimStates;
import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelManager;
import com.morphzuka.ui.Background;
import com.morphzuka.ui.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Ventana "Animaciones" de un modelo guardado: a la izquierda los estados (idle, walk, run, jump, attack...),
 * a la derecha las animaciones disponibles. Clic en una animacion = asignarla al estado elegido.
 * Cada cambio se guarda al instante (config/morphzuka.json y config/morphzuka_animations.json).
 */
public class AnimConfigScreen extends Screen {
    private static final class Hit { int x, y, w, h; int[] clip; Runnable r; }

    private final Screen parent;
    private final BBModel model;
    private final ModelManager.Settings s;
    private final List<Hit> hits = new ArrayList<>();
    private int[] clip;
    private int mx, my;
    private int state = 0, scrollL, scrollR;
    private int lx, lw, rx, rw, top, bottom;
    private String status = "";

    private static final int ROWL = 26, ROWR = 18;

    public AnimConfigScreen(Screen parent, BBModel model) {
        super(Text.literal("Animaciones"));
        this.parent = parent;
        this.model = model;
        this.s = ModelManager.settings(model);
    }

    private static int C(String k) { return Theme.c(k); }

    private static void rr(DrawContext g, int x, int y, int w, int h, int r, int c) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < h; i++) {
            int d = 0;
            int k = i < r ? i : (i >= h - r ? h - 1 - i : -1);
            if (k >= 0) { double dy = r - k - 0.5; d = r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy))); }
            g.fill(x + d, y + i, x + w - d, y + i + 1, c);
        }
    }

    private boolean over(int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h
                && (clip == null || (mx >= clip[0] && mx < clip[2] && my >= clip[1] && my < clip[3]));
    }

    private void hit(int x, int y, int w, int h, Runnable r) {
        Hit t = new Hit();
        t.x = x; t.y = y; t.w = w; t.h = h; t.r = r;
        t.clip = clip == null ? null : clip.clone();
        hits.add(t);
    }

    private void button(DrawContext g, int x, int y, int w, String label, boolean primary, Runnable r) {
        boolean hov = over(x, y, w, 18);
        rr(g, x, y, w, 18, 9, primary ? C("primary") : hov ? C("surfaceHi") : C("surface"));
        String l = textRenderer.trimToWidth(label, w - 8);
        g.drawText(textRenderer, l, x + w / 2 - textRenderer.getWidth(l) / 2, y + 5, primary ? C("onPrimary") : C("text"), false);
        hit(x, y, w, 18, r);
    }

    private void save() { ModelManager.saveConfig(); }

    @Override
    public void render(DrawContext g, int mouseX, int mouseY, float delta) {
        mx = mouseX;
        my = mouseY;
        hits.clear();
        clip = null;
        int text = C("text"), muted = C("muted"), prim = C("primary");

        g.fill(0, 0, width, height, 0xFF0B0808);
        Background.draw(g, width, height);

        int pad = 14;
        rr(g, pad, pad, width - 2 * pad, height - 2 * pad, 10, C("panel"));
        int ix = pad + 12, iw = width - 2 * pad - 24;
        g.drawText(textRenderer, Text.literal("Animaciones").formatted(Formatting.BOLD), ix, pad + 10, text, false);
        g.drawText(textRenderer, textRenderer.trimToWidth(model.id, iw - 120), ix + 84, pad + 10, muted, false);
        int bx = ix + iw;
        bx -= 76; button(g, bx, pad + 6, 76, "Cerrar", true, this::close);
        bx -= 130; button(g, bx, pad + 6, 126, "Detectar automático", false, () -> {
            int n = AnimConfig.autoDetect(model, s);
            save();
            status = n + " estados asignados por nombre";
        });

        top = pad + 32;
        bottom = height - pad - 22;
        lx = ix;
        lw = Math.min(iw * 40 / 100, 230);
        rx = lx + lw + 12;
        rw = iw - lw - 12;

        g.drawText(textRenderer, "Estado del jugador", lx, top, muted, false);
        g.drawText(textRenderer, "Animación para: " + AnimStates.get(ModelManager.STATES[state]).label()
                + "   (chip derecho = modo)", rx, top, muted, false);
        int ly = top + 12, lh = bottom - ly;
        rr(g, lx, ly, lw, lh, 8, 0x40000000);
        rr(g, rx, ly, rw, lh, 8, 0x40000000);

        // estados
        int n = ModelManager.STATES.length;
        int maxL = Math.max(0, n * ROWL - (lh - 6));
        scrollL = Math.max(0, Math.min(maxL, scrollL));
        g.enableScissor(lx, ly + 3, lx + lw, ly + lh - 3);
        clip = new int[]{lx, ly + 3, lx + lw, ly + lh - 3};
        for (int i = 0; i < n; i++) {
            int ry = ly + 3 + i * ROWL - scrollL;
            if (ry + ROWL < ly || ry > ly + lh) continue;
            final int idx = i;
            boolean sel = i == state;
            String a = s.anims.get(ModelManager.STATES[i]);
            if (sel) rr(g, lx + 3, ry, lw - 12, ROWL - 2, 7, C("pill"));
            else if (over(lx + 3, ry, lw - 12, ROWL - 2)) rr(g, lx + 3, ry, lw - 12, ROWL - 2, 7, C("line"));
            g.drawText(textRenderer, textRenderer.trimToWidth(ModelManager.STATE_LABELS[i], lw - 24), lx + 10, ry + 3, text, false);
            g.drawText(textRenderer, textRenderer.trimToWidth(a == null ? "(ninguna)" : a, lw - 24), lx + 10, ry + 13, a == null ? muted : prim, false);
            hit(lx + 3, ry, lw - 12, ROWL - 2, () -> state = idx);
        }
        g.disableScissor();
        clip = null;
        if (maxL > 0) scrollbar(g, lx + lw - 5, ly + 3, lh - 6, n * ROWL, scrollL, maxL);

        // animaciones
        List<String> names = new ArrayList<>();
        names.add(null);
        names.addAll(ModelManager.allAnimNames(model));
        String assigned = s.anims.get(ModelManager.STATES[state]);
        int maxR = Math.max(0, names.size() * ROWR - (lh - 6));
        scrollR = Math.max(0, Math.min(maxR, scrollR));
        g.enableScissor(rx, ly + 3, rx + rw, ly + lh - 3);
        clip = new int[]{rx, ly + 3, rx + rw, ly + lh - 3};
        for (int i = 0; i < names.size(); i++) {
            int ry = ly + 3 + i * ROWR - scrollR;
            if (ry + ROWR < ly || ry > ly + lh) continue;
            final String nm = names.get(i);
            boolean sel = Objects.equals(nm, assigned);
            if (sel) rr(g, rx + 3, ry, rw - 12, ROWR - 2, 6, prim);
            else if (over(rx + 3, ry, rw - 12, ROWR - 2)) rr(g, rx + 3, ry, rw - 12, ROWR - 2, 6, C("line"));
            g.drawText(textRenderer, textRenderer.trimToWidth(nm == null ? "(ninguna)" : nm, rw - 110), rx + 10, ry + 5, sel ? C("onPrimary") : text, false);
            if (nm != null) {
                final BBModel.Anim an = ModelManager.anim(model, nm);
                if (an != null) {
                    ModelManager.LoopMode lm = ModelManager.loopMode(s, an, false);
                    boolean custom = s.animModes.containsKey(an.name);
                    int cx = rx + rw - 80, cw = 60;
                    rr(g, cx, ry + 1, cw, ROWR - 4, 6, custom ? C("pill") : C("surface"));
                    g.drawText(textRenderer, lm.shortLabel, cx + 6, ry + 5, custom ? text : muted, false);
                    hit(cx, ry + 1, cw, ROWR - 4, () -> { ModelManager.cycleLoopMode(s, an); save(); });
                }
            }
            hit(rx + 3, ry, rw - 90, ROWR - 2, () -> {
                if (nm == null) s.anims.remove(ModelManager.STATES[state]);
                else s.anims.put(ModelManager.STATES[state], nm);
                save();
            });
        }
        g.disableScissor();
        clip = null;
        if (maxR > 0) scrollbar(g, rx + rw - 5, ly + 3, lh - 6, names.size() * ROWR, scrollR, maxR);
        if (names.size() <= 1) g.drawText(textRenderer, "Este modelo no tiene animaciones", rx + 10, ly + 24, muted, false);

        g.drawText(textRenderer, textRenderer.trimToWidth(status.isEmpty() ? "Se guarda solo en config/morphzuka_animations.json" : status, iw),
                ix, height - pad - 14, status.isEmpty() ? muted : prim, false);
    }

    private void scrollbar(DrawContext g, int x, int y, int h, int content, int scroll, int max) {
        int th = Math.max(12, h * h / content);
        int ty = y + (h - th) * scroll / max;
        rr(g, x, ty, 2, th, 1, 0x80E8C2BA);
    }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        if (button == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (x >= h.x && x < h.x + h.w && y >= h.y && y < h.y + h.h
                        && (h.clip == null || (x >= h.clip[0] && x < h.clip[2] && y >= h.clip[1] && y < h.clip[3]))) {
                    h.r.run();
                    return true;
                }
            }
        }
        return super.mouseClicked(x, y, button);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double hAmount, double vAmount) {
        int d = -(int) Math.signum(vAmount) * 18;
        if (x < rx) scrollL += d; else scrollR += d;
        return true;
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void close() {
        save();
        client.setScreen(parent);
    }
}
