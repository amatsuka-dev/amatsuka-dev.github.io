package com.morphzuka.screen;

import com.morphzuka.Gestures;
import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelManager;
import com.morphzuka.ui.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Slider para controlar una animacion fotograma a fotograma (categoria SLIDER). Esc para soltar la pose. */
public class SliderScreen extends Screen {
    private final String anim;
    private float length = 1f;
    private boolean drag;

    public SliderScreen(String anim) {
        super(Text.literal("Slider"));
        this.anim = anim;
    }

    @Override
    protected void init() {
        ModelManager.Active a = ModelManager.forSelf();
        if (a != null) {
            BBModel.Anim an = ModelManager.anim(a.model(), anim);
            if (an != null) length = Math.max(0.01f, an.length);
        }
        Gestures.slider(anim);
    }

    private int bx() { return width / 2 - 140; }
    private int by() { return height - 56; }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        int x = bx(), y = by(), w = 280;
        g.fill(x - 10, y - 22, x + w + 10, y + 24, Theme.c("panel"));
        g.drawText(textRenderer, anim, x, y - 16, Theme.c("title"), false);
        String t = String.format("%.2f / %.2f s", Gestures.sliderT * length, length);
        g.drawText(textRenderer, t, x + w - textRenderer.getWidth(t), y - 16, Theme.c("subtitle"), false);
        g.fill(x, y + 2, x + w, y + 6, Theme.c("surfaceHi"));
        int kx = x + Math.round(w * Gestures.sliderT);
        g.fill(x, y + 2, kx, y + 6, Theme.c("primary"));
        g.fill(kx - 3, y - 2, kx + 3, y + 10, Theme.c("primary"));
        g.drawText(textRenderer, "Arrastra la barra - Esc para soltar", x, y + 12, Theme.c("muted"), false);
    }

    private void set(double mx) { Gestures.sliderT = (float) Math.max(0, Math.min(1, (mx - bx()) / 280.0)); }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && my >= by() - 12 && my <= by() + 18 && mx >= bx() - 8 && mx <= bx() + 288) { drag = true; set(mx); return true; }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (drag) { set(mx); return true; }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) { drag = false; return super.mouseReleased(mx, my, button); }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void close() {
        Gestures.stop();
        super.close();
    }
}
