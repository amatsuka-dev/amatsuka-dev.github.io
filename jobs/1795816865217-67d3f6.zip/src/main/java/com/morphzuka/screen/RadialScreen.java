package com.morphzuka.screen;

import com.morphzuka.Gestures;
import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelManager;
import com.morphzuka.ui.Theme;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Menu circular (estilo rueda de gestos de Fortnite). Mantén la tecla, apunta con el ratón y suelta para elegir; o haz clic. */
public class RadialScreen extends Screen {
    public enum Mode { MODELS, GESTURES }

    private record Item(String label, String sub, Runnable action) {}

    private static final int PAGE = 10;

    private final Mode mode;
    private final KeyBinding key;
    private final List<Item> items = new ArrayList<>();
    private int page, openTicks;

    public RadialScreen(Mode mode, KeyBinding key) {
        super(Text.literal(mode == Mode.MODELS ? "Modelos" : "Gestos"));
        this.mode = mode;
        this.key = key;
    }

    @Override
    protected void init() {
        items.clear();
        if (mode == Mode.MODELS) {
            items.add(new Item("Vanilla", "sin modelo", () -> ModelManager.assign("@self", null)));
            for (String id : ModelManager.MODELS.keySet()) {
                String shown = id.contains("/") ? id.substring(id.lastIndexOf('/') + 1) : id;
                items.add(new Item(shown, "", () -> ModelManager.assign("@self", id)));
            }
        } else {
            ModelManager.Active a = ModelManager.forSelf();
            items.add(new Item("Detener", "", () -> { Gestures.stop(); Gestures.pose = null; Gestures.toggles.clear(); }));
            if (a != null) {
                BBModel m = a.model();
                ModelManager.Settings s = a.settings();
                for (String n : ModelManager.allAnimNames(m)) {
                    String cat = s.animCats.get(n);
                    if (cat == null) continue;
                    BBModel.Anim an = ModelManager.anim(m, n);
                    switch (cat) {
                        case ModelManager.CAT_GESTURE -> items.add(new Item(n, "gesto", () -> Gestures.play(m, s, n)));
                        case ModelManager.CAT_SLIDER -> items.add(new Item(n, "slider", () -> client.setScreen(new SliderScreen(n))));
                        case ModelManager.CAT_TOGGLE -> items.add(new Item(n, Gestures.toggles.contains(n) ? "toggle: on" : "toggle: off", () -> Gestures.toggle(n)));
                        case ModelManager.CAT_POSE -> items.add(new Item(n, "pose", () -> Gestures.pose = n));
                        default -> {}
                    }
                }
            }
        }
        page = 0;
    }

    private int pages() { return Math.max(1, (items.size() + PAGE - 1) / PAGE); }

    private List<Item> view() {
        int from = page * PAGE;
        return items.subList(from, Math.min(items.size(), from + PAGE));
    }

    private int hovered(double mx, double my) {
        List<Item> v = view();
        if (v.isEmpty()) return -1;
        double dx = mx - width / 2.0, dy = my - height / 2.0;
        if (Math.sqrt(dx * dx + dy * dy) < 28) return -1;
        double ang = Math.atan2(dx, -dy);            // 0 = arriba, crece en sentido horario
        if (ang < 0) ang += Math.PI * 2;
        double step = Math.PI * 2 / v.size();
        return (int) Math.round(ang / step) % v.size();
    }

    @Override
    public void render(DrawContext g, int mx, int my, float delta) {
        g.fill(0, 0, width, height, 0x90000000);
        List<Item> v = view();
        int cx = width / 2, cy = height / 2;
        int radius = Math.min(width, height) * 33 / 100;
        int hov = hovered(mx, my);
        double step = v.isEmpty() ? 0 : Math.PI * 2 / v.size();
        for (int i = 0; i < v.size(); i++) {
            double a = i * step;
            int x = cx + (int) Math.round(Math.sin(a) * radius), y = cy - (int) Math.round(Math.cos(a) * radius);
            Item it = v.get(i);
            int bw = 112, bh = it.sub().isEmpty() ? 22 : 30;
            boolean sel = i == hov;
            g.fill(x - bw / 2, y - bh / 2, x + bw / 2, y + bh / 2, sel ? Theme.c("primary") : Theme.c("surfaceHi"));
            g.fill(x - bw / 2, y + bh / 2 - 1, x + bw / 2, y + bh / 2, Theme.c("line"));
            String lab = textRenderer.trimToWidth(it.label(), bw - 8);
            int tc = sel ? Theme.c("onPrimary") : Theme.c("text");
            g.drawText(textRenderer, lab, x - textRenderer.getWidth(lab) / 2, y - (it.sub().isEmpty() ? 4 : 9), tc, false);
            if (!it.sub().isEmpty())
                g.drawText(textRenderer, it.sub(), x - textRenderer.getWidth(it.sub()) / 2, y + 2, sel ? Theme.c("onPrimary") : Theme.c("muted"), false);
        }
        String title = mode == Mode.MODELS ? "Modelos" : "Gestos";
        g.drawText(textRenderer, title, cx - textRenderer.getWidth(title) / 2, cy - 10, Theme.c("title"), false);
        String sub = pages() > 1 ? "Pág. " + (page + 1) + "/" + pages() + " (rueda del ratón)" : (items.size() <= 1 && mode == Mode.GESTURES ? "Asigna categorías en la pestaña Animación" : "");
        g.drawText(textRenderer, sub, cx - textRenderer.getWidth(sub) / 2, cy + 2, Theme.c("muted"), false);
    }

    private void choose(int idx) {
        List<Item> v = view();
        if (idx >= 0 && idx < v.size()) v.get(idx).action().run();
        close();
    }

    @Override
    public void tick() {
        openTicks++;
        if (key == null) return;
        int code = KeyBindingHelper.getBoundKeyOf(key).getCode();
        if (code == InputUtil.UNKNOWN_KEY.getCode() || openTicks < 3) return;
        boolean held = InputUtil.isKeyPressed(client.getWindow().getHandle(), code);
        if (!held) {
            double mx = client.mouse.getX() * width / client.getWindow().getWidth();
            double my = client.mouse.getY() * height / client.getWindow().getHeight();
            int h = hovered(mx, my);
            if (h >= 0) choose(h);
            else if (openTicks > 8) close(); // toque rápido: se queda abierta para elegir con clic
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) { choose(hovered(mx, my)); return true; }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        if (pages() > 1) { page = Math.floorMod(page + (v < 0 ? 1 : -1), pages()); return true; }
        return super.mouseScrolled(mx, my, h, v);
    }

    @Override
    public boolean shouldPause() { return false; }
}
