package com.morphzuka.ui;

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.List;

/** Contrato para decodificar video a fotogramas; la implementacion (JCodec) se carga por reflexion si esta empaquetada. */
public interface VideoLoader {
    /** Devuelve fotogramas reducidos a maxW de ancho. outDelayMs[0] = milisegundos por fotograma devuelto. */
    List<BufferedImage> load(File f, int maxW, int maxFrames, double[] outDelayMs) throws Exception;
}
