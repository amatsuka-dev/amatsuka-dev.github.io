package com.morphzuka.ui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import org.joml.Matrix4f;

/**
 * Primitivas 2D por lotes. DrawContext.fill hace un envio al GPU por cada llamada; con miles de rectitos
 * (rejillas, esquinas redondeadas, lineas dibujadas pixel a pixel) el visor se trababa.
 * Estas escriben los vertices en el buffer GUI y se envian todos juntos. Antes de dibujar una textura directa
 * (drawTexture) conviene hacer g.draw() para mantener el orden.
 */
public final class Gfx {
    private Gfx() {}

    private static final int[][] INSET = new int[48][];

    private static int[] inset(int r) {
        if (r >= INSET.length) return computeInset(r);
        int[] t = INSET[r];
        if (t == null) { t = computeInset(r); INSET[r] = t; }
        return t;
    }

    private static int[] computeInset(int r) {
        int[] t = new int[r];
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            t[i] = r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy)));
        }
        return t;
    }

    public static void fill(DrawContext g, int x1, int y1, int x2, int y2, int c) {
        if (x2 < x1) { int t = x1; x1 = x2; x2 = t; }
        if (y2 < y1) { int t = y1; y1 = y2; y2 = t; }
        if (x1 == x2 || y1 == y2) return;
        int a = c >>> 24;
        if (a == 0) return;
        Matrix4f m = g.getMatrices().peek().getPositionMatrix();
        VertexConsumer vc = g.getVertexConsumers().getBuffer(RenderLayer.getGui());
        int r = (c >> 16) & 255, gr = (c >> 8) & 255, b = c & 255;
        vc.vertex(m, x1, y1, 0f).color(r, gr, b, a);
        vc.vertex(m, x1, y2, 0f).color(r, gr, b, a);
        vc.vertex(m, x2, y2, 0f).color(r, gr, b, a);
        vc.vertex(m, x2, y1, 0f).color(r, gr, b, a);
    }

    /** Rectangulo redondeado con 2r+1 rectangulos (antes eran h rectangulos y h envios). */
    public static void rr(DrawContext g, int x, int y, int w, int h, int r, int c) {
        if (w <= 0 || h <= 0) return;
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { fill(g, x, y, x + w, y + h, c); return; }
        int[] in = inset(r);
        for (int i = 0; i < r; i++) {
            int d = in[i];
            fill(g, x + d, y + i, x + w - d, y + i + 1, c);
            fill(g, x + d, y + h - 1 - i, x + w - d, y + h - i, c);
        }
        fill(g, x, y + r, x + w, y + h - r, c);
    }

    /** Contorno de 1 px. */
    public static void box(DrawContext g, int x1, int y1, int x2, int y2, int c) {
        fill(g, x1, y1, x2, y1 + 1, c);
        fill(g, x1, y2 - 1, x2, y2, c);
        fill(g, x1, y1 + 1, x1 + 1, y2 - 1, c);
        fill(g, x2 - 1, y1 + 1, x2, y2 - 1, c);
    }

    /** Linea de grosor t como un solo quad (antes: un fill por pixel). */
    public static void line(DrawContext g, float x0, float y0, float x1, float y1, float t, int c) {
        int a = c >>> 24;
        if (a == 0) return;
        float dx = x1 - x0, dy = y1 - y0;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1e-3f) {
            int h = Math.max(1, Math.round(t));
            int x = Math.round(x0) - h / 2, y = Math.round(y0) - h / 2;
            fill(g, x, y, x + h, y + h, c);
            return;
        }
        float nx = -dy / len * t * 0.5f, ny = dx / len * t * 0.5f;
        float ax = x0 + nx, ay = y0 + ny, bx = x1 + nx, by = y1 + ny, cx = x1 - nx, cy = y1 - ny, ex = x0 - nx, ey = y0 - ny;
        // el culling del GUI exige el mismo sentido que fill(): TL -> BL -> BR -> TR
        float cross = (bx - ax) * (cy - by) - (by - ay) * (cx - bx);
        Matrix4f m = g.getMatrices().peek().getPositionMatrix();
        VertexConsumer vc = g.getVertexConsumers().getBuffer(RenderLayer.getGui());
        int r = (c >> 16) & 255, gr = (c >> 8) & 255, b = c & 255;
        if (cross <= 0) {
            vc.vertex(m, ax, ay, 0f).color(r, gr, b, a);
            vc.vertex(m, bx, by, 0f).color(r, gr, b, a);
            vc.vertex(m, cx, cy, 0f).color(r, gr, b, a);
            vc.vertex(m, ex, ey, 0f).color(r, gr, b, a);
        } else {
            vc.vertex(m, ex, ey, 0f).color(r, gr, b, a);
            vc.vertex(m, cx, cy, 0f).color(r, gr, b, a);
            vc.vertex(m, bx, by, 0f).color(r, gr, b, a);
            vc.vertex(m, ax, ay, 0f).color(r, gr, b, a);
        }
    }
}
