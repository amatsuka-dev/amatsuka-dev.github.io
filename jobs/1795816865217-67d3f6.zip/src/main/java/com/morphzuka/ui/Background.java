package com.morphzuka.ui;

import com.mojang.blaze3d.systems.RenderSystem;
import com.morphzuka.model.ModelManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.metadata.IIOMetadata;
import javax.imageio.stream.ImageInputStream;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Fondo del menu: imagen (png/jpg), gif animado o video mp4/mov. Se decodifica en un hilo y se sube a texturas en el hilo de render. */
public final class Background {
    private Background() {}

    private static volatile Identifier[] frames = new Identifier[0];
    private static volatile int[] delays = new int[0];
    private static volatile int total = 1;
    private static int w = 1, h = 1;
    private static long t0;
    private static volatile boolean loading;
    private static volatile String message = "";
    private static int serial;

    private static final long PIXEL_BUDGET = 16_000_000L;

    public static boolean loading() { return loading; }
    public static String message() { return message; }
    public static boolean has() { return frames.length > 0; }

    public static void clear() {
        serial++;
        MinecraftClient mc = MinecraftClient.getInstance();
        for (Identifier id : frames) mc.getTextureManager().destroyTexture(id);
        frames = new Identifier[0];
        delays = new int[0];
        message = "";
    }

    /** Resuelve rutas relativas contra .minecraft/morphzuka/backgrounds/. */
    public static Path resolve(String name) {
        Path p = Path.of(name);
        if (p.isAbsolute() || Files.exists(p)) return p;
        return ModelManager.bgDir().resolve(name);
    }

    public static void load(String name) {
        clear();
        if (name == null || name.isBlank()) return;
        Path p = resolve(name.trim().replace("\"", ""));
        if (!Files.isRegularFile(p)) { message = "No existe: " + p; return; }
        final int my = ++serial;
        loading = true;
        message = "Cargando fondo...";
        Thread t = new Thread(() -> decode(p, my), "morphzuka-bg");
        t.setDaemon(true);
        t.start();
    }

    private static void decode(Path p, int my) {
        try {
            String fn = p.getFileName().toString().toLowerCase(Locale.ROOT);
            List<BufferedImage> imgs = new ArrayList<>();
            List<Integer> dl = new ArrayList<>();
            if (fn.endsWith(".gif")) {
                readGif(p.toFile(), imgs, dl);
            } else if (fn.endsWith(".mp4") || fn.endsWith(".mov") || fn.endsWith(".m4v")) {
                VideoLoader vl;
                try { vl = (VideoLoader) Class.forName("com.morphzuka.ui.VideoDecoder").getDeclaredConstructor().newInstance(); }
                catch (Throwable t) { throw new IllegalStateException("Este build no incluye soporte de video (withVideo=false)"); }
                double[] d = new double[1];
                List<BufferedImage> v = vl.load(p.toFile(), 384, 120, d);
                if (v.isEmpty()) throw new IllegalStateException("No se pudo leer el video (usa mp4 H.264)");
                for (BufferedImage b : v) { imgs.add(b); dl.add((int) Math.max(30, d[0])); }
            } else {
                BufferedImage b = ImageIO.read(p.toFile());
                if (b == null) throw new IllegalStateException("Formato no soportado (png, jpg, gif, mp4)");
                imgs.add(fit(b, 1920));
                dl.add(1000);
            }
            if (imgs.isEmpty()) throw new IllegalStateException("Sin fotogramas");
            int iw = imgs.get(0).getWidth(), ih = imgs.get(0).getHeight();
            int maxFrames = (int) Math.max(1, PIXEL_BUDGET / Math.max(1, (long) iw * ih));
            while (imgs.size() > maxFrames && imgs.size() > 1) { // si no caben en el presupuesto, descarta un fotograma de cada dos
                List<BufferedImage> ni = new ArrayList<>();
                List<Integer> nd = new ArrayList<>();
                for (int i = 0; i < imgs.size(); i += 2) { ni.add(imgs.get(i)); nd.add(dl.get(i) * 2); }
                imgs = ni; dl = nd;
            }
            List<NativeImage> nat = new ArrayList<>();
            for (BufferedImage b : imgs) nat.add(toNative(b));
            final List<Integer> fdl = dl;
            final int fw = iw, fh = ih;
            MinecraftClient.getInstance().execute(() -> {
                if (my != serial) { for (NativeImage n : nat) n.close(); return; }
                Identifier[] ids = new Identifier[nat.size()];
                int[] ds = new int[nat.size()];
                int sum = 0;
                for (int i = 0; i < nat.size(); i++) {
                    NativeImageBackedTexture tex = new NativeImageBackedTexture(nat.get(i));
                    ids[i] = Identifier.of("morphzuka", "bg/" + my + "_" + i);
                    MinecraftClient.getInstance().getTextureManager().registerTexture(ids[i], tex);
                    ds[i] = Math.max(20, fdl.get(i));
                    sum += ds[i];
                }
                w = fw; h = fh; total = Math.max(1, sum); delays = ds; frames = ids; t0 = Util.getMeasuringTimeMs();
                loading = false;
                message = ids.length > 1 ? "Fondo animado: " + ids.length + " fotogramas" : "Fondo cargado";
            });
        } catch (Throwable e) {
            loading = false;
            message = "Error: " + (e.getMessage() == null ? e.toString() : e.getMessage());
        }
    }

    // GIF con composicion de fotogramas parciales
    private static void readGif(File f, List<BufferedImage> imgs, List<Integer> dl) throws Exception {
        try (ImageInputStream in = ImageIO.createImageInputStream(f)) {
            ImageReader r = ImageIO.getImageReadersByFormatName("gif").next();
            r.setInput(in, false);
            int n = r.getNumImages(true);
            int cw = 0, ch = 0;
            for (int i = 0; i < n; i++) { BufferedImage b = r.read(i); cw = Math.max(cw, b.getWidth()); ch = Math.max(ch, b.getHeight()); }
            BufferedImage canvas = new BufferedImage(cw, ch, BufferedImage.TYPE_INT_ARGB);
            int step = Math.max(1, n / 300);
            for (int i = 0; i < n; i++) {
                BufferedImage fr = r.read(i);
                int ox = 0, oy = 0, delay = 10;
                IIOMetadata md = r.getImageMetadata(i);
                Node root = md.getAsTree("javax_imageio_gif_image_1.0");
                for (Node c = root.getFirstChild(); c != null; c = c.getNextSibling()) {
                    NamedNodeMap at = c.getAttributes();
                    if ("ImageDescriptor".equals(c.getNodeName()) && at != null) {
                        ox = Integer.parseInt(at.getNamedItem("imageLeftPosition").getNodeValue());
                        oy = Integer.parseInt(at.getNamedItem("imageTopPosition").getNodeValue());
                    } else if ("GraphicControlExtension".equals(c.getNodeName()) && at != null) {
                        delay = Integer.parseInt(at.getNamedItem("delayTime").getNodeValue());
                    }
                }
                Graphics2D g = canvas.createGraphics();
                g.drawImage(fr, ox, oy, null);
                g.dispose();
                if (i % step != 0) continue;
                BufferedImage copy = new BufferedImage(cw, ch, BufferedImage.TYPE_INT_ARGB);
                Graphics2D g2 = copy.createGraphics();
                g2.drawImage(canvas, 0, 0, null);
                g2.dispose();
                imgs.add(fit(copy, 480));
                dl.add(Math.max(2, delay) * 10 * step);
            }
            r.dispose();
        }
    }

    private static BufferedImage fit(BufferedImage src, int maxW) {
        if (src.getWidth() <= maxW) return src;
        int nw = maxW, nh = Math.max(1, src.getHeight() * maxW / src.getWidth());
        BufferedImage o = new BufferedImage(nw, nh, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = o.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(src, 0, 0, nw, nh, null);
        g.dispose();
        return o;
    }

    private static NativeImage toNative(BufferedImage b) {
        NativeImage n = new NativeImage(NativeImage.Format.RGBA, b.getWidth(), b.getHeight(), false);
        for (int y = 0; y < b.getHeight(); y++)
            for (int x = 0; x < b.getWidth(); x++) {
                int argb = b.getRGB(x, y);
                int a = argb >>> 24, r = (argb >> 16) & 255, g = (argb >> 8) & 255, bl = argb & 255;
                n.setColor(x, y, (a << 24) | (bl << 16) | (g << 8) | r); // ABGR
            }
        return n;
    }

    public static void draw(DrawContext g, int sw, int sh) {
        Identifier[] fr = frames;
        if (fr.length == 0) return;
        int idx = 0;
        if (fr.length > 1) {
            long t = (Util.getMeasuringTimeMs() - t0) % total;
            int acc = 0;
            for (int i = 0; i < fr.length; i++) { acc += delays[i]; if (t < acc) { idx = i; break; } }
        }
        float scale = Math.max((float) sw / w, (float) sh / h);
        int rw = Math.min(w, Math.round(sw / scale)), rh = Math.min(h, Math.round(sh / scale));
        float u = (w - rw) / 2f, v = (h - rh) / 2f;
        RenderSystem.enableBlend();
        g.setShaderColor(1f, 1f, 1f, Theme.data.bgAlpha);
        g.drawTexture(fr[idx], 0, 0, sw, sh, u, v, rw, rh, w, h);
        g.setShaderColor(1f, 1f, 1f, 1f);
    }
}
