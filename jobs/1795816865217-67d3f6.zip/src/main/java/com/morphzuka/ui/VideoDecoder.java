package com.morphzuka.ui;

import org.jcodec.api.FrameGrab;
import org.jcodec.common.io.NIOUtils;
import org.jcodec.common.io.SeekableByteChannel;
import org.jcodec.common.model.Picture;
import org.jcodec.scale.AWTUtil;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Decodifica .mp4 / .mov (H.264) en Java puro con JCodec. Toma ~10 fotogramas por segundo. */
public class VideoDecoder implements VideoLoader {
    @Override
    public List<BufferedImage> load(File f, int maxW, int maxFrames, double[] outDelayMs) throws Exception {
        List<BufferedImage> out = new ArrayList<>();
        SeekableByteChannel ch = NIOUtils.readableChannel(f);
        try {
            FrameGrab grab = FrameGrab.createFrameGrab(ch);
            double fps = 30.0;
            try {
                var meta = grab.getVideoTrack().getMeta();
                double dur = meta.getTotalDuration(), frames = meta.getTotalFrames();
                if (dur > 0 && frames > 0) fps = Math.max(5, Math.min(120, frames / dur));
            } catch (Throwable ignored) {}
            int step = Math.max(1, (int) Math.round(fps / 10.0));
            outDelayMs[0] = 1000.0 * step / fps;
            int i = 0;
            Picture p;
            while (out.size() < maxFrames && (p = grab.getNativeFrame()) != null) {
                if (i++ % step != 0) continue;
                out.add(scale(AWTUtil.toBufferedImage(p), maxW));
            }
        } finally {
            NIOUtils.closeQuietly(ch);
        }
        return out;
    }

    private static BufferedImage scale(BufferedImage src, int maxW) {
        if (src.getWidth() <= maxW) return src;
        int w = maxW, h = Math.max(1, src.getHeight() * maxW / src.getWidth());
        BufferedImage o = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = o.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        g.drawImage(src, 0, 0, w, h, null);
        g.dispose();
        return o;
    }
}
