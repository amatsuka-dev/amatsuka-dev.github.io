package com.morphzuka.ui;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Colores personalizables de la interfaz + referencia al fondo (imagen / gif / video). Se guarda dentro del config. */
public final class Theme {
    private Theme() {}

    public static final String[] KEYS = {"panel", "rail", "surface", "surfaceHi", "pill", "primary", "onPrimary", "text", "title", "subtitle", "muted", "line", "error"};
    public static final String[] LABELS = {"Fondo panel", "Fondo barra", "Superficies", "Superficie activa", "Selección", "Acento", "Texto sobre acento", "Texto", "Títulos", "Subtítulos", "Texto apagado", "Líneas", "Error"};

    public static class Data {
        public Map<String, String> colors = new LinkedHashMap<>();
        public String bgFile = "";
        public float bgAlpha = 0.55f;
    }

    public static Data data = new Data();

    private static final Map<String, String> DEF = new LinkedHashMap<>();
    static {
        String[] v = {"D0181212", "E0100B0B", "66463C3A", "B0594B49", "FF4F3F3D", "FFE8C2BA", "FF442926", "FFEDE0DD", "FFEDE0DD", "FF9D8F8C", "FF9D8F8C", "30FFFFFF", "FFFFB4AB"};
        for (int i = 0; i < KEYS.length; i++) DEF.put(KEYS[i], v[i]);
    }

    public static void ensure(Data d) {
        if (d == null) d = new Data();
        if (d.colors == null) d.colors = new LinkedHashMap<>();
        for (String k : KEYS) d.colors.putIfAbsent(k, DEF.get(k));
        if (d.bgFile == null) d.bgFile = "";
        d.bgAlpha = Math.max(0f, Math.min(1f, d.bgAlpha));
        data = d;
    }

    public static int c(String key) { return parse(hex(key), (int) Long.parseLong(DEF.get(key), 16)); }

    public static String hex(String key) { return data.colors.getOrDefault(key, DEF.get(key)); }

    public static void set(String key, String hex) { data.colors.put(key, hex.trim().replace("#", "").toUpperCase(Locale.ROOT)); }

    public static boolean valid(String s) {
        String t = s.trim().replace("#", "");
        if (t.length() != 6 && t.length() != 8) return false;
        try { Long.parseLong(t, 16); return true; } catch (Exception e) { return false; }
    }

    public static int parse(String s, int def) {
        try {
            String t = s.trim().replace("#", "");
            if (t.length() == 6) t = "FF" + t;
            return (int) Long.parseLong(t, 16);
        } catch (Exception e) { return def; }
    }

    public static void reset() { for (String k : KEYS) data.colors.put(k, DEF.get(k)); }

    public static final String[] PRESETS = {"Oscuro", "Claro", "Rojo", "Azul", "Verde"};

    public static void preset(String name) {
        String[] p = switch (name) {
            case "Claro" -> new String[]{"E8F4F0F0", "F0E2DADA", "66B8ACAC", "B0A89C9C", "FFD6C4C4", "FF8A3A33", "FFFFFFFF", "FF2A1F1E", "FF1A1110", "FF5D4F4D", "FF6F6360", "40000000", "FFB3261E"};
            case "Rojo" -> new String[]{"D0200808", "E0150404", "66602020", "B0802828", "FF7A2020", "FFFF6B6B", "FF3A0000", "FFFFE5E5", "FFFFC0C0", "FFD08888", "FFA06060", "40FF8080", "FFFFB4AB"};
            case "Azul" -> new String[]{"D0081220", "E0040A15", "66203860", "B0284A80", "FF204A7A", "FF6BB6FF", "FF00203A", "FFE5F0FF", "FFC0DCFF", "FF88A8D0", "FF6080A0", "408080FF", "FFFFB4AB"};
            case "Verde" -> new String[]{"D0081A0C", "E0041006", "66205028", "B0286A34", "FF206A2C", "FF7BE08A", "FF00300A", "FFE5FFE9", "FFC0F0C8", "FF88C090", "FF609068", "4080FF80", "FFFFB4AB"};
            default -> null;
        };
        if (p == null) { reset(); return; }
        for (int i = 0; i < KEYS.length; i++) data.colors.put(KEYS[i], p[i]);
    }
}
