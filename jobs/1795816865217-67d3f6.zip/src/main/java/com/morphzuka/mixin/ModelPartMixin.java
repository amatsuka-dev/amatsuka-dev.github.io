package com.morphzuka.mixin;

import com.morphzuka.render.PartTree;
import net.minecraft.client.model.ModelPart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Map;

/** Apunta el nombre ("head", "right_arm"...) de cada parte cuando se crea, porque el juego no lo guarda en la parte. */
@Mixin(ModelPart.class)
public abstract class ModelPartMixin {

    @Inject(method = "<init>(Ljava/util/List;Ljava/util/Map;)V", at = @At("RETURN"), require = 0)
    private void morphzuka$names(List<?> cuboids, Map<String, ModelPart> children, CallbackInfo ci) {
        PartTree.register(children);
    }
}
