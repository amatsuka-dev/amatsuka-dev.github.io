package com.morphzuka.mixin;

import com.morphzuka.render.MorphManager;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Distancia de la camara en tercera persona segun el tamaño del morph. */
@Mixin(Camera.class)
public abstract class CameraMixin {

    @ModifyVariable(method = "clipToSpace", at = @At("HEAD"), argsOnly = true, require = 0)
    private float morphzuka$distance(float desired) {
        if (MorphManager.active() && MorphManager.copyHitbox) return desired * Math.max(0.5f, MorphManager.state().h / 1.8f);
        return desired;
    }
}
