package com.morphzuka.mixin;

import com.morphzuka.model.ModelManager;
import com.morphzuka.render.BBRenderer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Mano del modelo en primera persona. */
@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin {

    @Inject(method = "renderRightArm", at = @At("HEAD"), cancellable = true, require = 0)
    private void morphzuka$right(MatrixStack matrices, VertexConsumerProvider vcp, int light, AbstractClientPlayerEntity player, CallbackInfo ci) {
        ModelManager.Active a = ModelManager.forPlayer(player);
        if (a != null && BBRenderer.renderFirstPersonArm(player, matrices, vcp, light, true, a)) ci.cancel();
    }

    @Inject(method = "renderLeftArm", at = @At("HEAD"), cancellable = true, require = 0)
    private void morphzuka$left(MatrixStack matrices, VertexConsumerProvider vcp, int light, AbstractClientPlayerEntity player, CallbackInfo ci) {
        ModelManager.Active a = ModelManager.forPlayer(player);
        if (a != null && BBRenderer.renderFirstPersonArm(player, matrices, vcp, light, false, a)) ci.cancel();
    }
}
