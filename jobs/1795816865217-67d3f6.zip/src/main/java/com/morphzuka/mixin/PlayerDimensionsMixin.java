package com.morphzuka.mixin;

import com.morphzuka.HitboxRegistry;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Hitbox personalizada y altura de ojos. Mixin COMUN (cliente y servidor): el mismo calculo lo hace el ServerPlayerEntity
 * (colisiones y validacion de movimiento reales) y el jugador del cliente (prediccion), cada uno con su mapa de
 * {@link HitboxRegistry}. Se aplica a cada postura: de pie, agachado y nadando/gateando, asi un modelo pequeno pasa por
 * huecos de 1 bloque y uno grande se pone a gatear solo cuando no cabe de pie.
 */
@Mixin(PlayerEntity.class)
public abstract class PlayerDimensionsMixin {

    @Inject(method = "getBaseDimensions", at = @At("RETURN"), cancellable = true, require = 0)
    private void morphzuka$dims(EntityPose pose, CallbackInfoReturnable<EntityDimensions> cir) {
        float[] hb = HitboxRegistry.get((PlayerEntity) (Object) this);
        if (hb == null) return;
        float w = hb[0], h = hb[1], eye = hb[2];
        switch (pose) {
            case STANDING -> {}
            case CROUCHING -> { h *= 0.8333f; eye *= 0.784f; }
            case SWIMMING, FALL_FLYING, SPIN_ATTACK -> {
                float nh = Math.min(w, h);
                eye = Math.min(eye, nh * 0.667f);
                h = nh;
            }
            default -> { return; }   // dormir, morir...: caja vanilla
        }
        cir.setReturnValue(EntityDimensions.changing(w, h).withEyeHeight(eye));
    }
}
