package com.morphzuka.mixin;

import net.minecraft.client.model.ModelPart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;

/** Acceso a los hijos de una parte del modelo (para listar cabeza, brazos, patas... de cualquier entidad). */
@Mixin(ModelPart.class)
public interface ModelPartAccessor {
    @Accessor("children")
    Map<String, ModelPart> morphzuka$children();
}
