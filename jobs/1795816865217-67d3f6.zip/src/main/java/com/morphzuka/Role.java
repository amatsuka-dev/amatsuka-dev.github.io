package com.morphzuka;

import java.util.Locale;

public enum Role {
    NONE("-", "none"), HEAD("Cabeza", "head"), BODY("Torso", "body"), LEFT_ARM("Brazo izq", "left_arm"), RIGHT_ARM("Brazo der", "right_arm"),
    LEFT_LEG("Pierna izq", "left_leg"), RIGHT_LEG("Pierna der", "right_leg"), TAIL("Cola / extra", "tail");

    public final String label;
    /** Nombre portable usado en animaciones exportadas (sirve para cualquier modelo que tenga ese rol). */
    public final String alias;
    Role(String l, String a) { this.label = l; this.alias = a; }

    public static Role of(String s) {
        if (s == null) return NONE;
        try { return valueOf(s); } catch (Exception e) { return NONE; }
    }

    /** Adivina el rol por el nombre del hueso: entiende camelCase (LeftArm, ArmL, LArm), ingles y espanol. */
    public static Role guess(String name) {
        if (name == null) return NONE;
        String sp = name.replaceAll("([a-z0-9])([A-Z])", "$1_$2").replaceAll("([A-Z])([A-Z][a-z])", "$1_$2");
        String n = sp.toLowerCase(Locale.ROOT);
        boolean left = false, right = false;
        for (String t : n.split("[^a-z0-9\u00e1\u00e9\u00ed\u00f3\u00fa\u00f1]+")) {
            if (t.equals("l") || t.equals("left") || t.equals("izq") || t.startsWith("izquierd")) left = true;
            if (t.equals("r") || t.equals("right") || t.equals("der") || t.startsWith("derech")) right = true;
        }
        if (!left && !right) {
            left = n.contains("left") || n.contains("izq");
            right = n.contains("right") || n.contains("derech");
        }
        if (left && right) { left = false; right = false; }
        if (n.contains("head") || n.contains("cabeza")) return HEAD;
        if (n.contains("tail") || n.matches(".*(^|[^a-z])cola([^a-z]|$).*")) return TAIL;
        boolean armor = n.contains("armor") || n.contains("armour") || n.contains("armadura");
        if (!armor && (n.contains("arm") || n.contains("hand") || n.contains("brazo") || n.contains("mano")))
            return left ? LEFT_ARM : right ? RIGHT_ARM : NONE;
        if (n.contains("leg") || n.contains("foot") || n.contains("feet") || n.contains("pierna"))
            return left ? LEFT_LEG : right ? RIGHT_LEG : NONE;
        if (n.contains("body") || n.contains("torso") || n.contains("chest") || n.contains("cuerpo")) return BODY;
        return NONE;
    }
}
