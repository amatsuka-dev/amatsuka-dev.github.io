package com.morphzuka.render;

import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelBounds;
import com.morphzuka.model.ModelManager;
import com.morphzuka.model.VanillaPlayer;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;

/**
 * Descripcion de "como se ve" un jugador en un momento dado, lo justo para que el efecto de cubos pueda sacar trozos de
 * su superficie con la textura que le toca: skin vanilla, modelo propio, bloque o entidad (o una caja generica).
 */
public final class Form {
    public enum Type { MODEL, BLOCK, ENTITY, BOX }

    public static final Identifier WHITE = Identifier.of("minecraft", "textures/misc/white.png");

    public final Type type;
    public final String key;
    public float w = 0.6f, h = 1.8f;
    public BBModel model;                    // MODEL (tambien la skin vanilla)
    public ModelManager.Settings settings;   // MODEL
    public Identifier tex;                   // MODEL: textura real; ENTITY: textura de la entidad (puede ser null)
    public BlockState block;                 // BLOCK
    public Entity ent;                       // ENTITY: la entidad, para copiar la forma real de su modelo

    private Form(Type t, String key) { this.type = t; this.key = key; }

    public static Form model(BBModel m, ModelManager.Settings s, Identifier tex, String key) {
        Form f = new Form(Type.MODEL, key);
        f.model = m;
        f.settings = s;
        f.tex = tex != null ? tex : m.texture;
        ModelBounds.Box b = ModelBounds.of(m, s);
        if (m.id != null && m.id.startsWith("@vanilla")) { f.w = 0.6f; f.h = 1.8f; } else { f.w = b.width(); f.h = b.height(); }
        return f;
    }

    public static Form skin(Identifier skin, boolean slim, String key) {
        ModelManager.Settings st = new ModelManager.Settings();
        st.scale = 0.9375f;   // el render vanilla del jugador escala el modelo a 15/16
        return model(VanillaPlayer.get(slim), st, skin, key);
    }

    public static Form block(BlockState st, String key) {
        Form f = new Form(Type.BLOCK, key);
        f.block = st;
        f.w = f.h = 0.98f;
        return f;
    }

    public static Form entity(Entity e, float w, float h, String key) {
        Form f = new Form(Type.ENTITY, key);
        f.w = w;
        f.h = h;
        f.tex = entityTexture(e);
        f.ent = e;
        return f;
    }

    /** Caja generica con colores (cuando no sabemos nada de la forma, p. ej. un jugador lejano que aun no cargo). */
    public static Form box(float w, float h) {
        Form f = new Form(Type.BOX, "box");
        f.w = Math.max(0.2f, w);
        f.h = Math.max(0.2f, h);
        return f;
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Identifier entityTexture(Entity e) {
        if (e == null) return null;
        try {
            EntityRenderer r = MinecraftClient.getInstance().getEntityRenderDispatcher().getRenderer(e);
            return r == null ? null : r.getTexture(e);
        } catch (Throwable t) {
            return null;   // algunas entidades de mods no dan textura: se usa la caja de colores
        }
    }

    /** Clave barata de la forma actual de un jugador (cambia cuando cambia la forma). */
    public static String keyOf(AbstractClientPlayerEntity p) {
        MorphManager.State ms = MorphManager.stateOf(p);
        if (ms != null) return ms.kind + ":" + (ms.kind == MorphManager.Kind.PLAYER ? ms.name : String.valueOf(ms.id));
        ModelManager.Active a = ModelManager.forPlayer(p);
        return a != null ? "model:" + a.model().id : "skin";
    }

    /** Forma actual de un jugador. Nunca devuelve null. */
    public static Form of(AbstractClientPlayerEntity p) {
        String key = keyOf(p);
        try {
            MorphManager.State ms = MorphManager.stateOf(p);
            if (ms != null) {
                switch (ms.kind) {
                    case BLOCK: return ms.block == null ? box(ms.w, ms.h) : block(ms.block, key);
                    case PLAYER:
                        if (ms.entity instanceof AbstractClientPlayerEntity ap) return skinOf(ap, key);
                        return box(ms.w, ms.h);
                    default: return entity(ms.entity, ms.w, ms.h, key);
                }
            }
            ModelManager.Active a = ModelManager.forPlayer(p);
            if (a != null) return model(a.model(), a.settings(), null, key);
            return skinOf(p, key);
        } catch (Throwable t) {
            return box(0.6f, 1.8f);
        }
    }

    private static Form skinOf(AbstractClientPlayerEntity p, String key) {
        var st = p.getSkinTextures();
        return skin(st.texture(), "SLIM".equals(String.valueOf(st.model())), key);
    }
}
