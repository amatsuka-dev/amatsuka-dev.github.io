package com.morphzuka.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Util;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Recuerda la forma de cada jugador visible (la actual y la anterior). Asi, cuando alguien se transforma, el efecto de
 * cubos sabe de que skin / modelo / bloque / entidad sale y a cual llega, tambien para los jugadores remotos.
 */
public final class Forms {
    private Forms() {}

    private static final class Entry {
        String key;
        Form cur, prev;
        long changedMs;
    }

    private static final Map<UUID, Entry> MAP = new HashMap<>();

    public static void clear() { MAP.clear(); }

    /** Una vez por tick, ANTES de Transition.check. */
    public static void tick(MinecraftClient mc) {
        if (mc.world == null) { MAP.clear(); return; }
        long now = Util.getMeasuringTimeMs();
        for (AbstractClientPlayerEntity p : mc.world.getPlayers()) {
            String key = Form.keyOf(p);
            Entry e = MAP.get(p.getUuid());
            if (e == null) {
                e = new Entry();
                e.key = key;
                e.cur = Form.of(p);
                MAP.put(p.getUuid(), e);
            } else if (!e.key.equals(key)) {
                e.prev = e.cur;
                e.cur = Form.of(p);
                e.key = key;
                e.changedMs = now;
            }
        }
        MAP.keySet().removeIf(u -> mc.world.getPlayerByUuid(u) == null);
    }

    /**
     * {de donde sale, a donde llega} para un jugador que se acaba de transformar. Si el cambio ya esta registrado se usan las
     * formas reales; si no (el aviso del servidor llego antes que el cambio) se completa con lo que dice el paquete.
     */
    public static Form[] pair(UUID who, float ow, float oh, float nw, float nh, int blockId) {
        Entry e = MAP.get(who);
        if (e != null && e.prev != null && Util.getMeasuringTimeMs() - e.changedMs < 2000L) return new Form[]{e.prev, e.cur};
        Form old = e != null ? e.cur : Form.box(ow, oh);
        Form now = null;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world != null && mc.world.getPlayerByUuid(who) instanceof AbstractClientPlayerEntity p) {
            Form f = Form.of(p);
            if (e == null || !f.key.equals(old.key)) now = f;
        }
        if (now == null) {
            var b = blockId >= 0 ? Registries.BLOCK.get(blockId) : null;
            now = b != null && b != net.minecraft.block.Blocks.AIR ? Form.block(b.getDefaultState(), "block:" + blockId) : Form.box(nw, nh);
        }
        return new Form[]{old, now};
    }
}
