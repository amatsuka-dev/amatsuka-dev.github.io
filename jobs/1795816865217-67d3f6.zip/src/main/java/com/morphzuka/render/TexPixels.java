package com.morphzuka.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.AbstractTexture;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Random;

/**
 * Mapa de pixeles opacos de una textura. Solo se usa para no cortar trozos de zonas transparentes y para elegir
 * parches de entidades (cuyo mapa UV no conocemos). Si la textura no se puede leer (p. ej. una skin descargada),
 * se considera opaca en todas partes y el efecto sigue funcionando.
 */
final class TexPixels {
    private static final TexPixels NONE = new TexPixels(0, 0, null);
    private static final Map<Identifier, TexPixels> CACHE = new LinkedHashMap<>(16, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<Identifier, TexPixels> e) { return size() > 24; }
    };

    final int w, h;
    private final boolean[] opaque;

    private TexPixels(int w, int h, boolean[] opaque) { this.w = w; this.h = h; this.opaque = opaque; }

    static void clear() { CACHE.clear(); }

    /** null si no se pudo leer. */
    static TexPixels get(Identifier id) {
        if (id == null) return null;
        TexPixels t = CACHE.get(id);
        if (t == null) { t = read(id); CACHE.put(id, t); }
        return t == NONE ? null : t;
    }

    private static TexPixels read(Identifier id) {
        MinecraftClient mc = MinecraftClient.getInstance();
        NativeImage img = null;
        boolean close = false;
        try {
            AbstractTexture tx = mc.getTextureManager().getTexture(id);
            if (tx instanceof NativeImageBackedTexture nb) img = nb.getImage();
            if (img == null) {
                Optional<Resource> r = mc.getResourceManager().getResource(id);
                if (r.isPresent()) {
                    try (InputStream in = r.get().getInputStream()) { img = NativeImage.read(in); close = true; }
                }
            }
            if (img == null) return NONE;
            int w = img.getWidth(), h = img.getHeight();
            boolean[] op = new boolean[w * h];
            for (int y = 0; y < h; y++)
                for (int x = 0; x < w; x++) op[y * w + x] = ((img.getColor(x, y) >>> 24) & 0xFF) >= 128;
            return new TexPixels(w, h, op);
        } catch (Throwable t) {
            return NONE;
        } finally {
            if (close && img != null) img.close();
        }
    }

    boolean opaqueAt(float u, float v) {
        int x = Math.max(0, Math.min(w - 1, (int) (u * w))), y = Math.max(0, Math.min(h - 1, (int) (v * h)));
        return opaque[y * w + x];
    }

    /** Punto (u, v) normalizado de un pixel opaco al azar, o null si no hay ninguno tras varios intentos. */
    float[] randomOpaque(Random r) {
        for (int i = 0; i < 24; i++) {
            float u = r.nextFloat(), v = r.nextFloat();
            if (opaqueAt(u, v)) return new float[]{u, v};
        }
        return null;
    }
}
