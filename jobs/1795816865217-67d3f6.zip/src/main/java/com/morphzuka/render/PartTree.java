package com.morphzuka.render;

import com.morphzuka.mixin.ModelPartAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.entity.Entity;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.*;

/**
 * Lista las partes (cabeza, brazos, patas...) del modelo con el que el juego dibuja una entidad.
 * Funciona con cualquier modelo hecho de ModelPart (vanilla y la mayoria de mods). Los nombres vienen del registro
 * que rellena {@code ModelPartMixin}; cada parte se identifica por su ruta, p. ej. "body/right_arm".
 */
public final class PartTree {
    private PartTree() {}

    public record Node(String path, String name, int depth, ModelPart part) {}

    private static final Map<ModelPart, String> NAMES = Collections.synchronizedMap(new WeakHashMap<>());
    private static final Map<Object, List<Node>> CACHE = Collections.synchronizedMap(new WeakHashMap<>());

    /** Lo llama el mixin del constructor de ModelPart. */
    public static void register(Map<String, ModelPart> children) {
        if (children == null) return;
        for (Map.Entry<String, ModelPart> e : children.entrySet()) NAMES.put(e.getValue(), e.getKey());
    }

    /** El modelo (EntityModel) del renderer de esa entidad, o null si no es un renderer de seres vivos. */
    public static Object modelOf(Entity e) {
        if (e == null) return null;
        try {
            Object r = MinecraftClient.getInstance().getEntityRenderDispatcher().getRenderer(e);
            if (r instanceof LivingEntityRenderer<?, ?> l) return l.getModel();
        } catch (Throwable ignored) {}
        return null;
    }

    /** Partes con nombre del modelo, en orden de arbol. Vacio si el modelo no usa ModelPart. */
    public static List<Node> of(Object model) {
        if (model == null) return List.of();
        List<Node> c = CACHE.get(model);
        if (c == null) {
            c = build(model);
            CACHE.put(model, c);
        }
        return c;
    }

    private static Map<String, ModelPart> children(ModelPart p) {
        try {
            Map<String, ModelPart> m = ((ModelPartAccessor) (Object) p).morphzuka$children();
            return m == null ? Map.of() : m;
        } catch (Throwable t) {
            return Map.of();
        }
    }

    private static List<Node> build(Object model) {
        List<ModelPart> tops = new ArrayList<>();
        try {
            if (model instanceof SinglePartEntityModel<?> single) tops.add(single.getPart());
        } catch (Throwable ignored) {}
        for (Class<?> k = model.getClass(); k != null && k != Object.class; k = k.getSuperclass()) {
            for (Field f : k.getDeclaredFields()) {
                if (Modifier.isStatic(f.getModifiers())) continue;
                try {
                    f.setAccessible(true);
                    Object v = f.get(model);
                    if (v instanceof ModelPart one) {
                        tops.add(one);
                    } else if (v instanceof ModelPart[] arr) {
                        for (ModelPart a : arr) if (a != null) tops.add(a);
                    } else if (v instanceof List<?> list && list.size() < 64) {
                        for (Object o : list) if (o instanceof ModelPart lp) tops.add(lp);
                    }
                } catch (Throwable ignored) {}
            }
        }
        Set<ModelPart> inner = Collections.newSetFromMap(new IdentityHashMap<>());
        for (ModelPart t : tops) markInner(t, inner);
        List<Node> out = new ArrayList<>();
        Set<ModelPart> seen = Collections.newSetFromMap(new IdentityHashMap<>());
        for (ModelPart t : tops) {
            if (inner.contains(t) || !seen.add(t)) continue;      // solo las raices: el resto cuelga de ellas
            String nm = NAMES.get(t);
            if (nm != null) {
                out.add(new Node(nm, nm, 0, t));
                walk(t, nm, 1, out, seen);
            } else {
                walk(t, "", 0, out, seen);
            }
        }
        return Collections.unmodifiableList(out);
    }

    private static void markInner(ModelPart p, Set<ModelPart> inner) {
        for (ModelPart c : children(p).values()) if (inner.add(c)) markInner(c, inner);
    }

    private static void walk(ModelPart p, String prefix, int depth, List<Node> out, Set<ModelPart> seen) {
        for (Map.Entry<String, ModelPart> e : children(p).entrySet()) {
            ModelPart c = e.getValue();
            if (!seen.add(c)) continue;
            String path = prefix.isEmpty() ? e.getKey() : prefix + "/" + e.getKey();
            out.add(new Node(path, e.getKey(), depth, c));
            walk(c, path, depth + 1, out, seen);
        }
    }
}
