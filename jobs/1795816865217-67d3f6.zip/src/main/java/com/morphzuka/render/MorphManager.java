package com.morphzuka.render;

import com.morphzuka.model.ModelManager;
import com.morphzuka.net.ClientNet;
import com.morphzuka.net.Payloads;
import com.morphzuka.net.Payloads.MorphPayload;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import io.netty.buffer.Unpooled;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * Morpher: conviertete en cualquier entidad (vanilla o de mod), bloque u otro jugador.
 * Lo que elijas se manda al servidor (si tiene el mod), que lo valida y lo retransmite: los demas jugadores con el mod
 * te ven con esa forma. Sin el mod en el servidor solo lo ves tu.
 */
public final class MorphManager {
    private MorphManager() {}

    public enum Kind { ENTITY, BLOCK, PLAYER }

    public static final class State {
        public Kind kind;
        public Identifier id;
        public String name = "";
        public BlockState block;
        public Entity entity;
        public float w = 0.6f, h = 1.8f, eye = 1.62f;
        /** Datos sincronizados de la entidad copiada (especie, variante, color...). null = entidad generica. */
        public byte[] data;
    }

    private static State self;
    public static boolean copyHitbox = true;

    public static boolean active() { return self != null; }

    /** Forma actual de ese jugador (la tuya o la que dijo el servidor), o null si va con su aspecto normal. */
    public static State stateOf(AbstractClientPlayerEntity p) {
        return p == MinecraftClient.getInstance().player ? self : remote(p.getUuid());
    }
    public static State state() { return self; }

    public static String key() { return self == null ? null : keyOf(self); }

    private static String keyOf(State s) {
        return s.kind + ":" + (s.kind == Kind.PLAYER ? s.name : String.valueOf(s.id));
    }

    /** Hay alguna forma (la tuya o la de otro jugador) con entidad propia que dibujar. */
    public static boolean hasMorphEntities() { return self != null || !REMOTE_BUILT.isEmpty(); }

    /** Clave de ajustes ({@link EntityCfg}) de la forma a la que pertenece esa entidad, o null si no es de un morph. */
    public static String keyOfEntity(Entity e) {
        State s = self;
        if (s != null && s.entity == e) return keyOf(s);
        for (State r : REMOTE_BUILT.values()) if (r.entity == e) return keyOf(r);
        return null;
    }

    /** Morphs de otros jugadores (lo que dijo el servidor) y su entidad ya construida para dibujarla. */
    private static final Map<UUID, MorphPayload> REMOTE_REQ = new HashMap<>();
    private static final Map<UUID, State> REMOTE_BUILT = new HashMap<>();

    public static void clear() { self = null; publish(); }

    /** Avisa al servidor de la forma actual (o de que volviste a la normal). No hace nada si el servidor no tiene el mod. */
    private static void publish() {
        State s = self;
        if (s == null) ClientNet.sendMorph(Payloads.KIND_NONE, "", null);
        else ClientNet.sendMorph(kindByte(s.kind), s.kind == Kind.PLAYER ? s.name : String.valueOf(s.id), s.data);
    }

    /** Al entrar a un servidor: volver a decir quien eres. */
    public static void republish() { if (self != null) publish(); }

    private static byte kindByte(Kind k) {
        return switch (k) { case ENTITY -> Payloads.KIND_ENTITY; case BLOCK -> Payloads.KIND_BLOCK; case PLAYER -> Payloads.KIND_PLAYER; };
    }

    /** Respuesta del servidor. Para otros jugadores guarda su forma; para ti solo vale si el servidor la RECHAZO. */
    public static void setRemote(MorphPayload p) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && mc.player.getUuid().equals(p.who())) {
            if (p.kind() == Payloads.KIND_NONE && self != null) {
                self = null;   // el servidor no permite morph: vuelves a la forma normal (sin volver a avisar)
                mc.player.sendMessage(Text.literal("El servidor no permite transformarse"), true);
            }
            return;
        }
        REMOTE_BUILT.remove(p.who());
        if (p.kind() == Payloads.KIND_NONE) REMOTE_REQ.remove(p.who());
        else REMOTE_REQ.put(p.who(), p);
    }

    public static void clearRemotes() { REMOTE_REQ.clear(); REMOTE_BUILT.clear(); }

    private static State remote(UUID u) {
        MorphPayload r = REMOTE_REQ.get(u);
        if (r == null) return null;
        State s = REMOTE_BUILT.get(u);
        if (s == null) {
            s = buildRemote(r);
            if (s == null) { REMOTE_REQ.remove(u); return null; }
            REMOTE_BUILT.put(u, s);
        }
        return s;
    }

    private static State buildRemote(MorphPayload r) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return null;
        try {
            switch (r.kind()) {
                case Payloads.KIND_ENTITY: {
                    Identifier id = Identifier.tryParse(r.id());
                    EntityType<?> t = id == null ? null : Registries.ENTITY_TYPE.getOrEmpty(id).orElse(null);
                    if (t == null || t == EntityType.PLAYER) return null;
                    State st = entityState(mc, t, id);
                    if (st != null && r.data().length > 0) { applyData(st.entity, r.data()); refreshDims(st, st.entity); st.data = r.data(); }
                    return st;
                }
                case Payloads.KIND_BLOCK: {
                    Identifier id = Identifier.tryParse(r.id());
                    var b = id == null ? null : Registries.BLOCK.getOrEmpty(id).orElse(null);
                    return b == null ? null : blockState(b.getDefaultState());
                }
                case Payloads.KIND_PLAYER: {
                    PlayerListEntry le = mc.getNetworkHandler() == null ? null : mc.getNetworkHandler().getPlayerListEntry(r.id());
                    return le == null ? null : playerState(mc, le);
                }
                default: return null;
            }
        } catch (Throwable t) {
            ModelManager.LOG.warn("No se pudo construir el morph remoto {}: {}", r.id(), t.toString());
            return null;
        }
    }

    private static State entityState(MinecraftClient mc, EntityType<?> t, Identifier id) {
        Entity e = t.create(mc.world);
        if (e == null) return null;
        State s = new State();
        s.kind = Kind.ENTITY;
        s.id = id;
        s.entity = e;
        EntityDimensions d = t.getDimensions();
        s.w = d.width();
        s.h = d.height();
        s.eye = d.eyeHeight();
        return s;
    }

    private static final int MAX_DATA = Payloads.MAX_MORPH_DATA;

    /** Tamano segun la propia entidad: depende de la especie / tamano / bebe, no solo del tipo. */
    private static void refreshDims(State s, Entity src) {
        try {
            EntityDimensions d = src.getDimensions(EntityPose.STANDING);
            s.w = d.width(); s.h = d.height(); s.eye = d.eyeHeight();
        } catch (Throwable ignored) {}
    }

    /**
     * Copia los datos sincronizados de la entidad (los mismos que el servidor le manda al cliente), salvo los comunes de
     * Entity (invisible, en llamas, pose...) para no heredar estados del bicho. Funciona con cualquier mod, p. ej. Cobblemon
     * guarda ahi la especie y los aspectos del Pokemon.
     */
    private static byte[] captureData(Entity e) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            List<DataTracker.SerializedEntry<?>> list = e.getDataTracker().getChangedEntries();
            if (mc.world == null || list == null || list.isEmpty()) return null;
            RegistryByteBuf buf = new RegistryByteBuf(Unpooled.buffer(), mc.world.getRegistryManager());
            for (DataTracker.SerializedEntry<?> en : list) if (en.id() >= 8) en.write(buf);
            buf.writeByte(255);
            if (buf.readableBytes() > MAX_DATA) return null;   // demasiado grande para mandarlo: se queda como entidad generica
            byte[] out = new byte[buf.readableBytes()];
            buf.readBytes(out);
            return out;
        } catch (Throwable t) {
            ModelManager.LOG.warn("No se pudieron leer los datos de la entidad: {}", t.toString());
            return null;
        }
    }

    private static void applyData(Entity e, byte[] data) {
        MinecraftClient mc = MinecraftClient.getInstance();
        RegistryByteBuf buf = new RegistryByteBuf(Unpooled.wrappedBuffer(data), mc.world.getRegistryManager());
        List<DataTracker.SerializedEntry<?>> list = new ArrayList<>();
        int i;
        while ((i = buf.readUnsignedByte()) != 255) list.add(DataTracker.SerializedEntry.fromBuf(buf, i));
        e.getDataTracker().writeUpdatedEntries(list);   // igual que al recibir un EntityTrackerUpdate: dispara onTrackedDataSet
    }

    private static State blockState(BlockState st) {
        State s = new State();
        s.kind = Kind.BLOCK;
        s.id = Registries.BLOCK.getId(st.getBlock());
        s.block = st;
        s.w = 0.98f;
        s.h = 0.98f;
        s.eye = 0.5f;
        return s;
    }

    private static State playerState(MinecraftClient mc, PlayerListEntry le) {
        State s = new State();
        s.kind = Kind.PLAYER;
        s.name = le.getProfile().getName();
        s.entity = new OtherClientPlayerEntity(mc.world, le.getProfile());
        return s;
    }

    /** @return mensaje de error, o null si salio bien */
    public static String morphEntity(Identifier id) { return morphEntity(id, null); }

    /** Con 'template' (una entidad real del mundo) copia tambien sus datos: asi un Pokemon de Cobblemon sale con su especie. */
    public static String morphEntity(Identifier id, Entity template) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return "No estás en un mundo";
        EntityType<?> t = Registries.ENTITY_TYPE.getOrEmpty(id).orElse(null);
        if (t == null) return "Entidad desconocida: " + id;
        if (t == EntityType.PLAYER) return "Para copiar a un jugador usa la pestaña Jugador";
        State s;
        try { s = entityState(mc, t, id); } catch (Throwable ex) { return "No se pudo crear: " + ex.getMessage(); }
        if (s == null) return "Esa entidad no se puede crear en cliente";
        if (template != null) {
            byte[] d = captureData(template);
            if (d != null) {
                try { applyData(s.entity, d); s.data = d; }
                catch (Throwable ex) { ModelManager.LOG.warn("No se pudieron copiar los datos de {}: {}", id, ex.toString()); }
            }
            refreshDims(s, template);
        }
        self = s;
        publish();
        return null;
    }

    public static String morphBlock(BlockState st) {
        self = blockState(st);
        publish();
        return null;
    }

    public static String morphBlock(Identifier id) {
        var b = Registries.BLOCK.getOrEmpty(id).orElse(null);
        if (b == null) return "Bloque desconocido: " + id;
        return morphBlock(b.getDefaultState());
    }

    public static String morphPlayer(String name) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.getNetworkHandler() == null) return "No estás en un mundo";
        PlayerListEntry le = mc.getNetworkHandler().getPlayerListEntry(name);
        if (le == null) return "Jugador no encontrado: " + name;
        self = playerState(mc, le);
        publish();
        return null;
    }

    /** Te conviertes en la entidad o jugador indicado (lo usa la Morpher Gun). */
    public static void copyEntity(MinecraftClient mc, Entity e) {
        if (mc.player == null || mc.world == null) return;
        String err, what;
        if (e instanceof PlayerEntity pe) { err = morphPlayer(pe.getGameProfile().getName()); what = pe.getGameProfile().getName(); }
        else { err = morphEntity(Registries.ENTITY_TYPE.getId(e.getType()), e); what = e.getType().getName().getString(); }
        mc.player.sendMessage(Text.literal(err != null ? "Morph: " + err : "Ahora eres: " + what), true);
    }

    /** Te conviertes en el bloque de esa posicion (lo usa la Morpher Gun). */
    public static void copyBlock(MinecraftClient mc, BlockPos pos) {
        if (mc.player == null || mc.world == null) return;
        BlockState st = mc.world.getBlockState(pos);
        if (st.isAir()) { mc.player.sendMessage(Text.literal("Morph: ahí no hay nada"), true); return; }
        String err = morphBlock(st);
        mc.player.sendMessage(Text.literal(err != null ? "Morph: " + err : "Ahora eres: " + st.getBlock().getName().getString()), true);
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null) return;
        State s = self;
        if (s != null) tickLimbs(s, mc.player);
        if (mc.world == null) return;
        for (Map.Entry<UUID, State> e : REMOTE_BUILT.entrySet()) {
            PlayerEntity p = mc.world.getPlayerByUuid(e.getKey());
            if (p != null) tickLimbs(e.getValue(), p);
        }
    }

    private static void tickLimbs(State s, PlayerEntity p) {
        if (com.morphzuka.ui.MorphPreview.simWalk) return;   // la vista previa mueve las patas mientras prueba "Caminar"
        if (s.entity instanceof LivingEntity le) {
            double dx = p.getX() - p.prevX, dz = p.getZ() - p.prevZ;
            float f = Math.min((float) Math.sqrt(dx * dx + dz * dz) * 4f, 1f);
            le.limbAnimator.updateLimbs(f, 0.4f);
        }
    }

    /** {ancho, alto, altura de ojos} copiados del morph, o null si no aplica. */
    public static float[] hitbox() {
        State s = self;
        if (s == null || !copyHitbox) return null;
        return new float[]{s.w, s.h, s.eye};
    }

    private static void sync(Entity e, AbstractClientPlayerEntity p) {
        e.setPosition(p.getX(), p.getY(), p.getZ());
        e.prevX = p.prevX; e.prevY = p.prevY; e.prevZ = p.prevZ;
        e.setYaw(p.getYaw());
        e.prevYaw = p.prevYaw;
        e.setPitch(p.getPitch());
        e.prevPitch = p.prevPitch;
        e.age = p.age;
        e.setOnGround(p.isOnGround());
        if (e instanceof LivingEntity le) {
            le.bodyYaw = p.bodyYaw;
            le.prevBodyYaw = p.prevBodyYaw;
            le.headYaw = p.headYaw;
            le.prevHeadYaw = p.prevHeadYaw;
            le.handSwingProgress = p.handSwingProgress;
            le.lastHandSwingProgress = p.lastHandSwingProgress;
        }
        if (e instanceof PlayerEntity pe) {
            pe.setPose(p.getPose());
            pe.setSneaking(p.isSneaking());
            pe.setSprinting(p.isSprinting());
        }
    }

    /** Dibuja el morph en lugar del jugador. Devuelve true si se encargo del render. */
    public static boolean render(AbstractClientPlayerEntity p, float yaw, float td, MatrixStack m, VertexConsumerProvider vcp, int light) {
        MinecraftClient mc = MinecraftClient.getInstance();
        State s = p == mc.player ? self : remote(p.getUuid());
        if (s == null) return false;
        float sc = Transition.scale(p.getUuid());
        m.push();
        try {
            m.scale(sc, sc, sc);
            if (s.kind == Kind.BLOCK) {
                m.translate(-0.5, 0, -0.5);
                mc.getBlockRenderManager().renderBlockAsEntity(s.block, m, vcp, light, OverlayTexture.DEFAULT_UV);
            } else {
                sync(s.entity, p);
                mc.getEntityRenderDispatcher().render(s.entity, 0, 0, 0, yaw, td, m, vcp, light);
            }
            return true;
        } catch (Throwable t) {
            ModelManager.LOG.warn("Morph fallo, se desactiva: {}", t.toString());
            if (p == mc.player) clear(); else { REMOTE_REQ.remove(p.getUuid()); REMOTE_BUILT.remove(p.getUuid()); }
            return false;
        } finally {
            m.pop();
        }
    }

    public static List<Identifier> search(Kind kind, String q, int max) {
        String s = q == null ? "" : q.trim().toLowerCase(Locale.ROOT);
        List<Identifier> out = new ArrayList<>();
        Iterable<Identifier> ids = kind == Kind.BLOCK ? Registries.BLOCK.getIds() : Registries.ENTITY_TYPE.getIds();
        for (Identifier id : ids) {
            if (kind == Kind.ENTITY && id.equals(Registries.ENTITY_TYPE.getId(EntityType.PLAYER))) continue;
            if (s.isEmpty() || id.toString().contains(s)) out.add(id);
        }
        out.sort(Identifier::compareTo);
        return out.size() > max ? out.subList(0, max) : out;
    }
}
