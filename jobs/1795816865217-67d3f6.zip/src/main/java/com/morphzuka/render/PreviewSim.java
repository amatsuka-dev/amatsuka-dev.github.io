package com.morphzuka.render;

import net.minecraft.util.Util;

/**
 * Simulacion para la vista previa del editor: un golpe con el brazo cada ~1,1 s y la cabeza mirando de un lado a otro,
 * como si el jugador atacara y moviera la camara. No toca al jugador real, solo alimenta {@link BBRenderer#renderPreview}.
 */
public final class PreviewSim {
    private PreviewSim() {}

    public static boolean active;
    private static long t0;

    public static void start() { active = true; t0 = Util.getMeasuringTimeMs(); }

    public static void stop() { active = false; }

    public static void toggle() { if (active) stop(); else start(); }

    public static float time() { return (Util.getMeasuringTimeMs() - t0) / 1000f; }

    /** Progreso del golpe 0..1 (como getHandSwingProgress): 0,35 s de golpe y una pausa. */
    public static float swing() {
        float p = (time() % 1.1f) / 0.35f;
        return p >= 1f ? 0f : p;
    }

    /** Giro de la cabeza respecto al cuerpo, en grados. */
    public static float headDelta() { return 45f * (float) Math.sin(time() * 1.4f); }

    /** Cabeceo en grados (positivo = mirar abajo). */
    public static float pitch() { return 18f * (float) Math.sin(time() * 0.9f); }
}
