package com.morphzuka.render;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * Efecto "Cube form" (v2, con texturas).
 *
 *  1. Tu forma anterior (skin vanilla, modelo, bloque o entidad) se convierte en cientos de cubos pequenos pegados a su
 *     superficie, cada uno con el trocito de textura que le toca ahi.
 *  2. Los cubos salen volando (los de arriba primero), dan una vuelta y se colocan sobre la superficie de la forma nueva,
 *     asi la silueta nueva aparece hecha de cubos.
 *  3. Ya colocados, cada cubo va cambiando poco a poco su textura a la de la forma nueva.
 *  4. La forma real aparece con rebote (Transition.scale) y los cubos se encogen dentro de ella.
 *
 * Todo se calcula con el reloj a partir de (quien, forma vieja, forma nueva, semilla): sin entidades ni estado de servidor.
 * Cada cubo se dibuja con vertices propios (dos pasadas: textura vieja opaca, textura nueva encima con transparencia).
 */
public final class CubeSwarm {
    private CubeSwarm() {}

    /** Cubos que se intentan repartir por la superficie, y tope duro. */
    private static final int TARGET = 260, MAX_CUBES = 420;

    // linea de tiempo (ms)
    private static final float HOLD = 240f;       // quietos sobre la forma vieja
    private static final float SPREAD = 300f;     // los cubos despegan escalonados dentro de este margen
    private static final float FLY = 680f;        // duracion del vuelo de cada cubo
    private static final float BLEND = 340f;      // cambio de textura vieja -> nueva, una vez colocado
    /** La forma real esta oculta hasta aqui; entonces aparece con rebote y los cubos se encogen. */
    public static final float HIDE_MS = 1450f;
    private static final float SHRINK = 320f;
    private static final float TOTAL_MS = HIDE_MS + SHRINK + 40f;
    private static final int MAX_SWARMS = 12;

    private static final int LIGHT = 15728880;

    private static final class Cube {
        float sx, sy, sz;          // inicio (marco del modelo viejo)
        float cx, cy, cz;          // punto de control de la curva
        float tx, ty, tz;          // destino (marco del modelo nuevo)
        float delay;               // despegue (ms desde que acaba HOLD)
        float sizeA, sizeB;
        float spin;                // grados de giro maximo durante el vuelo
        float phase;
        float[] oldUv = new float[4], newUv = new float[4];
        int oldTint = 0xFFFFFF, newTint = 0xFFFFFF;
    }

    private static final class Swarm {
        final UUID who;
        final long start = Util.getMeasuringTimeMs();
        Cube[] cubes;
        Identifier texOld, texNew;
        boolean worldOld, worldNew;    // marco fijo al mundo (bloques) en vez de girar con el cuerpo
        double ox, oy, oz;
        boolean havePos;
        Swarm(UUID who) { this.who = who; }
    }

    private static final List<Swarm> ACTIVE = new ArrayList<>();

    public static void clear() { ACTIVE.clear(); TexPixels.clear(); }

    /** Version sin formas conocidas (paquete de un servidor/cliente antiguo): cajas de colores con las medidas dadas. */
    public static void spawn(UUID who, float ow, float oh, float nw, float nh, int blockId, long seed) {
        Form[] f = Forms.pair(who, ow, oh, nw, nh, blockId);
        spawn(who, f[0], f[1], seed);
    }

    public static void spawn(UUID who, Form from, Form to, long seed) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || from == null || to == null) return;
        ACTIVE.removeIf(s -> s.who.equals(who));
        if (ACTIVE.size() >= MAX_SWARMS) ACTIVE.remove(0);
        try {
            Swarm sw = build(who, from, to, seed);
            if (sw == null) return;
            PlayerEntity p = mc.world.getPlayerByUuid(who);
            if (p != null) { sw.ox = p.getX(); sw.oy = p.getY(); sw.oz = p.getZ(); sw.havePos = true; }
            ACTIVE.add(sw);
        } catch (Throwable t) {
            com.morphzuka.model.ModelManager.LOG.warn("Efecto de cubos: fallo al crear el enjambre: {}", t.toString());
        }
    }

    private static Swarm build(UUID who, Form from, Form to, long seed) {
        Random r = new Random(seed);
        Surface so = Surface.of(from), sn = Surface.of(to);
        float sA = so.cubeSize(TARGET, MAX_CUBES), sB = sn.cubeSize(TARGET, MAX_CUBES);
        List<Surface.Pt> a = so.scatter(sA, r), b = sn.scatter(sB, r);
        if (a.isEmpty() || b.isEmpty()) return null;
        a.sort((p, q) -> Float.compare(p.key, q.key));   // misma altura y mismo angulo -> la cabeza va a la cabeza
        b.sort((p, q) -> Float.compare(p.key, q.key));

        int m = Math.min(MAX_CUBES, Math.max(a.size(), b.size()));
        float fa = Math.max(0.55f, (float) Math.sqrt(a.size() / (float) m)), fb = Math.max(0.55f, (float) Math.sqrt(b.size() / (float) m));
        float reach = Math.max(0.6f, Math.max(from.w, to.w) * 0.9f);
        float hOld = Math.max(0.2f, so.maxY - so.minY);

        Swarm s = new Swarm(who);
        s.texOld = so.tex;
        s.texNew = sn.tex;
        s.worldOld = from.type == Form.Type.BLOCK;
        s.worldNew = to.type == Form.Type.BLOCK;
        s.cubes = new Cube[m];
        for (int i = 0; i < m; i++) {
            Surface.Pt pa = a.get((int) ((long) i * a.size() / m)), pb = b.get((int) ((long) i * b.size() / m));
            Cube c = new Cube();
            float jit = m > a.size() ? 0.5f * sA : 0f;   // si hay mas cubos que puntos de inicio, se esparcen un poco
            c.sx = pa.x + pa.nx * jit * r.nextFloat(); c.sy = pa.y + pa.ny * jit * r.nextFloat(); c.sz = pa.z + pa.nz * jit * r.nextFloat();
            c.tx = pb.x; c.ty = pb.y; c.tz = pb.z;
            // control: hacia fuera de la superficie vieja, con un poco de remolino y hacia arriba
            float push = (0.35f + r.nextFloat() * 0.9f) * reach;
            float sw = (r.nextFloat() - 0.5f) * reach;
            c.cx = c.sx + pa.nx * push - pa.nz * sw;
            c.cy = c.sy + pa.ny * push + 0.3f + r.nextFloat() * 0.9f;
            c.cz = c.sz + pa.nz * push + pa.nx * sw;
            float yn = MathHelper.clamp((pa.y - so.minY) / hOld, 0f, 1f);
            c.delay = (1f - yn) * SPREAD * 0.8f + r.nextFloat() * SPREAD * 0.2f;   // los de arriba primero
            c.sizeA = sA * fa * 1.08f;
            c.sizeB = sB * fb * 1.1f;
            c.spin = (180f + r.nextFloat() * 360f) * (r.nextBoolean() ? 1 : -1);
            c.phase = r.nextFloat() * 6.2832f;
            c.oldUv[0] = pa.u1; c.oldUv[1] = pa.v1; c.oldUv[2] = pa.u2; c.oldUv[3] = pa.v2;
            c.newUv[0] = pb.u1; c.newUv[1] = pb.v1; c.newUv[2] = pb.u2; c.newUv[3] = pb.v2;
            c.oldTint = pa.tint;
            c.newTint = pb.tint;
            s.cubes[i] = c;
        }
        return s;
    }

    // ================================================================ dibujo

    /** Se engancha a WorldRenderEvents.AFTER_ENTITIES. */
    public static void render(WorldRenderContext ctx) {
        if (ACTIVE.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientWorld w = mc.world;
        VertexConsumerProvider vcp = ctx.consumers();
        MatrixStack m = ctx.matrixStack();
        if (w == null || vcp == null || m == null) { if (w == null) ACTIVE.clear(); return; }

        Vec3d cam = ctx.camera().getPos();
        float td = mc.getRenderTickCounter().getTickDelta(false);
        long now = Util.getMeasuringTimeMs();

        Iterator<Swarm> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Swarm s = it.next();
            float age = now - s.start;
            if (age > TOTAL_MS) { it.remove(); continue; }
            float yaw = 0f;
            PlayerEntity p = w.getPlayerByUuid(s.who);
            if (p != null) {   // el enjambre acompana a quien se transforma
                s.ox = MathHelper.lerp(td, p.prevX, p.getX());
                s.oy = MathHelper.lerp(td, p.prevY, p.getY());
                s.oz = MathHelper.lerp(td, p.prevZ, p.getZ());
                s.havePos = true;
                yaw = 180f - MathHelper.lerpAngleDegrees(td, p.prevBodyYaw, p.bodyYaw);
            }
            if (!s.havePos) { it.remove(); continue; }
            try {
                drawSwarm(s, age, yaw, m, vcp, cam);
            } catch (Throwable t) {
                com.morphzuka.model.ModelManager.LOG.warn("Efecto de cubos: fallo al dibujar, se cancela: {}", t.toString());
                it.remove();
            }
        }
    }

    private static float smooth(float u) { u = MathHelper.clamp(u, 0f, 1f); return u * u * (3f - 2f * u); }

    private static void drawSwarm(Swarm s, float age, float yaw, MatrixStack m, VertexConsumerProvider vcp, Vec3d cam) {
        float yawO = s.worldOld ? 0f : yaw, yawN = s.worldNew ? 0f : yaw;
        float cO = MathHelper.cos(yawO * 0.017453292f), sO = MathHelper.sin(yawO * 0.017453292f);
        float cN = MathHelper.cos(yawN * 0.017453292f), sN = MathHelper.sin(yawN * 0.017453292f);
        float shrink = 1f - smooth((age - HIDE_MS) / SHRINK);   // al final los cubos se encogen dentro de la forma real
        if (shrink <= 0f) return;

        // pasada 1: textura vieja (opaca) - pasada 2: textura nueva por encima (translucida, con el avance del cambio)
        for (int pass = 0; pass < 2; pass++) {
            Identifier tex = pass == 0 ? s.texOld : s.texNew;
            RenderLayer layer = pass == 0 ? RenderLayer.getEntityCutoutNoCull(tex) : RenderLayer.getEntityTranslucent(tex);
            VertexConsumer vc = null;
            for (Cube c : s.cubes) {
                float t = age - HOLD - c.delay;
                float u = MathHelper.clamp(t / FLY, 0f, 1f);
                float e = smooth(u);
                float blend = smooth((t - FLY) / BLEND);
                if (pass == 0 && blend >= 1f) continue;
                if (pass == 1 && blend <= 0.01f) continue;

                float x, y, z, size, rotY, rotX;
                if (age < HOLD || t <= 0f) {
                    // quieto sobre la forma vieja, con un pequeno temblor y creciendo al aparecer
                    float k = MathHelper.clamp(age / 140f, 0f, 1f);
                    float tr = age < HOLD ? 0.012f * (age / HOLD) : 0.012f;
                    float jx = MathHelper.sin(age * 0.05f + c.phase) * tr, jz = MathHelper.cos(age * 0.045f + c.phase * 1.7f) * tr;
                    x = rx(c.sx, c.sz, cO, sO) + jx; y = c.sy + MathHelper.sin(age * 0.06f + c.phase * 2f) * tr; z = rz(c.sx, c.sz, cO, sO) + jz;
                    size = c.sizeA * (0.3f + 0.7f * k);
                    rotY = yawO; rotX = 0f;
                } else {
                    float a1 = 1f - e, b1 = 2f * e * a1, c1 = e * e;       // curva de Bezier cuadratica inicio -> control -> fin
                    x = a1 * rx(c.sx, c.sz, cO, sO) + b1 * rx(c.cx, c.cz, cO, sO) + c1 * rx(c.tx, c.tz, cN, sN);
                    y = a1 * c.sy + b1 * c.cy + c1 * c.ty;
                    z = a1 * rz(c.sx, c.sz, cO, sO) + b1 * rz(c.cx, c.cz, cO, sO) + c1 * rz(c.tx, c.tz, cN, sN);
                    size = MathHelper.lerp(e, c.sizeA, c.sizeB);
                    float tumble = c.spin * e * (1f - e) * 4f;            // da una vuelta en el aire y termina alineado
                    rotY = MathHelper.lerp(e, yawO, yawN) + tumble;
                    rotX = tumble * 0.6f;
                }
                size *= shrink;
                if (size < 0.008f) continue;
                if (vc == null) vc = vcp.getBuffer(layer);

                float[] uv = pass == 0 ? c.oldUv : c.newUv;
                int tint = pass == 0 ? c.oldTint : c.newTint;
                int alpha = pass == 0 ? 255 : (int) (255f * blend);
                float grow = pass == 0 ? 1f : 1.02f;   // la capa nueva un pelin mas grande para no pelear con la vieja

                m.push();
                m.translate(s.ox + x - cam.x, s.oy + y - cam.y, s.oz + z - cam.z);
                m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(rotY));
                if (rotX != 0f) m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rotX));
                m.scale(size * grow, size * grow, size * grow);
                cube(vc, m.peek(), uv, tint, alpha);
                m.pop();
            }
        }
    }

    /** Rota (x, z) alrededor de Y con el coseno/seno ya calculados (mismo sentido que RotationAxis.POSITIVE_Y). */
    private static float rx(float x, float z, float c, float s) { return x * c + z * s; }

    private static float rz(float x, float z, float c, float s) { return -x * s + z * c; }

    /** Cubo de lado 1 centrado en el origen; las 6 caras llevan el mismo parche de textura. */
    private static void cube(VertexConsumer vc, MatrixStack.Entry e, float[] uv, int tint, int alpha) {
        Matrix4f mat = e.getPositionMatrix();
        int r = (tint >> 16) & 255, g = (tint >> 8) & 255, b = tint & 255;
        float h = 0.5f, u1 = uv[0], v1 = uv[1], u2 = uv[2], v2 = uv[3];
        // norte (-Z), sur (+Z), este (+X), oeste (-X), arriba (+Y), abajo (-Y); mismo orden de vertices que BBRenderer
        q(vc, e, mat, r, g, b, alpha, u1, v1, u2, v2,  h,  h, -h, -h,  h, -h, -h, -h, -h,  h, -h, -h,  0,  0, -1);
        q(vc, e, mat, r, g, b, alpha, u1, v1, u2, v2, -h,  h,  h,  h,  h,  h,  h, -h,  h, -h, -h,  h,  0,  0,  1);
        q(vc, e, mat, r, g, b, alpha, u1, v1, u2, v2,  h,  h,  h,  h,  h, -h,  h, -h, -h,  h, -h,  h,  1,  0,  0);
        q(vc, e, mat, r, g, b, alpha, u1, v1, u2, v2, -h,  h, -h, -h,  h,  h, -h, -h,  h, -h, -h, -h, -1,  0,  0);
        q(vc, e, mat, r, g, b, alpha, u1, v1, u2, v2, -h,  h, -h,  h,  h, -h,  h,  h,  h, -h,  h,  h,  0,  1,  0);
        q(vc, e, mat, r, g, b, alpha, u1, v1, u2, v2, -h, -h,  h,  h, -h,  h,  h, -h, -h, -h, -h, -h,  0, -1,  0);
    }

    private static void q(VertexConsumer vc, MatrixStack.Entry e, Matrix4f mat, int r, int g, int b, int a,
                          float u1, float v1, float u2, float v2,
                          float ax, float ay, float az, float bx, float by, float bz,
                          float cx, float cy, float cz, float dx, float dy, float dz,
                          float nx, float ny, float nz) {
        vc.vertex(mat, ax, ay, az).color(r, g, b, a).texture(u1, v1).overlay(OverlayTexture.DEFAULT_UV).light(LIGHT).normal(e, nx, ny, nz);
        vc.vertex(mat, bx, by, bz).color(r, g, b, a).texture(u2, v1).overlay(OverlayTexture.DEFAULT_UV).light(LIGHT).normal(e, nx, ny, nz);
        vc.vertex(mat, cx, cy, cz).color(r, g, b, a).texture(u2, v2).overlay(OverlayTexture.DEFAULT_UV).light(LIGHT).normal(e, nx, ny, nz);
        vc.vertex(mat, dx, dy, dz).color(r, g, b, a).texture(u1, v2).overlay(OverlayTexture.DEFAULT_UV).light(LIGHT).normal(e, nx, ny, nz);
    }
}
