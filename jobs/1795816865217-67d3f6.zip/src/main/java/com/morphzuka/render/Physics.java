package com.morphzuka.render;

import com.morphzuka.model.ModelManager;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Fisicas de rebote (resortes amortiguados). Cada parte marcada se mueve al reves de la aceleracion del jugador
 * (la cola se queda atras al arrancar y rebota al frenar) y el cuerpo entero hace squash/stretch al saltar y aterrizar.
 * Se activa con {@link ModelManager.Settings#physicsOn} y se regula con {@link ModelManager.Settings#physicsIntensity}.
 * Coste: unas pocas multiplicaciones por parte marcada y por frame; sin objetos nuevos en el bucle.
 */
public final class Physics {
    private Physics() {}

    /** Identificador del "jugador" imaginario del editor 3D. */
    public static final UUID PREVIEW = new UUID(0L, 0xB0B0L);

    private static final class Spring { float x, z, vx, vz; }

    private static final class State {
        final Map<String, Spring> bones = new HashMap<>();
        double px, py, pz;
        float vx, vy, vz;          // velocidad suavizada (bloques/s)
        float ax, ay, az;          // aceleracion suavizada
        float bounce, bounceV;     // squash/stretch del cuerpo
        float lastTime = Float.NaN;
        float aFwd, aSide, vFwd, vSide;   // movimiento en el eje del modelo
        long seen;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();

    private static State st(UUID id) {
        State t = STATES.computeIfAbsent(id, k -> new State());
        t.seen = System.nanoTime();
        return t;
    }

    public static void forget(UUID id) { STATES.remove(id); }

    /** Evita acumular estados de jugadores que ya no estan (se llama de vez en cuando desde update). */
    private static void prune() {
        if (STATES.size() <= 16) return;
        long now = System.nanoTime();
        STATES.values().removeIf(t -> now - t.seen > 30_000_000_000L);
    }

    /** Actualiza el movimiento del jugador (una vez por frame) y avanza los resortes de sus partes. */
    public static void update(UUID id, double x, double y, double z, float bodyYawDeg, float time, ModelManager.Settings s, Iterable<String> bones) {
        prune();
        State t = st(id);
        if (Float.isNaN(t.lastTime) || time - t.lastTime > 1f || time < t.lastTime) {   // primer frame, pausa larga o retroceso
            t.lastTime = time; t.px = x; t.py = y; t.pz = z;
            t.vx = t.vy = t.vz = t.ax = t.ay = t.az = 0f;
            return;
        }
        float dt = time - t.lastTime;
        if (dt <= 1e-4f) return;           // mismo frame (segundo render) o juego en pausa
        if (dt > 0.1f) dt = 0.1f;
        t.lastTime = time;

        float rvx = (float) ((x - t.px) / dt), rvy = (float) ((y - t.py) / dt), rvz = (float) ((z - t.pz) / dt);
        t.px = x; t.py = y; t.pz = z;
        float k = 1f - (float) Math.exp(-dt * 14f);
        float nvx = t.vx + (rvx - t.vx) * k, nvy = t.vy + (rvy - t.vy) * k, nvz = t.vz + (rvz - t.vz) * k;
        float rax = (nvx - t.vx) / dt, ray = (nvy - t.vy) / dt, raz = (nvz - t.vz) / dt;
        t.vx = nvx; t.vy = nvy; t.vz = nvz;
        float ka = 1f - (float) Math.exp(-dt * 18f);
        t.ax += (clamp(rax, 60f) - t.ax) * ka;
        t.ay += (clamp(ray, 80f) - t.ay) * ka;
        t.az += (clamp(raz, 60f) - t.az) * ka;

        double yr = Math.toRadians(bodyYawDeg);
        float sin = (float) Math.sin(yr), cos = (float) Math.cos(yr);
        // adelante del jugador = (-sin, cos); derecha del modelo (+X) = (-cos, -sin)
        t.vFwd = -t.vx * sin + t.vz * cos;
        t.vSide = -t.vx * cos - t.vz * sin;
        t.aFwd = -t.ax * sin + t.az * cos;
        t.aSide = -t.ax * cos - t.az * sin;

        step(t, s, dt, bones);
    }

    private static float clamp(float v, float m) { return Math.max(-m, Math.min(m, v)); }

    private static void step(State t, ModelManager.Settings s, float dt, Iterable<String> bones) {
        float inten = Math.max(0f, s.physicsIntensity);
        // positivo en X = parte hacia delante: al acelerar hacia delante la parte se va hacia atras (negativo)
        float tx = clamp(-(t.aFwd * 0.55f + t.vFwd * 2.2f) * inten, 70f);
        float tz = clamp(-(t.aSide * 0.55f + t.vSide * 2.2f) * inten, 70f);
        int n = Math.max(1, (int) Math.ceil(dt / (1f / 120f)));
        float h = dt / n;
        for (String b : bones) {
            Spring sp = t.bones.computeIfAbsent(b, kk -> new Spring());
            float var = 0.85f + (Math.abs(b.hashCode()) % 31) / 100f;       // cada parte con su propia frecuencia
            float w = 2f * (float) Math.PI * 3.2f * var;
            float c = 2f * 0.22f * w;
            for (int i = 0; i < n; i++) {
                sp.vx += (w * w * (tx - sp.x) - c * sp.vx) * h;
                sp.vz += (w * w * (tz - sp.z) - c * sp.vz) * h;
                sp.x += sp.vx * h;
                sp.z += sp.vz * h;
                if (sp.x > 85f) { sp.x = 85f; sp.vx = 0; } else if (sp.x < -85f) { sp.x = -85f; sp.vx = 0; }
                if (sp.z > 85f) { sp.z = 85f; sp.vz = 0; } else if (sp.z < -85f) { sp.z = -85f; sp.vz = 0; }
            }
        }
        // cuerpo: aterrizar (aceleracion vertical positiva fuerte) = aplastarse
        float bt = Math.max(-0.22f, Math.min(0.22f, -t.ay * 0.0016f * inten));
        float wb = 2f * (float) Math.PI * 4f, cb = 2f * 0.2f * wb;
        for (int i = 0; i < n; i++) {
            t.bounceV += (wb * wb * (bt - t.bounce) - cb * t.bounceV) * h;
            t.bounce += t.bounceV * h;
        }
        t.bounce = Math.max(-0.3f, Math.min(0.3f, t.bounce));
    }

    /** {rotX, rotZ} en grados para una parte, o null si no tiene estado todavia. */
    public static float[] bone(UUID id, String bone, float[] out) {
        State t = STATES.get(id);
        if (t == null) return null;
        Spring sp = t.bones.get(bone);
        if (sp == null) return null;
        out[0] = sp.x;
        out[1] = sp.z;
        return out;
    }

    /** Estiramiento vertical del cuerpo (0 = normal). */
    public static float bounce(UUID id) {
        State t = STATES.get(id);
        return t == null ? 0f : t.bounce;
    }

    /** Empujon manual: lo usa el boton "Probar rebote" del editor. */
    public static void kick(UUID id, Iterable<String> bones, float strength) {
        State t = st(id);
        for (String b : bones) {
            Spring sp = t.bones.computeIfAbsent(b, kk -> new Spring());
            sp.vx += (Math.abs(b.hashCode()) % 2 == 0 ? 1 : -1) * 520f * strength;
            sp.vz += 360f * strength;
        }
        t.bounceV -= 2.2f * strength;
    }

    /** Avanza el modelo del editor, que no tiene jugador: no hay movimiento, solo dejar que los resortes se asienten. */
    public static void stepPreview(ModelManager.Settings s, float dt, Iterable<String> bones) {
        State t = st(PREVIEW);
        t.aFwd = t.aSide = t.vFwd = t.vSide = t.ay = 0f;
        dt = Math.min(dt, 0.05f);
        if (dt <= 0f) return;
        step(t, s, dt, bones);
    }
}
