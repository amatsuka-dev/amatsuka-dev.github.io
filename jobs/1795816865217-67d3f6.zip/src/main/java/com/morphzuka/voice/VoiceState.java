package com.morphzuka.voice;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Estado de voz por jugador. Lo alimentaran las integraciones (Simple Voice Chat / Plasmo Voice) en una fase posterior. */
public final class VoiceState {
    private VoiceState() {}

    private static final Map<UUID, Long> LAST = new ConcurrentHashMap<>();
    private static final long HOLD_MS = 250;
    public static volatile boolean muted;

    public static void markSpeaking(UUID id) { if (id != null) LAST.put(id, System.currentTimeMillis()); }

    public static boolean isSpeaking(UUID id) {
        Long t = LAST.get(id);
        return t != null && System.currentTimeMillis() - t < HOLD_MS;
    }
}
