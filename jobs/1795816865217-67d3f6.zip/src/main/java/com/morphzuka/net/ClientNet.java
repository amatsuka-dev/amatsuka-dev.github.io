package com.morphzuka.net;

import com.morphzuka.HitboxOverride;
import com.morphzuka.HitboxRegistry;
import com.morphzuka.model.ModelManager;
import com.morphzuka.net.Payloads.CubeFxPayload;
import com.morphzuka.net.Payloads.HitboxPayload;
import com.morphzuka.net.Payloads.HitboxSyncPayload;
import com.morphzuka.net.Payloads.MorphPayload;
import com.morphzuka.render.CubeSwarm;
import com.morphzuka.render.MorphManager;
import com.morphzuka.render.Transition;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.CustomPayload;

/**
 * Lado cliente de la red. Si el servidor no tiene el mod, canSend() da false y todo sigue funcionando como antes
 * (solo cliente): nunca se manda un paquete que el servidor no entienda.
 */
public final class ClientNet {
    private ClientNet() {}

    public static void register() {
        ClientPlayNetworking.registerGlobalReceiver(HitboxSyncPayload.ID, (pl, ctx) -> onHitbox(pl));
        ClientPlayNetworking.registerGlobalReceiver(MorphPayload.ID, (pl, ctx) -> MorphManager.setRemote(pl));
        ClientPlayNetworking.registerGlobalReceiver(CubeFxPayload.ID, (pl, ctx) -> onFx(pl));

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            HitboxOverride.reset();       // se vuelve a mandar tu caja al servidor en el siguiente tick
            MorphManager.republish();
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            HitboxRegistry.clearClient();
            MorphManager.clearRemotes();
            CubeSwarm.clear();
            com.morphzuka.render.Forms.clear();
        });
    }

    /** El servidor tiene el mod (y por tanto valida y retransmite). */
    public static boolean serverHasMod() { return ClientPlayNetworking.canSend(HitboxPayload.ID); }

    private static void send(CustomPayload pl) {
        if (ClientPlayNetworking.canSend(pl.getId())) ClientPlayNetworking.send(pl);
    }

    /** box = {ancho, alto, ojos}; null = quitar el override. */
    public static void sendHitbox(float[] box) {
        send(box == null ? new HitboxPayload(0, 0, 0) : new HitboxPayload(box[0], box[1], box[2]));
    }

    public static void sendMorph(byte kind, String id, byte[] data) {
        send(new MorphPayload(new java.util.UUID(0, 0), kind, id, data == null ? new byte[0] : data));   // el servidor ignora 'who' y usa el remitente real
    }

    public static void sendEffect(float oldW, float oldH, float newW, float newH, int blockId, long seed) {
        send(new CubeFxPayload(new java.util.UUID(0, 0), oldW, oldH, newW, newH, blockId, seed));
    }

    // ------------------------------------------------------------------ recepcion

    private static void onHitbox(HitboxSyncPayload p) {
        HitboxRegistry.setClient(p.who(), p.w() > 0 ? new float[]{p.w(), p.h(), p.eye()} : null);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        PlayerEntity e = mc.world.getPlayerByUuid(p.who());   // si aun no esta cargado, la caja se aplica cuando aparezca
        if (e != null) e.calculateDimensions();
    }

    private static void onFx(CubeFxPayload p) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.player.getUuid().equals(p.who())) return;   // el efecto propio ya se hizo en local
        if (!ModelManager.CONFIG.cubeEffect) return;   // tu ajuste de efectos tambien vale para los de los demas
        CubeSwarm.spawn(p.who(), p.oldW(), p.oldH(), p.newW(), p.newH(), p.blockId(), p.seed());
        Transition.startFor(p.who(), CubeSwarm.HIDE_MS);   // su forma real aparece cuando los cubos la han armado
    }
}
