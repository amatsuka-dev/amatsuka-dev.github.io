package com.morphzuka;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Reglas del servidor (config/morphzuka-server.json). En un mundo propio tambien se aplican, asi pruebas lo mismo
 * que vera un servidor real.
 */
public final class MzServerConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static MzServerConfig INSTANCE = new MzServerConfig();

    /** Los jugadores pueden tener una hitbox distinta (modelo / morph). */
    public boolean allowHitbox = true;
    /** Los jugadores pueden transformarse y los demas lo ven. */
    public boolean allowMorph = true;
    /** Se retransmite el efecto de cubos a los demas. */
    public boolean allowEffects = true;
    /** Si es true, solo los operadores pueden usar hitbox y morph. */
    public boolean opsOnly = false;
    /** Limites de la caja que se acepta (bloques). Evita cajas de 0 o gigantes. */
    public float minSize = 0.1f;
    public float maxWidth = 4f;
    public float maxHeight = 8f;

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("morphzuka-server.json"); }

    public static void load() {
        Path f = file();
        try {
            if (Files.exists(f)) {
                MzServerConfig c = GSON.fromJson(Files.readString(f), MzServerConfig.class);
                if (c != null) INSTANCE = c;
            }
            sanitize(INSTANCE);
            Files.writeString(f, GSON.toJson(INSTANCE));   // reescribe para que aparezcan los campos nuevos
        } catch (Exception e) {
            MorphZuka.LOG.warn("No se pudo leer {}: {}", f, e.toString());
        }
    }

    private static void sanitize(MzServerConfig c) {
        c.minSize = clamp(c.minSize, 0.01f, 1f);
        c.maxWidth = clamp(c.maxWidth, c.minSize, 64f);
        c.maxHeight = clamp(c.maxHeight, c.minSize, 64f);
    }

    private static float clamp(float v, float lo, float hi) { return Float.isNaN(v) ? lo : Math.max(lo, Math.min(hi, v)); }

    /** {ancho, alto, ojos} dentro de los limites, o null si los numeros no sirven. */
    public float[] clampBox(float w, float h, float eye) {
        if (!Float.isFinite(w) || !Float.isFinite(h) || !Float.isFinite(eye)) return null;
        w = clamp(w, minSize, maxWidth);
        h = clamp(h, minSize, maxHeight);
        eye = clamp(eye, 0.05f, h);
        return new float[]{w, h, eye};
    }
}
