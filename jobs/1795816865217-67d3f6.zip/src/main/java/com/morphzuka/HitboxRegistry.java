package com.morphzuka;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;

/**
 * Cajas de colision personalizadas por jugador ({ancho, alto, altura de ojos}). Clase comun: la leen el mixin de
 * dimensiones y los paquetes, tanto en cliente como en servidor.
 *
 * Hay dos mapas porque en un mundo propio cliente y servidor integrado comparten JVM:
 *  - SERVER: lo que el servidor acepto de cada jugador (ya validado). Lo usa el ServerPlayerEntity.
 *  - CLIENT: lo que ve el cliente (la caja propia que se predice y las que el servidor sincroniza de los demas).
 */
public final class HitboxRegistry {
    private HitboxRegistry() {}

    private static final Map<UUID, float[]> SERVER = new ConcurrentHashMap<>();
    private static final Map<UUID, float[]> CLIENT = new ConcurrentHashMap<>();

    /** Solo cliente: caja calculada localmente para jugadores sin dato del servidor (modelo asignado a mano a otro jugador, etc.). */
    public static volatile Function<PlayerEntity, float[]> clientProvider;

    public static float[] get(PlayerEntity p) {
        World w = p.getWorld();
        if (w == null) return null;
        UUID u = p.getUuid();
        if (!w.isClient) return SERVER.get(u);
        float[] a = CLIENT.get(u);
        if (a != null) return a;
        Function<PlayerEntity, float[]> f = clientProvider;
        return f == null ? null : f.apply(p);
    }

    public static void setServer(UUID u, float[] box) { if (box == null) SERVER.remove(u); else SERVER.put(u, box); }
    public static float[] getServer(UUID u) { return SERVER.get(u); }
    public static Map<UUID, float[]> allServer() { return SERVER; }

    public static void setClient(UUID u, float[] box) { if (box == null) CLIENT.remove(u); else CLIENT.put(u, box); }
    public static void clearClient() { CLIENT.clear(); }
}
