package com.morphzuka.model;

import org.joml.Matrix4f;

/**
 * Transformacion de UN bloque dentro de su grupo: la rotacion del archivo mas lo que se edito por bloque
 * (desplazamiento, rotacion extra, escala y pivote propio). La usan el renderer, el calculo de la caja y el efecto de cubos,
 * asi los tres ven exactamente la misma forma.
 */
public final class CubeXform {
    private CubeXform() {}

    private static boolean nz(float[] a) { return a[0] != 0f || a[1] != 0f || a[2] != 0f; }

    /** Pivote efectivo: el elegido, o el del archivo; si el bloque no tiene ni rotacion ni origen, su centro. */
    public static void pivotInto(BBModel.Cube cu, ModelManager.Settings s, float[] out) {
        float[] pv = s.cubePivots.isEmpty() ? null : s.cubePivots.get(cu.key);
        if (pv == null) {
            if (!nz(cu.rot) && !nz(cu.origin)) {
                out[0] = (cu.from[0] + cu.to[0]) * 0.5f; out[1] = (cu.from[1] + cu.to[1]) * 0.5f; out[2] = (cu.from[2] + cu.to[2]) * 0.5f;
            } else { out[0] = cu.origin[0]; out[1] = cu.origin[1]; out[2] = cu.origin[2]; }
        } else { out[0] = pv[0]; out[1] = pv[1]; out[2] = pv[2]; }
    }

    /** true si el bloque necesita alguna transformacion (si no, se dibuja tal cual). */
    public static boolean needs(BBModel.Cube cu, ModelManager.Settings s) {
        if (nz(cu.rot)) return true;
        String k = cu.key;
        return s.cubeOffsets.containsKey(k) || s.cubeRots.containsKey(k) || s.cubeScales.containsKey(k) || s.cubePivots.containsKey(k);
    }

    /** Multiplica m por la transformacion del bloque (JOML, para calculos fuera del render). */
    public static void apply(Matrix4f m, BBModel.Cube cu, ModelManager.Settings s) {
        if (!needs(cu, s)) return;
        float[] o = new float[3];
        pivotInto(cu, s, o);
        float[] off = s.cubeOffsets.get(cu.key), ro = s.cubeRots.get(cu.key), sc = s.cubeScales.get(cu.key);
        m.translate(o[0] + (off == null ? 0f : off[0]), o[1] + (off == null ? 0f : off[1]), o[2] + (off == null ? 0f : off[2]));
        float rx = cu.rot[0] + (ro == null ? 0f : ro[0]), ry = cu.rot[1] + (ro == null ? 0f : ro[1]), rz = cu.rot[2] + (ro == null ? 0f : ro[2]);
        if (rx != 0f || ry != 0f || rz != 0f) m.rotateZYX((float) Math.toRadians(rz), (float) Math.toRadians(ry), (float) Math.toRadians(rx));
        if (sc != null) m.scale(Math.max(0.001f, sc[0]), Math.max(0.001f, sc[1]), Math.max(0.001f, sc[2]));
        m.translate(-o[0], -o[1], -o[2]);
    }
}
