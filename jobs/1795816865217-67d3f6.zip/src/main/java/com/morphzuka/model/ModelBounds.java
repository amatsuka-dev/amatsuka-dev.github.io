package com.morphzuka.model;

import com.morphzuka.Role;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Calcula la caja real que ocupa el modelo (en bloques, pose de reposo, con los ajustes del editor aplicados).
 * Asi la hitbox sale del modelo de verdad y no de un numero a ojo.
 */
public final class ModelBounds {
    private ModelBounds() {}

    /** width = lado de la caja cuadrada de Minecraft, height = alto desde los pies, eye = altura de ojos. */
    public record Box(float width, float height, float eye, float minY, float sizeX, float sizeZ) {}

    private static final class Acc {
        float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, minZ = Float.MAX_VALUE;
        float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE, maxZ = -Float.MAX_VALUE;
        boolean any;
        void add(Vector3f v) {
            any = true;
            minX = Math.min(minX, v.x); maxX = Math.max(maxX, v.x);
            minY = Math.min(minY, v.y); maxY = Math.max(maxY, v.y);
            minZ = Math.min(minZ, v.z); maxZ = Math.max(maxZ, v.z);
        }
    }

    private static final Map<String, Box> CACHE = new HashMap<>();
    private static final Map<String, Integer> CACHE_KEY = new HashMap<>();

    private static int hash(Map<String, float[]> m) {
        int h = m.size();
        for (Map.Entry<String, float[]> e : m.entrySet()) h += e.getKey().hashCode() * 31 + Arrays.hashCode(e.getValue());
        return h;
    }

    /** Con cache: solo recalcula si cambio algo que afecta a la forma (escala, offsets, pivotes, ocultos, roles...). */
    public static Box of(BBModel m, ModelManager.Settings s) {
        int key = hash(s.offsets) * 31 + hash(s.rotOffsets) * 17 + hash(s.scales) * 13 + hash(s.pivots) * 7
                + hash(s.cubeOffsets) * 19 + hash(s.cubeRots) * 23 + hash(s.cubeScales) * 29 + hash(s.cubePivots) * 37
                + s.hidden.hashCode() * 5 + Float.hashCode(s.scale) + s.roles.hashCode() * 3;
        Integer old = CACHE_KEY.get(m.id);
        if (old != null && old == key) return CACHE.get(m.id);
        Box b = compute(m, s);
        CACHE.put(m.id, b);
        CACHE_KEY.put(m.id, key);
        return b;
    }

    public static Box compute(BBModel m, ModelManager.Settings s) {
        Acc all = new Acc(), head = new Acc();
        float sc = (s.scale <= 0 ? 1f : s.scale) / 16f;
        Matrix4f root = new Matrix4f().scale(sc);
        for (BBModel.Bone b : m.roots) walk(s, b, root, all, head, false);
        if (!all.any) return new Box(0.6f, 1.8f, 1.62f, 0f, 0.6f, 0.6f);
        float sx = all.maxX - all.minX, sz = all.maxZ - all.minZ;
        float w = Math.max(0.1f, Math.max(sx, sz));
        float h = Math.max(0.1f, all.maxY);                 // la caja de Minecraft nace en los pies (y = 0)
        float eye = head.any ? head.minY + 0.25f * (head.maxY - head.minY) : h * 0.9f;
        eye = Math.max(0.05f, Math.min(h, eye));
        return new Box(round(w), round(h), round(eye), all.minY, sx, sz);
    }

    private static float round(float v) { return Math.round(v * 100f) / 100f; }

    private static void walk(ModelManager.Settings s, BBModel.Bone b, Matrix4f parent, Acc all, Acc head, boolean inHead) {
        Matrix4f mt = new Matrix4f(parent);
        float[] piv = s.pivots.containsKey(b.name) ? s.pivots.get(b.name) : b.pivot;
        float[] off = s.offsets.get(b.name), ro = s.rotOffsets.get(b.name), bs = s.scales.get(b.name);
        mt.translate(piv[0] + (off == null ? 0 : off[0]), piv[1] + (off == null ? 0 : off[1]), piv[2] + (off == null ? 0 : off[2]));
        mt.rotateZYX((float) Math.toRadians(b.rot[2] + (ro == null ? 0 : ro[2])), (float) Math.toRadians(b.rot[1] + (ro == null ? 0 : ro[1])),
                (float) Math.toRadians(b.rot[0] + (ro == null ? 0 : ro[0])));
        if (bs != null) mt.scale(Math.max(0.001f, bs[0]), Math.max(0.001f, bs[1]), Math.max(0.001f, bs[2]));
        mt.translate(-piv[0], -piv[1], -piv[2]);

        boolean isHead = inHead || Role.of(s.roles.get(b.name)) == Role.HEAD;
        if (b.visible && !s.hidden.contains(b.name)) {
            Vector3f v = new Vector3f();
            for (BBModel.Cube c : b.cubes) {
                Matrix4f cm = new Matrix4f(mt);
                CubeXform.apply(cm, c, s);
                float i = c.inflate;
                for (int k = 0; k < 8; k++) {
                    v.set((k & 1) == 0 ? c.from[0] - i : c.to[0] + i, (k & 2) == 0 ? c.from[1] - i : c.to[1] + i, (k & 4) == 0 ? c.from[2] - i : c.to[2] + i);
                    cm.transformPosition(v);
                    all.add(v);
                    if (isHead) head.add(v);
                }
            }
        }
        for (BBModel.Bone ch : b.children) walk(s, ch, mt, all, head, isHead);
    }

    public static String describe(Box b) {
        return String.format(Locale.ROOT, "%.2f x %.2f x %.2f", b.sizeX(), b.height(), b.sizeZ());
    }
}
