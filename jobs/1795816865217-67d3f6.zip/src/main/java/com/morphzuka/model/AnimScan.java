package com.morphzuka.model;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;

import java.io.BufferedReader;
import java.util.*;

/**
 * Busca los archivos de animacion (GeckoLib / Bedrock: "animations": {...}) que traen los mods y resourcepacks para una
 * entidad, y los modelos ya cargados en MorphZuka que se llaman igual. Las entidades vanilla no traen archivos: sus
 * movimientos los calcula el propio juego.
 */
public final class AnimScan {
    private AnimScan() {}

    public record Result(List<String> files, List<String> names) {}

    private static final Map<String, Result> CACHE = new HashMap<>();

    public static Result find(Identifier id) {
        return CACHE.computeIfAbsent(id.toString(), k -> scan(id));
    }

    public static void clearCache() { CACHE.clear(); }

    /** Modelos cargados en MorphZuka cuyo nombre contiene el de la entidad (p. ej. un .geo.json de ese mob). */
    public static List<BBModel> models(Identifier id) {
        List<BBModel> out = new ArrayList<>();
        String p = id.getPath().toLowerCase(Locale.ROOT);
        for (BBModel m : ModelManager.MODELS.values()) if (m.id.toLowerCase(Locale.ROOT).contains(p)) out.add(m);
        return out;
    }

    private static Result scan(Identifier id) {
        List<String> files = new ArrayList<>(), names = new ArrayList<>();
        String ns = id.getNamespace(), p = id.getPath().toLowerCase(Locale.ROOT);
        try {
            ResourceManager rm = MinecraftClient.getInstance().getResourceManager();
            for (String root : new String[]{"animations", "bedrock"}) {
                Map<Identifier, Resource> found = rm.findResources(root,
                        i -> i.getNamespace().equals(ns) && i.getPath().endsWith(".json") && i.getPath().toLowerCase(Locale.ROOT).contains(p));
                for (Map.Entry<Identifier, Resource> en : found.entrySet()) {
                    if (files.size() >= 12) break;
                    try (BufferedReader r = en.getValue().getReader()) {
                        JsonElement el = JsonParser.parseReader(r);
                        if (!el.isJsonObject()) continue;
                        JsonElement an = el.getAsJsonObject().get("animations");
                        if (an == null || !an.isJsonObject()) continue;
                        JsonObject o = an.getAsJsonObject();
                        files.add(en.getKey().getPath());
                        for (String n : o.keySet()) if (names.size() < 300) names.add(n);
                    } catch (Exception ignored) {}
                }
            }
        } catch (Throwable t) {
            ModelManager.LOG.warn("No se pudieron buscar animaciones de {}: {}", id, t.toString());
        }
        return new Result(files, names);
    }
}
