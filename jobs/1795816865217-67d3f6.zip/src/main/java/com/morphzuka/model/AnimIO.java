package com.morphzuka.model;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.morphzuka.Role;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Exporta animaciones a .json (formato Bedrock .animation.json, el mismo que lee el importador). */
public final class AnimIO {
    private AnimIO() {}

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    /** portable: los huesos con rol se guardan con el nombre del rol (head, left_arm...) para usarse en cualquier modelo. */
    public static String export(BBModel m, ModelManager.Settings s, String animName, boolean portable) throws IOException {
        BBModel.Anim a = ModelManager.anim(m, animName);
        if (a == null) throw new IOException("Animación no encontrada: " + animName);
        JsonObject bones = new JsonObject();
        for (Map.Entry<String, BBModel.BoneAnim> e : a.bones.entrySet()) {
            String key = e.getKey();
            if (portable) {
                Role r = Role.of(s.roles.get(key));
                if (r != Role.NONE) key = r.alias;
            }
            JsonObject b = new JsonObject();
            put(b, "rotation", e.getValue().rot, new float[]{-1, -1, 1});
            put(b, "position", e.getValue().pos, new float[]{-1, 1, 1});
            put(b, "scale", e.getValue().scale, new float[]{1, 1, 1});
            if (b.size() > 0 && !bones.has(key)) bones.add(key, b);
        }
        JsonObject an = new JsonObject();
        an.addProperty("loop", a.loop);
        an.addProperty("animation_length", a.length);
        an.add("bones", bones);
        JsonObject anims = new JsonObject();
        anims.add("animation." + animName, an);
        JsonObject root = new JsonObject();
        root.addProperty("format_version", "1.8.0");
        root.add("animations", anims);

        Files.createDirectories(ModelManager.animsDir());
        String base = animName.replaceAll("[^A-Za-z0-9_\\-]", "_").toLowerCase(Locale.ROOT);
        Path target = ModelManager.animsDir().resolve(base + ".animation.json");
        int n = 2;
        while (Files.exists(target)) target = ModelManager.animsDir().resolve(base + "_" + n++ + ".animation.json");
        Files.writeString(target, GSON.toJson(root));
        return target.getFileName().toString();
    }

    private static void put(JsonObject bone, String channel, List<BBModel.Key> keys, float[] sign) {
        if (keys.isEmpty()) return;
        JsonObject o = new JsonObject();
        for (BBModel.Key k : keys) {
            JsonArray v = new JsonArray();
            for (int i = 0; i < 3; i++) v.add(k.v[i] * sign[i]);
            o.add(Float.toString(k.time), v);
        }
        bone.add(channel, o);
    }
}
