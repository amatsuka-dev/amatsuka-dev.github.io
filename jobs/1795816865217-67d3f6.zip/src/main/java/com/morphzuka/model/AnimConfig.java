package com.morphzuka.model;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/**
 * Asignacion estado -> animacion de cada modelo (idle, walk, run, jump, attack...), guardada en su propio archivo:
 * .minecraft/config/morphzuka_animations.json. Se reescribe cada vez que se guarda la config del mod.
 * Formato: { "modelo.bbmodel": { "IDLE": "idle", "WALK": "walk" }, ... }
 */
public final class AnimConfig {
    private AnimConfig() {}

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final java.lang.reflect.Type TYPE = new TypeToken<Map<String, Map<String, String>>>() {}.getType();
    private static String lastJson = "";

    public static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("morphzuka_animations.json"); }

    /** Escribe el archivo solo si cambio algo (se llama desde saveConfig, que es frecuente). */
    public static void save() {
        Map<String, Map<String, String>> out = new HashMap<>();
        for (Map.Entry<String, ModelManager.Settings> e : ModelManager.CONFIG.settings.entrySet()) {
            Map<String, String> a = e.getValue().anims;
            if (a != null && !a.isEmpty()) out.put(e.getKey(), new java.util.TreeMap<>(a));
        }
        String json = GSON.toJson(new java.util.TreeMap<>(out));
        if (json.equals(lastJson)) return;
        try {
            Files.writeString(file(), json);
            lastJson = json;
        } catch (IOException e) {
            ModelManager.LOG.warn("No se pudo guardar {}: {}", file().getFileName(), e.toString());
        }
    }

    /** Lee el archivo y aplica las asignaciones a los modelos cargados. */
    public static void apply() {
        try {
            if (!Files.exists(file())) return;
            String json = Files.readString(file());
            Map<String, Map<String, String>> in = GSON.fromJson(json, TYPE);
            if (in == null) return;
            for (Map.Entry<String, Map<String, String>> e : in.entrySet()) {
                BBModel m = ModelManager.MODELS.get(e.getKey());
                if (m == null || e.getValue() == null) continue;
                ModelManager.settings(m).anims = new HashMap<>(e.getValue());
            }
            lastJson = json;
        } catch (Exception e) {
            ModelManager.LOG.warn("{} invalido: {}", file().getFileName(), e.toString());
        }
    }

    /** Asigna a cada estado la primera animacion cuyo nombre coincida (idle, walk, run...). */
    public static int autoDetect(BBModel m, ModelManager.Settings s) {
        int n = 0;
        for (AnimStates.Def d : AnimStates.ALL) {
            for (String an : ModelManager.allAnimNames(m)) {
                if (AnimStates.match(d, an)) { s.anims.put(d.key(), an); n++; break; }
            }
        }
        return n;
    }
}
