package com.morphzuka.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Catalogo de tipos de animacion (estilo CPM): poses exclusivas, capas que se suman y capas de valor (0..1). */
public final class AnimStates {
    private AnimStates() {}

    public enum Kind { POSE, LAYER, VALUE }

    /** kw: sin prefijo = basta uno; "+x" = obligatorio; "-x" = excluye. */
    public record Def(String key, String label, Kind kind, String[] kw) {}

    public static final List<Def> ALL = new ArrayList<>();

    private static void d(String key, String label, Kind k, String... kw) { ALL.add(new Def(key, label, k, kw)); }

    static {
        // ---- poses (solo una a la vez)
        d("IDLE", "Pose: Quieto", Kind.POSE, "idle", "stand", "-ladder");
        d("WALK", "Pose: Caminar", Kind.POSE, "walk", "-sneak", "-crouch");
        d("SPRINT", "Pose: Correr", Kind.POSE, "run", "sprint");
        d("SNEAK", "Pose: Agachado", Kind.POSE, "sneak", "crouch", "-walk", "-move");
        d("SNEAK_WALK", "Pose: Agachado caminando", Kind.POSE, "sneak_walk", "crouch_walk", "sneakwalk", "sneak walk");
        d("SWIM", "Pose: Nadar", Kind.POSE, "swim");
        d("FALL", "Pose: Caída", Kind.POSE, "fall");
        d("SLEEP", "Pose: Dormir", Kind.POSE, "sleep");
        d("RIDE", "Pose: Montado", Kind.POSE, "ride", "sit", "mount");
        d("ELYTRA", "Pose: Volando (elytra)", Kind.POSE, "flying", "glide", "-wearing", "-creative");
        d("DYING", "Pose: Muriendo", Kind.POSE, "dying", "death", "die");
        d("CREATIVE_FLY", "Pose: Volar creativo", Kind.POSE, "creative");
        d("WATER", "Pose: En el agua", Kind.POSE, "water", "-swim");
        d("JUMP", "Pose: Salto (500ms)", Kind.POSE, "jump");
        d("CRAWL", "Pose: Gatear", Kind.POSE, "crawl");
        d("LADDER_STAND", "Pose: Quieto en escalera", Kind.POSE, "+ladder", "+stand");
        d("CLIMB", "Pose: Escalando", Kind.POSE, "climb");
        // ---- capas (se suman a la pose)
        d("GLOBAL", "Capa: Global (siempre)", Kind.LAYER, "global");
        d("SWING_L", "Capa: Golpe izquierdo", Kind.LAYER, "+swing", "+left");
        d("SWING_R", "Capa: Golpe derecho", Kind.LAYER, "+swing", "+right");
        d("EAT_L", "Capa: Comer/beber izq", Kind.LAYER, "eat", "drink", "+left");
        d("EAT_R", "Capa: Comer/beber der", Kind.LAYER, "eat", "drink", "+right");
        d("ARMOR_HEAD", "Capa: Armadura cabeza", Kind.LAYER, "+armor", "+head");
        d("ARMOR_BODY", "Capa: Armadura pecho", Kind.LAYER, "+armor", "body", "chest");
        d("ARMOR_LEGS", "Capa: Armadura piernas", Kind.LAYER, "+armor", "legs", "leggings");
        d("ARMOR_BOOTS", "Capa: Armadura botas", Kind.LAYER, "+armor", "boots", "feet");
        d("ELYTRA_WEAR", "Capa: Con elytra puesta", Kind.LAYER, "+wearing", "+elytra");
        d("BOW_L", "Capa: Apuntar arco izq", Kind.LAYER, "+bow", "+left");
        d("BOW_R", "Capa: Apuntar arco der", Kind.LAYER, "+bow", "+right");
        d("XBOW_HOLD_L", "Capa: Ballesta cargada izq", Kind.LAYER, "+crossbow", "+hold", "+left");
        d("XBOW_HOLD_R", "Capa: Ballesta cargada der", Kind.LAYER, "+crossbow", "+hold", "+right");
        d("XBOW_LOAD_L", "Capa: Cargando ballesta izq", Kind.LAYER, "+crossbow", "+load", "+left");
        d("XBOW_LOAD_R", "Capa: Cargando ballesta der", Kind.LAYER, "+crossbow", "+load", "+right");
        d("TRIDENT_L", "Capa: Tridente izq", Kind.LAYER, "+trident", "+left", "-spin");
        d("TRIDENT_R", "Capa: Tridente der", Kind.LAYER, "+trident", "+right", "-spin");
        d("TRIDENT_SPIN", "Capa: Tridente girando", Kind.LAYER, "+trident", "+spin");
        d("SPYGLASS_L", "Capa: Catalejo izq", Kind.LAYER, "+spyglass", "+left");
        d("SPYGLASS_R", "Capa: Catalejo der", Kind.LAYER, "+spyglass", "+right");
        d("HOLD_L", "Capa: Sosteniendo izq", Kind.LAYER, "+hold", "+left", "-crossbow");
        d("HOLD_R", "Capa: Sosteniendo der", Kind.LAYER, "+hold", "+right", "-crossbow");
        d("SKULL", "Capa: Con cráneo puesto", Kind.LAYER, "skull");
        d("BLOCK_L", "Capa: Bloqueando izq", Kind.LAYER, "+block", "+left");
        d("BLOCK_R", "Capa: Bloqueando der", Kind.LAYER, "+block", "+right");
        d("PARROT_L", "Capa: Loro hombro izq", Kind.LAYER, "+parrot", "+left");
        d("PARROT_R", "Capa: Loro hombro der", Kind.LAYER, "+parrot", "+right");
        d("HURT", "Capa: Daño", Kind.LAYER, "hurt", "damage");
        d("ON_FIRE", "Capa: En llamas", Kind.LAYER, "+fire");
        d("FREEZING", "Capa: Congelándose", Kind.LAYER, "freez");
        d("SPEAKING", "Capa: Hablando (voz)", Kind.LAYER, "speak", "talk");
        d("VOICE_MUTED", "Capa: Voz silenciada", Kind.LAYER, "+muted");
        d("HORN_L", "Capa: Cuerno de cabra izq", Kind.LAYER, "+horn", "+left");
        d("HORN_R", "Capa: Cuerno de cabra der", Kind.LAYER, "+horn", "+right");
        d("BRUSH_L", "Capa: Cepillo izq", Kind.LAYER, "+brush", "+left");
        d("BRUSH_R", "Capa: Cepillo der", Kind.LAYER, "+brush", "+right");
        d("CONTAINER", "Capa: Usando contenedor", Kind.LAYER, "container");
        d("FP_VIEW", "Capa: Vista 1ª persona (modelo)", Kind.LAYER, "+first", "+view");
        d("FP_HAND", "Capa: Mano 1ª persona", Kind.LAYER, "+first", "+hand");
        // ---- capas de valor (el tiempo de la animacion = valor 0..1 x duracion)
        d("HEALTH", "Valor: Salud", Kind.VALUE, "health");
        d("HUNGER", "Valor: Hambre", Kind.VALUE, "hunger");
        d("AIR", "Valor: Aire", Kind.VALUE, "+air");
        d("LIGHT", "Valor: Nivel de luz", Kind.VALUE, "light");
        d("HEAD_YAW", "Valor: Giro de cabeza", Kind.VALUE, "+head", "+yaw");
        d("HEAD_PITCH", "Valor: Inclinación de cabeza", Kind.VALUE, "+head", "+pitch");
    }

    public static String[] keys() { return ALL.stream().map(Def::key).toArray(String[]::new); }

    public static String[] labels() { return ALL.stream().map(Def::label).toArray(String[]::new); }

    public static Def get(String key) {
        for (Def d : ALL) if (d.key().equals(key)) return d;
        return null;
    }

    public static boolean match(Def d, String animName) {
        String l = animName.toLowerCase(Locale.ROOT).replace('-', '_');
        boolean anyPlain = false, anyHit = false;
        for (String k : d.kw()) {
            if (k.startsWith("-")) { if (l.contains(k.substring(1))) return false; }
            else if (k.startsWith("+")) { if (!l.contains(k.substring(1))) return false; }
            else { anyPlain = true; if (l.contains(k)) anyHit = true; }
        }
        return !anyPlain || anyHit;
    }
}
