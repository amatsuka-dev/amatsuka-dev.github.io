package com.morphzuka.model;

/**
 * El cuerpo vanilla del jugador (64x64, brazos anchos o slim) como un BBModel de cajas con UV de caja.
 * Sirve para que la skin vanilla se pueda tratar igual que cualquier modelo (por ejemplo en el efecto de cubos).
 * Solo la capa base: la capa exterior (sombrero, chaqueta...) tiene zonas transparentes.
 */
public final class VanillaPlayer {
    private VanillaPlayer() {}

    private static BBModel WIDE, SLIM;

    public static BBModel get(boolean slim) {
        if (slim) { if (SLIM == null) SLIM = build(true); return SLIM; }
        if (WIDE == null) WIDE = build(false);
        return WIDE;
    }

    private static BBModel build(boolean slim) {
        BBModel m = new BBModel();
        m.id = slim ? "@vanilla_slim" : "@vanilla_wide";
        m.texW = m.texH = m.imgW = m.imgH = 64;
        float aw = slim ? 3f : 4f;
        add(m, "head", -4, 24, -4, 4, 32, 4, 0, 0);
        add(m, "body", -4, 12, -2, 4, 24, 2, 16, 16);
        add(m, "right_arm", 4, 12, -2, 4 + aw, 24, 2, 40, 16);   // frente = -Z, asi que su derecha es +X
        add(m, "left_arm", -4 - aw, 12, -2, -4, 24, 2, 32, 48);
        add(m, "right_leg", 0, 0, -2, 4, 12, 2, 0, 16);
        add(m, "left_leg", -4, 0, -2, 0, 12, 2, 16, 48);
        m.indexCubes();
        return m;
    }

    private static void add(BBModel m, String name, float x0, float y0, float z0, float x1, float y1, float z1, float u, float v) {
        BBModel.Bone b = new BBModel.Bone();
        b.name = name;
        b.origName = name;
        BBModel.Cube c = new BBModel.Cube();
        c.name = name;
        c.from = new float[]{x0, y0, z0};
        c.to = new float[]{x1, y1, z1};
        c.boxUv = true;
        c.uvOffset = new float[]{u, v};
        b.cubes.add(c);
        m.roots.add(b);
        m.bones.put(name, b);
    }
}
