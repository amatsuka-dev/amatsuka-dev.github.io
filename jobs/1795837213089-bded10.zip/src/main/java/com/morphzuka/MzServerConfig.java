package com.morphzuka;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Reglas del servidor (config/morphzuka-server.json). En un mundo propio tambien se aplican, asi pruebas lo mismo
 * que vera un servidor real.
 */
public final class MzServerConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    public static MzServerConfig INSTANCE = new MzServerConfig();

    /** Los jugadores pueden tener una hitbox distinta (modelo / morph). */
    public boolean allowHitbox = true;
    /** Los jugadores pueden transformarse y los demas lo ven. */
    public boolean allowMorph = true;
    /** Se retransmite el efecto de cubos a los demas. */
    public boolean allowEffects = true;
    /** Los jugadores pueden compartir su modelo de Blockbench para que los demas lo vean. */
    public boolean allowModels = true;
    /** Tamano maximo (KB, ya comprimido) del modelo que se acepta de cada jugador. */
    public int maxModelKB = 8192;
    /** Al transformarte en una entidad copias su velocidad de movimiento (paso 40). La velocidad la aplica el servidor, asi que no hay tirones. */
    public boolean copySpeed = true;
    /** Multiplicador general sobre la velocidad copiada (1 = tal cual) y limites del resultado respecto a tu velocidad normal. */
    public float speedScale = 1f;
    public float minSpeedMul = 0.3f;
    public float maxSpeedMul = 2f;
    /** Si es true, solo los operadores pueden usar hitbox y morph. */
    public boolean opsOnly = false;
    /** Si es true, a todos los que NO son operadores se les bloquea el menu/interfaz de MorphZuka (y morph, hitbox, modelos y gestos). */
    public boolean lockNonOps = false;
    /** Jugadores (nombre en minusculas) con el menu bloqueado individualmente. Los operadores nunca se bloquean. */
    public java.util.List<String> lockedPlayers = new java.util.ArrayList<>();
    /** Limites de la caja que se acepta (bloques). Evita cajas de 0 o gigantes. */
    public float minSize = 0.1f;
    public float maxWidth = 4f;
    public float maxHeight = 8f;

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("morphzuka-server.json"); }

    public static void load() {
        Path f = file();
        try {
            if (Files.exists(f)) {
                MzServerConfig c = GSON.fromJson(Files.readString(f), MzServerConfig.class);
                if (c != null) INSTANCE = c;
            }
            sanitize(INSTANCE);
            Files.writeString(f, GSON.toJson(INSTANCE));   // reescribe para que aparezcan los campos nuevos
        } catch (Exception e) {
            MorphZuka.LOG.warn("No se pudo leer {}: {}", f, e.toString());
        }
    }

    public static void save() {
        try { Files.writeString(file(), GSON.toJson(INSTANCE)); }
        catch (IOException e) { MorphZuka.LOG.warn("No se pudo guardar {}: {}", file(), e.toString()); }
    }

    private static void sanitize(MzServerConfig c) {
        java.util.List<String> names = new java.util.ArrayList<>();
        if (c.lockedPlayers != null)
            for (String n : c.lockedPlayers) if (n != null && !n.isBlank()) names.add(n.trim().toLowerCase(java.util.Locale.ROOT));
        c.lockedPlayers = names;
        c.maxModelKB = Math.max(64, Math.min(65536, c.maxModelKB));
        c.speedScale = clamp(c.speedScale, 0.1f, 10f);
        c.minSpeedMul = clamp(c.minSpeedMul, 0.05f, 1f);
        c.maxSpeedMul = clamp(c.maxSpeedMul, 1f, 10f);
        c.minSize = clamp(c.minSize, 0.01f, 1f);
        c.maxWidth = clamp(c.maxWidth, c.minSize, 64f);
        c.maxHeight = clamp(c.maxHeight, c.minSize, 64f);
    }

    private static float clamp(float v, float lo, float hi) { return Float.isNaN(v) ? lo : Math.max(lo, Math.min(hi, v)); }

    /** {ancho, alto, ojos} dentro de los limites, o null si los numeros no sirven. */
    public float[] clampBox(float w, float h, float eye) {
        if (!Float.isFinite(w) || !Float.isFinite(h) || !Float.isFinite(eye)) return null;
        w = clamp(w, minSize, maxWidth);
        h = clamp(h, minSize, maxHeight);
        eye = clamp(eye, 0.05f, h);
        return new float[]{w, h, eye};
    }
}
