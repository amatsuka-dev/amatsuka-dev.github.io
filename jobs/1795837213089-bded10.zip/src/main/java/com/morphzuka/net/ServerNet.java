package com.morphzuka.net;

import com.morphzuka.HitboxRegistry;
import com.morphzuka.MorphZuka;
import com.morphzuka.MzServerConfig;
import com.morphzuka.net.Payloads.CubeFxPayload;
import com.morphzuka.net.Payloads.GesturePayload;
import com.morphzuka.net.Payloads.HitboxPayload;
import com.morphzuka.net.Payloads.HitboxSyncPayload;
import com.morphzuka.MenuLock;
import com.morphzuka.net.Payloads.MenuLockPayload;
import com.morphzuka.net.Payloads.MorphPayload;
import com.morphzuka.net.Payloads.ModelChunkPayload;
import com.morphzuka.net.Payloads.ModelInfoPayload;
import com.morphzuka.net.Payloads.ModelRequestPayload;
import com.morphzuka.net.Payloads.ModelUploadPayload;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.registry.Registries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Logica de servidor: valida lo que piden los clientes, lo aplica al ServerPlayerEntity (colisiones reales) y lo
 * retransmite a los demas. Se registra en ambos lados porque los tipos de paquete deben conocerse en los dos.
 */
public final class ServerNet {
    private ServerNet() {}

    private static final Map<UUID, MorphPayload> MORPHS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_FX = new ConcurrentHashMap<>();
    private static final long FX_MIN_GAP_MS = 400;
    private static final Map<UUID, GesturePayload> GESTURES = new ConcurrentHashMap<>();   // paso 35: estado de gestos de cada jugador
    private static final Map<UUID, Long> LAST_GESTURE = new ConcurrentHashMap<>();

    // ---- modelos compartidos (paso 33). El servidor no interpreta el paquete: solo lo valida por tamano, lo guarda y lo reparte.
    private record Stored(String hash, byte[] data) {}
    private static final class Upload {
        final byte[] buf; int off, idx;
        Upload(int n) { buf = new byte[n]; }
    }
    private static final class Job {   // un modelo que se esta mandando, trozo a trozo, a un jugador
        final ServerPlayerEntity to; final UUID who; final Stored s; int idx;
        Job(ServerPlayerEntity to, UUID who, Stored s) { this.to = to; this.who = who; this.s = s; }
    }
    private static final Map<UUID, Stored> MODELS = new ConcurrentHashMap<>();
    private static final Map<UUID, Upload> UPLOADS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_UPLOAD_START = new ConcurrentHashMap<>();
    private static final Map<UUID, long[]> REQ_WINDOW = new ConcurrentHashMap<>();   // {inicio de ventana, peticiones}
    private static final List<Job> JOBS = new ArrayList<>();                         // solo se toca en el hilo del servidor
    private static final Map<UUID, Boolean> LOCK_SENT = new ConcurrentHashMap<>();   // ultimo estado de bloqueo de menu enviado a cada jugador
    private static int lockTick;
    private static final int CHUNKS_PER_TICK = 16;                                   // ~480 KB por tick: no atasca la red

    public static void register() {
        PayloadTypeRegistry.playS2C().register(MenuLockPayload.ID, MenuLockPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(HitboxPayload.ID, HitboxPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(HitboxSyncPayload.ID, HitboxSyncPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MorphPayload.ID, MorphPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(MorphPayload.ID, MorphPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(CubeFxPayload.ID, CubeFxPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(CubeFxPayload.ID, CubeFxPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(GesturePayload.ID, GesturePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(GesturePayload.ID, GesturePayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ModelUploadPayload.ID, ModelUploadPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(ModelRequestPayload.ID, ModelRequestPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ModelInfoPayload.ID, ModelInfoPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(ModelChunkPayload.ID, ModelChunkPayload.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(HitboxPayload.ID, (pl, ctx) -> onHitbox(pl, ctx.player(), ctx.server()));
        ServerPlayNetworking.registerGlobalReceiver(MorphPayload.ID, (pl, ctx) -> onMorph(pl, ctx.player(), ctx.server()));
        ServerPlayNetworking.registerGlobalReceiver(CubeFxPayload.ID, (pl, ctx) -> onFx(pl, ctx.player()));
        ServerPlayNetworking.registerGlobalReceiver(GesturePayload.ID, (pl, ctx) -> onGesture(pl, ctx.player(), ctx.server()));
        ServerPlayNetworking.registerGlobalReceiver(ModelUploadPayload.ID, (pl, ctx) -> onModelUpload(pl, ctx.player(), ctx.server()));
        ServerPlayNetworking.registerGlobalReceiver(ModelRequestPayload.ID, (pl, ctx) -> onModelRequest(pl, ctx.player()));
        ServerTickEvents.END_SERVER_TICK.register(srv -> {
            tickJobs();
            if (++lockTick >= 20) { lockTick = 0; refreshLocks(srv); }   // por si alguien pasa a ser (o deja de ser) operador
        });

        // Al entrar: el nuevo jugador recibe las cajas y morphs que ya existen.
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity me = handler.getPlayer();
            LOCK_SENT.remove(me.getUuid());
            refreshLock(me, server);
            HitboxRegistry.allServer().forEach((u, b) -> send(me, new HitboxSyncPayload(u, b[0], b[1], b[2])));
            MORPHS.values().forEach(m -> send(me, m));
            GESTURES.values().forEach(g -> send(me, g));
            MODELS.forEach((u, s) -> send(me, new ModelInfoPayload(u, s.hash(), s.data().length)));   // el cliente pide los que no tenga en su cache
        });

        // Al salir: se borra todo lo suyo y se avisa a los demas.
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            ServerPlayerEntity gone = handler.getPlayer();
            UUID u = gone.getUuid();
            boolean hadBox = HitboxRegistry.getServer(u) != null;
            boolean hadMorph = MORPHS.remove(u) != null;
            boolean hadModel = MODELS.remove(u) != null;
            boolean hadGesture = GESTURES.remove(u) != null;
            LAST_GESTURE.remove(u);
            LOCK_SENT.remove(u);
            UPLOADS.remove(u);
            LAST_UPLOAD_START.remove(u);
            REQ_WINDOW.remove(u);
            JOBS.removeIf(j -> j.to == gone || j.who.equals(u));
            HitboxRegistry.setServer(u, null);
            com.morphzuka.BlockMorphRegistry.setServer(u, false);
            LAST_FX.remove(u);
            for (ServerPlayerEntity o : PlayerLookup.all(server)) {
                if (o == gone) continue;
                if (hadBox) send(o, new HitboxSyncPayload(u, 0, 0, 0));
                if (hadMorph) send(o, new MorphPayload(u, Payloads.KIND_NONE, "", new byte[0]));
                if (hadModel) send(o, new ModelInfoPayload(u, "", 0));
                if (hadGesture) send(o, new GesturePayload(u, "", (byte) 0, 0, "", java.util.List.of()));
            }
        });

        ServerLifecycleEvents.SERVER_STOPPED.register(s -> {   // en mundo propio el JVM sigue vivo: no arrastrar estado al siguiente mundo
            HitboxRegistry.allServer().clear();
            com.morphzuka.BlockMorphRegistry.clearServer();
            MORPHS.clear();
            LAST_FX.clear();
            MODELS.clear();
            GESTURES.clear();
            LAST_GESTURE.clear();
            LOCK_SENT.clear();
            UPLOADS.clear();
            LAST_UPLOAD_START.clear();
            REQ_WINDOW.clear();
            JOBS.clear();
        });
    }

    // ------------------------------------------------------------------ helpers

    private static boolean may(ServerPlayerEntity p, boolean feature) {
        if (!feature) return false;
        if (MenuLock.isLocked(p)) return false;   // menu bloqueado: tampoco se aceptan morph, hitbox, modelos ni gestos
        if (!MzServerConfig.INSTANCE.opsOnly) return true;
        MinecraftServer s = p.getServer();
        return s != null && s.getPlayerManager().isOperator(p.getGameProfile());
    }

    // ------------------------------------------------------------------ bloqueo de menu

    /** Recalcula el bloqueo de todos los jugadores conectados (tras /mz lock, /mz unlock, /mz reload o un cambio de op). */
    public static void refreshLocks(MinecraftServer srv) {
        for (ServerPlayerEntity p : PlayerLookup.all(srv)) refreshLock(p, srv);
    }

    private static void refreshLock(ServerPlayerEntity p, MinecraftServer srv) {
        boolean now = MenuLock.isLocked(p);
        Boolean was = LOCK_SENT.put(p.getUuid(), now);
        if (was != null && was == now) return;
        if (was == null && !now) return;   // nunca estuvo bloqueado: el cliente ya parte de "desbloqueado"
        send(p, new MenuLockPayload(now));
        if (now) strip(p, srv);
    }

    /** Al bloquear a alguien se le quita lo que tenia puesto: vuelve a la forma normal y deja de compartir modelo/gestos. */
    private static void strip(ServerPlayerEntity sp, MinecraftServer srv) {
        UUID u = sp.getUuid();
        onMorph(new MorphPayload(u, Payloads.KIND_NONE, "", new byte[0]), sp, srv);
        onHitbox(new HitboxPayload(0, 0, 0), sp, srv);
        if (MODELS.containsKey(u)) {
            dropModel(u, srv);
            send(sp, new ModelInfoPayload(u, "", -1));
        }
        if (GESTURES.remove(u) != null) {
            GesturePayload empty = new GesturePayload(u, "", (byte) 0, 0, "", java.util.List.of());
            for (ServerPlayerEntity o : PlayerLookup.all(srv)) send(o, empty);
        }
    }

    private static void send(ServerPlayerEntity to, CustomPayload pl) {
        if (ServerPlayNetworking.canSend(to, pl.getId())) ServerPlayNetworking.send(to, pl);
    }

    private static void broadcast(MinecraftServer srv, CustomPayload pl) {
        for (ServerPlayerEntity o : PlayerLookup.all(srv)) send(o, pl);
    }

    // ------------------------------------------------------------------ hitbox

    private static void onHitbox(HitboxPayload pl, ServerPlayerEntity sp, MinecraftServer srv) {
        UUID u = sp.getUuid();
        float[] box = null;
        if (pl.w() > 0 && may(sp, MzServerConfig.INSTANCE.allowHitbox))
            box = MzServerConfig.INSTANCE.clampBox(pl.w(), pl.h(), pl.eye());
        HitboxRegistry.setServer(u, box);
        sp.calculateDimensions();   // el servidor ya usa la caja nueva: colisiones, validacion de movimiento, golpes
        broadcast(srv, box == null ? new HitboxSyncPayload(u, 0, 0, 0) : new HitboxSyncPayload(u, box[0], box[1], box[2]));
    }

    // ------------------------------------------------------------------ morph

    private static boolean validMorph(byte kind, String id) {
        if (id == null || id.isEmpty() || id.length() > 100) return false;
        return switch (kind) {
            case Payloads.KIND_ENTITY -> { Identifier i = Identifier.tryParse(id); yield i != null && Registries.ENTITY_TYPE.containsId(i); }
            case Payloads.KIND_BLOCK -> { Identifier i = Identifier.tryParse(id); yield i != null && Registries.BLOCK.containsId(i); }
            case Payloads.KIND_PLAYER -> id.length() <= 16;
            default -> false;
        };
    }

    private static void onMorph(MorphPayload pl, ServerPlayerEntity sp, MinecraftServer srv) {
        UUID u = sp.getUuid();
        MorphPayload clean;
        if (pl.kind() != Payloads.KIND_NONE && may(sp, MzServerConfig.INSTANCE.allowMorph) && validMorph(pl.kind(), pl.id())) {
            byte[] extra = pl.kind() == Payloads.KIND_ENTITY ? pl.data()
                    : pl.kind() == Payloads.KIND_BLOCK && pl.data().length > 0 ? new byte[]{(byte) (pl.data()[0] & 3)}   // giro del bloque (paso 39)
                    : new byte[0];
            clean = new MorphPayload(u, pl.kind(), pl.id(), extra);
            MORPHS.put(u, clean);
        } else {
            clean = new MorphPayload(u, Payloads.KIND_NONE, "", new byte[0]);   // tambien sirve de respuesta si el servidor lo rechaza
            MORPHS.remove(u);
        }
        com.morphzuka.BlockMorphRegistry.setServer(u, clean.kind() == Payloads.KIND_BLOCK);   // el jugador-bloque es solido
        applySpeed(sp, clean);
        broadcast(srv, clean);   // incluye al remitente: si fue rechazado, su cliente vuelve a la forma normal
    }

    // ------------------------------------------------------------------ velocidad del morph (paso 40)

    private static final Identifier SPEED_ID = Identifier.of("morphzuka", "morph_speed");
    /** Velocidad base que se toma como "normal" (la de un zombi, que anda mas o menos como un jugador). */
    private static final double REF_SPEED = 0.23;

    /** Copia la velocidad de la entidad en la que te transformas como un modificador temporal; se quita al volver a la forma normal. */
    private static void applySpeed(ServerPlayerEntity sp, MorphPayload m) {
        try {
            var inst = sp.getAttributeInstance(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MOVEMENT_SPEED);
            if (inst == null) return;
            inst.removeModifier(SPEED_ID);
            MzServerConfig c = MzServerConfig.INSTANCE;
            if (!c.copySpeed || m.kind() != Payloads.KIND_ENTITY) return;
            Identifier i = Identifier.tryParse(m.id());
            var t = i == null ? null : Registries.ENTITY_TYPE.getOrEmpty(i).orElse(null);
            if (t == null || !net.minecraft.entity.attribute.DefaultAttributeRegistry.hasDefinitionFor(t)) return;
            @SuppressWarnings("unchecked")
            var cont = net.minecraft.entity.attribute.DefaultAttributeRegistry.get((net.minecraft.entity.EntityType<? extends net.minecraft.entity.LivingEntity>) t);
            if (!cont.has(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MOVEMENT_SPEED)) return;
            double base = cont.getValue(net.minecraft.entity.attribute.EntityAttributes.GENERIC_MOVEMENT_SPEED);
            if (!(base > 0)) return;
            double mul = Math.max(c.minSpeedMul, Math.min(c.maxSpeedMul, base / REF_SPEED * c.speedScale));
            if (Math.abs(mul - 1.0) < 0.02) return;
            inst.addTemporaryModifier(new net.minecraft.entity.attribute.EntityAttributeModifier(SPEED_ID, mul - 1.0,
                    net.minecraft.entity.attribute.EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL));
        } catch (Throwable t) {
            MorphZuka.LOG.warn("No se pudo copiar la velocidad del morph de {}: {}", sp.getName().getString(), t.toString());
        }
    }

    // ------------------------------------------------------------------ efecto de cubos

    private static boolean sane(float v) { return Float.isFinite(v) && v > 0.01f && v < 64f; }

    private static void onFx(CubeFxPayload pl, ServerPlayerEntity sp) {
        if (!may(sp, MzServerConfig.INSTANCE.allowEffects)) return;
        if (!sane(pl.oldW()) || !sane(pl.oldH()) || !sane(pl.newW()) || !sane(pl.newH())) return;
        UUID u = sp.getUuid();
        long now = Util.getMeasuringTimeMs();
        Long last = LAST_FX.get(u);
        if (last != null && now - last < FX_MIN_GAP_MS) return;   // antiflood
        LAST_FX.put(u, now);
        int block = pl.blockId() >= 0 && pl.blockId() < Registries.BLOCK.size() ? pl.blockId() : -1;
        CubeFxPayload out = new CubeFxPayload(u, pl.oldW(), pl.oldH(), pl.newW(), pl.newH(), block, pl.seed());
        for (ServerPlayerEntity o : PlayerLookup.tracking(sp)) send(o, out);   // solo quienes lo tienen a la vista
    }

    // ------------------------------------------------------------------ gestos (paso 35)

    private static void onGesture(GesturePayload pl, ServerPlayerEntity sp, MinecraftServer srv) {
        if (!may(sp, MzServerConfig.INSTANCE.allowModels)) return;
        UUID u = sp.getUuid();
        long now = Util.getMeasuringTimeMs();
        Long last = LAST_GESTURE.get(u);
        if (last != null && now - last < 60) return;   // antiflood
        LAST_GESTURE.put(u, now);
        java.util.List<String> tg = new ArrayList<>();
        for (String t : pl.toggles()) if (t != null && !t.isEmpty() && tg.size() < Payloads.MAX_TOGGLES) tg.add(t);
        int modes = com.morphzuka.model.ModelManager.LoopMode.values().length;
        byte mode = pl.mode() >= 0 && pl.mode() < modes ? pl.mode() : 1;
        GesturePayload clean = new GesturePayload(u, pl.current(), mode, pl.playId(), pl.pose(), java.util.List.copyOf(tg));
        boolean empty = clean.current().isEmpty() && clean.pose().isEmpty() && tg.isEmpty();
        if (empty) GESTURES.remove(u); else GESTURES.put(u, clean);
        for (ServerPlayerEntity o : PlayerLookup.all(srv)) if (o != sp) send(o, clean);
    }

    // ------------------------------------------------------------------ modelos compartidos

    public static int modelCount() { return MODELS.size(); }

    /** Una linea por modelo compartido (para /mz status). */
    public static List<String> modelLines(MinecraftServer srv) {
        List<String> l = new ArrayList<>();
        for (Map.Entry<UUID, Stored> e : MODELS.entrySet()) {
            ServerPlayerEntity p = srv.getPlayerManager().getPlayer(e.getKey());
            l.add(String.format("  %s: %d KB (%s)", p == null ? e.getKey().toString() : p.getName().getString(), e.getValue().data().length / 1024, e.getValue().hash().substring(0, 8)));
        }
        return l;
    }

    public static long modelBytes() {
        long n = 0;
        for (Stored s : MODELS.values()) n += s.data().length;
        return n;
    }

    /** Quita el modelo guardado de un jugador y avisa a todos (a el tambien: asi su cliente se entera). */
    private static void dropModel(UUID u, MinecraftServer srv) {
        UPLOADS.remove(u);
        if (MODELS.remove(u) != null) {
            JOBS.removeIf(j -> j.who.equals(u));
            broadcast(srv, new ModelInfoPayload(u, "", 0));
        }
    }

    private static void onModelUpload(ModelUploadPayload pl, ServerPlayerEntity sp, MinecraftServer srv) {
        UUID u = sp.getUuid();
        MzServerConfig cfg = MzServerConfig.INSTANCE;

        if (pl.size() == 0) {   // quitar mi modelo
            dropModel(u, srv);
            send(sp, new ModelInfoPayload(u, "", 0));
            return;
        }
        if (!may(sp, cfg.allowModels)) {
            dropModel(u, srv);
            if (pl.index() == 0) send(sp, new ModelInfoPayload(u, "", -1));
            return;
        }
        long max = (long) cfg.maxModelKB * 1024L;
        if (pl.size() < 0) { UPLOADS.remove(u); return; }
        if (pl.size() > max) {
            dropModel(u, srv);   // si dejara el modelo viejo, los demas verian uno distinto al que elegiste
            if (pl.index() == 0) {
                send(sp, new ModelInfoPayload(u, "", -cfg.maxModelKB));
                MorphZuka.LOG.info("{} intento compartir un modelo de {} KB (maximo {} KB)", sp.getName().getString(), pl.size() / 1024, cfg.maxModelKB);
            }
            return;
        }

        Upload up;
        if (pl.index() == 0) {
            long now = Util.getMeasuringTimeMs();
            Long lastStart = LAST_UPLOAD_START.get(u);
            if (lastStart != null && now - lastStart < 250) { UPLOADS.remove(u); return; }   // antiflood: no reservar memoria sin parar
            LAST_UPLOAD_START.put(u, now);
            up = new Upload(pl.size());
            UPLOADS.put(u, up);
        } else {
            up = UPLOADS.get(u);
            if (up == null || up.buf.length != pl.size() || pl.index() != up.idx) { UPLOADS.remove(u); return; }   // trozo fuera de orden
        }
        byte[] ch = pl.chunk();
        boolean last = up.off + ch.length == up.buf.length;
        if (ch.length == 0 || up.off + ch.length > up.buf.length || (ch.length != Payloads.MODEL_CHUNK && !last)) { UPLOADS.remove(u); return; }
        System.arraycopy(ch, 0, up.buf, up.off, ch.length);
        up.off += ch.length;
        up.idx++;
        if (!last) return;

        UPLOADS.remove(u);
        byte[] d = up.buf;
        if (d.length < 18 || (d[0] & 0xFF) != 0x1f || (d[1] & 0xFF) != 0x8b) return;   // no es un paquete gzip de MorphZuka
        String h = Payloads.hash(d);
        Stored cur = MODELS.get(u);
        if (cur != null && cur.hash().equals(h)) { send(sp, new ModelInfoPayload(u, h, d.length)); return; }   // ya lo tenia
        MODELS.put(u, new Stored(h, d));
        MorphZuka.LOG.info("{} compartio un modelo ({} KB, {})", sp.getName().getString(), d.length / 1024, h.substring(0, 8));
        JOBS.removeIf(j -> j.who.equals(u));   // lo que se estuviera mandando era la version vieja
        broadcast(srv, new ModelInfoPayload(u, h, d.length));   // incluye al remitente: es su confirmacion
    }

    private static void onModelRequest(ModelRequestPayload pl, ServerPlayerEntity sp) {
        Stored s = MODELS.get(pl.who());
        if (s == null || !s.hash().equals(pl.hash())) return;
        long now = Util.getMeasuringTimeMs();
        long[] w = REQ_WINDOW.computeIfAbsent(sp.getUuid(), k -> new long[]{now, 0});
        if (now - w[0] > 10_000) { w[0] = now; w[1] = 0; }
        if (++w[1] > 64) return;   // antiflood de peticiones
        for (Job j : JOBS) if (j.to == sp && j.s == s) return;   // ya se lo estoy mandando
        JOBS.add(new Job(sp, pl.who(), s));
    }

    /** Reparte los modelos pedidos a un ritmo fijo de trozos por tick. */
    private static void tickJobs() {
        if (JOBS.isEmpty()) return;
        int budget = CHUNKS_PER_TICK;
        for (Iterator<Job> it = JOBS.iterator(); it.hasNext() && budget > 0; ) {
            Job j = it.next();
            byte[] data = j.s.data();
            while (budget > 0) {
                int off = j.idx * Payloads.MODEL_CHUNK;
                int n = Math.min(Payloads.MODEL_CHUNK, data.length - off);
                if (n <= 0) { it.remove(); break; }
                send(j.to, new ModelChunkPayload(j.who, j.s.hash(), data.length, j.idx, Arrays.copyOfRange(data, off, off + n)));
                j.idx++;
                budget--;
                if (off + n >= data.length) { it.remove(); break; }
            }
        }
    }
}
