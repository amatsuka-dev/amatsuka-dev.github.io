package com.morphzuka.net;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

import java.util.UUID;

/**
 * Paquetes del mod. Solo usan clases comunes (nada de cliente) para poder cargarse en un servidor dedicado.
 * Todos se leen con limites: el servidor nunca se fia de lo que manda un cliente.
 */
public final class Payloads {
    private Payloads() {}

    // ---- hitbox: cliente -> servidor (la caja que quiere tener). w <= 0 = quitar override.
    public record HitboxPayload(float w, float h, float eye) implements CustomPayload {
        public static final CustomPayload.Id<HitboxPayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "hitbox"));
        public static final PacketCodec<RegistryByteBuf, HitboxPayload> CODEC = PacketCodec.of(
                (v, b) -> { b.writeFloat(v.w); b.writeFloat(v.h); b.writeFloat(v.eye); },
                b -> new HitboxPayload(b.readFloat(), b.readFloat(), b.readFloat()));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    // ---- hitbox: servidor -> todos (la caja ya validada de un jugador). w <= 0 = sin override.
    public record HitboxSyncPayload(UUID who, float w, float h, float eye) implements CustomPayload {
        public static final CustomPayload.Id<HitboxSyncPayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "hitbox_sync"));
        public static final PacketCodec<RegistryByteBuf, HitboxSyncPayload> CODEC = PacketCodec.of(
                (v, b) -> { b.writeUuid(v.who); b.writeFloat(v.w); b.writeFloat(v.h); b.writeFloat(v.eye); },
                b -> new HitboxSyncPayload(b.readUuid(), b.readFloat(), b.readFloat(), b.readFloat()));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    // ---- morph: en ambos sentidos. Cliente -> servidor (who se ignora y se pone el remitente real); servidor -> clientes.
    public static final int MAX_MORPH_DATA = 16000;
    public static final byte KIND_NONE = 0, KIND_ENTITY = 1, KIND_BLOCK = 2, KIND_PLAYER = 3;

    /** data = datos sincronizados de la entidad copiada (especie de un Pokemon, color, variante...), opaco para el servidor. */
    public record MorphPayload(UUID who, byte kind, String id, byte[] data) implements CustomPayload {
        public static final CustomPayload.Id<MorphPayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "morph"));
        public static final PacketCodec<RegistryByteBuf, MorphPayload> CODEC = PacketCodec.of(
                (v, b) -> { b.writeUuid(v.who); b.writeByte(v.kind); b.writeString(v.id, 128); b.writeByteArray(v.data); },
                b -> new MorphPayload(b.readUuid(), b.readByte(), b.readString(128), b.readByteArray(MAX_MORPH_DATA)));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    // ================================================================ modelos compartidos (paso 33)
    // Un modelo se manda como un paquete .gz (ver ModelBundle) partido en trozos: un paquete C2S no puede pasar de 32 KB.
    //   dueno -> servidor : ModelUploadPayload (trozos)            el servidor lo valida y lo guarda
    //   servidor -> todos : ModelInfoPayload (quien + hash)        "este jugador tiene este modelo"
    //   cliente -> servidor: ModelRequestPayload (quien + hash)    "mandamelo" (solo si no lo tiene ya en su cache)
    //   servidor -> cliente: ModelChunkPayload (trozos)

    public static final int MODEL_CHUNK = 30000;
    /** Tope absoluto de lo que un cliente acepta bajar (el servidor ademas tiene su propio limite). */
    public static final int MODEL_HARD_MAX = 64 * 1024 * 1024;

    /** SHA-256 en hexadecimal, 40 caracteres. Lo calcula igual el servidor y el cliente: sirve de identificador y de comprobacion. */
    public static String hash(byte[] data) { return com.morphzuka.model.ModelBundle.hash(data); }

    /** Un hash valido son 40 caracteres hexadecimales en minuscula (se usa como nombre de archivo: nada de rutas). */
    public static boolean validHash(String h) { return com.morphzuka.model.ModelBundle.validHash(h); }

    /** size = bytes totales del paquete; index = numero de trozo (empieza en 0). size == 0 = quitar mi modelo. */
    public record ModelUploadPayload(int size, int index, byte[] chunk) implements CustomPayload {
        public static final CustomPayload.Id<ModelUploadPayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "model_up"));
        public static final PacketCodec<RegistryByteBuf, ModelUploadPayload> CODEC = PacketCodec.of(
                (v, b) -> { b.writeInt(v.size); b.writeInt(v.index); b.writeByteArray(v.chunk); },
                b -> new ModelUploadPayload(b.readInt(), b.readInt(), b.readByteArray(MODEL_CHUNK)));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    /**
     * Servidor -> clientes. hash vacio = ese jugador ya no tiene modelo compartido.
     * Para el remitente tambien es la respuesta a su subida: size >= 0 aceptado, -1 el servidor no lo permite,
     * <= -64 demasiado grande (el numero es el maximo en KB).
     */
    public record ModelInfoPayload(UUID who, String hash, int size) implements CustomPayload {
        public static final CustomPayload.Id<ModelInfoPayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "model_info"));
        public static final PacketCodec<RegistryByteBuf, ModelInfoPayload> CODEC = PacketCodec.of(
                (v, b) -> { b.writeUuid(v.who); b.writeString(v.hash, 64); b.writeInt(v.size); },
                b -> new ModelInfoPayload(b.readUuid(), b.readString(64), b.readInt()));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    public record ModelRequestPayload(UUID who, String hash) implements CustomPayload {
        public static final CustomPayload.Id<ModelRequestPayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "model_req"));
        public static final PacketCodec<RegistryByteBuf, ModelRequestPayload> CODEC = PacketCodec.of(
                (v, b) -> { b.writeUuid(v.who); b.writeString(v.hash, 64); },
                b -> new ModelRequestPayload(b.readUuid(), b.readString(64)));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    public record ModelChunkPayload(UUID who, String hash, int size, int index, byte[] chunk) implements CustomPayload {
        public static final CustomPayload.Id<ModelChunkPayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "model_chunk"));
        public static final PacketCodec<RegistryByteBuf, ModelChunkPayload> CODEC = PacketCodec.of(
                (v, b) -> { b.writeUuid(v.who); b.writeString(v.hash, 64); b.writeInt(v.size); b.writeInt(v.index); b.writeByteArray(v.chunk); },
                b -> new ModelChunkPayload(b.readUuid(), b.readString(64), b.readInt(), b.readInt(), b.readByteArray(MODEL_CHUNK)));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    // ---- gestos / pose / toggles (paso 35): estado de animaciones manuales. Cliente -> servidor (who se ignora) y servidor -> los demas.
    public static final int MAX_TOGGLES = 16;

    /** Vacios = nada activo. mode = ordinal de LoopMode; playId distingue lanzar dos veces el mismo gesto. */
    public record GesturePayload(UUID who, String current, byte mode, int playId, String pose, java.util.List<String> toggles) implements CustomPayload {
        public static final CustomPayload.Id<GesturePayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "gesture"));
        public static final PacketCodec<RegistryByteBuf, GesturePayload> CODEC = PacketCodec.of(
                (v, b) -> {
                    b.writeUuid(v.who);
                    b.writeString(v.current, 128);
                    b.writeByte(v.mode);
                    b.writeVarInt(v.playId);
                    b.writeString(v.pose, 128);
                    b.writeVarInt(v.toggles.size());
                    for (String t : v.toggles) b.writeString(t, 128);
                },
                b -> {
                    UUID w = b.readUuid();
                    String cur = b.readString(128);
                    byte mode = b.readByte();
                    int id = b.readVarInt();
                    String pose = b.readString(128);
                    int n = b.readVarInt();
                    if (n < 0 || n > MAX_TOGGLES) throw new io.netty.handler.codec.DecoderException("demasiados toggles: " + n);
                    java.util.List<String> t = new java.util.ArrayList<>(n);
                    for (int i = 0; i < n; i++) t.add(b.readString(128));
                    return new GesturePayload(w, cur, mode, id, pose, t);
                });
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    // ---- efecto "cube form": en ambos sentidos, igual que el morph. blockId = id de bloque del registro o -1 (paleta).
    public record CubeFxPayload(UUID who, float oldW, float oldH, float newW, float newH, int blockId, long seed) implements CustomPayload {
        public static final CustomPayload.Id<CubeFxPayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "cube_fx"));
        public static final PacketCodec<RegistryByteBuf, CubeFxPayload> CODEC = PacketCodec.of(
                (v, b) -> {
                    b.writeUuid(v.who);
                    b.writeFloat(v.oldW); b.writeFloat(v.oldH); b.writeFloat(v.newW); b.writeFloat(v.newH);
                    b.writeVarInt(v.blockId + 1);
                    b.writeLong(v.seed);
                },
                b -> new CubeFxPayload(b.readUuid(), b.readFloat(), b.readFloat(), b.readFloat(), b.readFloat(), b.readVarInt() - 1, b.readLong()));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    // ---- bloqueo del menu: servidor -> un cliente. true = el menu de MorphZuka esta bloqueado para ti.
    public record MenuLockPayload(boolean locked) implements CustomPayload {
        public static final CustomPayload.Id<MenuLockPayload> ID = new CustomPayload.Id<>(Identifier.of("morphzuka", "menu_lock"));
        public static final PacketCodec<RegistryByteBuf, MenuLockPayload> CODEC = PacketCodec.of(
                (v, b) -> b.writeBoolean(v.locked),
                b -> new MenuLockPayload(b.readBoolean()));
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }
}
