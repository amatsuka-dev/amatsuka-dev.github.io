package com.morphzuka.net;

import com.morphzuka.Gestures;
import com.morphzuka.net.Payloads.GesturePayload;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.List;

/**
 * Comparte tus gestos, tu pose y tus capas toggle (paso 35) y recibe los de los demas. Solo cliente.
 * Se manda el estado completo cuando cambia (no cada tick); los "una vez" que terminan solos tambien se notifican al acabar.
 */
public final class GestureSync {
    private GestureSync() {}

    private static final String EMPTY = key(null, 0, 0, null, List.of());
    private static String last = EMPTY;
    private static long nextMs;

    private static String key(String cur, int playId, int mode, String pose, List<String> toggles) {
        return (cur == null ? "" : cur + "#" + playId + "#" + mode) + "|" + (pose == null ? "" : pose) + "|" + toggles;
    }

    public static void onJoin() { last = EMPTY; nextMs = 0; }

    public static void onDisconnect() { last = EMPTY; Gestures.clearRemotes(); }

    public static void tick(MinecraftClient c) {
        if (c.player == null) return;
        String cur = Gestures.current;
        List<String> tg = new ArrayList<>(Gestures.toggles);
        String k = key(cur, Gestures.playId, Gestures.mode.ordinal(), Gestures.pose, tg);
        if (k.equals(last)) return;
        long now = Util.getMeasuringTimeMs();
        if (now < nextMs) return;                                  // como mucho ~10 envios por segundo
        if (!ClientNet.canSendGestures()) return;                  // el servidor no tiene el mod: se reintenta solo (last no cambia)
        if (tg.size() > Payloads.MAX_TOGGLES) tg = tg.subList(0, Payloads.MAX_TOGGLES);
        ClientNet.sendGesture(new GesturePayload(new java.util.UUID(0, 0), cur == null ? "" : cur, (byte) Gestures.mode.ordinal(),
                Gestures.playId, Gestures.pose == null ? "" : Gestures.pose, tg));
        last = k;
        nextMs = now + 100;
    }

    public static void onState(GesturePayload p) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || p.who().equals(mc.player.getUuid())) return;
        Gestures.setRemote(p.who(), p.current(), p.mode(), p.playId(), p.pose(), p.toggles());
    }
}
