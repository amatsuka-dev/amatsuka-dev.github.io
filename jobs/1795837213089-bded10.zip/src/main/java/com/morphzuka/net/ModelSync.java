package com.morphzuka.net;

import com.google.gson.Gson;
import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelManager;
import com.morphzuka.model.ModelShare;
import com.morphzuka.model.RemoteModels;
import com.morphzuka.net.Payloads.ModelChunkPayload;
import com.morphzuka.net.Payloads.ModelInfoPayload;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;

/**
 * Comparte tu modelo y recibe los de los demas (paso 33). Solo cliente.
 *
 *  Tu modelo: cuando cambias de modelo o de ajustes (ModelManager.saveConfig -> markDirty) se espera un momento, se
 *  empaqueta en un hilo aparte (ModelShare), y si el paquete es distinto del ultimo que se mando se sube al servidor
 *  a un ritmo de pocos trozos por tick. Al entrar a un servidor se manda otra vez.
 *
 *  Los demas: el servidor avisa "este jugador tiene este modelo (hash)". Si ya esta en la cache del disco se usa; si no,
 *  se pide, se reciben los trozos, se comprueba el hash y se carga en RemoteModels. Nada de esto toca tu carpeta de modelos.
 */
public final class ModelSync {
    private ModelSync() {}

    private static final Gson GSON = new Gson();
    private static final long DEBOUNCE_MS = 1200;
    private static final long JOIN_DELAY_MS = 600;
    private static final long STALE_MS = 20_000;
    private static final int UPLOAD_CHUNKS_PER_TICK = 4;
    private static final int CACHE_KEEP = 64;

    // ---------------------------------------------------------------- tu modelo (subida)

    private static boolean dirty = true;
    private static long dueMs;
    private static boolean building;
    private static String sentHash;          // hash de lo ultimo que se subio en esta conexion (null = nada)
    private static byte[] upData;            // paquete que se esta subiendo
    private static int upOff, upIdx;
    private static int netRetries;      // veces que se reintento porque el servidor aun no anunciaba MorphZuka

    /** Texto para la pestana Aplicar: como va el compartir tu modelo. */
    public static volatile String status = "";
    private static String settled = "";      // ultimo resultado definitivo del servidor (aceptado / rechazado), para repetirlo si nada cambia

    /** Algo cambio (modelo elegido, ajustes, archivo): se vuelve a mirar un momento despues. */
    public static void markDirty() {
        dirty = true;
        dueMs = Util.getMeasuringTimeMs() + DEBOUNCE_MS;
    }

    // ---------------------------------------------------------------- modelos de los demas (descarga)

    private static final class Pending {
        final String hash; final byte[] buf; int off, idx; long last;
        Pending(String hash, int size) { this.hash = hash; this.buf = new byte[size]; this.last = Util.getMeasuringTimeMs(); }
    }
    private static final Map<UUID, Pending> PENDING = new HashMap<>();

    // ---------------------------------------------------------------- ciclo de vida

    public static void onJoin() {
        sentHash = null;
        upData = null;
        building = false;
        PENDING.clear();
        status = "";
        settled = "";
        netRetries = 0;
        dirty = true;
        dueMs = Util.getMeasuringTimeMs() + JOIN_DELAY_MS;
    }

    public static void onDisconnect() {
        sentHash = null;
        upData = null;
        building = false;
        PENDING.clear();
        RemoteModels.clear();
        status = "";
        settled = "";
    }

    /** Cada tick del cliente (con el jugador en un mundo). */
    public static void tick(MinecraftClient c) {
        if (c.player == null) return;
        pumpUpload();
        long now = Util.getMeasuringTimeMs();
        if (!PENDING.isEmpty()) PENDING.values().removeIf(p -> now - p.last > STALE_MS);   // si el servidor no contesto, el proximo aviso lo reintenta
        if (!dirty || building || now < dueMs) return;
        dirty = false;

        if (!ClientNet.serverHasModels()) {
            if (netRetries++ < 8) {   // justo tras entrar el servidor puede tardar un momento en anunciar sus canales: se reintenta
                dirty = true;
                dueMs = now + 1500;
                status = "Conectando con MorphZuka del servidor...";
            } else status = "Este servidor no tiene MorphZuka: solo tú ves tu modelo";
            return;
        }
        netRetries = 0;
        String id = ModelManager.selfShareId();
        BBModel m = id == null ? null : ModelManager.MODELS.get(id);
        if (m == null) {   // sin modelo propio: si habia uno compartido, se quita
            if (sentHash != null) { ClientNet.sendModelClear(); sentHash = null; }
            upData = null;
            settled = "";
            status = "Sin modelo propio que compartir (aplícate uno con \"Yo\")";
            return;
        }

        // lo que toca ajustes se lee aqui (hilo del juego); el hilo aparte solo lee archivos y comprime
        ModelManager.Settings s = ModelManager.settings(m);
        final String settingsJson = GSON.toJson(s);
        final String libJson = GSON.toJson(libAnimsUsed(m, s));
        building = true;
        status = "Preparando tu modelo para compartirlo...";
        Thread t = new Thread(() -> {
            byte[] data = null;
            String err = null;
            try { data = ModelShare.build(m, settingsJson, libJson); }
            catch (Throwable e) { err = e.getMessage() != null ? e.getMessage() : e.toString(); }
            final byte[] d = data;
            final String er = err;
            c.send(() -> { building = false; finishBuild(d, er); });
        }, "morphzuka-pack");
        t.setDaemon(true);
        t.start();
    }

    /** Animaciones de la biblioteca (carpeta animations/) que usan los ajustes y que el modelo no trae: las demas personas no las tienen. */
    private static Map<String, BBModel.Anim> libAnimsUsed(BBModel m, ModelManager.Settings s) {
        Set<String> names = new HashSet<>(s.anims.values());
        names.addAll(s.animCats.keySet());
        names.addAll(s.animModes.keySet());
        Map<String, BBModel.Anim> r = new LinkedHashMap<>();
        for (String n : names) {
            if (n == null || m.anims.containsKey(n)) continue;
            BBModel.Anim a = ModelManager.LIB.get(n);
            if (a != null) r.put(n, a);
        }
        return r;
    }

    private static void finishBuild(byte[] data, String err) {
        if (err != null) { status = "No se pudo compartir tu modelo: " + err; return; }
        String h = Payloads.hash(data);
        if (h.equals(sentHash)) {   // nada cambio desde la ultima vez
            if (upData == null) status = settled.isEmpty() ? "Tu modelo ya está compartido" : settled;
            return;
        }
        if (!ClientNet.serverHasModels()) { markDirty(); return; }   // el servidor aun no anuncia MorphZuka: se reintenta
        sentHash = h;
        settled = "";
        upData = data;
        upOff = 0;
        upIdx = 0;
        status = "Subiendo tu modelo (" + kb(data.length) + " KB)...";
        ModelManager.LOG.info("MorphZuka: subiendo tu modelo {} ({} KB, hash {})", ModelManager.selfShareId(), kb(data.length), h);
    }

    private static void pumpUpload() {
        for (int i = 0; i < UPLOAD_CHUNKS_PER_TICK && upData != null; i++) {
            if (!ClientNet.serverHasModels()) { upData = null; return; }
            int n = Math.min(Payloads.MODEL_CHUNK, upData.length - upOff);
            ClientNet.sendModelChunk(upData.length, upIdx, Arrays.copyOfRange(upData, upOff, upOff + n));
            upOff += n;
            upIdx++;
            if (upOff >= upData.length) { upData = null; status = "Enviado, esperando al servidor..."; }
        }
    }

    private static String kb(int bytes) { return String.valueOf(Math.max(1, bytes / 1024)); }

    // ---------------------------------------------------------------- recepcion

    /** El servidor dice que modelo tiene (o ya no tiene) un jugador. */
    public static void onInfo(ModelInfoPayload p) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        UUID who = p.who();

        if (who.equals(mc.player.getUuid())) { onSelfInfo(p); return; }

        if (p.hash().isEmpty()) {   // ese jugador ya no comparte modelo
            PENDING.remove(who);
            RemoteModels.remove(who);
            return;
        }
        if (!Payloads.validHash(p.hash()) || p.size() <= 0 || p.size() > Payloads.MODEL_HARD_MAX) return;
        if (p.hash().equals(RemoteModels.hashOf(who))) return;   // ya lo tengo cargado
        Pending pd = PENDING.get(who);
        if (pd != null && pd.hash.equals(p.hash())) return;       // ya lo he pedido
        PENDING.remove(who);

        byte[] cached = cacheRead(p.hash());
        if (cached != null && tryInstall(who, p.hash(), cached)) return;

        PENDING.put(who, new Pending(p.hash(), p.size()));
        ClientNet.sendModelRequest(who, p.hash());
    }

    private static void onSelfInfo(ModelInfoPayload p) {
        if (p.size() == -1) { settled = status = "Este servidor no permite compartir modelos"; return; }
        if (p.size() < 0) { settled = status = "Tu modelo es demasiado grande para este servidor (máximo " + (-p.size()) + " KB)"; return; }
        if (p.hash().isEmpty()) return;   // confirmacion de "quitar": el estado ya lo puso tick()
        if (p.hash().equals(sentHash)) {
            settled = status = "Compartido con el servidor (" + kb(p.size()) + " KB): los demás ven tu modelo";
            ModelManager.LOG.info("MorphZuka: el servidor acepto tu modelo ({} KB)", kb(p.size()));
        }
    }

    public static void onChunk(ModelChunkPayload p) {
        Pending pd = PENDING.get(p.who());
        if (pd == null || !pd.hash.equals(p.hash()) || p.size() != pd.buf.length) return;
        byte[] c = p.chunk();
        long off = (long) p.index() * Payloads.MODEL_CHUNK;
        if (c.length == 0 || p.index() != pd.idx || off != pd.off || off + c.length > pd.buf.length) { PENDING.remove(p.who()); return; }
        System.arraycopy(c, 0, pd.buf, (int) off, c.length);
        pd.off += c.length;
        pd.idx++;
        pd.last = Util.getMeasuringTimeMs();
        if (pd.off < pd.buf.length) return;

        PENDING.remove(p.who());
        if (!Payloads.hash(pd.buf).equals(pd.hash)) { ModelManager.LOG.warn("Modelo de {} recibido corrupto (hash distinto)", p.who()); return; }
        cacheWrite(pd.hash, pd.buf);
        tryInstall(p.who(), pd.hash, pd.buf);
    }

    private static boolean tryInstall(UUID who, String hash, byte[] data) {
        try {
            RemoteModels.install(who, hash, data);
            ModelManager.LOG.info("MorphZuka: modelo de {} cargado ({} KB)", nameOf(who), kb(data.length));
            return true;
        } catch (Throwable t) {
            ModelManager.LOG.warn("No se pudo cargar el modelo compartido de {}: {}", who, t.toString());
            return false;
        }
    }

    // ---------------------------------------------------------------- cache en disco (morphzuka/cache/<hash>.mzb)

    private static Path cacheDir() { return ModelManager.root().resolve("cache"); }

    private static byte[] cacheRead(String hash) {
        try {
            if (!Payloads.validHash(hash)) return null;
            Path f = cacheDir().resolve(hash + ".mzb");
            if (!Files.isRegularFile(f)) return null;
            byte[] d = Files.readAllBytes(f);
            if (!Payloads.hash(d).equals(hash)) { Files.deleteIfExists(f); return null; }   // archivo roto o cambiado
            return d;
        } catch (Throwable t) { return null; }
    }

    private static void cacheWrite(String hash, byte[] data) {
        try {
            if (!Payloads.validHash(hash)) return;
            Path dir = cacheDir();
            Files.createDirectories(dir);
            Files.write(dir.resolve(hash + ".mzb"), data);
            List<Path> files;
            try (Stream<Path> st = Files.list(dir)) { files = new ArrayList<>(st.filter(f -> f.toString().endsWith(".mzb")).toList()); }
            if (files.size() <= CACHE_KEEP) return;
            files.sort(Comparator.comparingLong(ModelSync::modified));   // los mas viejos primero
            for (int i = 0; i < files.size() - CACHE_KEEP; i++) Files.deleteIfExists(files.get(i));
        } catch (IOException ignored) {}
    }

    private static long modified(Path f) {
        try { return Files.getLastModifiedTime(f).toMillis(); } catch (IOException e) { return 0; }
    }

    /** Nombre de un jugador por su UUID (para mensajes); si no se conoce, el UUID. */
    private static String nameOf(UUID u) {
        try {
            var nh = MinecraftClient.getInstance().getNetworkHandler();
            var e = nh == null ? null : nh.getPlayerListEntry(u);
            if (e != null) return e.getProfile().getName();
        } catch (Throwable ignored) {}
        return u.toString();
    }

    /** Informe para /morphzuka net: por que alguien ve (o no) tu modelo. */
    public static List<String> report() {
        List<String> l = new ArrayList<>();
        l.add("Servidor con MorphZuka (modelos): " + (ClientNet.serverHasModels() ? "sí" : "NO"));
        String id = ModelManager.selfShareId();
        l.add("Tu modelo para compartir: " + (id == null ? "ninguno (aplícate uno con \"Yo\")" : id));
        l.add("Estado: " + (status.isEmpty() ? "(sin estado)" : status));
        l.add("Último paquete enviado: " + (sentHash == null ? "ninguno" : sentHash));
        l.add("Ver modelos de los demás: " + (ModelManager.CONFIG.showRemote ? "sí" : "NO"));
        l.add("Descargando ahora: " + PENDING.size());
        Map<UUID, String> r = RemoteModels.hashes();
        l.add("Modelos ajenos cargados: " + r.size());
        for (Map.Entry<UUID, String> e : r.entrySet()) l.add("  - " + nameOf(e.getKey()) + " (" + e.getValue().substring(0, 8) + ")");
        return l;
    }

    /** Vuelve a empaquetar y subir tu modelo aunque no haya cambiado (por si el servidor lo perdio). */
    public static void forceResend() {
        sentHash = null;
        upData = null;
        netRetries = 0;
        settled = "";
        markDirty();
    }

    /** Cuantos modelos de otros jugadores hay cargados (para la pestana Aplicar). */
    public static int remoteCount() { return RemoteModels.count(); }
}
