package com.morphzuka.render;

import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelManager;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * Fisicas de rebote. Solo las partes marcadas ({@link ModelManager.Settings#physBones}) se mueven; el resto del modelo
 * no se toca. Cada parte marcada simula su PUNTA (el extremo libre de ella y sus subgrupos) como una masa colgada de
 * un resorte amortiguado, en coordenadas del mundo. Como el objetivo de la punta se calcula con la pose final del
 * hueso (animacion, gestos, cabeza...) mas la posicion y el giro del cuerpo, la parte reacciona igual al caminar,
 * saltar, girar, o a una animacion (baile, gacha...). Despues se gira la parte lo justo para que su punta siga a la
 * masa. Un subgrupo marcado dentro de otro marcado hace cadena (pelo en segmentos).
 * El cuerpo entero (squash/stretch al saltar) es aparte y solo si se activa ({@link ModelManager.Settings#physicsBody}).
 * Se activa con {@link ModelManager.Settings#physicsOn} y se regula con {@link ModelManager.Settings#physicsIntensity}.
 */
public final class Physics {
    private Physics() {}

    /** Identificador del "jugador" imaginario del editor 3D. */
    public static final UUID PREVIEW = new UUID(0L, 0xB0B0L);

    private static final class Spring { float x, z, vx, vz; }

    /** Masa simulada en la punta de una parte (coordenadas del mundo). */
    private static final class BoneSim {
        double sx, sy, sz;          // posicion simulada de la punta
        double wx, wy, wz;          // objetivo (punta animada) del paso anterior
        float vx, vy, vz;           // velocidad (bloques/s)
        float lastT = Float.NaN;
        boolean init;
        final Quaternionf q = new Quaternionf();   // giro resultante, en el marco del padre
    }

    private static final class State {
        final Map<String, BoneSim> sims = new HashMap<>();
        final Map<String, Spring> bones = new HashMap<>();
        double px, py, pz;
        float vx, vy, vz;          // velocidad suavizada (bloques/s)
        float ax, ay, az;          // aceleracion suavizada
        float bounce, bounceV;     // squash/stretch del cuerpo
        float lastTime = Float.NaN;
        float aFwd, aSide, vFwd, vSide;   // movimiento en el eje del modelo
        long seen;
    }

    private static final Map<UUID, State> STATES = new HashMap<>();

    private static State st(UUID id) {
        State t = STATES.computeIfAbsent(id, k -> new State());
        t.seen = System.nanoTime();
        return t;
    }

    public static void forget(UUID id) { STATES.remove(id); }

    /** Evita acumular estados de jugadores que ya no estan (se llama de vez en cuando desde update). */
    private static void prune() {
        if (STATES.size() <= 16) return;
        long now = System.nanoTime();
        STATES.values().removeIf(t -> now - t.seen > 30_000_000_000L);
    }

    /** Actualiza el movimiento del jugador (una vez por frame) y avanza los resortes de sus partes. */
    public static void update(UUID id, double x, double y, double z, float bodyYawDeg, float time, ModelManager.Settings s, Iterable<String> bones) {
        prune();
        State t = st(id);
        if (Float.isNaN(t.lastTime) || time - t.lastTime > 1f || time < t.lastTime) {   // primer frame, pausa larga o retroceso
            t.lastTime = time; t.px = x; t.py = y; t.pz = z;
            t.vx = t.vy = t.vz = t.ax = t.ay = t.az = 0f;
            return;
        }
        float dt = time - t.lastTime;
        if (dt <= 1e-4f) return;           // mismo frame (segundo render) o juego en pausa
        if (dt > 0.1f) dt = 0.1f;
        t.lastTime = time;

        float rvx = (float) ((x - t.px) / dt), rvy = (float) ((y - t.py) / dt), rvz = (float) ((z - t.pz) / dt);
        t.px = x; t.py = y; t.pz = z;
        float k = 1f - (float) Math.exp(-dt * 14f);
        float nvx = t.vx + (rvx - t.vx) * k, nvy = t.vy + (rvy - t.vy) * k, nvz = t.vz + (rvz - t.vz) * k;
        float rax = (nvx - t.vx) / dt, ray = (nvy - t.vy) / dt, raz = (nvz - t.vz) / dt;
        t.vx = nvx; t.vy = nvy; t.vz = nvz;
        float ka = 1f - (float) Math.exp(-dt * 18f);
        t.ax += (clamp(rax, 60f) - t.ax) * ka;
        t.ay += (clamp(ray, 80f) - t.ay) * ka;
        t.az += (clamp(raz, 60f) - t.az) * ka;

        double yr = Math.toRadians(bodyYawDeg);
        float sin = (float) Math.sin(yr), cos = (float) Math.cos(yr);
        // adelante del jugador = (-sin, cos); derecha del modelo (+X) = (-cos, -sin)
        t.vFwd = -t.vx * sin + t.vz * cos;
        t.vSide = -t.vx * cos - t.vz * sin;
        t.aFwd = -t.ax * sin + t.az * cos;
        t.aSide = -t.ax * cos - t.az * sin;

        step(t, s, dt, bones);
    }

    private static float clamp(float v, float m) { return Math.max(-m, Math.min(m, v)); }

    private static void step(State t, ModelManager.Settings s, float dt, Iterable<String> bones) {
        float inten = Math.max(0f, s.physicsIntensity);
        // positivo en X = parte hacia delante: al acelerar hacia delante la parte se va hacia atras (negativo)
        float tx = clamp(-(t.aFwd * 0.55f + t.vFwd * 2.2f) * inten, 70f);
        float tz = clamp(-(t.aSide * 0.55f + t.vSide * 2.2f) * inten, 70f);
        int n = Math.max(1, (int) Math.ceil(dt / (1f / 120f)));
        float h = dt / n;
        for (String b : bones) {
            Spring sp = t.bones.computeIfAbsent(b, kk -> new Spring());
            float var = 0.85f + (Math.abs(b.hashCode()) % 31) / 100f;       // cada parte con su propia frecuencia
            float w = 2f * (float) Math.PI * 3.2f * var;
            float c = 2f * 0.22f * w;
            for (int i = 0; i < n; i++) {
                sp.vx += (w * w * (tx - sp.x) - c * sp.vx) * h;
                sp.vz += (w * w * (tz - sp.z) - c * sp.vz) * h;
                sp.x += sp.vx * h;
                sp.z += sp.vz * h;
                if (sp.x > 85f) { sp.x = 85f; sp.vx = 0; } else if (sp.x < -85f) { sp.x = -85f; sp.vx = 0; }
                if (sp.z > 85f) { sp.z = 85f; sp.vz = 0; } else if (sp.z < -85f) { sp.z = -85f; sp.vz = 0; }
            }
        }
        // cuerpo: aterrizar (aceleracion vertical positiva fuerte) = aplastarse
        float bt = Math.max(-0.22f, Math.min(0.22f, -t.ay * 0.0016f * inten));
        float wb = 2f * (float) Math.PI * 4f, cb = 2f * 0.2f * wb;
        for (int i = 0; i < n; i++) {
            t.bounceV += (wb * wb * (bt - t.bounce) - cb * t.bounceV) * h;
            t.bounce += t.bounceV * h;
        }
        t.bounce = Math.max(-0.3f, Math.min(0.3f, t.bounce));
    }

    /** {rotX, rotZ} en grados para una parte, o null si no tiene estado todavia. */
    public static float[] bone(UUID id, String bone, float[] out) {
        State t = STATES.get(id);
        if (t == null) return null;
        Spring sp = t.bones.get(bone);
        if (sp == null) return null;
        out[0] = sp.x;
        out[1] = sp.z;
        return out;
    }

    /** Estiramiento vertical del cuerpo (0 = normal). */
    public static float bounce(UUID id) {
        State t = STATES.get(id);
        return t == null ? 0f : t.bounce;
    }

    /** Empujon manual: lo usa el boton "Probar rebote" del editor. */
    public static void kick(UUID id, Iterable<String> bones, float strength) {
        State t = st(id);
        for (String b : bones) {
            BoneSim bs = t.sims.computeIfAbsent(b, kk -> new BoneSim());
            float dir = Math.abs(b.hashCode()) % 2 == 0 ? 1f : -1f;
            bs.vx += dir * 5f * strength;
            bs.vy += 2.5f * strength;
            bs.vz += 3.5f * strength;
        }
        t.bounceV -= 2.2f * strength;
    }

    /** Avanza el modelo del editor, que no tiene jugador: no hay movimiento, solo dejar que los resortes se asienten. */
    public static void stepPreview(ModelManager.Settings s, float dt, Iterable<String> bones) {
        State t = st(PREVIEW);
        t.aFwd = t.aSide = t.vFwd = t.vSide = t.ay = 0f;
        dt = Math.min(dt, 0.05f);
        if (dt <= 0f) return;
        step(t, s, dt, bones);
    }

    // ================================================================ fisicas por parte

    /** Ganancia general: con intensidad 1 el movimiento se nota sin ser exagerado. */
    private static final float GAIN = 2.2f;
    private static final float MAX_ANGLE = 80f;

    /** Si es true, el modelo del editor se mueve solo (pasea, gira y salta) para ver las fisicas sin jugador. */
    public static boolean previewMove;
    private static final long T0 = System.nanoTime();

    /** Reloj propio (segundos) para el editor 3D. */
    public static float clock() { return (System.nanoTime() - T0) / 1e9f; }

    // marco del dibujo actual (un solo hilo de render)
    private static State fs;
    private static float ftime, fkk, fcos, fsin, finten;
    private static double fex, fey, fez;

    private static final Vector3f V0 = new Vector3f(), V1 = new Vector3f(), VP = new Vector3f(), VT = new Vector3f();
    private static final Quaternionf QA = new Quaternionf(), QI = new Quaternionf(), QS = new Quaternionf();
    private static final WeakHashMap<BBModel.Bone, float[]> TIPS = new WeakHashMap<>();

    /**
     * Empieza un dibujo con fisicas por parte. (x, y, z) = posicion del cuerpo en el mundo, bodyYawDeg = giro del cuerpo,
     * kk = bloques por pixel del modelo, time = segundos.
     */
    public static void beginFrame(UUID id, double x, double y, double z, float bodyYawDeg, float kk, float time, float intensity) {
        fs = st(id);
        ftime = time;
        fkk = Math.max(1e-5f, kk);
        double a = Math.toRadians(180f - bodyYawDeg);     // el modelo se dibuja girado 180 - yaw
        fcos = (float) Math.cos(a);
        fsin = (float) Math.sin(a);
        finten = Math.max(0f, intensity);
        fex = x; fey = y; fez = z;
    }

    public static void endFrame() { fs = null; }

    /** {centro x,y,z, esquina mas lejana x,y,z} (espacio del modelo, px) de los bloques del grupo y sus subgrupos. */
    private static float[] tip(BBModel.Bone b) {
        float[] r = TIPS.get(b);
        if (r != null) return r;
        float[] bb = {1e9f, 1e9f, 1e9f, -1e9f, -1e9f, -1e9f};
        bounds(b, bb);
        if (bb[0] > bb[3]) { bb[0] = bb[3] = b.pivot[0]; bb[1] = bb[4] = b.pivot[1] - 4f; bb[2] = bb[5] = b.pivot[2]; }
        float cx = (bb[0] + bb[3]) / 2f, cy = (bb[1] + bb[4]) / 2f, cz = (bb[2] + bb[5]) / 2f;
        float fx = Math.abs(bb[0] - b.pivot[0]) > Math.abs(bb[3] - b.pivot[0]) ? bb[0] : bb[3];
        float fy = Math.abs(bb[1] - b.pivot[1]) > Math.abs(bb[4] - b.pivot[1]) ? bb[1] : bb[4];
        float fz = Math.abs(bb[2] - b.pivot[2]) > Math.abs(bb[5] - b.pivot[2]) ? bb[2] : bb[5];
        r = new float[]{cx, cy, cz, fx, fy, fz};
        TIPS.put(b, r);
        return r;
    }

    private static void bounds(BBModel.Bone b, float[] bb) {
        for (BBModel.Cube c : b.cubes) {
            for (int i = 0; i < 3; i++) {
                bb[i] = Math.min(bb[i], Math.min(c.from[i], c.to[i]) - c.inflate);
                bb[i + 3] = Math.max(bb[i + 3], Math.max(c.from[i], c.to[i]) + c.inflate);
            }
        }
        for (BBModel.Bone ch : b.children) bounds(ch, bb);
    }

    /**
     * Giro extra de una parte con fisicas (en el marco de su padre; se aplica antes de su rotacion animada), o null.
     * mp = matriz del padre en espacio del modelo (px). piv/pos/rot/sc = pivote, desplazamiento, rotacion (grados) y escala
     * de la parte con la animacion ya aplicada, sin fisicas.
     */
    public static Quaternionf solve(BBModel.Bone b, Matrix4f mp, float[] piv, float[] pos, float[] rot, float[] sc) {
        State t = fs;
        if (t == null || finten <= 0f) return null;
        BoneSim bs = t.sims.computeIfAbsent(b.name, k -> new BoneSim());
        float[] tp = tip(b);
        float lx = tp[0] - piv[0], ly = tp[1] - piv[1], lz = tp[2] - piv[2];
        if (lx * lx + ly * ly + lz * lz < 4f) { lx = tp[3] - piv[0]; ly = tp[4] - piv[1]; lz = tp[5] - piv[2]; }
        if (lx * lx + ly * ly + lz * lz < 1f) { lx = 0f; ly = -4f; lz = 0f; }

        QA.rotationZYX((float) Math.toRadians(rot[2]), (float) Math.toRadians(rot[1]), (float) Math.toRadians(rot[0]));
        V0.set(lx * sc[0], ly * sc[1], lz * sc[2]).rotate(QA);          // pivote -> punta, en el marco del padre
        VP.set(piv[0] + pos[0], piv[1] + pos[1], piv[2] + pos[2]);
        VT.set(VP).add(V0);
        mp.transformPosition(VT);                                         // punta en el espacio del modelo (px)
        float bx = VT.x * fkk, by = VT.y * fkk, bz = VT.z * fkk;
        double wx = fex + bx * fcos + bz * fsin, wy = fey + by, wz = fez - bx * fsin + bz * fcos;

        if (bs.lastT != ftime) step(bs, b.name, wx, wy, wz);

        float dx = (float) (bs.sx - wx) * finten * GAIN, dy = (float) (bs.sy - wy) * finten * GAIN, dz = (float) (bs.sz - wz) * finten * GAIN;
        float mx = (dx * fcos - dz * fsin) / fkk, my = dy / fkk, mz = (dx * fsin + dz * fcos) / fkk;   // de vuelta al modelo (px)
        mp.getNormalizedRotation(QI).invert();
        V1.set(mx, my, mz).rotate(QI).add(V0);                            // punta deseada en el marco del padre
        if (V0.lengthSquared() < 1e-6f || V1.lengthSquared() < 1e-6f) return null;
        bs.q.rotationTo(V0, V1);
        float ang = (float) Math.toDegrees(2.0 * Math.acos(Math.max(-1f, Math.min(1f, bs.q.w))));
        if (ang > MAX_ANGLE) { QS.identity().slerp(bs.q, MAX_ANGLE / ang); bs.q.set(QS); }
        return bs.q;
    }

    private static void step(BoneSim bs, String name, double wx, double wy, double wz) {
        float dt = Float.isNaN(bs.lastT) ? 0f : ftime - bs.lastT;
        double jx = wx - bs.wx, jy = wy - bs.wy, jz = wz - bs.wz;
        boolean reset = !bs.init || dt < 0f || dt > 1f || jx * jx + jy * jy + jz * jz > 64.0;   // primer frame, pausa larga o teletransporte
        bs.lastT = ftime;
        if (reset) {
            bs.sx = bs.wx = wx; bs.sy = bs.wy = wy; bs.sz = bs.wz = wz;
            bs.init = true;
            return;
        }
        if (dt < 1e-4f) return;       // mismo instante (segundo render) o juego en pausa
        dt = Math.min(dt, 0.05f);
        float var = 0.85f + (Math.abs(name.hashCode()) % 31) / 100f;       // cada parte con su propia frecuencia
        float w = 2f * (float) Math.PI * 3.2f * var;
        float c = 2f * 0.24f * w;
        int n = Math.max(1, (int) Math.ceil(dt / (1f / 120f)));
        float h = dt / n;
        for (int i = 1; i <= n; i++) {
            float f = i / (float) n;
            double tx = bs.wx + (wx - bs.wx) * f, ty = bs.wy + (wy - bs.wy) * f, tz = bs.wz + (wz - bs.wz) * f;
            bs.vx += (float) (w * w * (tx - bs.sx) - c * bs.vx) * h;
            bs.vy += (float) (w * w * (ty - bs.sy) - c * bs.vy) * h;
            bs.vz += (float) (w * w * (tz - bs.sz) - c * bs.vz) * h;
            bs.sx += bs.vx * h; bs.sy += bs.vy * h; bs.sz += bs.vz * h;
        }
        bs.wx = wx; bs.wy = wy; bs.wz = wz;
        double ex = bs.sx - wx, ey = bs.sy - wy, ez = bs.sz - wz, l2 = ex * ex + ey * ey + ez * ez;
        if (l2 > 9.0) { double k = 3.0 / Math.sqrt(l2); bs.sx = wx + ex * k; bs.sy = wy + ey * k; bs.sz = wz + ez * k; }   // tope: 3 bloques
    }
}
