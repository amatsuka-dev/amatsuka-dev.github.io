package com.morphzuka.render;

import com.morphzuka.GunItem;
import com.morphzuka.net.ClientNet;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.Util;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Contorno de "esto es en lo que te vas a convertir": con la RoZuka en la mano, el bloque (o la entidad) al que apuntas se
 * rodea con un contorno de color que late suavemente. Verde = bloque, azul = entidad / jugador.
 * No se dibuja agachado (agachado + clic = volver a la forma normal) ni si el servidor te bloqueo el menu.
 */
public final class MorphTarget {
    private MorphTarget() {}

    private static final float GROW = 0.004f;   // un pelin mas grande que el contorno vanilla para que no parpadee (z-fighting)

    /** Se engancha a WorldRenderEvents.AFTER_ENTITIES. */
    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        if (!GunItem.isGun(mc.player.getMainHandStack()) || mc.player.isSneaking() || ClientNet.menuLocked) return;
        HitResult hit = mc.crosshairTarget;
        MatrixStack m = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        if (hit == null || m == null || vcp == null) return;

        float pulse = 0.75f + 0.25f * MathHelper.sin(Util.getMeasuringTimeMs() / 180f);
        Vec3d cam = ctx.camera().getPos();
        try {
            if (hit instanceof BlockHitResult bh && hit.getType() == HitResult.Type.BLOCK) {
                BlockPos pos = bh.getBlockPos();
                BlockState st = mc.world.getBlockState(pos);
                if (st.isAir()) return;
                VertexConsumer vc = vcp.getBuffer(RenderLayer.getLines());
                m.push();
                m.translate(-cam.x, -cam.y, -cam.z);
                st.getOutlineShape(mc.world, pos, ShapeContext.of(mc.player)).forEachBox((x1, y1, z1, x2, y2, z2) ->
                        WorldRenderer.drawBox(m, vc, new Box(x1, y1, z1, x2, y2, z2).offset(pos).expand(GROW), 0.35f * pulse, 1f * pulse, 0.55f * pulse, 1f));
                m.pop();
            } else if (hit instanceof EntityHitResult eh && hit.getType() == HitResult.Type.ENTITY) {
                Entity e = eh.getEntity();
                float td = mc.getRenderTickCounter().getTickDelta(false);
                Vec3d d = new Vec3d(MathHelper.lerp(td, e.prevX, e.getX()) - e.getX(),
                        MathHelper.lerp(td, e.prevY, e.getY()) - e.getY(),
                        MathHelper.lerp(td, e.prevZ, e.getZ()) - e.getZ());
                VertexConsumer vc = vcp.getBuffer(RenderLayer.getLines());
                m.push();
                m.translate(-cam.x, -cam.y, -cam.z);
                WorldRenderer.drawBox(m, vc, e.getBoundingBox().offset(d).expand(0.02), 0.35f * pulse, 0.7f * pulse, 1f * pulse, 1f);
                m.pop();
            }
        } catch (Throwable t) {
            com.morphzuka.model.ModelManager.LOG.warn("Contorno del morph: fallo al dibujar: {}", t.toString());
        }
    }
}
