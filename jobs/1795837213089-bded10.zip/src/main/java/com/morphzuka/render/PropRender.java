package com.morphzuka.render;

import com.morphzuka.model.ModelManager;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionf;

/**
 * Objetos de ejemplo (bloque, espada, item) que se dibujan vinculados a un grupo del modelo, para previsualizar
 * donde caeria algo en la mano, la espalda, etc. Solo se dibujan en el Editor 3D. Unidades: pixeles del modelo
 * (16 px = 1 bloque), relativas al pivote del grupo al que estan vinculados.
 */
public final class PropRender {
    private PropRender() {}

    public static final String BLOCK = "BLOCK", SWORD = "SWORD", ITEM = "ITEM";
    public static final String[] KINDS = {BLOCK, SWORD, ITEM};

    private static final String[] BLOCKS = {"minecraft:grass_block", "minecraft:stone", "minecraft:oak_planks", "minecraft:glass",
            "minecraft:diamond_block", "minecraft:gold_block", "minecraft:tnt", "minecraft:bookshelf"};
    private static final String[] SWORDS = {"minecraft:diamond_sword", "minecraft:wooden_sword", "minecraft:stone_sword",
            "minecraft:iron_sword", "minecraft:golden_sword", "minecraft:netherite_sword"};
    private static final String[] ITEMS = {"minecraft:apple", "minecraft:stick", "minecraft:bow", "minecraft:diamond_pickaxe",
            "minecraft:totem_of_undying", "minecraft:ender_pearl", "minecraft:elytra", "minecraft:diamond_helmet"};

    private static final Quaternionf Q = new Quaternionf();

    private static final String[] HAND_ITEMS = {"minecraft:diamond_sword", "minecraft:bow", "minecraft:apple", "minecraft:diamond_pickaxe",
            "minecraft:shield", "minecraft:torch", "minecraft:totem_of_undying", "minecraft:trident", "minecraft:fishing_rod"};

    public static String label(String kind) {
        if (Anchors.isAnchor(kind)) return Anchors.label(kind);
        return switch (kind == null ? "" : kind) { case BLOCK -> "Bloque"; case SWORD -> "Espada"; default -> "Item"; };
    }

    public static String[] presets(String kind) {
        if (Anchors.isHand(kind)) return HAND_ITEMS;
        return switch (kind == null ? "" : kind) { case BLOCK -> BLOCKS; case SWORD -> SWORDS; default -> ITEMS; };
    }

    public static String defaultRef(String kind) { return presets(kind)[0]; }

    /** El id existe en el registro de bloques (BLOCK) o de items (SWORD / ITEM). */
    public static boolean exists(String kind, String ref) {
        Identifier id = Identifier.tryParse(ref == null ? "" : ref.trim());
        if (id == null) return false;
        if (BLOCK.equals(kind)) return Registries.BLOCK.containsId(id);
        return Registries.ITEM.containsId(id) && !id.equals(Identifier.of("minecraft", "air"));
    }

    /** BlockState, ItemStack, o null si el id no existe. Se guarda en el propio objeto mientras no cambie. */
    private static Object resolve(ModelManager.Prop p) {
        String key = p.kind + "|" + p.ref;
        if (key.equals(p.cacheKey)) return p.cache instanceof Boolean ? null : p.cache;
        Object r = null;
        Identifier id = Identifier.tryParse(p.ref == null ? "" : p.ref.trim());
        if (id != null) {
            if (BLOCK.equals(p.kind)) {
                Block b = Registries.BLOCK.getOrEmpty(id).orElse(null);
                if (b != null) r = b.getDefaultState();
            } else {
                Item it = Registries.ITEM.getOrEmpty(id).orElse(null);
                if (it != null && it != Items.AIR) r = new ItemStack(it);
            }
        }
        p.cacheKey = key;
        p.cache = r == null ? Boolean.FALSE : r;
        return r;
    }

    /** Dibuja el objeto con el origen de la pila de matrices en el pivote del grupo. */
    public static void render(ModelManager.Prop p, MatrixStack m, VertexConsumerProvider vcp, int light) {
        if (p == null || !p.visible || vcp == null) return;
        if (Anchors.isAnchor(p.kind)) { renderAnchorSample(p, m, vcp, light); return; }
        Object r = resolve(p);
        if (r == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        m.push();
        try {
            m.translate(p.pos[0], p.pos[1], p.pos[2]);
            if (p.rot[0] != 0f || p.rot[1] != 0f || p.rot[2] != 0f) {
                Q.rotationZYX((float) Math.toRadians(p.rot[2]), (float) Math.toRadians(p.rot[1]), (float) Math.toRadians(p.rot[0]));
                m.multiply(Q);
            }
            m.scale(16f * Math.max(0.01f, p.scale[0]), 16f * Math.max(0.01f, p.scale[1]), 16f * Math.max(0.01f, p.scale[2]));
            if (r instanceof BlockState st) {
                m.translate(-0.5f, -0.5f, -0.5f);
                mc.getBlockRenderManager().renderBlockAsEntity(st, m, vcp, light, OverlayTexture.DEFAULT_UV);
            } else if (r instanceof ItemStack is) {
                ModelTransformationMode mode = SWORD.equals(p.kind) ? ModelTransformationMode.THIRD_PERSON_RIGHT_HAND : ModelTransformationMode.FIXED;
                mc.getItemRenderer().renderItem(is, mode, light, OverlayTexture.DEFAULT_UV, m, vcp, mc.world, 0);
            }
        } catch (Throwable t) {
            p.cache = Boolean.FALSE;   // no se vuelve a intentar mientras no cambie el id
            ModelManager.LOG.warn("Objeto de ejemplo {} fallo: {}", p.ref, t.toString());
        } finally {
            m.pop();
        }
    }

    // ------------------------------------------------------------ puntos de anclaje (mano, ...)

    /** Pone la posicion / rotacion / escala que el usuario eligio para el punto (px respecto al pivote del grupo). */
    private static void applyUser(ModelManager.Prop p, MatrixStack m) { applyUser(p, m, 0); }

    /**
     * @param hand 0 = no es una mano, 1 = derecha, 2 = izquierda. En las manos, rotar y escalar giran alrededor del agarre del item
     *             (no del pivote del brazo) mientras 'gripPivot' este activo: asi el item gira "en la mano".
     */
    private static void applyUser(ModelManager.Prop p, MatrixStack m, int hand) {
        if (p == null) return;
        m.translate(p.pos[0], p.pos[1], p.pos[2]);
        float[] gr = hand != 0 && p.gripPivot ? Anchors.grip(hand == 1) : null;
        if (gr != null) m.translate(gr[0], gr[1], gr[2]);
        if (p.rot[0] != 0f || p.rot[1] != 0f || p.rot[2] != 0f) {
            Q.rotationZYX((float) Math.toRadians(p.rot[2]), (float) Math.toRadians(p.rot[1]), (float) Math.toRadians(p.rot[0]));
            m.multiply(Q);
        }
        m.scale(Math.max(0.01f, p.scale[0]), Math.max(0.01f, p.scale[1]), Math.max(0.01f, p.scale[2]));
        if (gr != null) m.translate(-gr[0], -gr[1], -gr[2]);
    }

    /**
     * Deja la pila en el sistema de coordenadas de vanilla (Y hacia abajo, X invertido, unidades de bloque) con el origen en
     * el punto: asi las posiciones del juego (que estan escritas para el esqueleto vanilla) valen tal cual.
     */
    private static void toVanillaFrame(MatrixStack m) {
        m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(180f));
        m.scale(16f, 16f, 16f);
    }

    /** Posicion vanilla de un item en la mano (la misma que usa el juego con el esqueleto de jugador). */
    private static void handPose(MatrixStack m, boolean right) {
        m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90f));
        m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180f));
        m.translate((right ? 1f : -1f) / 16f, 0.125f, -0.625f);
    }

    /** Item en la mano con el punto de agarre configurado. La pila esta en el pivote del grupo (px). */
    public static void renderHeld(LivingEntity e, ItemStack st, boolean right, ModelManager.Prop p,
                                  MatrixStack m, VertexConsumerProvider vcp, int light, int overlay) {
        if (st == null || st.isEmpty() || vcp == null) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        m.push();
        try {
            applyUser(p, m, right ? 1 : 2);
            toVanillaFrame(m);
            handPose(m, right);
            ModelTransformationMode mode = right ? ModelTransformationMode.THIRD_PERSON_RIGHT_HAND : ModelTransformationMode.THIRD_PERSON_LEFT_HAND;
            mc.getItemRenderer().renderItem(e, st, mode, !right, m, vcp, e == null ? mc.world : e.getWorld(), light, overlay,
                    (e == null ? 0 : e.getId()) + mode.ordinal());
        } catch (Throwable t) {
            ModelManager.LOG.warn("Item en la mano fallo: {}", t.toString());
        } finally {
            m.pop();
        }
    }

    private static net.minecraft.client.render.entity.model.BipedEntityModel<LivingEntity> armorModel;
    private static net.minecraft.client.model.ModelPart cloakPart;
    private static net.minecraft.client.render.entity.model.ElytraEntityModel<LivingEntity> elytraModel;

    /** Muestra de capa / elytra / loro: lo mismo que dibuja el juego, en el marco vanilla del punto. */
    private static void renderFeatureSample(ModelManager.Prop p, MatrixStack m, VertexConsumerProvider vcp, int light) {
        if (p.cache instanceof Boolean) return;   // ya fallo: no se reintenta
        MinecraftClient mc = MinecraftClient.getInstance();
        m.push();
        try {
            applyUser(p, m);
            if (Anchors.PARROT_L.equals(p.kind) || Anchors.PARROT_R.equals(p.kind)) {
                // un huevo de loro donde se sienta el loro (hombro, mirando al frente)
                m.translate(Anchors.PARROT_L.equals(p.kind) ? -6.4f : 6.4f, 5f, 0f);
                m.scale(9f, 9f, 9f);
                mc.getItemRenderer().renderItem(new ItemStack(Items.PARROT_SPAWN_EGG), ModelTransformationMode.FIXED, light,
                        OverlayTexture.DEFAULT_UV, m, vcp, mc.world, 0);
                return;
            }
            toVanillaFrame(m);
            if (Anchors.isArmor(p.kind)) {
                if (armorModel == null)
                    armorModel = new net.minecraft.client.render.entity.model.BipedEntityModel<>(
                            mc.getEntityModelLoader().getModelPart(net.minecraft.client.render.entity.model.EntityModelLayers.PLAYER_OUTER_ARMOR));
                var am = armorModel;
                net.minecraft.client.model.ModelPart[] all = {am.head, am.hat, am.body, am.rightArm, am.leftArm, am.rightLeg, am.leftLeg};
                for (net.minecraft.client.model.ModelPart mp : all) mp.visible = false;
                net.minecraft.client.model.ModelPart show = switch (p.kind) {
                    case Anchors.ARMOR_HEAD -> am.head;
                    case Anchors.ARMOR_BODY -> am.body;
                    case Anchors.ARMOR_ARM_R -> am.rightArm;
                    case Anchors.ARMOR_ARM_L -> am.leftArm;
                    case Anchors.ARMOR_LEG_R -> am.rightLeg;
                    default -> am.leftLeg;
                };
                show.visible = true;
                float[] pv = {show.pivotX, show.pivotY, show.pivotZ, show.pitch, show.yaw, show.roll};
                show.setPivot(0f, 0f, 0f);
                show.setAngles(0f, 0f, 0f);
                am.render(m, vcp.getBuffer(net.minecraft.client.render.RenderLayer.getArmorCutoutNoCull(
                        Identifier.of("minecraft", "textures/models/armor/iron_layer_1.png"))), light, OverlayTexture.DEFAULT_UV, 0xFFFFFFFF);
                show.setPivot(pv[0], pv[1], pv[2]);
                show.setAngles(pv[3], pv[4], pv[5]);
                return;
            }
            m.translate(0f, 0f, 0.125f);
            if (Anchors.CAPE.equals(p.kind)) {
                if (cloakPart == null)
                    cloakPart = mc.getEntityModelLoader().getModelPart(net.minecraft.client.render.entity.model.EntityModelLayers.PLAYER).getChild("cloak");
                Identifier tex = mc.player != null && mc.player.getSkinTextures().capeTexture() != null
                        ? mc.player.getSkinTextures().capeTexture() : Identifier.of("minecraft", "textures/block/white_wool.png");
                m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(6f));
                cloakPart.render(m, vcp.getBuffer(net.minecraft.client.render.RenderLayer.getEntitySolid(tex)), light, OverlayTexture.DEFAULT_UV);
            } else {
                if (elytraModel == null)
                    elytraModel = new net.minecraft.client.render.entity.model.ElytraEntityModel<>(
                            mc.getEntityModelLoader().getModelPart(net.minecraft.client.render.entity.model.EntityModelLayers.ELYTRA));
                if (mc.player != null) elytraModel.setAngles(mc.player, 0f, 0f, 0f, 0f, 0f);
                elytraModel.render(m, vcp.getBuffer(net.minecraft.client.render.RenderLayer.getArmorCutoutNoCull(
                        Identifier.of("minecraft", "textures/entity/elytra.png"))), light, OverlayTexture.DEFAULT_UV, 0xFFFFFFFF);
            }
        } catch (Throwable t) {
            p.cache = Boolean.FALSE;   // no se vuelve a intentar dibujar la muestra
            ModelManager.LOG.warn("Muestra de {} fallo: {}", p.kind, t.toString());
        } finally {
            m.pop();
        }
    }

    /** Muestra del punto en el Editor 3D (el item de ejemplo en la mano, la capa, las alas...). */
    private static void renderAnchorSample(ModelManager.Prop p, MatrixStack m, VertexConsumerProvider vcp, int light) {
        if (Anchors.isFeature(p.kind)) { renderFeatureSample(p, m, vcp, light); return; }
        if (Anchors.isHand(p.kind)) {
            Object r = resolve(p);
            if (!(r instanceof ItemStack is)) return;
            MinecraftClient mc = MinecraftClient.getInstance();
            boolean right = Anchors.HAND_R.equals(p.kind);
            m.push();
            try {
                applyUser(p, m, right ? 1 : 2);
                toVanillaFrame(m);
                handPose(m, right);
                ModelTransformationMode mode = right ? ModelTransformationMode.THIRD_PERSON_RIGHT_HAND : ModelTransformationMode.THIRD_PERSON_LEFT_HAND;
                mc.getItemRenderer().renderItem(is, mode, light, OverlayTexture.DEFAULT_UV, m, vcp, mc.world, 0);
            } catch (Throwable t) {
                p.cache = Boolean.FALSE;
                ModelManager.LOG.warn("Muestra de {} fallo: {}", p.kind, t.toString());
            } finally {
                m.pop();
            }
        }
    }
}
