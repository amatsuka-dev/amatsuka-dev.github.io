package com.morphzuka.render;

import com.morphzuka.model.ModelManager;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.SinglePartEntityModel;
import net.minecraft.entity.AnimationState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Detecta, dentro de los .class del juego y de los mods, que entidades traen animaciones y de que tipo:
 * <ul>
 *   <li><b>Keyframes</b>: el .class del modelo usa constantes {@code Animation} (las de Camel, Frog, Warden, Sniffer...);
 *       se lee el pool de constantes del propio .class buscando campos de ese tipo y se dice en que clases viven.</li>
 *   <li><b>Estados</b>: la entidad tiene campos {@code AnimationState} (idle, walking, attacking...).</li>
 *   <li><b>Procedural</b>: el modelo sobrescribe {@code setAngles} / {@code animateModel} y calcula el movimiento con formulas
 *       (el conejo, el cerdo, la gallina...).</li>
 * </ul>
 * Todo se hace por estructura (tipos y firmas), nunca por nombre, porque en el juego sin modo desarrollo los nombres de las
 * clases y metodos de Minecraft estan ofuscados (class_1234).
 */
public final class ClassAnimScan {
    private ClassAnimScan() {}

    public record Report(String entityClass, String modelClass, boolean hasModelParts, boolean singlePart,
                         boolean overridesSetAngles, boolean overridesAnimateModel,
                         List<String> keyframeOwners, int keyframeRefs, List<String> stateFields, String driver) {

        public boolean keyframes() { return keyframeRefs > 0; }

        public boolean states() { return !stateFields.isEmpty(); }

        /** Resumen corto de una linea. */
        public String kind() {
            if (!hasModelParts) return "Sin ModelPart (render propio del mod)";
            List<String> k = new ArrayList<>();
            if (keyframes()) k.add("Keyframes");
            if (states()) k.add("Estados");
            if (overridesSetAngles || overridesAnimateModel) k.add("Procedural");
            if (k.isEmpty()) k.add("Solo pose base");
            return String.join(" + ", k);
        }

        public boolean any() { return keyframes() || states() || overridesSetAngles || overridesAnimateModel; }
    }

    private static final Map<Class<?>, Report> CACHE = new HashMap<>();
    private static Method baseSetAngles, baseAnimate;
    private static boolean baseTried;
    private static Class<?> animCls;
    private static boolean animTried;

    public static void clearCache() { CACHE.clear(); }

    // ------------------------------------------------------------------ firmas base (por estructura, no por nombre)

    private static void initBase() {
        if (baseTried) return;
        baseTried = true;
        try {
            for (Method m : EntityModel.class.getDeclaredMethods()) {
                Class<?>[] p = m.getParameterTypes();
                if (m.getReturnType() != void.class || p.length == 0 || p[0] != Entity.class) continue;
                boolean floats = true;
                for (int i = 1; i < p.length; i++) if (p[i] != float.class) floats = false;
                if (!floats) continue;
                if (p.length == 6) baseSetAngles = m;
                else if (p.length == 4) baseAnimate = m;
            }
        } catch (Throwable t) {
            ModelManager.LOG.warn("No se pudieron leer las firmas de EntityModel: {}", t.toString());
        }
    }

    /** La clase Animation (la de los keyframes), sacada de los metodos de SinglePartEntityModel que reciben AnimationState. */
    private static Class<?> animationClass() {
        if (animTried) return animCls;
        animTried = true;
        try {
            for (Method m : SinglePartEntityModel.class.getDeclaredMethods()) {
                Class<?>[] p = m.getParameterTypes();
                if (p.length >= 3 && p[0] == AnimationState.class) { animCls = p[1]; break; }
            }
        } catch (Throwable t) {
            ModelManager.LOG.warn("No se pudo localizar la clase Animation: {}", t.toString());
        }
        return animCls;
    }

    private static String declaringBelowBase(Class<?> model, Method base) {
        if (base == null) return null;
        for (Class<?> k = model; k != null && k != EntityModel.class && k != Object.class; k = k.getSuperclass()) {
            try {
                k.getDeclaredMethod(base.getName(), base.getParameterTypes());
                return k.getName();
            } catch (NoSuchMethodException ignored) {
            } catch (Throwable t) {
                return null;
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ lectura del .class

    private static byte[] bytes(Class<?> c) {
        String res = c.getName().replace('.', '/') + ".class";
        ClassLoader cl = c.getClassLoader();
        try (InputStream in = cl == null ? ClassLoader.getSystemResourceAsStream(res) : cl.getResourceAsStream(res)) {
            return in == null ? null : in.readAllBytes();
        } catch (Throwable t) {
            return null;
        }
    }

    /**
     * Busca en el pool de constantes del .class las referencias a campos cuyo tipo es {@code typeInternal}.
     * @return clases (nombre interno) que los contienen, y cuantas referencias hay (por la lista 'count')
     */
    static Set<String> fieldRefsOfType(byte[] b, String typeInternal, int[] count) {
        Set<String> owners = new TreeSet<>();
        if (b == null || typeInternal == null) return owners;
        String want = "L" + typeInternal + ";";
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(b))) {
            if (in.readInt() != 0xCAFEBABE) return owners;
            in.readUnsignedShort();
            in.readUnsignedShort();
            int n = in.readUnsignedShort();
            String[] utf = new String[n];
            int[] tag = new int[n], a = new int[n], c = new int[n];
            for (int i = 1; i < n; i++) {
                int t = in.readUnsignedByte();
                tag[i] = t;
                switch (t) {
                    case 1 -> utf[i] = in.readUTF();
                    case 3, 4 -> in.readInt();
                    case 5, 6 -> { in.readLong(); i++; }
                    case 7, 8, 16, 19, 20 -> a[i] = in.readUnsignedShort();
                    case 9, 10, 11, 12, 17, 18 -> { a[i] = in.readUnsignedShort(); c[i] = in.readUnsignedShort(); }
                    case 15 -> { in.readUnsignedByte(); in.readUnsignedShort(); }
                    default -> { return owners; }       // etiqueta desconocida: no seguimos
                }
            }
            for (int i = 1; i < n; i++) {
                if (tag[i] != 9) continue;                // Fieldref
                int nat = c[i];
                if (nat <= 0 || nat >= n || tag[nat] != 12) continue;
                String desc = utf[c[nat]];
                if (!want.equals(desc)) continue;
                int cls = a[i];
                if (cls <= 0 || cls >= n || tag[cls] != 7) continue;
                String owner = utf[a[cls]];
                if (owner != null) owners.add(owner.replace('/', '.'));
                count[0]++;
            }
        } catch (Throwable ignored) { }
        return owners;
    }

    private static String simple(String cls) {
        int i = cls.lastIndexOf('.');
        String s = i >= 0 ? cls.substring(i + 1) : cls;
        return s.replace('$', '.');
    }

    // ------------------------------------------------------------------ informe de una entidad

    /** Informe de esa entidad (cacheado por clase de entidad). null si no es un ser vivo. */
    public static Report of(Entity e) {
        if (e == null) return null;
        Report r = CACHE.get(e.getClass());
        if (r != null) return r;
        r = build(e);
        CACHE.put(e.getClass(), r);
        return r;
    }

    private static Report build(Entity e) {
        initBase();
        Object model = PartTree.modelOf(e);
        List<String> states = new ArrayList<>();
        for (Class<?> k = e.getClass(); k != null && k != Entity.class && k != Object.class; k = k.getSuperclass()) {
            if (k == LivingEntity.class) break;
            try {
                for (Field f : k.getDeclaredFields()) {
                    if (Modifier.isStatic(f.getModifiers()) || f.getType() != AnimationState.class) continue;
                    states.add(simple(k.getName()) + "." + f.getName());
                }
            } catch (Throwable ignored) { }
        }
        String driver = MorphAnim.driverName(e);
        if (model == null) {
            return new Report(e.getClass().getName(), "", false, false, false, false, List.of(), 0, states, driver);
        }
        Class<?> mc = model.getClass();
        boolean single = model instanceof SinglePartEntityModel<?>;
        boolean sa = declaringBelowBase(mc, baseSetAngles) != null;
        boolean am = declaringBelowBase(mc, baseAnimate) != null;

        Set<String> owners = new TreeSet<>();
        int[] cnt = {0};
        Class<?> anim = animationClass();
        if (anim != null) {
            String internal = anim.getName().replace('.', '/');
            // el modelo y sus clases padre (hasta EntityModel) pueden usar las constantes
            for (Class<?> k = mc; k != null && k != EntityModel.class && k != SinglePartEntityModel.class && k != Object.class; k = k.getSuperclass())
                owners.addAll(fieldRefsOfType(bytes(k), internal, cnt));
        }
        List<String> own = new ArrayList<>();
        for (String o : owners) own.add(simple(o));
        return new Report(e.getClass().getName(), mc.getName(), true, single, sa, am, own, cnt[0], states, driver);
    }

    // ------------------------------------------------------------------ informe de todo el registro

    /**
     * Recorre todas las entidades registradas (vanilla y de mods), las crea en el mundo del cliente solo para mirarlas y
     * escribe config/morphzuka_animscan.txt. Devuelve un resumen para el chat.
     */
    public static String scanAll() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return "Entra a un mundo primero";
        clearCache();
        List<String> keyf = new ArrayList<>(), stat = new ArrayList<>(), proc = new ArrayList<>(), none = new ArrayList<>(), raw = new ArrayList<>();
        int total = 0, failed = 0;
        List<Identifier> ids = new ArrayList<>(Registries.ENTITY_TYPE.getIds());
        ids.sort(Identifier::compareTo);
        for (Identifier id : ids) {
            EntityType<?> t = Registries.ENTITY_TYPE.get(id);
            if (t == EntityType.PLAYER) continue;
            total++;
            Entity e;
            try { e = t.create(mc.world); } catch (Throwable ex) { e = null; }
            if (e == null) { failed++; continue; }
            Report r;
            try { r = of(e); } catch (Throwable ex) { failed++; continue; }
            if (r == null) { failed++; continue; }
            StringBuilder sb = new StringBuilder();
            sb.append(id).append("  [").append(r.kind()).append("]\n");
            sb.append("    entidad: ").append(r.entityClass()).append('\n');
            if (r.hasModelParts()) sb.append("    modelo : ").append(r.modelClass()).append(r.singlePart() ? "  (SinglePartEntityModel)" : "").append('\n');
            if (r.keyframes()) sb.append("    keyframes: ").append(r.keyframeRefs()).append(" referencias en ").append(String.join(", ", r.keyframeOwners())).append('\n');
            if (r.states()) sb.append("    estados : ").append(String.join(", ", r.stateFields())).append('\n');
            if (r.overridesSetAngles() || r.overridesAnimateModel())
                sb.append("    procedural: ").append(r.overridesSetAngles() ? "setAngles " : "").append(r.overridesAnimateModel() ? "animateModel" : "").append('\n');
            if (!r.driver().isEmpty()) sb.append("    MorphZuka: ").append(r.driver()).append('\n');
            String line = sb.toString();
            if (!r.hasModelParts()) raw.add(line);
            else if (r.keyframes()) keyf.add(line);
            else if (r.states()) stat.add(line);
            else if (r.overridesSetAngles() || r.overridesAnimateModel()) proc.add(line);
            else none.add(line);
        }
        StringBuilder out = new StringBuilder();
        out.append("MorphZuka - clases con animaciones (").append(total).append(" entidades, ").append(failed).append(" no se pudieron crear)\n");
        out.append("Keyframes (Animation): ").append(keyf.size()).append("   Estados (AnimationState): ").append(stat.size())
                .append("   Procedural: ").append(proc.size()).append("   Sin ModelPart: ").append(raw.size()).append("\n\n");
        section(out, "KEYFRAMES (el .class del modelo usa constantes Animation)", keyf);
        section(out, "ESTADOS (la entidad tiene AnimationState)", stat);
        section(out, "PROCEDURAL (el modelo calcula el movimiento en setAngles / animateModel)", proc);
        section(out, "SOLO POSE BASE", none);
        section(out, "SIN ModelPart (render propio del mod, p. ej. Cobblemon)", raw);
        try {
            Path f = FabricLoader.getInstance().getConfigDir().resolve("morphzuka_animscan.txt");
            Files.writeString(f, out.toString());
        } catch (Throwable ex) {
            ModelManager.LOG.warn("No se pudo escribir el informe de animaciones: {}", ex.toString());
        }
        return keyf.size() + " con keyframes, " + stat.size() + " con estados, " + proc.size() + " procedurales, "
                + raw.size() + " sin ModelPart. Informe: config/morphzuka_animscan.txt";
    }

    private static void section(StringBuilder out, String title, List<String> items) {
        out.append("==== ").append(title).append(" : ").append(items.size()).append(" ====\n");
        for (String s : items) out.append(s);
        out.append('\n');
    }
}
