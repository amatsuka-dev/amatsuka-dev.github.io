package com.morphzuka.render;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.morphzuka.Role;
import com.morphzuka.model.ModelManager;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.model.ModelPart;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Ajustes de animacion de cada entidad en la que te transformas (config/morphzuka_entities.json):
 * que parte de su modelo es la cabeza, los brazos, las piernas..., y como se mueve en reposo (idle).
 * {@link #apply} se llama justo despues de que el juego coloque el modelo y sobrescribe solo las partes con rol:
 * la cabeza sigue la camara, los brazos dan el golpe de Minecraft y piernas/brazos balancean al caminar.
 */
public final class EntityCfg {
    private EntityCfg() {}

    public static final String[] IDLE_KEYS = {"NONE", "MC", "BREATH", "SWAY"};
    public static final String[] IDLE_LABELS = {"Ninguno", "Minecraft (brazos)", "Respirar", "Balanceo"};
    public static final String[] IDLE_INFO = {
            "No se añade ningún movimiento en reposo.",
            "Los brazos se balancean suave, como el jugador normal.",
            "Cuerpo, cabeza y brazos suben y bajan despacio.",
            "El cuerpo se mece y la cola (si hay) se mueve."};
    public static final Role[] ROLE_CYCLE = {Role.NONE, Role.HEAD, Role.BODY, Role.RIGHT_ARM, Role.LEFT_ARM, Role.RIGHT_LEG, Role.LEFT_LEG, Role.TAIL};

    public static final class Data {
        public Map<String, String> roles = new LinkedHashMap<>();   // ruta de la parte -> Role
        public String idle = "NONE";
        public float idleAmount = 1f;
        public boolean head = true;          // la cabeza (con rol) sigue la camara
        public boolean attack = true;        // el brazo (con rol) da el golpe de Minecraft
        public boolean walk = true;          // brazos y piernas (con rol) balancean al caminar
        public boolean rightHanded = true;   // false = golpea con el brazo izquierdo
        public boolean nativeAnim = true;    // el mob usa su propia animacion (salto del conejo, aleteo...): se ejecuta su tick
    }

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final java.lang.reflect.Type TYPE = new TypeToken<Map<String, Data>>() {}.getType();
    private static final Map<String, Data> ALL = new TreeMap<>();
    private static String last = "";
    private static final float RAD = (float) (Math.PI / 180.0);

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("morphzuka_entities.json"); }

    /** Ajustes guardados de esa forma, o unos por defecto (que no se guardan hasta que cambies algo). */
    public static Data of(String key) {
        Data d = key == null ? null : ALL.get(key);
        return d != null ? d : new Data();
    }

    /** Para modificar: crea la entrada si no existia. */
    public static Data edit(String key) { return ALL.computeIfAbsent(key, k -> new Data()); }

    public static void load() {
        try {
            if (!Files.exists(file())) return;
            Map<String, Data> in = GSON.fromJson(Files.readString(file()), TYPE);
            ALL.clear();
            if (in != null) for (Map.Entry<String, Data> e : in.entrySet()) if (e.getValue() != null) ALL.put(e.getKey(), e.getValue());
            last = GSON.toJson(ALL);
        } catch (Exception e) {
            ModelManager.LOG.warn("{} invalido: {}", file().getFileName(), e.toString());
        }
    }

    public static void save() {
        String json = GSON.toJson(ALL);
        if (json.equals(last)) return;
        try {
            Files.writeString(file(), json);
            last = json;
        } catch (IOException e) {
            ModelManager.LOG.warn("No se pudo guardar {}: {}", file().getFileName(), e.toString());
        }
    }

    // ------------------------------------------------------------------ aplicar al modelo

    private static final List<ModelPart> SAVED_PARTS = new ArrayList<>();
    private static final List<float[]> SAVED = new ArrayList<>();

    private static void keep(ModelPart p) {
        SAVED_PARTS.add(p);
        SAVED.add(new float[]{p.pitch, p.yaw, p.roll});
    }

    /** Devuelve a las partes su rotacion original para no afectar a otras entidades que usan el mismo modelo. */
    public static void restore() {
        if (SAVED_PARTS.isEmpty()) return;
        for (int i = 0; i < SAVED_PARTS.size(); i++) {
            ModelPart p = SAVED_PARTS.get(i);
            float[] v = SAVED.get(i);
            p.pitch = v[0]; p.yaw = v[1]; p.roll = v[2];
        }
        SAVED_PARTS.clear();
        SAVED.clear();
    }

    public static void apply(LivingEntity e, Object model, float td) {
        if (!MorphManager.hasMorphEntities()) return;
        String key = MorphManager.keyOfEntity(e);
        if (key == null) return;
        Data d = ALL.get(key);
        if (d == null || d.roles.isEmpty()) return;
        List<PartTree.Node> nodes = PartTree.of(model);
        if (nodes.isEmpty()) return;

        List<ModelPart> head = new ArrayList<>(), body = new ArrayList<>(), tail = new ArrayList<>();
        List<ModelPart> rArm = new ArrayList<>(), lArm = new ArrayList<>(), rLeg = new ArrayList<>(), lLeg = new ArrayList<>();
        for (PartTree.Node n : nodes) {
            switch (Role.of(d.roles.get(n.path()))) {
                case HEAD -> head.add(n.part());
                case BODY -> body.add(n.part());
                case TAIL -> tail.add(n.part());
                case RIGHT_ARM -> rArm.add(n.part());
                case LEFT_ARM -> lArm.add(n.part());
                case RIGHT_LEG -> rLeg.add(n.part());
                case LEFT_LEG -> lLeg.add(n.part());
                default -> { }
            }
        }

        String idle = d.idle == null ? "NONE" : d.idle;
        float age = e.age + td;
        float limbPos = e.limbAnimator.getPos(td);
        float limbSpd = MathHelper.clamp(e.limbAnimator.getSpeed(td), 0f, 1f);
        float swing = d.attack ? e.getHandSwingProgress(td) : 0f;
        float yawN = MathHelper.clamp(MathHelper.wrapDegrees(MathHelper.lerpAngleDegrees(td, e.prevHeadYaw, e.headYaw)
                - MathHelper.lerpAngleDegrees(td, e.prevBodyYaw, e.bodyYaw)), -80f, 80f) * RAD;
        float pitch = MathHelper.lerp(td, e.prevPitch, e.getPitch()) * RAD;
        float k = Math.max(0f, d.idleAmount);
        float still = 1f - Math.min(1f, limbSpd * 2f);         // el idle se apaga al caminar

        boolean haveR = !rArm.isEmpty(), haveL = !lArm.isEmpty();
        boolean swingRight = haveR && (d.rightHanded || !haveL);
        boolean swinging = swing > 0f && (haveR || haveL);
        float twist = MathHelper.sin(MathHelper.sqrt(swing) * (float) (Math.PI * 2.0)) * 0.2f * (swingRight ? 1f : -1f);
        float f1 = 1f - swing;
        f1 = 1f - f1 * f1 * f1 * f1;
        float g = MathHelper.sin(f1 * (float) Math.PI);
        float h = MathHelper.sin(swing * (float) Math.PI) * -((d.head && !head.isEmpty() ? pitch : 0f) - 0.7f) * 0.75f;

        for (ModelPart p : head) {
            keep(p);
            if (d.head) { p.pitch = pitch; p.yaw = yawN; p.roll = 0f; }
            if (idle.equals("BREATH")) p.pitch += MathHelper.sin(age * 0.08f) * 0.02f * k * still;
            else if (idle.equals("SWAY")) p.yaw += MathHelper.sin(age * 0.04f) * 0.12f * k * still;
        }
        for (ModelPart p : body) {
            keep(p);
            if (swinging) p.yaw = twist;
            if (idle.equals("BREATH")) p.pitch += MathHelper.sin(age * 0.08f) * 0.03f * k * still;
            else if (idle.equals("SWAY")) p.roll += MathHelper.sin(age * 0.06f) * 0.05f * k * still;
        }
        for (ModelPart p : rArm) arm(p, true, d, idle, limbPos, limbSpd, age, k, still, swinging && swingRight, swing, g, h, twist);
        for (ModelPart p : lArm) arm(p, false, d, idle, limbPos, limbSpd, age, k, still, swinging && !swingRight, swing, g, h, twist);
        for (ModelPart p : rLeg) leg(p, true, d, limbPos, limbSpd);
        for (ModelPart p : lLeg) leg(p, false, d, limbPos, limbSpd);
        for (ModelPart p : tail) {
            keep(p);
            if (idle.equals("SWAY")) p.yaw = MathHelper.sin(age * 0.12f) * 0.3f * k;
        }
    }

    private static void arm(ModelPart p, boolean right, Data d, String idle, float limbPos, float limbSpd, float age, float k,
                            float still, boolean swinging, float swing, float g, float h, float twist) {
        keep(p);
        float sigma = right ? 1f : -1f;
        p.pitch = d.walk ? MathHelper.cos(limbPos * 0.6662f + (right ? (float) Math.PI : 0f)) * limbSpd : 0f;
        p.yaw = 0f;
        p.roll = 0f;
        if (idle.equals("MC")) {
            p.roll += sigma * (MathHelper.cos(age * 0.09f) * 0.05f + 0.05f) * k;
            p.pitch += sigma * MathHelper.sin(age * 0.067f) * 0.05f * k;
        } else if (idle.equals("BREATH")) {
            p.roll += sigma * MathHelper.sin(age * 0.08f) * 0.04f * k * still;
        }
        if (swinging) {
            p.pitch -= g * 1.2f + h;
            p.yaw += twist * 2f;
            p.roll += MathHelper.sin(swing * (float) Math.PI) * -0.4f;
        }
    }

    private static void leg(ModelPart p, boolean right, Data d, float limbPos, float limbSpd) {
        keep(p);
        p.pitch = d.walk ? MathHelper.cos(limbPos * 0.6662f + (right ? 0f : (float) Math.PI)) * 1.4f * limbSpd : 0f;
        p.yaw = 0f;
        p.roll = 0f;
    }
}
