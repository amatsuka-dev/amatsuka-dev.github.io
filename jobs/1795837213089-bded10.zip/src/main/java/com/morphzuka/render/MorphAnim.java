package com.morphzuka.render;

import com.morphzuka.model.ModelManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.RabbitEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Util;

import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;

/**
 * Animacion propia de los mobs en los que te transformas.
 *
 * El morph dibuja una entidad "muneco" que NO esta en el mundo, asi que el juego nunca la ejecuta (tick). Por eso todo lo
 * que el modelo lee del estado de la entidad se quedaba congelado: el salto del conejo (jumpTicks), el aleteo de gallinas y
 * loros, los tentaculos del calamar, el chafado del slime, el ataque del golem... Aqui la ejecutamos nosotros una vez por
 * tick y le damos las "ordenes" que en vanilla da la IA (saltar, golpear), deducidas de lo que hace el jugador.
 */
public final class MorphAnim {
    private MorphAnim() {}

    /** Estado propio de cada muneco. */
    private static final class St {
        long lastTickMs;
        int hopCooldown;
        float lastSwing;
        boolean wasOnGround = true;
        boolean broken;
        String driver = "";
    }

    private static final Map<Entity, St> STATE = Collections.synchronizedMap(new WeakHashMap<>());

    private static St st(Entity e) { return STATE.computeIfAbsent(e, k -> new St()); }

    /** Entidades que no se ejecutan nunca (su tick necesita estar de verdad en el mundo). */
    private static boolean denied(Entity e) {
        EntityType<?> t = e.getType();
        return t == EntityType.ENDER_DRAGON || t == EntityType.PLAYER;
    }

    /** Nombre del "conductor" que se usa para esa entidad (para el informe de clases). */
    public static String driverName(Entity e) {
        if (e == null) return "";
        EntityType<?> t = e.getType();
        if (e instanceof RabbitEntity) return "salto de conejo (hop) al caminar o saltar";
        if (t == EntityType.FROG) return "salto largo de rana al saltar";
        if (t == EntityType.IRON_GOLEM || t == EntityType.RAVAGER || t == EntityType.HOGLIN
                || t == EntityType.ZOGLIN || t == EntityType.WARDEN) return "ataque propio al golpear";
        if (e instanceof LivingEntity) return "tick propio (aleteo, tentaculos, chafado...)";
        return "";
    }

    /**
     * Un paso de animacion del muneco.
     *
     * @param moving    el jugador / la simulacion se esta desplazando por el suelo
     * @param onGround  esta en el suelo
     * @param vy        velocidad vertical del jugador
     * @param swing     progreso del golpe (0..1), como getHandSwingProgress
     * @param nativeOn  false = no se toca nada (opcion del menu)
     */
    public static void step(Entity e, boolean moving, boolean onGround, double vy, float swing, boolean nativeOn) {
        if (!nativeOn || !(e instanceof LivingEntity le) || denied(e)) return;
        St s = st(e);
        if (s.broken) return;
        long now = Util.getMeasuringTimeMs();
        if (now - s.lastTickMs < 40) return;          // el juego y la vista previa pueden llamar a la vez: un tick cada 50 ms
        s.lastTickMs = now;
        try {
            drive(le, s, moving, onGround, vy, swing);
            le.setOnGround(onGround);
            le.tick();
        } catch (Throwable t) {
            s.broken = true;
            ModelManager.LOG.warn("Animacion propia de {} desactivada: {}", e.getType().getTranslationKey(), t.toString());
        }
    }

    /** Las "ordenes" de la IA que el jugador hace con su cuerpo. */
    private static void drive(LivingEntity le, St s, boolean moving, boolean onGround, double vy, float swing) {
        boolean jumped = s.wasOnGround && !onGround && vy > 0.05;
        s.wasOnGround = onGround;
        boolean swingStart = swing > 0f && s.lastSwing == 0f;
        s.lastSwing = swing;
        if (s.hopCooldown > 0) s.hopCooldown--;

        if (le instanceof RabbitEntity) {
            // el conejo avanza a saltos: uno tras otro mientras caminas (10 ticks de salto + una pausa corta) y uno al saltar
            if (jumped || (moving && onGround && s.hopCooldown == 0)) {
                le.handleStatus((byte) 1);                   // el mismo aviso que manda el servidor: jumpDuration = 10, jumpTicks = 0
                s.hopCooldown = 13;
            }
            return;
        }
        EntityType<?> t = le.getType();
        if (t == EntityType.FROG) {
            le.setPose(!onGround && vy > 0.05 ? EntityPose.LONG_JUMPING : EntityPose.STANDING);
            return;
        }
        if (swingStart && (t == EntityType.IRON_GOLEM || t == EntityType.RAVAGER || t == EntityType.HOGLIN
                || t == EntityType.ZOGLIN || t == EntityType.WARDEN)) {
            le.handleStatus((byte) 4);                       // "atacar": el mismo aviso que manda el servidor
        }
    }

    /** Cuanto sube el cuerpo durante un salto (en bloques). Solo visual: la hitbox no cambia. 0 si no aplica. */
    public static float lift(Entity e, float td) {
        if (e instanceof RabbitEntity r) {
            try {
                float p = r.getJumpProgress(td);
                if (p <= 0f || p >= 1f) return 0f;
                return (float) Math.sin(p * Math.PI) * 0.22f;
            } catch (Throwable ignored) { }
        }
        return 0f;
    }

    /** Vuelve a activar un muneco que habia fallado (al cambiar de forma). */
    public static void reset(Entity e) { if (e != null) STATE.remove(e); }

    // ------------------------------------------------------------------ desde el jugador

    /** Llamado cada tick del cliente con el jugador al que pertenece el muneco. */
    public static void tickFor(Entity e, PlayerEntity p, boolean nativeOn) {
        if (e == null || p == null) return;
        double dx = p.getX() - p.prevX, dz = p.getZ() - p.prevZ;
        boolean moving = Math.sqrt(dx * dx + dz * dz) > 0.03;
        e.setPosition(p.getX(), p.getY(), p.getZ());
        e.setVelocity(p.getVelocity());
        step(e, moving, p.isOnGround(), p.getVelocity().y, p.handSwingProgress, nativeOn);
    }
}
