package com.morphzuka.mixin;

import com.morphzuka.model.ModelManager;
import com.morphzuka.render.BBRenderer;
import com.morphzuka.render.EntityCfg;
import com.morphzuka.render.MorphManager;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {

    @Inject(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"), cancellable = true)
    private void morphzuka$render(LivingEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                                  VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        if (entity instanceof AbstractClientPlayerEntity p && !p.isInvisible() && !p.isSpectator()) {
            if (MorphManager.render(p, yaw, tickDelta, matrices, vcp, light)) { ci.cancel(); return; } // morph: reemplaza el render vanilla
            ModelManager.Active a = ModelManager.forPlayer(p);
            if (a != null) BBRenderer.render(p, tickDelta, matrices, vcp, light, a);
        }
    }

    /** Justo despues de colocar el modelo: cabeza, brazos y piernas con rol (EntityCfg) de una entidad en la que te transformaste. */
    @Inject(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/entity/model/EntityModel;setAngles(Lnet/minecraft/entity/Entity;FFFFF)V",
                    shift = At.Shift.AFTER), require = 0)
    private void morphzuka$roles(LivingEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                                 VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        try {
            EntityCfg.apply(entity, ((LivingEntityRenderer<?, ?>) (Object) this).getModel(), tickDelta);
        } catch (Throwable t) {
            EntityCfg.restore();
        }
    }

    @Inject(method = "render(Lnet/minecraft/entity/LivingEntity;FFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("RETURN"), require = 0)
    private void morphzuka$rolesRestore(LivingEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                                        VertexConsumerProvider vcp, int light, CallbackInfo ci) {
        EntityCfg.restore();
        if (entity instanceof AbstractClientPlayerEntity p) BBRenderer.endFeatures(p);
    }

    /** Con modelo custom el modelo vanilla no se dibuja. */
    @Inject(method = "getRenderLayer", at = @At("RETURN"), cancellable = true)
    private void morphzuka$hideVanilla(LivingEntity entity, boolean showBody, boolean translucent, boolean showOutline,
                                       CallbackInfoReturnable<RenderLayer> cir) {
        if (entity instanceof AbstractClientPlayerEntity p && ModelManager.forPlayer(p) != null) cir.setReturnValue(null);
    }
}
