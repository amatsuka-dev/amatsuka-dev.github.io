package com.morphzuka.mixin;

import com.morphzuka.render.Anchors;
import com.morphzuka.render.BBRenderer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Armadura con modelo propio: en vez de dibujar la armadura entera pegada al esqueleto vanilla, se dibuja una vez por pieza
 * (cabeza, torso, cada brazo, cada pierna) y cada vez en el punto de su grupo. Cada llamada es el dibujo normal del juego
 * (texturas, adornos, brillo...) con solo esa pieza visible y puesta en el origen.
 */
@Mixin(ArmorFeatureRenderer.class)
public abstract class ArmorFeatureRendererMixin {

    @Shadow
    private void renderArmor(MatrixStack matrices, VertexConsumerProvider vcp, LivingEntity entity, EquipmentSlot slot, int light, BipedEntityModel model) {
        throw new AssertionError();
    }

    @Inject(method = "renderArmor", at = @At("HEAD"), cancellable = true, require = 0)
    private void morphzuka$perPart(MatrixStack matrices, VertexConsumerProvider vcp, LivingEntity entity, EquipmentSlot slot, int light,
                                   BipedEntityModel model, CallbackInfo ci) {
        if (BBRenderer.armorPart != null) return;                       // ya es una de nuestras llamadas por pieza
        if (!(entity instanceof AbstractClientPlayerEntity p) || !BBRenderer.hasFeatures(p)) return;
        ci.cancel();
        if (entity.getEquippedStack(slot).isEmpty()) return;
        String[] parts = switch (slot) {
            case HEAD -> new String[]{Anchors.ARMOR_HEAD};
            case CHEST -> new String[]{Anchors.ARMOR_BODY, Anchors.ARMOR_ARM_R, Anchors.ARMOR_ARM_L};
            case LEGS -> new String[]{Anchors.ARMOR_BODY, Anchors.ARMOR_LEG_R, Anchors.ARMOR_LEG_L};
            case FEET -> new String[]{Anchors.ARMOR_LEG_R, Anchors.ARMOR_LEG_L};
            default -> new String[0];
        };
        for (String part : parts) {
            if (BBRenderer.featureBegin(p, part, matrices)) continue;   // "Se dibuja: no"
            BBRenderer.armorPart = part;
            try {
                this.renderArmor(matrices, vcp, entity, slot, light, model);
            } finally {
                BBRenderer.armorPart = null;
                BBRenderer.featureEnd(matrices);
            }
        }
    }

    /** Justo despues de que el juego decida que partes se ven para esta ranura: solo la pieza actual, en su origen. */
    @Inject(method = "setVisible", at = @At("RETURN"), require = 0)
    private void morphzuka$onlyPart(BipedEntityModel model, EquipmentSlot slot, CallbackInfo ci) {
        String g = BBRenderer.armorPart;
        if (g == null) return;
        boolean h = model.head.visible, ht = model.hat.visible, b = model.body.visible, ra = model.rightArm.visible,
                la = model.leftArm.visible, rl = model.rightLeg.visible, ll = model.leftLeg.visible;
        model.head.visible = h && Anchors.ARMOR_HEAD.equals(g);
        model.hat.visible = ht && Anchors.ARMOR_HEAD.equals(g);
        model.body.visible = b && Anchors.ARMOR_BODY.equals(g);
        model.rightArm.visible = ra && Anchors.ARMOR_ARM_R.equals(g);
        model.leftArm.visible = la && Anchors.ARMOR_ARM_L.equals(g);
        model.rightLeg.visible = rl && Anchors.ARMOR_LEG_R.equals(g);
        model.leftLeg.visible = ll && Anchors.ARMOR_LEG_L.equals(g);
        for (net.minecraft.client.model.ModelPart mp : new net.minecraft.client.model.ModelPart[]{model.head, model.hat, model.body,
                model.rightArm, model.leftArm, model.rightLeg, model.leftLeg}) {
            if (!mp.visible) continue;
            mp.setPivot(0f, 0f, 0f);
            mp.setAngles(0f, 0f, 0f);
        }
    }
}
