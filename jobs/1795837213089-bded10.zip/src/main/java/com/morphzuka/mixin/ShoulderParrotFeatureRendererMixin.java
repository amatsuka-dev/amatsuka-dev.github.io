package com.morphzuka.mixin;

import com.morphzuka.render.Anchors;
import com.morphzuka.render.BBRenderer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.feature.ShoulderParrotFeatureRenderer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Los loros de los hombros los dibuja el juego (uno por llamada); aqui cada uno va a su punto "Loro der" / "Loro izq". */
@Mixin(ShoulderParrotFeatureRenderer.class)
public abstract class ShoulderParrotFeatureRendererMixin {

    @Inject(method = "renderShoulderParrot", at = @At("HEAD"), cancellable = true, require = 0)
    private void morphzuka$begin(MatrixStack matrices, VertexConsumerProvider vcp, int light, PlayerEntity player,
                                 float a, float b, float c, float d, boolean leftShoulder, CallbackInfo ci) {
        if (player instanceof AbstractClientPlayerEntity p
                && BBRenderer.featureBegin(p, leftShoulder ? Anchors.PARROT_L : Anchors.PARROT_R, matrices)) ci.cancel();
    }

    @Inject(method = "renderShoulderParrot", at = @At("RETURN"), require = 0)
    private void morphzuka$end(MatrixStack matrices, VertexConsumerProvider vcp, int light, PlayerEntity player,
                               float a, float b, float c, float d, boolean leftShoulder, CallbackInfo ci) {
        BBRenderer.featureEnd(matrices);
    }
}
