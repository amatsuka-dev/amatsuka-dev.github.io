package com.morphzuka.mixin;

import com.morphzuka.render.BBRenderer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Con modelo propio los items de las manos los dibuja BBRenderer en el punto de agarre configurado; aqui se apaga el dibujo vanilla. */
@Mixin(HeldItemFeatureRenderer.class)
public abstract class HeldItemFeatureRendererMixin {

    @Inject(method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/entity/LivingEntity;FFFFFF)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void morphzuka$skip(MatrixStack matrices, VertexConsumerProvider vcp, int light, LivingEntity entity,
                                float limbAngle, float limbDistance, float tickDelta, float animationProgress, float headYaw, float headPitch,
                                CallbackInfo ci) {
        if (entity instanceof AbstractClientPlayerEntity p && BBRenderer.drawsFeatures(p)) ci.cancel();
    }
}
