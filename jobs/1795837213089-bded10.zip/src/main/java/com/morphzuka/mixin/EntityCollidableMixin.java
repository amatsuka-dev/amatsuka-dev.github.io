package com.morphzuka.mixin;

import com.morphzuka.BlockMorphRegistry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Un jugador transformado en bloque tiene colision: los demas (y los mobs) chocan con su caja y pueden subirse encima,
 * como con un bote o un shulker. Mixin COMUN: el servidor decide las colisiones reales y el cliente las predice.
 */
@Mixin(Entity.class)
public abstract class EntityCollidableMixin {

    @Inject(method = "isCollidable", at = @At("HEAD"), cancellable = true, require = 0)
    private void morphzuka$solid(CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof PlayerEntity p && BlockMorphRegistry.solid(p)) cir.setReturnValue(true);
    }
}
