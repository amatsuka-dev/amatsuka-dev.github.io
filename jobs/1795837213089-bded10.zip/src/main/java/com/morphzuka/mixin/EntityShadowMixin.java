package com.morphzuka.mixin;

import com.morphzuka.render.MorphManager;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.world.WorldView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Un jugador transformado en bloque no proyecta la sombra redonda de jugador en el suelo. */
@Mixin(EntityRenderDispatcher.class)
public abstract class EntityShadowMixin {

    @Inject(method = "renderShadow", at = @At("HEAD"), cancellable = true, require = 0)
    private static void morphzuka$noShadow(MatrixStack matrices, VertexConsumerProvider vcp, Entity entity, float opacity, float tickDelta,
                                           WorldView world, float radius, CallbackInfo ci) {
        if (entity instanceof AbstractClientPlayerEntity p) {
            MorphManager.State st = MorphManager.stateOf(p);
            if (st != null && st.kind == MorphManager.Kind.BLOCK) ci.cancel();
        }
    }
}
