package com.morphzuka.mixin;

import com.morphzuka.BlockLock;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Jugador-bloque agachado: no hay movimiento ni salto (el agacharse se mantiene). */
@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends Input {

    @Inject(method = "tick", at = @At("RETURN"), require = 0)
    private void morphzuka$freeze(boolean slowDown, float slowDownFactor, CallbackInfo ci) {
        if (!BlockLock.locked) return;
        this.pressingForward = false;
        this.pressingBack = false;
        this.pressingLeft = false;
        this.pressingRight = false;
        this.jumping = false;
        this.movementForward = 0f;
        this.movementSideways = 0f;
    }
}
