package com.morphzuka.mixin;

import com.morphzuka.render.Anchors;
import com.morphzuka.render.BBRenderer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** La capa la dibuja el juego; aqui se mueve al punto "Capa" del modelo (o se oculta). */
@Mixin(CapeFeatureRenderer.class)
public abstract class CapeFeatureRendererMixin {

    private static final String RENDER = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/client/network/AbstractClientPlayerEntity;FFFFFF)V";

    @Inject(method = RENDER, at = @At("HEAD"), cancellable = true, require = 0)
    private void morphzuka$begin(MatrixStack matrices, VertexConsumerProvider vcp, int light, AbstractClientPlayerEntity player,
                                 float a, float b, float c, float d, float e, float f, CallbackInfo ci) {
        if (BBRenderer.featureBegin(player, Anchors.CAPE, matrices)) ci.cancel();
    }

    @Inject(method = RENDER, at = @At("RETURN"), require = 0)
    private void morphzuka$end(MatrixStack matrices, VertexConsumerProvider vcp, int light, AbstractClientPlayerEntity player,
                               float a, float b, float c, float d, float e, float f, CallbackInfo ci) {
        BBRenderer.featureEnd(matrices);
    }
}
