package com.morphzuka.mixin;

import com.morphzuka.BlockMorphRegistry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Un bloque no se mueve cuando alguien se le pega: el jugador-bloque no es empujable. */
@Mixin(LivingEntity.class)
public abstract class LivingPushableMixin {

    @Inject(method = "isPushable", at = @At("HEAD"), cancellable = true, require = 0)
    private void morphzuka$notPushable(CallbackInfoReturnable<Boolean> cir) {
        if ((Object) this instanceof PlayerEntity p && BlockMorphRegistry.solid(p)) cir.setReturnValue(false);
    }
}
