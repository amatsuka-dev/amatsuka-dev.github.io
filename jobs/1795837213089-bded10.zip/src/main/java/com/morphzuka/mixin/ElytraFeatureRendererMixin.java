package com.morphzuka.mixin;

import com.morphzuka.render.Anchors;
import com.morphzuka.render.BBRenderer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.feature.ElytraFeatureRenderer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Las alas las dibuja el juego; aqui se mueven al punto "Elytra" del modelo (o se ocultan). */
@Mixin(ElytraFeatureRenderer.class)
public abstract class ElytraFeatureRendererMixin {

    private static final String RENDER = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/entity/LivingEntity;FFFFFF)V";

    @Inject(method = RENDER, at = @At("HEAD"), cancellable = true, require = 0)
    private void morphzuka$begin(MatrixStack matrices, VertexConsumerProvider vcp, int light, LivingEntity entity,
                                 float a, float b, float c, float d, float e, float f, CallbackInfo ci) {
        if (entity instanceof AbstractClientPlayerEntity p && BBRenderer.featureBegin(p, Anchors.ELYTRA, matrices)) ci.cancel();
    }

    @Inject(method = RENDER, at = @At("RETURN"), require = 0)
    private void morphzuka$end(MatrixStack matrices, VertexConsumerProvider vcp, int light, LivingEntity entity,
                               float a, float b, float c, float d, float e, float f, CallbackInfo ci) {
        BBRenderer.featureEnd(matrices);
    }
}
