package com.morphzuka.model;

import com.google.gson.Gson;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Modelos que OTROS jugadores comparten por el servidor (paso 33). Viven solo en memoria: no se escribe nada en tu
 * carpeta morphzuka/ ni en tu config, y se borran al salir del servidor. Se usan desde ModelManager.forPlayer.
 *
 * Lo que llega de la red no es de fiar, asi que al cargarlo se limitan el tamano de la textura y el numero de cubos
 * y se sanean los ajustes (ver ModelManager.sanitizeRemote). Todo esto corre en el hilo del juego.
 */
public final class RemoteModels {
    private RemoteModels() {}

    private static final Gson GSON = new Gson();
    private static final int MAX_TEX = 4096;       // lado maximo de la textura de un modelo ajeno (px)
    private static final int MAX_CUBES = 20000;    // un modelo con mas bloques que esto no se acepta

    /** owned = el modelo es de este registro (se destruye al quitarlo). ref != null = modelo de mod / resourcepack que ya tienes tu: no se toca. */
    private record Entry(String hash, BBModel model, ModelManager.Active active, boolean owned, byte[] ref) {}

    private static final Map<UUID, Entry> MAP = new HashMap<>();

    public static ModelManager.Active get(UUID u) {
        Entry e = MAP.get(u);
        return e == null ? null : e.active();
    }

    /** Hash del modelo que ya tenemos de ese jugador, o null. */
    public static String hashOf(UUID u) {
        Entry e = MAP.get(u);
        return e == null ? null : e.hash();
    }

    public static int count() { return MAP.size(); }

    /** Jugador -> hash del modelo cargado (copia, para informes). */
    public static Map<UUID, String> hashes() {
        Map<UUID, String> r = new HashMap<>();
        for (Map.Entry<UUID, Entry> e : MAP.entrySet()) r.put(e.getKey(), e.getValue().hash());
        return r;
    }

    /** Carga el modelo recibido y lo deja listo para dibujar a ese jugador. Lanza excepcion si el paquete no sirve. */
    public static void install(UUID who, String hash, byte[] data) throws Exception {
        ModelBundle.Parts p = ModelBundle.read(data);
        if (".ref".equals(p.ext)) { installRef(who, hash, p, data); return; }
        String id = "net/" + who + "/" + hash.substring(0, 12);   // unico por jugador y version: tambien da el nombre de su textura
        BBModel m = null;
        int oldLimit = ModelLoader.texLimit;
        ModelLoader.texLimit = MAX_TEX;
        try {
            if (".geo.json".equals(p.ext)) {
                m = ModelLoader.geo(id, JsonParser.parseString(new String(p.main, StandardCharsets.UTF_8)).getAsJsonObject());
                m.source = "geckolib";
                if (p.png != null) ModelLoader.registerTexture(m, p.png, true);
                if (p.anim != null) ModelLoader.geoAnims(m, JsonParser.parseString(new String(p.anim, StandardCharsets.UTF_8)).getAsJsonObject());
            } else {
                m = ModelLoader.fromBbmodel(id, new String(p.main, StandardCharsets.UTF_8), null);   // la textura ya viene incrustada (ModelShare)
            }
            for (Map.Entry<String, byte[]> e : p.skins.entrySet()) {   // skins por parte (paso 36); una que no sirva solo deja esa parte con la textura del modelo
                try { ModelLoader.registerExtra(m, e.getKey(), e.getValue()); }
                catch (Throwable ex) { ModelManager.LOG.warn("Skin '{}' de {} no valida: {}", e.getKey(), who, ex.toString()); }
            }
            if (m.cubeCount() > MAX_CUBES) throw new IllegalStateException("Modelo con demasiados bloques (" + m.cubeCount() + ")");

            ModelManager.Settings s = null;
            try { if (!p.settings.isBlank()) s = GSON.fromJson(p.settings, ModelManager.Settings.class); } catch (Exception ignored) {}
            if (s == null) s = ModelManager.autoSettings(m);
            else { ModelManager.normalize(s); ModelManager.sanitizeRemote(s); }

            // animaciones de la biblioteca del dueno que usan sus ajustes (tu no las tienes)
            try {
                Map<String, BBModel.Anim> lib = GSON.fromJson(p.lib, new TypeToken<Map<String, BBModel.Anim>>() {}.getType());
                if (lib != null) for (Map.Entry<String, BBModel.Anim> e : lib.entrySet())
                    if (e.getKey() != null && e.getValue() != null) m.anims.putIfAbsent(e.getKey(), e.getValue());
            } catch (Exception ex) { ModelManager.LOG.warn("Animaciones de biblioteca de {} no validas: {}", who, ex.toString()); }

            Entry old = MAP.put(who, new Entry(hash, m, new ModelManager.Active(m, s), true, null));
            if (old != null) dispose(old);
            m = null;   // ya es del registro: no se destruye abajo
        } finally {
            ModelLoader.texLimit = oldLimit;
            if (m != null) dispose(m);   // algo fallo despues de registrar la textura
        }
        refreshBox(who);
    }

    public static void remove(UUID who) {
        Entry e = MAP.remove(who);
        if (e != null) { dispose(e); refreshBox(who); }
    }

    public static void clear() {
        for (Entry e : MAP.values()) dispose(e);
        MAP.clear();
    }

    /** Modelo de mod / resourcepack (paso 37): el otro jugador solo mando su id; se usa TU copia, con SUS ajustes. */
    private static void installRef(UUID who, String hash, ModelBundle.Parts p, byte[] data) throws Exception {
        String ref = new String(p.main, StandardCharsets.UTF_8);
        if (ref.length() > 200 || !ref.startsWith("geckolib:")) throw new IllegalStateException("Referencia de modelo no valida");
        BBModel local = ModelManager.MODELS.get(ref);
        if (local == null) throw new IllegalStateException("No tienes el modelo '" + ref + "' (hace falta el mismo mod / resourcepack)");
        ModelManager.Settings s = null;
        try { if (!p.settings.isBlank()) s = GSON.fromJson(p.settings, ModelManager.Settings.class); } catch (Exception ignored) {}
        if (s == null) s = ModelManager.autoSettings(local);
        else { ModelManager.normalize(s); ModelManager.sanitizeRemote(s); }
        Entry old = MAP.put(who, new Entry(hash, local, new ModelManager.Active(local, s), false, data));
        if (old != null) dispose(old);
        refreshBox(who);
    }

    /** Tras recargar modelos (tus BBModel son objetos nuevos) se vuelven a enlazar los de mod / resourcepack de los demas. */
    public static void refreshRefs() {
        for (Map.Entry<UUID, Entry> en : new java.util.ArrayList<>(MAP.entrySet())) {
            Entry e = en.getValue();
            if (e.ref() == null) continue;
            try { installRef(en.getKey(), e.hash(), ModelBundle.read(e.ref()), e.ref()); }
            catch (Throwable t) { MAP.remove(en.getKey()); ModelManager.LOG.warn("Modelo de {} ya no disponible tras recargar: {}", en.getKey(), t.toString()); }
        }
    }

    private static void dispose(Entry e) { if (e.owned()) dispose(e.model()); }

    private static void dispose(BBModel m) {
        if (m.ownsTexture) MinecraftClient.getInstance().getTextureManager().destroyTexture(m.texture);
        for (net.minecraft.util.Identifier t : m.extraTex.values()) MinecraftClient.getInstance().getTextureManager().destroyTexture(t);
        m.extraTex.clear();
        ModelBounds.forget(m.id);
    }

    /** La caja del jugador depende de su modelo: si esta en pantalla se recalcula. */
    private static void refreshBox(UUID who) {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.world == null) return;
            PlayerEntity e = mc.world.getPlayerByUuid(who);
            if (e != null) e.calculateDimensions();
        } catch (Throwable ignored) {}
    }
}
