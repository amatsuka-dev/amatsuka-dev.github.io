package com.morphzuka.model;

import net.minecraft.util.Identifier;

import java.util.*;

/** Modelo interno comun para .bbmodel, GeckoLib (.geo.json) y CPM. Unidades: pixeles (1/16 bloque), Y arriba, frente = -Z. */
public class BBModel {
    public String id;
    public String source = "bbmodel";
    public Identifier texture = Identifier.of("minecraft", "textures/entity/player/wide/steve.png");
    public boolean ownsTexture;
    /** Skins propias (nombre de archivo -> textura) que trae un modelo compartido por otro jugador (paso 36). Vacio en tus modelos. */
    public final Map<String, Identifier> extraTex = new HashMap<>();
    public int texW = 64, texH = 64;      // espacio UV declarado por el archivo
    public int imgW = 64, imgH = 64;      // pixeles reales de la imagen de textura
    public final List<Bone> roots = new ArrayList<>();
    public final Map<String, Bone> bones = new LinkedHashMap<>();
    public final Map<String, Anim> anims = new LinkedHashMap<>();

    public static class Bone {
        public String name;      // clave unica (si el archivo repite nombres se le anade _2)
        public String origName;  // nombre EXACTO del archivo original
        public int depth;
        public boolean visible = true;
        public float[] pivot = new float[3];
        public float[] rot = new float[3]; // grados
        public final List<Bone> children = new ArrayList<>();
        public final List<Cube> cubes = new ArrayList<>();

        /** Nombre que se muestra en las listas: el del archivo original. */
        public String label() { return origName != null && !origName.isEmpty() ? origName : name; }
    }

    public static class Cube {
        public String name = "cube";  // nombre original del bloque en el archivo
        public String key = "";       // hueso#indice: identifica al bloque en el editor
        public float[] from = new float[3], to = new float[3], origin = new float[3], rot = new float[3];
        public float inflate;
        public boolean boxUv;
        public float[] uvOffset = new float[2];
        public final Map<String, float[]> faces = new HashMap<>(); // north,east,south,west,up,down -> [u1,v1,u2,v2] en pixeles
    }

    public static class Key {
        public float time;
        public float[] v = new float[3];
        public boolean step;
    }

    public static class BoneAnim {
        public final List<Key> rot = new ArrayList<>(), pos = new ArrayList<>(), scale = new ArrayList<>();
    }

    public static class Anim {
        public String name;
        public float length;
        public boolean loop;
        public final Map<String, BoneAnim> bones = new HashMap<>();
    }

    /** Asigna a cada bloque su clave estable y un nombre por defecto si el archivo no trae. */
    public void indexCubes() {
        for (Bone b : bones.values()) {
            for (int i = 0; i < b.cubes.size(); i++) {
                Cube c = b.cubes.get(i);
                c.key = b.name + "#" + i;
                if (c.name == null || c.name.isEmpty()) c.name = "cube " + (i + 1);
            }
        }
    }

    public int cubeCount() {
        int n = 0;
        for (Bone b : bones.values()) n += b.cubes.size();
        return n;
    }

    public static float[] sample(List<Key> ks, float t, float[] def) {
        if (ks.isEmpty()) return def;
        if (t <= ks.get(0).time) return ks.get(0).v;
        for (int i = 0; i < ks.size() - 1; i++) {
            Key a = ks.get(i), b = ks.get(i + 1);
            if (t < b.time) {
                if (a.step) return a.v;
                float f = (t - a.time) / Math.max(1e-5f, b.time - a.time);
                return new float[]{a.v[0] + (b.v[0] - a.v[0]) * f, a.v[1] + (b.v[1] - a.v[1]) * f, a.v[2] + (b.v[2] - a.v[2]) * f};
            }
        }
        return ks.get(ks.size() - 1).v;
    }

    /** Igual que sample pero escribe en out en vez de crear arrays (se llama por hueso y por frame). */
    public static void sampleInto(List<Key> ks, float t, float[] out, float d0, float d1, float d2) {
        int n = ks.size();
        if (n == 0) { out[0] = d0; out[1] = d1; out[2] = d2; return; }
        Key f = ks.get(0);
        if (t <= f.time) { out[0] = f.v[0]; out[1] = f.v[1]; out[2] = f.v[2]; return; }
        for (int i = 0; i < n - 1; i++) {
            Key a = ks.get(i), b = ks.get(i + 1);
            if (t < b.time) {
                if (a.step) { out[0] = a.v[0]; out[1] = a.v[1]; out[2] = a.v[2]; return; }
                float k = (t - a.time) / Math.max(1e-5f, b.time - a.time);
                out[0] = a.v[0] + (b.v[0] - a.v[0]) * k;
                out[1] = a.v[1] + (b.v[1] - a.v[1]) * k;
                out[2] = a.v[2] + (b.v[2] - a.v[2]) * k;
                return;
            }
        }
        Key l = ks.get(n - 1);
        out[0] = l.v[0]; out[1] = l.v[1]; out[2] = l.v[2];
    }
}
