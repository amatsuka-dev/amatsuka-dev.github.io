package com.morphzuka.model;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Base64;
import java.util.function.Consumer;

/** Importa modelos desde texto (Base64 / JSON / data URI) o desde un link http(s). Guarda en .minecraft/morphzuka/. */
public final class ModelImporter {
    private ModelImporter() {}

    public record Result(String file, String error) {}

    public static Result fromText(String text, String nameHint) {
        try {
            return new Result(saveBytes(decodeAny(text.trim()), nameHint, 0), null);
        } catch (Exception e) {
            return new Result(null, msg(e));
        }
    }

    public static void fromUrl(String url, String nameHint, Consumer<Result> callback) {
        Thread t = new Thread(() -> {
            Result r;
            try {
                if (!url.startsWith("http://") && !url.startsWith("https://"))
                    throw new IllegalArgumentException("El link debe empezar por http:// o https://");
                String u = url;
                if (u.contains("github.com/") && u.contains("/blob/"))
                    u = u.replace("github.com/", "raw.githubusercontent.com/").replace("/blob/", "/");
                HttpClient c = HttpClient.newBuilder().followRedirects(HttpClient.Redirect.NORMAL)
                        .connectTimeout(Duration.ofSeconds(10)).build();
                HttpResponse<byte[]> resp = c.send(HttpRequest.newBuilder(URI.create(u))
                        .timeout(Duration.ofSeconds(30)).header("User-Agent", "MorphZuka").GET().build(),
                        HttpResponse.BodyHandlers.ofByteArray());
                if (resp.statusCode() / 100 != 2) throw new IOException("HTTP " + resp.statusCode());
                byte[] body = resp.body();
                if (body.length > 32 * 1024 * 1024) throw new IOException("Archivo demasiado grande (>32MB)");
                String hint = nameHint;
                if (hint == null || hint.isBlank()) {
                    String path = URI.create(u).getPath();
                    hint = path == null ? "" : path.substring(path.lastIndexOf('/') + 1);
                    hint = hint.replaceAll("(?i)\\.(bbmodel|geo\\.json|json|cpmproject|txt)$", "");
                }
                r = new Result(saveBytes(body, hint, 0), null);
            } catch (Exception e) {
                r = new Result(null, msg(e));
            }
            callback.accept(r);
        }, "morphzuka-download");
        t.setDaemon(true);
        t.start();
    }

    /** True si el modelo es un archivo de la carpeta morphzuka/ y se puede borrar (no los de CPM ni los de mods/resourcepacks). */
    public static boolean deletable(BBModel m) {
        return m != null && m.id != null && !m.id.startsWith("cpm/") && !m.id.startsWith("geckolib:");
    }

    /**
     * Borra el archivo del modelo (y, si es .geo.json, su textura .png y su .animation.json), sus ajustes y
     * las asignaciones que lo usaban. Devuelve null si salio bien o el mensaje de error.
     */
    public static String delete(BBModel m) {
        if (!deletable(m)) return "Este modelo no está en la carpeta morphzuka (solo lectura)";
        try {
            Path root = ModelManager.modelsDir().toAbsolutePath().normalize();
            Path f = root.resolve(m.id).normalize();
            if (!f.startsWith(root)) return "Ruta no válida";
            String fn = f.getFileName().toString();
            Files.deleteIfExists(f);
            if (fn.toLowerCase(java.util.Locale.ROOT).endsWith(".geo.json")) {
                String base = fn.substring(0, fn.length() - ".geo.json".length());
                Files.deleteIfExists(f.resolveSibling(base + ".png"));
                Files.deleteIfExists(f.resolveSibling(base + ".animation.json"));
            }
            ModelManager.CONFIG.settings.remove(m.id);
            ModelManager.CONFIG.assignments.values().removeIf(v -> v.equals(m.id));
            ModelManager.saveConfig();
            return null;
        } catch (Exception e) {
            return msg(e);
        }
    }

    private static String msg(Exception e) {
        return e.getMessage() == null ? e.toString() : e.getMessage();
    }

    static byte[] decodeAny(String t) {
        if (t.startsWith("{")) return t.getBytes(StandardCharsets.UTF_8);
        if (t.startsWith("data:")) {
            int i = t.indexOf(',');
            if (i < 0) throw new IllegalArgumentException("data URI invalido");
            t = t.substring(i + 1);
        }
        t = t.replaceAll("\\s", "");
        try {
            return Base64.getDecoder().decode(t);
        } catch (IllegalArgumentException e) {
            try { return Base64.getUrlDecoder().decode(t); }
            catch (IllegalArgumentException e2) { throw new IllegalArgumentException("No es Base64 valido"); }
        }
    }

    private static String saveBytes(byte[] data, String hint, int depth) throws IOException {
        String ext;
        byte[] out = data;
        if (data.length > 2 && data[0] == 'P' && data[1] == 'K') {
            ext = ".cpmproject";
        } else {
            String s = new String(data, StandardCharsets.UTF_8).trim();
            if (s.startsWith("{")) {
                JsonObject o = JsonParser.parseString(s).getAsJsonObject();
                boolean geo = o.has("minecraft:geometry") || o.keySet().stream().anyMatch(k -> k.startsWith("geometry."));
                if (geo) ext = ".geo.json";
                else if (o.has("elements") || o.has("outliner") || o.has("meta")) ext = ".bbmodel";
                else throw new IllegalArgumentException("JSON no reconocido (ni .bbmodel ni geo)");
                out = s.getBytes(StandardCharsets.UTF_8);
            } else if (depth < 2) {
                return saveBytes(decodeAny(s), hint, depth + 1);
            } else {
                throw new IllegalArgumentException("Contenido no reconocido");
            }
        }
        String base = hint == null ? "" : hint.replaceAll("[^A-Za-z0-9_\\-]", "_");
        if (base.isBlank()) base = "imported_" + (System.currentTimeMillis() / 1000);
        Path dir = ModelManager.modelsDir();
        Files.createDirectories(dir);
        Path target = dir.resolve(base + ext);
        int n = 2;
        while (Files.exists(target)) target = dir.resolve(base + "_" + n++ + ext);
        Files.write(target, out);
        return target.getFileName().toString();
    }
}
