package com.morphzuka.model;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 * Formato del modelo que viaja por la red (paso 33): un unico paquete comprimido con gzip que lleva el archivo del
 * modelo, su textura, sus animaciones y los ajustes (roles, pivotes, animaciones por estado...). Es lo mismo que haria
 * falta copiar a mano para que otra persona viera tu modelo igual que tu.
 *
 * Clase sin nada del juego: el cliente la usa para empaquetar y desempaquetar, y se puede probar suelta.
 * Lo que llega de la red NO es de fiar: {@link #read} limita lo que descomprime y comprueba cada longitud.
 */
public final class ModelBundle {
    private ModelBundle() {}

    private static final int MAGIC = 0x4D5A4231;           // "MZB1"
    /** Tope de lo que se descomprime (evita las "bombas" gzip: pocos KB que se hacen gigas). */
    public static final int MAX_RAW = 64 * 1024 * 1024;
    /** Skins propias que acompanan a un modelo (paso 36) y tamano maximo de cada una. */
    public static final int MAX_SKINS = 16, MAX_SKIN_BYTES = 1 << 20;

    public static final class Parts {
        public String name = "";                 // nombre original, solo informativo
        public String ext = ".bbmodel";          // ".bbmodel" (tambien .morphzuka / .cpmproject ya resueltos), ".geo.json" o ".ref" (paso 37: solo el id de un modelo de mod / resourcepack)
        public byte[] main = new byte[0];        // contenido del archivo del modelo
        public byte[] png;                       // textura aparte (solo .geo.json); null = ninguna
        public byte[] anim;                      // .animation.json (solo .geo.json); null = ninguna
        public String settings = "{}";           // ModelManager.Settings en JSON
        public String lib = "{}";                // animaciones de la biblioteca que usan los ajustes, en JSON
        public java.util.Map<String, byte[]> skins = new java.util.LinkedHashMap<>();   // skins propias usadas por partes (nombre -> png)
    }

    public static byte[] write(Parts p) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream(Math.max(1024, p.main.length / 3));
        try (DataOutputStream out = new DataOutputStream(new GZIPOutputStream(bo))) {
            out.writeInt(MAGIC);
            blob(out, utf8(p.name));
            blob(out, utf8(p.ext));
            blob(out, p.main);
            blob(out, p.png);
            blob(out, p.anim);
            blob(out, utf8(p.settings));
            blob(out, utf8(p.lib));
            out.writeInt(p.skins.size());
            for (java.util.Map.Entry<String, byte[]> e : p.skins.entrySet()) { blob(out, utf8(e.getKey())); blob(out, e.getValue()); }
        }
        return bo.toByteArray();
    }

    public static Parts read(byte[] gz) throws IOException {
        byte[] raw = inflate(gz);
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(raw));
        if (in.readInt() != MAGIC) throw new IOException("Formato de modelo desconocido");
        Parts p = new Parts();
        p.name = str(blob(in));
        p.ext = str(blob(in));
        byte[] main = blob(in);
        if (main == null) throw new IOException("Paquete sin modelo");
        p.main = main;
        p.png = blob(in);
        p.anim = blob(in);
        p.settings = str(blob(in));
        p.lib = str(blob(in));
        if (in.available() >= 4) {   // los paquetes anteriores al paso 36 acaban aqui
            int n = in.readInt();
            if (n < 0 || n > MAX_SKINS) throw new IOException("Demasiadas skins en el paquete");
            for (int i = 0; i < n; i++) {
                String name = str(blob(in));
                byte[] d = blob(in);
                if (d != null && d.length <= MAX_SKIN_BYTES && !name.isEmpty() && name.length() <= 128) p.skins.put(name, d);
            }
        }
        if (!p.ext.equals(".bbmodel") && !p.ext.equals(".geo.json") && !p.ext.equals(".ref")) throw new IOException("Tipo de modelo no soportado: " + p.ext);
        return p;
    }

    /** SHA-256 en hexadecimal, 40 caracteres (los 20 primeros bytes). Identifica un paquete y comprueba que llego entero. */
    public static String hash(byte[] data) {
        try {
            byte[] d = java.security.MessageDigest.getInstance("SHA-256").digest(data);
            StringBuilder sb = new StringBuilder(40);
            for (int i = 0; i < 20; i++) sb.append(Character.forDigit((d[i] >> 4) & 15, 16)).append(Character.forDigit(d[i] & 15, 16));
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) { throw new IllegalStateException(e); }
    }

    /** 40 caracteres hexadecimales en minuscula: se usa como nombre de archivo de la cache, asi que nada de rutas. */
    public static boolean validHash(String h) {
        if (h == null || h.length() != 40) return false;
        for (int i = 0; i < 40; i++) { char c = h.charAt(i); if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f'))) return false; }
        return true;
    }

    // ------------------------------------------------------------ helpers

    private static byte[] utf8(String s) { return (s == null ? "" : s).getBytes(StandardCharsets.UTF_8); }

    private static String str(byte[] b) { return b == null ? "" : new String(b, StandardCharsets.UTF_8); }

    private static void blob(DataOutputStream out, byte[] b) throws IOException {
        out.writeInt(b == null ? -1 : b.length);
        if (b != null) out.write(b);
    }

    private static byte[] blob(DataInputStream in) throws IOException {
        int n = in.readInt();
        if (n == -1) return null;
        if (n < 0 || n > in.available()) throw new IOException("Paquete de modelo corrupto");
        byte[] b = new byte[n];
        in.readFully(b);
        return b;
    }

    private static byte[] inflate(byte[] gz) throws IOException {
        try (GZIPInputStream in = new GZIPInputStream(new ByteArrayInputStream(gz))) {
            ByteArrayOutputStream out = new ByteArrayOutputStream(Math.min(Math.max(gz.length * 4, 1024), 1 << 20));
            byte[] buf = new byte[16384];
            long total = 0;
            int n;
            while ((n = in.read(buf)) != -1) {
                total += n;
                if (total > MAX_RAW) throw new IOException("El modelo ocupa demasiado al descomprimirse");
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        }
    }
}
