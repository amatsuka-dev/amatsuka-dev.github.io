package com.morphzuka.model;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.Locale;
import java.util.Optional;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Empaqueta uno de TUS modelos (el archivo, su textura y sus animaciones) para mandarlo al servidor.
 * Lee archivos y comprime: se ejecuta en un hilo aparte, nunca en el hilo del juego.
 * Los modelos que vienen de un mod o resourcepack (GeckoLib) no se comparten: no son archivos tuyos.
 */
public final class ModelShare {
    private ModelShare() {}

    public static byte[] build(BBModel m, String settingsJson, String libJson) throws Exception {
        if (m == null || m.id == null) throw new IOException("No hay modelo");
        if (m.id.startsWith("geckolib:")) {   // paso 37: no se manda el modelo (no es tuyo), solo su id: el otro lo tiene si tiene el mismo mod / resourcepack
            ModelBundle.Parts r = new ModelBundle.Parts();
            r.name = m.id;
            r.ext = ".ref";
            r.main = m.id.getBytes(StandardCharsets.UTF_8);
            r.settings = settingsJson == null ? "{}" : settingsJson;
            r.lib = "{}";
            return ModelBundle.write(r);
        }
        Path file = fileOf(m);
        String fn = file.getFileName().toString();
        String low = fn.toLowerCase(Locale.ROOT);

        ModelBundle.Parts p = new ModelBundle.Parts();
        p.name = fn;
        p.settings = settingsJson == null ? "{}" : settingsJson;
        p.lib = libJson == null ? "{}" : libJson;

        if (low.endsWith(".geo.json")) {
            p.ext = ".geo.json";
            p.main = Files.readAllBytes(file);
            String base = fn.substring(0, fn.length() - ".geo.json".length());
            Path png = file.resolveSibling(base + ".png");
            if (Files.isRegularFile(png)) p.png = Files.readAllBytes(png);
            Path an = file.resolveSibling(base + ".animation.json");
            if (Files.isRegularFile(an)) p.anim = Files.readAllBytes(an);
        } else if (low.endsWith(".bbmodel") || low.endsWith(".morphzuka")) {
            p.ext = ".bbmodel";
            p.main = embedTexture(Files.readString(file), file.getParent()).getBytes(StandardCharsets.UTF_8);
        } else if (low.endsWith(".cpmproject")) {
            p.ext = ".bbmodel";
            try (ZipFile z = new ZipFile(file.toFile())) {
                Optional<? extends ZipEntry> en = z.stream().filter(e -> e.getName().toLowerCase(Locale.ROOT).endsWith(".bbmodel")).findFirst();
                if (en.isEmpty()) throw new IOException(".cpmproject sin .bbmodel dentro");
                String json = new String(z.getInputStream(en.get()).readAllBytes(), StandardCharsets.UTF_8);
                p.main = embedTexture(json, file.getParent()).getBytes(StandardCharsets.UTF_8);
            }
        } else {
            throw new IOException("tipo de archivo no soportado: " + fn);
        }
        collectSkins(p);
        return ModelBundle.write(p);
    }

    /** Skins propias (carpeta morphzuka/skins/) que los ajustes asignan a alguna parte: los demas no las tienen, asi que viajan con el modelo. */
    private static void collectSkins(ModelBundle.Parts p) {
        try {
            JsonObject so = JsonParser.parseString(p.settings).getAsJsonObject();
            if (!so.has("partTex") || !so.get("partTex").isJsonObject()) return;
            Path root = com.morphzuka.render.PartTex.dir().toAbsolutePath().normalize();
            for (java.util.Map.Entry<String, JsonElement> e : so.getAsJsonObject("partTex").entrySet()) {
                if (!e.getValue().isJsonPrimitive()) continue;
                String v = e.getValue().getAsString();
                if (!v.startsWith(com.morphzuka.render.PartTex.FILE)) continue;
                String name = v.substring(com.morphzuka.render.PartTex.FILE.length());
                if (name.isEmpty() || name.length() > 128 || p.skins.containsKey(name) || p.skins.size() >= ModelBundle.MAX_SKINS) continue;
                Path f = root.resolve(name).normalize();
                if (!f.startsWith(root) || !Files.isRegularFile(f) || Files.size(f) > ModelBundle.MAX_SKIN_BYTES) continue;
                p.skins.put(name, Files.readAllBytes(f));
            }
        } catch (Exception ignored) {}   // sin skins el modelo se comparte igual (esas partes usaran la textura del modelo)
    }

    /** La carpeta de donde salio el modelo, con la misma regla de ModelLoader.scanFolder (ids "cpm/..." = carpeta player_models de CPM). */
    private static Path fileOf(BBModel m) throws IOException {
        Path root;
        String rel;
        if (m.id.startsWith("cpm/")) {
            root = FabricLoader.getInstance().getGameDir().resolve("player_models");
            rel = m.id.substring(4);
        } else {
            root = ModelManager.modelsDir();
            rel = m.id;
        }
        root = root.toAbsolutePath().normalize();
        Path f = root.resolve(rel).normalize();
        if (!f.startsWith(root) || !Files.isRegularFile(f)) throw new IOException("no encuentro el archivo del modelo: " + m.id);
        return f;
    }

    /**
     * Un .bbmodel puede llevar la textura incrustada (data:...) o solo la ruta de un .png que esta al lado. Los demas
     * jugadores no tienen ese .png, asi que se incrusta aqui. ModelLoader solo usa la primera textura: las demas se quitan.
     */
    static String embedTexture(String json, Path baseDir) throws IOException {
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        if (!root.has("textures") || !root.get("textures").isJsonArray() || root.getAsJsonArray("textures").size() == 0) return json;
        JsonElement first = root.getAsJsonArray("textures").get(0);
        if (!first.isJsonObject()) return json;
        JsonObject t = first.getAsJsonObject();

        String src = t.has("source") && t.get("source").isJsonPrimitive() ? t.get("source").getAsString() : "";
        if (!src.startsWith("data:") && baseDir != null) {
            byte[] png = null;
            for (String k : new String[]{"path", "relative_path"}) {
                if (png == null && t.has(k) && t.get(k).isJsonPrimitive()) {
                    Path pp = baseDir.resolve(t.get(k).getAsString()).normalize();
                    if (Files.isRegularFile(pp)) png = Files.readAllBytes(pp);
                }
            }
            if (png != null) t.addProperty("source", "data:image/png;base64," + Base64.getEncoder().encodeToString(png));
        }
        JsonArray one = new JsonArray();
        one.add(t);
        root.add("textures", one);
        return root.toString();
    }
}
