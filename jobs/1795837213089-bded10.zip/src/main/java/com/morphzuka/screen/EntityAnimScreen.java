package com.morphzuka.screen;

import com.morphzuka.Role;
import com.morphzuka.model.AnimScan;
import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelManager;
import com.morphzuka.render.EntityCfg;
import com.morphzuka.render.MorphManager;
import com.morphzuka.render.PartTree;
import com.morphzuka.ui.Background;
import com.morphzuka.ui.MorphPreview;
import com.morphzuka.ui.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * "Animaciones" de la forma en la que estas transformado: vista previa 3D con las poses (caminar, golpear, girar la cabeza),
 * lista de animaciones que trae la entidad, asignacion de roles a sus partes (cabeza, manos, piernas...) para que golpee
 * y gire la cabeza como el jugador de Minecraft, y la configuracion de su idle. Todo se guarda al instante
 * en config/morphzuka_entities.json.
 */
public class EntityAnimScreen extends Screen {
    private static final class Hit { int x, y, w, h; int[] clip; Runnable r; }
    private static final class Area { String key; int x, y, w, h, max; }

    private enum Tab {
        ANIMS("Animaciones"), PARTS("Partes"), IDLE("Idle");
        final String label;
        Tab(String l) { label = l; }
    }

    /** kind: 0 titulo, 1 pose, 2 nombre de animacion, 3 texto, 4 boton. sim: 0 caminar, 1 golpear, 2 cabeza (-1 = ninguno). */
    private record Row(int kind, String a, String b, int sim, Runnable r) {}

    private final Screen parent;
    private final MorphManager.State st;
    private final String key;
    private final Identifier entId;
    private final List<Hit> hits = new ArrayList<>();
    private final List<Area> areas = new ArrayList<>();
    private final Map<String, Integer> scroll = new HashMap<>();
    private int[] clip;
    private Area lastArea;
    private int mx, my;

    private Tab tab = Tab.ANIMS;
    private float yaw = 25f, zoom = 1f;
    private boolean drag, walk, swing = true, look = true;
    private int pvX, pvY, pvW, pvH;
    private String status = "";
    private List<PartTree.Node> nodes = List.of();
    private AnimScan.Result scan = new AnimScan.Result(List.of(), List.of());
    private List<BBModel> models = List.of();

    public EntityAnimScreen(Screen parent) {
        super(Text.literal("Animaciones"));
        this.parent = parent;
        this.st = MorphManager.state();
        this.key = MorphManager.key();
        this.entId = st != null && st.kind == MorphManager.Kind.ENTITY ? st.id : null;
    }

    @Override
    protected void init() {
        nodes = st == null || st.entity == null ? List.of() : PartTree.of(PartTree.modelOf(st.entity));
        if (entId != null) {
            scan = AnimScan.find(entId);
            models = AnimScan.models(entId);
        }
    }

    // ------------------------------------------------------------------ helpers

    private static int C(String k) { return Theme.c(k); }

    private static void rr(DrawContext g, int x, int y, int w, int h, int r, int c) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        for (int i = 0; i < h; i++) {
            int d = 0;
            int k = i < r ? i : (i >= h - r ? h - 1 - i : -1);
            if (k >= 0) { double dy = r - k - 0.5; d = r - (int) Math.round(Math.sqrt(Math.max(0, r * r - dy * dy))); }
            g.fill(x + d, y + i, x + w - d, y + i + 1, c);
        }
    }

    private boolean over(int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h
                && (clip == null || (mx >= clip[0] && mx < clip[2] && my >= clip[1] && my < clip[3]));
    }

    private void hit(int x, int y, int w, int h, Runnable r) {
        Hit t = new Hit();
        t.x = x; t.y = y; t.w = w; t.h = h; t.r = r;
        t.clip = clip == null ? null : clip.clone();
        hits.add(t);
    }

    private void txt(DrawContext g, String s, int x, int y, int c) { g.drawText(textRenderer, s, x, y, c, false); }

    private String trim(String s, int px) { return textRenderer.trimToWidth(s, Math.max(0, px)); }

    private void button(DrawContext g, int x, int y, int w, String label, boolean primary, Runnable r) {
        boolean hov = over(x, y, w, 18);
        rr(g, x, y, w, 18, 9, primary ? C("primary") : hov ? C("surfaceHi") : C("surface"));
        String l = trim(label, w - 8);
        txt(g, l, x + w / 2 - textRenderer.getWidth(l) / 2, y + 5, primary ? C("onPrimary") : C("text"));
        hit(x, y, w, 18, r);
    }

    private void chip(DrawContext g, int x, int y, int w, String label, boolean sel, Runnable r) {
        boolean hov = over(x, y, w, 16);
        rr(g, x, y, w, 16, 8, sel ? C("primary") : hov ? C("surfaceHi") : C("surface"));
        String l = trim(label, w - 6);
        txt(g, l, x + w / 2 - textRenderer.getWidth(l) / 2, y + 4, sel ? C("onPrimary") : C("text"));
        hit(x, y, w, 16, r);
    }

    private void radio(DrawContext g, int x, int y, boolean sel, String label, Runnable r) {
        rr(g, x, y, 12, 12, 6, sel ? C("primary") : C("muted"));
        rr(g, x + 1, y + 1, 10, 10, 5, 0xFF1E1716);
        if (sel) rr(g, x + 3, y + 3, 6, 6, 3, C("primary"));
        txt(g, label, x + 18, y + 2, C("text"));
        hit(x, y, 18 + textRenderer.getWidth(label), 14, r);
    }

    private int beginScroll(DrawContext g, String k, int x, int y, int w, int h, int content) {
        Area a = new Area();
        a.key = k; a.x = x; a.y = y; a.w = w; a.h = h;
        a.max = Math.max(0, content - h);
        int s = Math.max(0, Math.min(a.max, scroll.getOrDefault(k, 0)));
        scroll.put(k, s);
        areas.add(a);
        lastArea = a;
        g.enableScissor(x, y, x + w, y + h);
        clip = new int[]{x, y, x + w, y + h};
        return s;
    }

    private void endScroll(DrawContext g) {
        g.disableScissor();
        clip = null;
        Area a = lastArea;
        if (a != null && a.max > 0) {
            int th = Math.max(12, a.h * a.h / (a.h + a.max));
            int ty = a.y + (a.h - th) * scroll.get(a.key) / a.max;
            rr(g, a.x + a.w - 3, ty, 2, th, 1, 0x80E8C2BA);
        }
    }

    // ------------------------------------------------------------------ render

    @Override
    public void render(DrawContext g, int mouseX, int mouseY, float delta) {
        mx = mouseX;
        my = mouseY;
        hits.clear();
        areas.clear();
        clip = null;
        int text = C("text"), muted = C("muted"), prim = C("primary");

        g.fill(0, 0, width, height, 0xFF0B0808);
        Background.draw(g, width, height);

        int pad = 14;
        rr(g, pad, pad, width - 2 * pad, height - 2 * pad, 10, C("panel"));
        int ix = pad + 12, iw = width - 2 * pad - 24;
        g.drawText(textRenderer, Text.literal("Animaciones").formatted(Formatting.BOLD), ix, pad + 10, text, false);
        txt(g, trim(key == null ? "sin forma" : key, iw - 190), ix + 84, pad + 10, muted);
        button(g, ix + iw - 76, pad + 6, 76, "Cerrar", true, this::close);

        int top = pad + 32, bottom = height - pad - 22;
        int lw = Math.max(110, Math.min(iw * 38 / 100, 230));
        int rx = ix + lw + 12, rw = iw - lw - 12;

        // ---- vista previa
        pvX = ix; pvY = top; pvW = lw; pvH = Math.max(20, bottom - top - 40);
        rr(g, pvX, pvY, pvW, pvH, 8, 0x40000000);
        boolean ok = st != null && MorphPreview.draw(g, st, pvX, pvY, pvW, pvH, yaw, zoom, walk, swing, look);
        if (!ok) txt(g, trim("Sin vista previa", pvW - 8), pvX + 8, pvY + 8, muted);
        hit(pvX, pvY, pvW, pvH, () -> drag = true);
        int cy2 = pvY + pvH + 6;
        int cw3 = (lw - 8) / 3;
        chip(g, ix, cy2, cw3, "Caminar", walk, () -> walk = !walk);
        chip(g, ix + cw3 + 4, cy2, cw3, "Golpear", swing, () -> swing = !swing);
        chip(g, ix + 2 * (cw3 + 4), cy2, cw3, "Cabeza", look, () -> look = !look);
        txt(g, trim("Arrastra: girar  -  Rueda: zoom", lw), ix, cy2 + 20, muted);

        // ---- pestañas
        int tx = rx;
        for (Tab t : Tab.values()) {
            final Tab tt = t;
            int tw = textRenderer.getWidth(t.label) + 20;
            chip(g, tx, top, tw, t.label, tab == t, () -> tab = tt);
            tx += tw + 4;
        }
        int cy = top + 22, ch = bottom - cy;
        rr(g, rx, cy, rw, ch, 8, 0x40000000);
        if (st == null) {
            txt(g, trim("No llevas ninguna forma: transfórmate primero en la pestaña Morph.", rw - 16), rx + 8, cy + 8, muted);
        } else {
            switch (tab) {
                case ANIMS -> drawAnims(g, rx, cy, rw, ch);
                case PARTS -> drawParts(g, rx, cy, rw, ch);
                case IDLE -> drawIdle(g, rx, cy, rw, ch);
            }
        }
        if (!status.isEmpty()) txt(g, trim(status, iw), ix, height - pad - 16, prim);
    }

    // ---------------------------------------------------------------- ANIMACIONES

    private static String shortName(String cls) {
        int i = cls.lastIndexOf('.');
        return i >= 0 ? cls.substring(i + 1) : cls;
    }

    private String roleInfo(Role... roles) {
        EntityCfg.Data d = EntityCfg.of(key);
        if (nodes.isEmpty()) return "Este modelo no usa partes estándar";
        int n = 0;
        for (String v : d.roles.values()) for (Role r : roles) if (Role.of(v) == r) n++;
        return n == 0 ? "Sin partes con rol: usa el movimiento propio de la entidad" : n + (n == 1 ? " parte con rol" : " partes con rol");
    }

    private List<Row> animRows() {
        EntityCfg.Data d = EntityCfg.of(key);
        List<Row> r = new ArrayList<>();
        r.add(new Row(0, "Poses del jugador (pruébalas en la vista previa)", null, -1, null));
        int idleIdx = Math.max(0, Arrays.asList(EntityCfg.IDLE_KEYS).indexOf(d.idle == null ? "NONE" : d.idle));
        r.add(new Row(1, "Quieto (idle)", "Preset: " + EntityCfg.IDLE_LABELS[idleIdx] + "  -  clic para cambiarlo", -1, () -> tab = Tab.IDLE));
        r.add(new Row(1, "Caminar", roleInfo(Role.RIGHT_LEG, Role.LEFT_LEG, Role.RIGHT_ARM, Role.LEFT_ARM), 0, () -> tab = Tab.PARTS));
        r.add(new Row(1, "Golpear (ataque)", roleInfo(Role.RIGHT_ARM, Role.LEFT_ARM), 1, () -> tab = Tab.PARTS));
        r.add(new Row(1, "Girar cabeza", roleInfo(Role.HEAD), 2, () -> tab = Tab.PARTS));

        r.add(new Row(0, "Animación propia del mob (detectada en sus .class)", null, -1, null));
        com.morphzuka.render.ClassAnimScan.Report cr = null;
        try { cr = st == null || st.entity == null ? null : com.morphzuka.render.ClassAnimScan.of(st.entity); } catch (Throwable ignored) { }
        if (cr == null) {
            r.add(new Row(3, "Esta forma no es un ser vivo: no tiene animación propia.", null, -1, null));
        } else {
            r.add(new Row(3, "Tipo: " + cr.kind(), null, -1, null));
            if (cr.hasModelParts()) r.add(new Row(3, "Modelo: " + shortName(cr.modelClass()) + (cr.singlePart() ? " (keyframes posibles)" : ""), null, -1, null));
            if (cr.keyframes()) r.add(new Row(3, "Keyframes: " + cr.keyframeRefs() + " refs en " + String.join(", ", cr.keyframeOwners()), null, -1, null));
            if (cr.states()) r.add(new Row(3, "Estados: " + String.join(", ", cr.stateFields()), null, -1, null));
            if (cr.overridesSetAngles() || cr.overridesAnimateModel()) r.add(new Row(3, "Procedural: el modelo calcula el movimiento con fórmulas", null, -1, null));
            if (!cr.driver().isEmpty()) r.add(new Row(3, "MorphZuka mueve: " + cr.driver(), null, -1, null));
        }
        r.add(new Row(4, "Animación propia del mob: " + (d.nativeAnim ? "SÍ" : "NO") + "  (clic para cambiar)", null, -1, () -> {
            EntityCfg.Data ed = EntityCfg.edit(key);
            ed.nativeAnim = !ed.nativeAnim;
            EntityCfg.save();
        }));

        r.add(new Row(0, "Animaciones de archivos", null, -1, null));
        if (entId == null) {
            r.add(new Row(3, "Solo las entidades pueden traer archivos de animación.", null, -1, null));
        } else if (scan.files().isEmpty() && models.isEmpty()) {
            r.add(new Row(3, "Esta entidad no trae archivos de animación (es vanilla o las lleva", null, -1, null));
            r.add(new Row(3, "dentro del mod): sus movimientos los dibuja el propio juego.", null, -1, null));
            r.add(new Row(3, "Usa las poses de arriba y la pestaña Partes.", null, -1, null));
        }
        for (String f : scan.files()) r.add(new Row(3, f, null, -1, null));
        for (String n : scan.names()) r.add(new Row(2, n, null, -1, null));
        for (BBModel m : models) {
            r.add(new Row(4, "Configurar «" + m.id + "» (" + ModelManager.allAnimNames(m).size() + " anim.)", null, -1, () -> {
                ModelManager.saveConfig();
                client.setScreen(new AnimConfigScreen(this, m));
            }));
        }
        return r;
    }

    private static int rowH(Row r) {
        return switch (r.kind()) { case 0 -> 16; case 1 -> 30; case 4 -> 24; default -> 14; };
    }

    private void drawAnims(DrawContext g, int x, int y, int w, int h) {
        List<Row> rows = animRows();
        int total = 6;
        for (Row r : rows) total += rowH(r);
        int sc = beginScroll(g, "anims", x + 3, y + 3, w - 6, h - 6, total);
        int yy = y + 6 - sc;
        int text = C("text"), muted = C("muted"), prim = C("primary");
        for (Row r : rows) {
            int rh = rowH(r);
            if (yy + rh >= y && yy <= y + h) {
                switch (r.kind()) {
                    case 0 -> txt(g, trim(r.a(), w - 20), x + 10, yy + 4, prim);
                    case 1 -> {
                        boolean hov = over(x + 6, yy, w - 18, rh - 3);
                        rr(g, x + 6, yy, w - 18, rh - 3, 7, hov ? C("line") : C("surface"));
                        txt(g, trim(r.a(), w - 100), x + 14, yy + 4, text);
                        txt(g, trim(r.b(), w - 100), x + 14, yy + 15, muted);
                        if (r.r() != null) hit(x + 6, yy, w - 18, rh - 3, r.r());
                        if (r.sim() >= 0) {
                            boolean on = r.sim() == 0 ? walk : r.sim() == 1 ? swing : look;
                            final int si = r.sim();
                            chip(g, x + w - 70, yy + 5, 54, on ? "Parar" : "Probar", on, () -> {
                                if (si == 0) walk = !walk; else if (si == 1) swing = !swing; else look = !look;
                            });
                        }
                    }
                    case 2 -> txt(g, trim("•  " + r.a(), w - 24), x + 12, yy + 3, text);
                    case 3 -> txt(g, trim(r.a(), w - 24), x + 10, yy + 3, muted);
                    case 4 -> button(g, x + 8, yy + 2, Math.min(w - 24, textRenderer.getWidth(r.a()) + 26), r.a(), false, r.r());
                    default -> { }
                }
            }
            yy += rh;
        }
        endScroll(g);
    }

    // ---------------------------------------------------------------- PARTES

    private void autoDetect() {
        EntityCfg.Data d = EntityCfg.edit(key);
        int n = 0;
        for (PartTree.Node nd : nodes) {
            Role r = Role.guess(nd.name());
            if (r != Role.NONE) { d.roles.put(nd.path(), r.name()); n++; }
        }
        EntityCfg.save();
        status = n == 0 ? "No reconocí ninguna parte por su nombre: asígnalas a mano" : n + " partes asignadas por su nombre";
    }

    private void cycleRole(PartTree.Node n) {
        EntityCfg.Data d = EntityCfg.edit(key);
        Role cur = Role.of(d.roles.get(n.path()));
        int i = 0;
        for (int j = 0; j < EntityCfg.ROLE_CYCLE.length; j++) if (EntityCfg.ROLE_CYCLE[j] == cur) i = j;
        Role next = EntityCfg.ROLE_CYCLE[(i + 1) % EntityCfg.ROLE_CYCLE.length];
        if (next == Role.NONE) d.roles.remove(n.path()); else d.roles.put(n.path(), next.name());
        EntityCfg.save();
    }

    private void drawParts(DrawContext g, int x, int y, int w, int h) {
        int muted = C("muted"), text = C("text");
        if (nodes.isEmpty()) {
            txt(g, trim("Este modelo no usa partes estándar (lo dibuja un mod con su propio sistema).", w - 16), x + 8, y + 8, muted);
            txt(g, trim("Aquí no se pueden asignar cabeza ni manos; se mueve con sus propias animaciones.", w - 16), x + 8, y + 22, muted);
            return;
        }
        button(g, x + 8, y + 6, 96, "Autodetectar", true, this::autoDetect);
        button(g, x + 110, y + 6, 96, "Quitar todo", false, () -> {
            EntityCfg.edit(key).roles.clear();
            EntityCfg.save();
            status = "Roles quitados";
        });
        txt(g, trim("Clic en el rol para cambiarlo", w - 220), x + 214, y + 11, muted);
        int ly = y + 30, lh = h - 34;
        int rowH = 18;
        EntityCfg.Data d = EntityCfg.of(key);
        int sc = beginScroll(g, "parts", x + 3, ly, w - 6, lh, nodes.size() * rowH + 4);
        for (int i = 0; i < nodes.size(); i++) {
            int ry = ly + 2 + i * rowH - sc;
            if (ry + rowH < ly || ry > ly + lh) continue;
            final PartTree.Node n = nodes.get(i);
            Role role = Role.of(d.roles.get(n.path()));
            boolean hov = over(x + 6, ry, w - 18, rowH - 2);
            if (hov) rr(g, x + 6, ry, w - 18, rowH - 2, 6, C("line"));
            txt(g, trim(n.name(), w - 130 - n.depth() * 8), x + 12 + n.depth() * 8, ry + 5, role == Role.NONE ? muted : text);
            int cw = 92, cx = x + w - cw - 14;
            rr(g, cx, ry + 1, cw, rowH - 4, 6, role == Role.NONE ? C("surface") : C("pill"));
            String lab = role == Role.NONE ? "-" : role.label;
            txt(g, trim(lab, cw - 8), cx + cw / 2 - textRenderer.getWidth(trim(lab, cw - 8)) / 2, ry + 4, role == Role.NONE ? muted : text);
            hit(x + 6, ry, w - 18, rowH - 2, () -> cycleRole(n));
        }
        endScroll(g);
    }

    // ---------------------------------------------------------------- IDLE

    private void drawIdle(DrawContext g, int x, int y, int w, int h) {
        int muted = C("muted"), prim = C("primary");
        EntityCfg.Data d = EntityCfg.of(key);
        String cur = d.idle == null ? "NONE" : d.idle;
        txt(g, trim("Movimiento en reposo (se aplica a las partes con rol)", w - 20), x + 10, y + 8, muted);
        int yy = y + 24;
        for (int i = 0; i < EntityCfg.IDLE_KEYS.length; i++) {
            final String k = EntityCfg.IDLE_KEYS[i];
            radio(g, x + 10, yy, cur.equals(k), EntityCfg.IDLE_LABELS[i], () -> { EntityCfg.edit(key).idle = k; EntityCfg.save(); });
            txt(g, trim(EntityCfg.IDLE_INFO[i], w - 40), x + 28, yy + 13, muted);
            yy += 30;
        }
        txt(g, "Intensidad", x + 10, yy + 5, C("text"));
        int bx = x + 10 + textRenderer.getWidth("Intensidad") + 10;
        button(g, bx, yy, 22, "-", false, () -> setAmount(EntityCfg.edit(key), -0.25f));
        String v = String.format(java.util.Locale.ROOT, "%.2f", d.idleAmount);
        txt(g, v, bx + 22 + 8, yy + 5, prim);
        button(g, bx + 22 + 16 + textRenderer.getWidth(v), yy, 22, "+", false, () -> setAmount(EntityCfg.edit(key), 0.25f));
        yy += 30;
        radio(g, x + 10, yy, d.head, "La cabeza sigue la cámara", () -> { EntityCfg.Data m = EntityCfg.edit(key); m.head = !m.head; EntityCfg.save(); });
        yy += 18;
        radio(g, x + 10, yy, d.attack, "Golpe estilo Minecraft con los brazos", () -> { EntityCfg.Data m = EntityCfg.edit(key); m.attack = !m.attack; EntityCfg.save(); });
        yy += 18;
        radio(g, x + 10, yy, d.walk, "Brazos y piernas balancean al caminar", () -> { EntityCfg.Data m = EntityCfg.edit(key); m.walk = !m.walk; EntityCfg.save(); });
        yy += 18;
        radio(g, x + 10, yy, !d.rightHanded, "Zurdo: golpea con el brazo izquierdo", () -> { EntityCfg.Data m = EntityCfg.edit(key); m.rightHanded = !m.rightHanded; EntityCfg.save(); });
        yy += 24;
        if (d.roles.isEmpty()) txt(g, trim("Aún no hay partes con rol: ve a Partes y pulsa Autodetectar.", w - 20), x + 10, yy, C("error"));
    }

    private void setAmount(EntityCfg.Data d, float delta) {
        d.idleAmount = Math.max(0f, Math.min(2f, Math.round((d.idleAmount + delta) * 4f) / 4f));
        EntityCfg.save();
    }

    // ---------------------------------------------------------------- input

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        if (button == 0) {
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (x >= h.x && x < h.x + h.w && y >= h.y && y < h.y + h.h
                        && (h.clip == null || (x >= h.clip[0] && x < h.clip[2] && y >= h.clip[1] && y < h.clip[3]))) {
                    h.r.run();
                    return true;
                }
            }
        }
        return super.mouseClicked(x, y, button);
    }

    @Override
    public boolean mouseDragged(double x, double y, int button, double dx, double dy) {
        if (drag && button == 0) { yaw += (float) dx * 1.6f; return true; }
        return super.mouseDragged(x, y, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double x, double y, int button) {
        drag = false;
        return super.mouseReleased(x, y, button);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double hAmount, double vAmount) {
        if (x >= pvX && x < pvX + pvW && y >= pvY && y < pvY + pvH) {
            zoom = Math.max(0.4f, Math.min(3f, zoom * (vAmount > 0 ? 1.1f : 0.9f)));
            return true;
        }
        for (int i = areas.size() - 1; i >= 0; i--) {
            Area a = areas.get(i);
            if (x >= a.x && x < a.x + a.w && y >= a.y && y < a.y + a.h) {
                int s = scroll.getOrDefault(a.key, 0) - (int) Math.signum(vAmount) * 16;
                scroll.put(a.key, Math.max(0, Math.min(a.max, s)));
                return true;
            }
        }
        return super.mouseScrolled(x, y, hAmount, vAmount);
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void removed() {
        MorphPreview.stop();
        EntityCfg.save();
        super.removed();
    }

    @Override
    public void close() {
        EntityCfg.save();
        client.setScreen(parent);
    }
}
