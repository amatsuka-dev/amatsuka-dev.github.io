package com.morphzuka;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Predicate;

/**
 * Jugadores transformados en bloque, que se comportan como un bloque solido: tienen colision, se puede caminar y
 * saltar encima de ellos y no se les empuja. Clase comun (cliente y servidor), igual que {@link HitboxRegistry}:
 *  - SERVER: los que el servidor acepto como morph de bloque (lo rellena ServerNet).
 *  - cliente: se pregunta a {@link #clientProvider} (forma propia y las que el servidor retransmite de los demas).
 * La leen los mixins EntityCollidableMixin y LivingPushableMixin en ambos lados.
 */
public final class BlockMorphRegistry {
    private BlockMorphRegistry() {}

    private static final Set<UUID> SERVER = ConcurrentHashMap.newKeySet();

    /** Solo cliente: true si ese jugador va transformado en bloque. */
    public static volatile Predicate<PlayerEntity> clientProvider;

    public static boolean solid(PlayerEntity p) {
        World w = p.getWorld();
        if (w == null || p.isSpectator() || !p.isAlive()) return false;
        if (!w.isClient) return SERVER.contains(p.getUuid());
        Predicate<PlayerEntity> f = clientProvider;
        return f != null && f.test(p);
    }

    public static void setServer(UUID u, boolean block) { if (block) SERVER.add(u); else SERVER.remove(u); }
    public static void clearServer() { SERVER.clear(); }
}
