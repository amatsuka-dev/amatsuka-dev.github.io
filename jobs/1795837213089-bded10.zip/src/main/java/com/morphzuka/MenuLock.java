package com.morphzuka;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.Locale;

/**
 * Bloqueo del menu/interfaz de MorphZuka para jugadores sin permisos. Clase comun: nada de cliente.
 * Los operadores nunca quedan bloqueados.
 */
public final class MenuLock {
    private MenuLock() {}

    public static boolean isOp(ServerPlayerEntity p) {
        MinecraftServer s = p.getServer();
        return s != null && s.getPlayerManager().isOperator(p.getGameProfile());
    }

    /** true si a este jugador se le bloquea el menu (global para no-ops, o por nombre). */
    public static boolean isLocked(ServerPlayerEntity p) {
        if (isOp(p)) return false;
        MzServerConfig c = MzServerConfig.INSTANCE;
        return c.lockNonOps || c.lockedPlayers.contains(p.getGameProfile().getName().toLowerCase(Locale.ROOT));
    }
}
