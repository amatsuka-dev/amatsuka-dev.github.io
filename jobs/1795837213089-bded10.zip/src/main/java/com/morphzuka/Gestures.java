package com.morphzuka;

import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelManager;
import net.minecraft.util.Util;

/** Animacion que el jugador lanza a mano (gesto o comando). Solo afecta a tu propio modelo. */
public final class Gestures {
    private Gestures() {}

    public static String current;
    /** Como se reproduce la animacion actual: repetir, una vez o pausar al terminar. */
    public static ModelManager.LoopMode mode = ModelManager.LoopMode.ONCE;
    private static long startMs;
    /** Sube cada vez que lanzas un gesto: asi el servidor distingue lanzar dos veces el mismo. */
    public static int playId;

    public static void play(String anim, ModelManager.LoopMode m) {
        current = anim;
        mode = m;
        playId++;
        startMs = Util.getMeasuringTimeMs();
        sliderAnim = null;
    }

    /** Lanza una animacion con el modo elegido para ella en los ajustes del modelo (o el del archivo). */
    public static void play(BBModel model, ModelManager.Settings s, String anim) {
        BBModel.Anim a = ModelManager.anim(model, anim);
        play(anim, a == null ? ModelManager.LoopMode.ONCE : ModelManager.loopMode(s, a, false));
    }

    public static String pose;                                   // pose personalizada (se mantiene hasta quitarla)
    public static final java.util.Set<String> toggles = new java.util.LinkedHashSet<>(); // capas toggle activas
    public static String setupModel;                             // modelo para el que ya se lanzo la animacion de inicio

    public static String sliderAnim;   // animacion controlada por slider
    public static float sliderT;       // 0..1

    public static void slider(String anim) { sliderAnim = anim; sliderT = 0f; current = null; }

    public static void stop() { current = null; sliderAnim = null; }

    public static boolean toggle(String anim) { return toggles.add(anim) || !toggles.remove(anim); }

    // ---------------------------------------------------------------- gestos de los demas jugadores (paso 35)

    /** Lo que otro jugador tiene lanzado a mano; llega por el servidor (GestureSync). */
    public static final class Remote {
        public String current, pose;
        public ModelManager.LoopMode mode = ModelManager.LoopMode.ONCE;
        public int playId;
        public long startMs;
        public java.util.List<String> toggles = java.util.List.of();
        public float elapsedSec() { return (Util.getMeasuringTimeMs() - startMs) / 1000f; }
    }

    private static final java.util.Map<java.util.UUID, Remote> REMOTE = new java.util.HashMap<>();

    public static Remote remote(java.util.UUID u) { return REMOTE.get(u); }

    public static void clearRemotes() { REMOTE.clear(); }

    public static void setRemote(java.util.UUID u, String current, byte mode, int playId, String pose, java.util.List<String> toggles) {
        if (current.isEmpty() && pose.isEmpty() && toggles.isEmpty()) { REMOTE.remove(u); return; }
        Remote r = REMOTE.computeIfAbsent(u, k -> new Remote());
        String cur = current.isEmpty() ? null : current;
        if (cur != null && (!cur.equals(r.current) || playId != r.playId)) r.startMs = Util.getMeasuringTimeMs();   // gesto nuevo: empieza ahora
        r.current = cur;
        r.playId = playId;
        ModelManager.LoopMode[] ms = ModelManager.LoopMode.values();
        r.mode = mode >= 0 && mode < ms.length ? ms[mode] : ModelManager.LoopMode.ONCE;
        r.pose = pose.isEmpty() ? null : pose;
        r.toggles = java.util.List.copyOf(toggles);
    }

    public static float elapsedSec() { return (Util.getMeasuringTimeMs() - startMs) / 1000f; }

    /** Solo "Una vez" termina sola; "Repetir" sigue hasta /morphzuka anim stop y "Pausar" se queda en el ultimo fotograma. */
    public static void tick(BBModel m) {
        if (current == null || m == null || mode != ModelManager.LoopMode.ONCE) return;
        BBModel.Anim a = ModelManager.anim(m, current);
        if (a == null || (a.length > 0 && elapsedSec() > a.length)) current = null;
    }
}
