package com.morphzuka.ui;

import com.morphzuka.model.ModelManager;
import com.morphzuka.render.MorphManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Util;
import net.minecraft.util.math.RotationAxis;
import org.joml.Quaternionf;

/**
 * Vista previa 3D de lo que llevas puesto (entidad, bloque, jugador o tu propio modelo) dentro de un menu.
 * Dibuja la misma entidad que ve el mundo, asi que lo que ves aqui (cabeza, golpe, patas) es lo que sale con tus ajustes
 * de {@link com.morphzuka.render.EntityCfg}. Los campos del jugador/entidad que toca se restauran al terminar.
 */
public final class MorphPreview {
    private MorphPreview() {}

    /** true mientras la vista previa prueba "Caminar": los pasos reales no deben pisar las patas. */
    public static boolean simWalk;

    private static final long T0 = Util.getMeasuringTimeMs();
    private static long lastLimb;

    public static void stop() { simWalk = false; }

    private static final class Snap {
        final Entity e;
        final double x, y, z;
        final float yaw, prevYaw, pitch, prevPitch;
        final int age;
        float body, prevBody, head, prevHead, swing, prevSwing;

        Snap(Entity e) {
            this.e = e;
            x = e.getX(); y = e.getY(); z = e.getZ();
            yaw = e.getYaw(); prevYaw = e.prevYaw; pitch = e.getPitch(); prevPitch = e.prevPitch;
            age = e.age;
            if (e instanceof LivingEntity le) {
                body = le.bodyYaw; prevBody = le.prevBodyYaw; head = le.headYaw; prevHead = le.prevHeadYaw;
                swing = le.handSwingProgress; prevSwing = le.lastHandSwingProgress;
            }
        }

        void restore() {
            e.setPosition(x, y, z);
            e.setYaw(yaw); e.prevYaw = prevYaw; e.setPitch(pitch); e.prevPitch = prevPitch;
            e.age = age;
            if (e instanceof LivingEntity le) {
                le.bodyYaw = body; le.prevBodyYaw = prevBody; le.headYaw = head; le.prevHeadYaw = prevHead;
                le.handSwingProgress = swing; le.lastHandSwingProgress = prevSwing;
            }
        }
    }

    /**
     * @param st    forma a mostrar (null = tu aspecto normal: skin o modelo propio)
     * @param yawDeg giro del visor en grados
     * @param zoom  1 = ajustado al recuadro
     * @param walk  simula caminar; swing = golpea cada ~1,1 s; look = mueve la cabeza de lado a lado
     * @return false si no se pudo dibujar
     */
    public static boolean draw(DrawContext g, MorphManager.State st, int x, int y, int w, int h,
                               float yawDeg, float zoom, boolean walk, boolean swing, boolean look) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || w < 8 || h < 8) return false;
        simWalk = walk;
        float t = (Util.getMeasuringTimeMs() - T0) / 1000f;
        MatrixStack ms = g.getMatrices();
        g.enableScissor(x, y, x + w, y + h);
        try {
            if (st != null && st.kind == MorphManager.Kind.BLOCK) return drawBlock(g, ms, mc, st, x, y, w, h, yawDeg, zoom);
            return drawEntity(g, ms, mc, st, x, y, w, h, yawDeg, zoom, walk, swing, look, t);
        } catch (Throwable ex) {
            ModelManager.LOG.warn("Vista previa fallo: {}", ex.toString());
            return false;
        } finally {
            g.disableScissor();
        }
    }

    private static boolean drawBlock(DrawContext g, MatrixStack ms, MinecraftClient mc, MorphManager.State st,
                                     int x, int y, int w, int h, float yawDeg, float zoom) {
        if (st.block == null) return false;
        float s = Math.min(w, h) * 0.5f * zoom;
        ms.push();
        try {
            ms.translate(x + w / 2f, y + h / 2f, 150f);
            ms.scale(s, s, -s);
            ms.multiply(new Quaternionf().rotationZ((float) Math.PI));
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-20f));
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yawDeg + 30f));
            ms.translate(-0.5, -0.5, -0.5);
            mc.getBlockRenderManager().renderBlockAsEntity(st.block, ms, g.getVertexConsumers(), 15728880, OverlayTexture.DEFAULT_UV);
            g.draw();
        } finally {
            ms.pop();
        }
        return true;
    }

    private static boolean drawEntity(DrawContext g, MatrixStack ms, MinecraftClient mc, MorphManager.State st,
                                      int x, int y, int w, int h, float yawDeg, float zoom,
                                      boolean walk, boolean swing, boolean look, float t) {
        Entity e = st == null ? mc.player : st.entity;
        if (e == null) return false;
        float bw = st == null ? 0.6f : st.w, bh = Math.max(0.2f, st == null ? 1.8f : st.h);
        float size = Math.max(bh, bw * 0.9f);
        float s = Math.max(1f, h * 0.78f / size) * zoom;

        Snap snap = new Snap(e);
        EntityRenderDispatcher disp = mc.getEntityRenderDispatcher();
        try {
            // animacion propia del mob (salto del conejo...): antes de mover el muneco lejos, para que su tick ocurra en un sitio normal
            if (st != null && st.kind == MorphManager.Kind.ENTITY) {
                float sw0 = swing ? (t % 1.1f) / 0.35f : 0f;
                if (sw0 >= 1f) sw0 = 0f;
                boolean nat = st != MorphManager.state() || com.morphzuka.render.EntityCfg.of(MorphManager.key()).nativeAnim;
                com.morphzuka.render.MorphAnim.step(e, walk, true, 0.0, sw0, nat);
            }
            float tt = t * 20f;
            e.age = (int) tt;
            float td = tt - (int) tt;
            if (st != null) e.setPosition(0, -4000, 0);      // lejos de la camara: no sale la etiqueta de nombre (el render usa 0,0,0)
            float headDelta = look ? 45f * (float) Math.sin(t * 1.4f) : 0f;
            float pitch = look ? 18f * (float) Math.sin(t * 0.9f) : 0f;
            e.setYaw(180f); e.prevYaw = 180f;
            e.setPitch(pitch); e.prevPitch = pitch;
            if (e instanceof LivingEntity le) {
                le.bodyYaw = 180f; le.prevBodyYaw = 180f;
                le.headYaw = 180f + headDelta; le.prevHeadYaw = le.headYaw;
                float sw = swing ? (t % 1.1f) / 0.35f : 0f;
                if (sw >= 1f) sw = 0f;
                le.handSwingProgress = sw; le.lastHandSwingProgress = sw;
                long now = Util.getMeasuringTimeMs();
                if (walk && now - lastLimb >= 50) {
                    lastLimb = now;
                    le.limbAnimator.updateLimbs(0.9f, 0.6f);
                } else if (!walk && simWalkWasOn) {
                    le.limbAnimator.updateLimbs(0f, 1f);
                }
            }
            simWalkWasOn = walk;

            ms.push();
            disp.setRenderShadows(false);
            try {
                ms.translate(x + w / 2f, y + h / 2f, 150f);
                ms.scale(s, s, -s);
                ms.translate(0f, bh / 2f, 0f);
                ms.multiply(new Quaternionf().rotationZ((float) Math.PI));
                ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-8f));
                ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yawDeg));
                float lift = st == null ? 0f : com.morphzuka.render.MorphAnim.lift(e, td);
                if (lift != 0f) ms.translate(0f, lift, 0f);
                disp.render(e, 0, 0, 0, 0f, td, ms, g.getVertexConsumers(), 15728880);
                g.draw();
            } finally {
                disp.setRenderShadows(true);
                ms.pop();
            }
        } finally {
            snap.restore();
        }
        return true;
    }

    private static boolean simWalkWasOn;
}
