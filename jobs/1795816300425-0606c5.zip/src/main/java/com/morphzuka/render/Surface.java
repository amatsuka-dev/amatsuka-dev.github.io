package com.morphzuka.render;

import com.morphzuka.model.BBModel;
import com.morphzuka.model.CubeXform;
import com.morphzuka.model.ModelManager;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.Model;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.BakedQuad;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.texture.SpriteAtlasTexture;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * La piel de una {@link Form}: lista de caras (cada una con su textura y su rectangulo UV) de la que se pueden sacar
 * puntos repartidos por la superficie. Cada punto trae el parche de textura (unos 2x2 pixeles) que hay justo ahi, asi un
 * cubo pequeno puede llevar "el trocito de skin" que le toca. Coordenadas en bloques, relativas a los pies,
 * en el marco del modelo (frente = -Z).
 */
final class Surface {
    /** Un punto de la superficie con el parche de textura que le corresponde. */
    static final class Pt {
        float x, y, z, nx, ny, nz;
        float u1, v1, u2, v2;     // parche de textura (normalizado 0..1)
        int tint = 0xFFFFFF;
        float key;                // para emparejar origen y destino por altura y angulo
    }

    private static final class Face {
        final float[] a = new float[3], ab = new float[3], ad = new float[3], n = new float[3];
        float u1, v1, u2, v2;     // rectangulo UV de la cara
        float px, py;             // tamano de un pixel de textura en unidades UV
        boolean randomUv;         // sin mapa UV conocido: parche al azar entre los pixeles opacos
        int tint = 0xFFFFFF;
        float lu, lv, area;
    }

    final Identifier tex;
    final boolean atlas;
    final boolean palette;        // caja generica: cada cubo lleva un color de la paleta
    float minY = Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
    float area;
    private final List<Face> faces = new ArrayList<>();
    private TexPixels pix;

    private Surface(Identifier tex, boolean atlas, boolean palette) { this.tex = tex; this.atlas = atlas; this.palette = palette; }

    // ================================================================ construccion

    static Surface of(Form f) {
        try {
            Surface s = switch (f.type) {
                case MODEL -> ofModel(f);
                case BLOCK -> ofBlock(f);
                case ENTITY -> {
                    Surface e = ofEntity(f);
                    yield e != null ? e : ofBox(f, f.tex != null ? f.tex : Form.WHITE, f.tex == null);
                }
                default -> ofBox(f, Form.WHITE, true);
            };
            if (s.faces.isEmpty()) s = ofBox(f, Form.WHITE, true);
            return s;
        } catch (Throwable t) {
            ModelManager.LOG.warn("Efecto de cubos: no se pudo leer la superficie ({}): {}", f.type, t.toString());
            return ofBox(f, Form.WHITE, true);
        }
    }

    private static Surface ofBox(Form f, Identifier tex, boolean palette) {
        Surface s = new Surface(tex, false, palette);
        s.pix = palette ? null : TexPixels.get(tex);
        float hw = f.w * 0.5f;
        for (int d = 0; d < 6; d++) {
            Face fc = s.boxFace(-hw, 0f, -hw, hw, f.h, hw, d, null);
            fc.randomUv = !palette;
            fc.u1 = 0f; fc.v1 = 0f; fc.u2 = 1f; fc.v2 = 1f;
            fc.px = fc.py = 1f / 32f;
        }
        return s;
    }

    private static Surface ofBlock(Form f) {
        Surface s = new Surface(SpriteAtlasTexture.BLOCK_ATLAS_TEXTURE, true, false);
        MinecraftClient mc = MinecraftClient.getInstance();
        BlockState st = f.block;
        BakedModel bm = mc.getBlockRenderManager().getModel(st);
        Direction[] dirs = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP, Direction.DOWN};
        // Forma real del bloque (escaleras, losas, vallas...): se usan los quads del modelo, no una caja entera
        List<BakedQuad> all = new ArrayList<>();
        try {
            for (Direction d : dirs) all.addAll(bm.getQuads(st, d, Random.create(42L)));
            all.addAll(bm.getQuads(st, null, Random.create(42L)));
        } catch (Throwable ignored) {}
        for (BakedQuad q : all) {
            try {
                int[] vd = q.getVertexData();
                if (vd.length < 32) continue;
                float[][] p = new float[4][3], uv = new float[4][2];
                for (int i = 0; i < 4; i++) {
                    p[i][0] = Float.intBitsToFloat(vd[i * 8]) - 0.5f;
                    p[i][1] = Float.intBitsToFloat(vd[i * 8 + 1]);
                    p[i][2] = Float.intBitsToFloat(vd[i * 8 + 2]) - 0.5f;
                    uv[i][0] = Float.intBitsToFloat(vd[i * 8 + 4]);
                    uv[i][1] = Float.intBitsToFloat(vd[i * 8 + 5]);
                }
                Sprite sp = q.getSprite();
                float pw = (sp.getMaxU() - sp.getMinU()) / 16f, ph = (sp.getMaxV() - sp.getMinV()) / 16f;
                int tint = 0xFFFFFF;
                if (q.hasColor()) {
                    int c = mc.getBlockColors().getColor(st, null, null, q.getColorIndex());
                    if (c != -1) tint = c & 0xFFFFFF;
                }
                Direction fd = q.getFace();
                Face fc = s.addQuad(p, uv, pw, ph, new float[]{fd.getOffsetX(), fd.getOffsetY(), fd.getOffsetZ()});
                if (fc != null) fc.tint = tint;
            } catch (Throwable ignored) {}
        }
        if (!s.faces.isEmpty()) return s;
        // respaldo: caja entera
        Sprite fallback = mc.getBlockRenderManager().getModels().getModelParticleSprite(st);
        for (int d = 0; d < 6; d++) {
            Face fc = s.boxFace(-0.49f, 0.01f, -0.49f, 0.49f, 0.99f, 0.49f, d, null);
            fc.u1 = fallback.getMinU(); fc.u2 = fallback.getMaxU(); fc.v1 = fallback.getMinV(); fc.v2 = fallback.getMaxV();
            fc.px = (fc.u2 - fc.u1) / 16f;
            fc.py = (fc.v2 - fc.v1) / 16f;
        }
        return s;
    }

    /** Recoge los vertices que dibuja un modelo (sin dibujar nada) para copiar su forma real. */
    private static final class Capture implements VertexConsumer {
        final List<float[]> v = new ArrayList<>();   // x, y, z, u, v
        private float[] cur;
        @Override public VertexConsumer vertex(double x, double y, double z) { cur = new float[]{(float) x, (float) y, (float) z, 0f, 0f}; v.add(cur); return this; }
        @Override public VertexConsumer color(int r, int g, int b, int a) { return this; }
        @Override public VertexConsumer texture(float u, float w) { if (cur != null) { cur[3] = u; cur[4] = w; } return this; }
        @Override public VertexConsumer overlay(int u, int w) { return this; }
        @Override public VertexConsumer light(int u, int w) { return this; }
        @Override public VertexConsumer normal(float x, float y, float z) { return this; }
    }

    /** La forma real de una entidad: se le pide a su modelo que se dibuje en un recolector y cada cuadrilatero pasa a ser una cara. */
    private static Surface ofEntity(Form f) {
        if (f.ent == null || f.tex == null) return null;
        Object mo = PartTree.modelOf(f.ent);
        if (!(mo instanceof Model model)) return null;
        Surface s = new Surface(f.tex, false, false);
        s.pix = TexPixels.get(f.tex);
        float pw = s.pix != null && s.pix.w > 0 ? 1f / s.pix.w : 1f / 64f;
        float ph = s.pix != null && s.pix.h > 0 ? 1f / s.pix.h : 1f / 64f;
        Capture cap = new Capture();
        MatrixStack ms = new MatrixStack();
        ms.scale(-1f, -1f, 1f);              // igual que LivingEntityRenderer: el modelo viene boca abajo
        ms.translate(0f, -1.501f, 0f);
        model.render(ms, cap, 0, OverlayTexture.DEFAULT_UV, 0xFFFFFFFF);
        int n = cap.v.size() / 4;
        if (n == 0) return null;
        float cx = 0, cy = 0, cz = 0;
        for (float[] q : cap.v) { cx += q[0]; cy += q[1]; cz += q[2]; }
        cx /= cap.v.size(); cy /= cap.v.size(); cz /= cap.v.size();
        for (int i = 0; i < n; i++) {
            float[][] p = new float[4][3], uv = new float[4][2];
            for (int k = 0; k < 4; k++) {
                float[] q = cap.v.get(i * 4 + k);
                p[k][0] = q[0]; p[k][1] = q[1]; p[k][2] = q[2];
                uv[k][0] = q[3]; uv[k][1] = q[4];
            }
            // normal por producto vectorial, orientada hacia fuera del centro del modelo
            float[] ab = {p[1][0] - p[0][0], p[1][1] - p[0][1], p[1][2] - p[0][2]};
            float[] ad = {p[3][0] - p[0][0], p[3][1] - p[0][1], p[3][2] - p[0][2]};
            float[] nn = {ab[1] * ad[2] - ab[2] * ad[1], ab[2] * ad[0] - ab[0] * ad[2], ab[0] * ad[1] - ab[1] * ad[0]};
            float l = len(nn);
            if (l < 1e-8f) continue;
            nn[0] /= l; nn[1] /= l; nn[2] /= l;
            float mx = (p[0][0] + p[2][0]) * 0.5f - cx, my = (p[0][1] + p[2][1]) * 0.5f - cy, mz = (p[0][2] + p[2][2]) * 0.5f - cz;
            if (nn[0] * mx + nn[1] * my + nn[2] * mz < 0f) { nn[0] = -nn[0]; nn[1] = -nn[1]; nn[2] = -nn[2]; }
            s.addQuad(p, uv, pw, ph, nn);
        }
        return s.faces.isEmpty() ? null : s;
    }

    /**
     * Anade un cuadrilatero (vertices 0..3 en orden) con su UV. El eje A->B debe llevar la U y A->D la V; si el cuadrilatero
     * esta girado se intercambian los ejes.
     */
    private Face addQuad(float[][] p, float[][] uv, float pw, float ph, float[] n) {
        float du01 = Math.abs(uv[1][0] - uv[0][0]), dv01 = Math.abs(uv[1][1] - uv[0][1]);
        int b = 1, d = 3;
        if (dv01 > du01) { b = 3; d = 1; }
        Face fc = new Face();
        for (int i = 0; i < 3; i++) {
            fc.a[i] = p[0][i];
            fc.ab[i] = p[b][i] - p[0][i];
            fc.ad[i] = p[d][i] - p[0][i];
            fc.n[i] = n[i];
        }
        fc.u1 = uv[0][0]; fc.v1 = uv[0][1];
        fc.u2 = uv[2][0]; fc.v2 = uv[2][1];
        fc.px = pw; fc.py = ph;
        fc.lu = len(fc.ab);
        fc.lv = len(fc.ad);
        fc.area = fc.lu * fc.lv;
        if (fc.area <= 1e-6f) return null;
        faces.add(fc);
        area += fc.area;
        for (int i = 0; i < 4; i++) { minY = Math.min(minY, p[i][1]); maxY = Math.max(maxY, p[i][1]); }
        return fc;
    }

    private static Surface ofModel(Form f) {
        BBModel m = f.model;
        ModelManager.Settings st = f.settings;
        Surface s = new Surface(f.tex, false, false);
        s.pix = TexPixels.get(f.tex);
        float k = (st.scale <= 0 ? 1f : st.scale) / 16f;
        Matrix4f root = new Matrix4f().scale(k);
        for (BBModel.Bone b : m.roots) s.walk(m, st, b, root);
        return s;
    }

    private void walk(BBModel m, ModelManager.Settings st, BBModel.Bone b, Matrix4f parent) {
        Matrix4f mt = new Matrix4f(parent);
        float[] piv = st.pivots.containsKey(b.name) ? st.pivots.get(b.name) : b.pivot;
        float[] off = st.offsets.get(b.name), ro = st.rotOffsets.get(b.name), bs = st.scales.get(b.name);
        mt.translate(piv[0] + (off == null ? 0 : off[0]), piv[1] + (off == null ? 0 : off[1]), piv[2] + (off == null ? 0 : off[2]));
        mt.rotateZYX((float) Math.toRadians(b.rot[2] + (ro == null ? 0 : ro[2])), (float) Math.toRadians(b.rot[1] + (ro == null ? 0 : ro[1])),
                (float) Math.toRadians(b.rot[0] + (ro == null ? 0 : ro[0])));
        if (bs != null) mt.scale(Math.max(0.001f, bs[0]), Math.max(0.001f, bs[1]), Math.max(0.001f, bs[2]));
        mt.translate(-piv[0], -piv[1], -piv[2]);

        if (b.visible && !st.hidden.contains(b.name)) {
            int uvW = com.morphzuka.render.BBRenderer.uvW(m, st), uvH = com.morphzuka.render.BBRenderer.uvH(m, st);
            float kx = com.morphzuka.render.BBRenderer.uvKx(m, st), ky = com.morphzuka.render.BBRenderer.uvKy(m, st);
            float[] uv = new float[4];
            for (BBModel.Cube cu : b.cubes) {
                Matrix4f cm = new Matrix4f(mt);
                CubeXform.apply(cm, cu, st);
                float i = cu.inflate;
                float[] sh = st.uvShift.isEmpty() ? null : st.uvShift.get(cu.key);
                for (int d = 0; d < 6; d++) {
                    if (!com.morphzuka.render.BBRenderer.uvRect(cu, d, kx, ky, sh, uv)) continue;
                    Face fc = boxFace(cu.from[0] - i, cu.from[1] - i, cu.from[2] - i, cu.to[0] + i, cu.to[1] + i, cu.to[2] + i, d, cm);
                    fc.u1 = uv[0] / uvW; fc.v1 = uv[1] / uvH; fc.u2 = uv[2] / uvW; fc.v2 = uv[3] / uvH;
                    fc.px = 1f / Math.max(1, m.imgW);   // un pixel real de la imagen, en unidades UV
                    fc.py = 1f / Math.max(1, m.imgH);
                }
            }
        }
        for (BBModel.Bone c : b.children) walk(m, st, c, mt);
    }

    /**
     * Cara de una caja: A = esquina del vertice 0, AB = eje U, AD = eje V (mismo orden de vertices que BBRenderer.cube,
     * asi el UV de cada punto coincide con lo que se ve dibujado). 'm' transforma de px del modelo a bloques (o null).
     */
    private Face boxFace(float x0, float y0, float z0, float x1, float y1, float z1, int dir, Matrix4f m) {
        float[] A, B, D, N;
        switch (dir) {
            case 0 -> { A = new float[]{x1, y1, z0}; B = new float[]{x0, y1, z0}; D = new float[]{x1, y0, z0}; N = new float[]{0, 0, -1}; }
            case 1 -> { A = new float[]{x0, y1, z1}; B = new float[]{x1, y1, z1}; D = new float[]{x0, y0, z1}; N = new float[]{0, 0, 1}; }
            case 2 -> { A = new float[]{x1, y1, z1}; B = new float[]{x1, y1, z0}; D = new float[]{x1, y0, z1}; N = new float[]{1, 0, 0}; }
            case 3 -> { A = new float[]{x0, y1, z0}; B = new float[]{x0, y1, z1}; D = new float[]{x0, y0, z0}; N = new float[]{-1, 0, 0}; }
            case 4 -> { A = new float[]{x0, y1, z0}; B = new float[]{x1, y1, z0}; D = new float[]{x0, y1, z1}; N = new float[]{0, 1, 0}; }
            default -> { A = new float[]{x0, y0, z1}; B = new float[]{x1, y0, z1}; D = new float[]{x0, y0, z0}; N = new float[]{0, -1, 0}; }
        }
        Face fc = new Face();
        Vector3f a = new Vector3f(A[0], A[1], A[2]), b = new Vector3f(B[0], B[1], B[2]), dd = new Vector3f(D[0], D[1], D[2]), n = new Vector3f(N[0], N[1], N[2]);
        if (m != null) { m.transformPosition(a); m.transformPosition(b); m.transformPosition(dd); m.transformDirection(n); n.normalize(); }
        fc.a[0] = a.x; fc.a[1] = a.y; fc.a[2] = a.z;
        fc.ab[0] = b.x - a.x; fc.ab[1] = b.y - a.y; fc.ab[2] = b.z - a.z;
        fc.ad[0] = dd.x - a.x; fc.ad[1] = dd.y - a.y; fc.ad[2] = dd.z - a.z;
        fc.n[0] = n.x; fc.n[1] = n.y; fc.n[2] = n.z;
        fc.lu = len(fc.ab);
        fc.lv = len(fc.ad);
        fc.area = fc.lu * fc.lv;
        if (fc.area <= 1e-6f) return fc;   // cara aplastada: no cuenta
        faces.add(fc);
        area += fc.area;
        float[] ys = {a.y, b.y, dd.y, b.y + dd.y - a.y};
        for (float y : ys) { minY = Math.min(minY, y); maxY = Math.max(maxY, y); }
        return fc;
    }

    private static float len(float[] v) { return (float) Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]); }

    // ================================================================ muestreo

    /** Cuantos puntos saldrian con cubos de lado s (sin azar), para ajustar s al limite. */
    int count(float s) {
        int n = 0;
        for (Face f : faces) {
            if (f.area < 0.3f * s * s) { n += 0; continue; }
            n += Math.max(1, Math.round(f.lu / s)) * Math.max(1, Math.round(f.lv / s));
        }
        return Math.max(n, 1);
    }

    /** Lado de cubo que reparte unos 'target' cubos por la superficie, subido hasta no pasar de 'max'. */
    float cubeSize(int target, int max) {
        float s = (float) Math.sqrt(Math.max(area, 0.05f) / target);
        s = Math.max(0.05f, Math.min(0.32f, s));
        for (int i = 0; i < 12 && count(s) > max; i++) s *= 1.12f;
        return s;
    }

    /** Puntos repartidos por la superficie (rejilla con un poco de azar por cara). */
    List<Pt> scatter(float s, java.util.Random r) {
        List<Pt> out = new ArrayList<>();
        float h = Math.max(0.01f, maxY - minY);
        for (Face f : faces) {
            float small = 0.3f * s * s;
            if (f.area < small) {   // cara diminuta: a veces un cubo, a veces nada
                if (r.nextFloat() < f.area / small) add(out, f, 0.5f, 0.5f, r, h);
                continue;
            }
            int nu = Math.max(1, Math.round(f.lu / s)), nv = Math.max(1, Math.round(f.lv / s));
            for (int i = 0; i < nu; i++)
                for (int j = 0; j < nv; j++)
                    add(out, f, (i + 0.5f + (r.nextFloat() - 0.5f) * 0.5f) / nu, (j + 0.5f + (r.nextFloat() - 0.5f) * 0.5f) / nv, r, h);
        }
        return out;
    }

    private static final int[] PALETTE = {0x2EE6E6, 0x4CB5FF, 0xA64CFF, 0xFF4CE0, 0xFFFFFF, 0x7CFF4C};

    private void add(List<Pt> out, Face f, float a, float b, java.util.Random r, float h) {
        Pt p = new Pt();
        p.x = f.a[0] + f.ab[0] * a + f.ad[0] * b;
        p.y = f.a[1] + f.ab[1] * a + f.ad[1] * b;
        p.z = f.a[2] + f.ad[2] * b + f.ab[2] * a;
        p.nx = f.n[0]; p.ny = f.n[1]; p.nz = f.n[2];
        p.tint = f.tint;
        float cu, cv;
        if (f.randomUv) {
            float[] q = pix == null ? null : pix.randomOpaque(r);
            if (q == null) { q = new float[]{r.nextFloat(), r.nextFloat()}; }
            cu = q[0]; cv = q[1];
        } else {
            cu = f.u1 + (f.u2 - f.u1) * a;
            cv = f.v1 + (f.v2 - f.v1) * b;
            if (pix != null && !pix.opaqueAt(cu, cv)) return;   // zona transparente de la textura: ese cubo no existe
        }
        float loU = Math.min(f.u1, f.u2), hiU = Math.max(f.u1, f.u2), loV = Math.min(f.v1, f.v2), hiV = Math.max(f.v1, f.v2);
        if (f.randomUv) { loU = 0f; hiU = 1f; loV = 0f; hiV = 1f; }
        p.u1 = Math.max(loU, cu - f.px); p.u2 = Math.min(hiU, cu + f.px);
        p.v1 = Math.max(loV, cv - f.py); p.v2 = Math.min(hiV, cv + f.py);
        if (p.u2 <= p.u1) { p.u1 = cu; p.u2 = cu + f.px * 0.5f; }
        if (p.v2 <= p.v1) { p.v1 = cv; p.v2 = cv + f.py * 0.5f; }
        if (palette) p.tint = PALETTE[r.nextInt(PALETTE.length)];
        float yn = Math.max(0f, Math.min(0.999f, (p.y - minY) / h));
        float ang = (float) ((Math.atan2(p.z, p.x) + Math.PI) / (Math.PI * 2));
        p.key = (int) (yn * 10f) + ang;
        out.add(p);
    }
}
