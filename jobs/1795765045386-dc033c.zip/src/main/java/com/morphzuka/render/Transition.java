package com.morphzuka.render;

import com.morphzuka.model.ModelManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.Util;

/** Animacion de transformacion: nube de particulas + el modelo "salta" desde cero con rebote. Solo para tu propio jugador. */
public final class Transition {
    private Transition() {}

    private static String key;
    private static long start = -1;
    private static final float DURATION_MS = 550f;

    public static void check(String newKey, ClientPlayerEntity p) {
        if (key == null) { key = newKey; return; }
        if (key.equals(newKey)) return;
        key = newKey;
        start = Util.getMeasuringTimeMs();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || p == null || !ModelManager.CONFIG.cubeEffect) return;
        for (int i = 0; i < 28; i++) {
            double ox = (mc.world.random.nextDouble() - 0.5) * 1.2;
            double oy = mc.world.random.nextDouble() * 1.8;
            double oz = (mc.world.random.nextDouble() - 0.5) * 1.2;
            mc.world.addParticle(i % 3 == 0 ? ParticleTypes.CLOUD : ParticleTypes.POOF, p.getX() + ox, p.getY() + oy, p.getZ() + oz, 0, 0.03, 0);
        }
    }

    /** 1 normalmente; durante la transformacion crece de 0 con rebote (easeOutBack). */
    public static float scale() {
        if (start < 0) return 1f;
        float t = (Util.getMeasuringTimeMs() - start) / DURATION_MS;
        if (t >= 1f) { start = -1; return 1f; }
        float c1 = 1.70158f, c3 = c1 + 1f, u = t - 1f;
        return Math.max(0.01f, 1f + c3 * u * u * u + c1 * u * u);
    }
}
