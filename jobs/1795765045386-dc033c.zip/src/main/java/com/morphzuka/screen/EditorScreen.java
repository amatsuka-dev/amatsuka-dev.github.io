package com.morphzuka.screen;

import com.morphzuka.Role;
import com.morphzuka.model.BBModel;
import com.morphzuka.model.ModelManager;
import com.morphzuka.render.BBRenderer;
import com.morphzuka.render.PreviewSim;
import com.morphzuka.ui.Background;
import com.morphzuka.ui.Gfx;
import com.morphzuka.ui.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Editor 3D de partes: visor orbital del modelo, selector de partes (lista o puntos de pivote en el visor),
 * gizmo para mover / rotar / escalar / mover pivote, y campos XYZ numericos.
 * Todo se guarda en los ajustes del modelo (offsets, rotOffsets, scales, pivots), no modifica el archivo original.
 */
public class EditorScreen extends Screen {

    private enum Mode {
        MOVE("Mover"), ROTATE("Rotar"), SCALE("Escalar"), PIVOT("Pivote");
        final String label;
        Mode(String l) { label = l; }
    }

    private static final int[] AXC = {0xFFE04848, 0xFF58C458, 0xFF4880E0};
    private static final String[] AXN = {"X", "Y", "Z"};
    private static final float[] ZERO3 = {0, 0, 0};
    private static final int ROW = 14;

    private static final class Hit { int x, y, w, h; Runnable r; }

    /** Datos del gizmo para el hueso seleccionado, en coordenadas de pantalla. */
    private static final class Gz {
        float ox, oy;                 // origen en pantalla
        float len;                    // largo de los ejes en unidades del modelo
        final float[][] axis = new float[3][2];     // desplazamiento en pantalla de cada eje (len unidades)
        final float[][] ru = new float[3][2], rv = new float[3][2]; // vectores del aro de rotacion de cada eje
    }

    private record Snap(String bone, float[] off, float[] rot, float[] sc, float[] piv) {}

    private final Screen parent;
    private final BBModel model;
    private final ModelManager.Settings s;
    private String sel;
    private Mode mode = Mode.MOVE;

    private float yaw = 25f, pitch = 12f, zoom = 1f;
    private int vx, vy, vw, vh;       // viewport
    private int mx, my;
    private final List<Hit> hits = new ArrayList<>();
    private final Map<String, float[]> dots = new LinkedHashMap<>();
    private final Deque<Snap> undo = new ArrayDeque<>();
    private int listScroll;
    private String selCube;                                      // bloque elegido (clave hueso#indice)
    private final java.util.Set<String> collapsed = new java.util.HashSet<>();
    private final List<Row> rows = new ArrayList<>();
    private boolean rowsDirty = true;
    private boolean pressMoved;
    private double pressX, pressY;
    private record Row(BBModel.Bone bone, BBModel.Cube cube) {}
    private String status = "";

    private TextFieldWidget[] f = new TextFieldWidget[3];
    private boolean syncing;

    // estado de arrastre
    private boolean orbit;
    private int dragAxis = -1;
    private Mode dragMode;
    private double dsx, dsy;
    private float[] startVal;
    private float dax, day, dLen, dGox, dGoy, rotSign, rotLast, rotAcc;

    public EditorScreen(Screen parent, BBModel model, String bone) {
        super(Text.literal("Editor 3D"));
        this.parent = parent;
        this.model = model;
        this.s = ModelManager.settings(model);
        this.sel = bone != null && model.bones.containsKey(bone) ? bone : null;
    }

    // ================================================================ init

    @Override
    protected void init() {
        for (int i = 0; i < 3; i++) {
            final int k = i;
            TextFieldWidget t = new TextFieldWidget(textRenderer, 0, 0, 50, 12, Text.literal(AXN[i]));
            t.setDrawsBackground(false);
            t.setMaxLength(12);
            t.setEditableColor(Theme.c("text"));
            t.setPlaceholder(Text.literal(AXN[i]).formatted(Formatting.DARK_GRAY));
            t.setChangedListener(str -> onField(k, str));
            addDrawableChild(t);
            f[i] = t;
        }
        syncFields();
    }

    private void onField(int i, String str) {
        if (syncing || sel == null) return;
        try {
            float v = Float.parseFloat(str.trim());
            float[] cur = get(mode, sel).clone();
            cur[i] = v;
            set(mode, sel, cur);
        } catch (Exception ignored) {}
    }

    private void syncFields() {
        syncing = true;
        for (int i = 0; i < 3; i++) f[i].setText(sel == null ? "" : fmt(get(mode, sel)[i]));
        syncing = false;
    }

    // ================================================================ datos

    private float[] get(Mode m, String b) {
        return switch (m) {
            case MOVE -> s.offsets.getOrDefault(b, ZERO3);
            case ROTATE -> s.rotOffsets.getOrDefault(b, ZERO3);
            case SCALE -> s.scales.getOrDefault(b, new float[]{1, 1, 1});
            case PIVOT -> s.pivots.containsKey(b) ? s.pivots.get(b) : model.bones.get(b).pivot;
        };
    }

    private void set(Mode m, String b, float[] v) {
        switch (m) {
            case MOVE -> s.offsets.put(b, v);
            case ROTATE -> s.rotOffsets.put(b, v);
            case SCALE -> s.scales.put(b, v);
            case PIVOT -> s.pivots.put(b, v);
        }
    }

    private float[] pivotOf(BBModel.Bone b) { return s.pivots.containsKey(b.name) ? s.pivots.get(b.name) : b.pivot; }

    private static float[] cp(float[] a) { return a == null ? null : a.clone(); }

    private void snapshot() {
        if (sel == null) return;
        undo.push(new Snap(sel, cp(s.offsets.get(sel)), cp(s.rotOffsets.get(sel)), cp(s.scales.get(sel)), cp(s.pivots.get(sel))));
        if (undo.size() > 60) undo.removeLast();
    }

    private static void put(Map<String, float[]> m, String k, float[] v) { if (v == null) m.remove(k); else m.put(k, v); }

    private void restore() {
        Snap k = undo.poll();
        if (k == null) { status = "Nada que deshacer"; return; }
        put(s.offsets, k.bone(), k.off());
        put(s.rotOffsets, k.bone(), k.rot());
        put(s.scales, k.bone(), k.sc());
        put(s.pivots, k.bone(), k.piv());
        sel = k.bone();
        syncFields();
        status = "Deshecho";
    }

    private void resetBone() {
        if (sel == null) return;
        snapshot();
        s.offsets.remove(sel); s.rotOffsets.remove(sel); s.scales.remove(sel); s.pivots.remove(sel);
        syncFields();
        status = "Parte restaurada";
    }

    private void resetAll() {
        s.offsets.clear(); s.rotOffsets.clear(); s.scales.clear(); s.pivots.clear();
        undo.clear();
        syncFields();
        status = "Todo restaurado";
    }

    private void setRole(Role r) {
        if (sel == null) return;
        if (r == Role.NONE) s.roles.remove(sel); else s.roles.put(sel, r.name());
        status = r == Role.NONE ? "Rol quitado" : "Rol: " + r.label;
    }

    private void select(String name) {
        sel = name;
        selCube = null;
        syncFields();
        scrollToSelection();
    }

    private void selectCube(BBModel.Bone b, BBModel.Cube c) {
        sel = b.name;
        selCube = c.key;
        syncFields();
        for (BBModel.Bone p : pathTo(b.name)) if (collapsed.remove(p.name)) rowsDirty = true;   // abre los grupos plegados
        scrollToSelection();
    }

    private void buildRows() {
        rows.clear();
        for (BBModel.Bone r : model.roots) addRows(r);
        rowsDirty = false;
    }

    private void addRows(BBModel.Bone b) {
        rows.add(new Row(b, null));
        if (collapsed.contains(b.name)) return;
        for (BBModel.Cube c : b.cubes) rows.add(new Row(b, c));
        for (BBModel.Bone ch : b.children) addRows(ch);
    }

    private void scrollToSelection() {
        if (rowsDirty) buildRows();
        int idx = -1;
        for (int i = 0; i < rows.size(); i++) {
            Row r = rows.get(i);
            boolean hit = selCube != null ? r.cube() != null && r.cube().key.equals(selCube) : r.cube() == null && r.bone().name.equals(sel);
            if (hit) { idx = i; break; }
        }
        if (idx < 0) return;
        int vr = visibleRows();
        if (idx < listScroll) listScroll = idx;
        else if (idx >= listScroll + vr) listScroll = idx - vr + 1;
    }

    private static String fmt(float v) {
        float r = Math.round(v * 100f) / 100f;
        return r == (long) r ? Long.toString((long) r) : Float.toString(r);
    }

    // ================================================================ matematicas del visor

    private float pxPerBlock() { return zoom * Math.min(vh, vw) / 2.3f; }

    private float scaleK() { return pxPerBlock() * (s.scale <= 0 ? 1f : s.scale) / 16f; } // px de pantalla por unidad del modelo

    /** Matriz modelo(px) -> pantalla. Igual que la cadena de MatrixStack usada al dibujar. */
    private Matrix4f view() {
        float S = pxPerBlock();
        float sc = s.scale <= 0 ? 1f : s.scale;
        return new Matrix4f()
                .translate(vx + vw / 2f, vy + vh / 2f, 0f)
                .scale(S, S, -S)
                .rotateZ((float) Math.PI)
                .rotateX((float) Math.toRadians(pitch))
                .rotateY((float) Math.toRadians(yaw))
                .translate(0f, -1f, 0f)
                .scale(sc / 16f, sc / 16f, sc / 16f);
    }

    /** Aplica la transformacion de un hueso, igual que BBRenderer.bone (sin animacion). */
    private void apply(Matrix4f m, BBModel.Bone b, boolean withScale) {
        float[] piv = pivotOf(b);
        float[] off = s.offsets.getOrDefault(b.name, ZERO3);
        float[] ro = s.rotOffsets.getOrDefault(b.name, ZERO3);
        float[] sc = s.scales.get(b.name);
        m.translate(piv[0] + off[0], piv[1] + off[1], piv[2] + off[2]);
        m.rotateZ((float) Math.toRadians(b.rot[2] + ro[2]));
        m.rotateY((float) Math.toRadians(b.rot[1] + ro[1]));
        m.rotateX((float) Math.toRadians(b.rot[0] + ro[0]));
        if (withScale && sc != null) m.scale(Math.max(0.001f, sc[0]), Math.max(0.001f, sc[1]), Math.max(0.001f, sc[2]));
        m.translate(-piv[0], -piv[1], -piv[2]);
    }

    private List<BBModel.Bone> pathTo(String name) {
        List<BBModel.Bone> out = new ArrayList<>();
        for (BBModel.Bone r : model.roots) if (dfs(r, name, out)) break;
        return out;
    }

    private boolean dfs(BBModel.Bone b, String name, List<BBModel.Bone> out) {
        out.add(b);
        if (b.name.equals(name)) return true;
        for (BBModel.Bone c : b.children) if (dfs(c, name, out)) return true;
        out.remove(out.size() - 1);
        return false;
    }

    private static Vector3f unit(int i) { return new Vector3f(i == 0 ? 1 : 0, i == 1 ? 1 : 0, i == 2 ? 1 : 0); }

    private Gz gizmo() {
        if (sel == null) return null;
        List<BBModel.Bone> p = pathTo(sel);
        if (p.isEmpty()) return null;
        Matrix4f m = view();
        for (int i = 0; i < p.size() - 1; i++) apply(m, p.get(i), true);
        BBModel.Bone b = p.get(p.size() - 1);
        float[] piv = pivotOf(b);
        float[] off = s.offsets.getOrDefault(sel, ZERO3);
        Vector3f o = m.transformPosition(new Vector3f(piv[0] + off[0], piv[1] + off[1], piv[2] + off[2]));
        Gz g = new Gz();
        g.ox = o.x;
        g.oy = o.y;
        float k = Math.max(0.0001f, scaleK());
        g.len = 70f / k;
        float ring = 55f / k;
        Matrix4f dm = m;
        if (mode == Mode.SCALE) { dm = new Matrix4f(m); apply(dm, b, false); }
        for (int i = 0; i < 3; i++) {
            Vector3f d = dm.transformDirection(unit(i), new Vector3f());
            g.axis[i][0] = d.x * g.len;
            g.axis[i][1] = d.y * g.len;
            Vector3f u = m.transformDirection(unit((i + 1) % 3), new Vector3f());
            Vector3f v = m.transformDirection(unit((i + 2) % 3), new Vector3f());
            g.ru[i][0] = u.x * ring; g.ru[i][1] = u.y * ring;
            g.rv[i][0] = v.x * ring; g.rv[i][1] = v.y * ring;
        }
        return g;
    }

    private void collectDots(BBModel.Bone b, Matrix4f parentM) {
        float[] piv = pivotOf(b);
        float[] off = s.offsets.getOrDefault(b.name, ZERO3);
        Vector3f v = parentM.transformPosition(new Vector3f(piv[0] + off[0], piv[1] + off[1], piv[2] + off[2]));
        dots.put(b.name, new float[]{v.x, v.y});
        Matrix4f m = new Matrix4f(parentM);
        apply(m, b, true);
        for (BBModel.Bone c : b.children) collectDots(c, m);
    }

    private static double segDist(double px, double py, double ax, double ay, double bx, double by) {
        double dx = bx - ax, dy = by - ay;
        double l2 = dx * dx + dy * dy;
        double t = l2 < 1e-6 ? 0 : Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / l2));
        double cx = ax + t * dx, cy = ay + t * dy;
        return Math.hypot(px - cx, py - cy);
    }

    private static final int RING_N = 36;

    private float[] ringPoint(Gz g, int i, int n) {
        double a = Math.PI * 2 * n / RING_N;
        float c = (float) Math.cos(a), sn = (float) Math.sin(a);
        return new float[]{g.ox + g.ru[i][0] * c + g.rv[i][0] * sn, g.oy + g.ru[i][1] * c + g.rv[i][1] * sn};
    }

    /** 0..2 = eje, 3 = escala uniforme, -1 = nada. */
    private int pick(Gz g, double x, double y) {
        double best = 7;
        int res = -1;
        if (mode == Mode.ROTATE) {
            for (int i = 0; i < 3; i++) {
                float[] prev = ringPoint(g, i, 0);
                for (int n = 1; n <= RING_N; n++) {
                    float[] cur = ringPoint(g, i, n);
                    double d = segDist(x, y, prev[0], prev[1], cur[0], cur[1]);
                    if (d < best) { best = d; res = i; }
                    prev = cur;
                }
            }
            return res;
        }
        if (mode == Mode.SCALE && Math.hypot(x - g.ox, y - g.oy) < 8) return 3;
        for (int i = 0; i < 3; i++) {
            double d = Math.min(segDist(x, y, g.ox, g.oy, g.ox + g.axis[i][0], g.oy + g.axis[i][1]),
                    Math.hypot(x - (g.ox + g.axis[i][0]), y - (g.oy + g.axis[i][1])) - 2);
            if (d < best) { best = d; res = i; }
        }
        return res;
    }

    // ================================================================ dibujo

    private static void rr(DrawContext g, int x, int y, int w, int h, int r, int c) { Gfx.rr(g, x, y, w, h, r, c); }

    private void line(DrawContext g, float x0, float y0, float x1, float y1, int c, int t) { Gfx.line(g, x0, y0, x1, y1, t, c); }

    private boolean over(int x, int y, int w, int h) { return mx >= x && mx < x + w && my >= y && my < y + h; }

    private void hit(int x, int y, int w, int h, Runnable r) {
        Hit t = new Hit();
        t.x = x; t.y = y; t.w = w; t.h = h; t.r = r;
        hits.add(t);
    }

    private void button(DrawContext g, int x, int y, int w, String label, boolean primary, boolean on, Runnable r) {
        boolean hov = over(x, y, w, 18);
        int bg = on ? Theme.c("primary") : primary ? Theme.c("pill") : hov ? Theme.c("surfaceHi") : Theme.c("surface");
        rr(g, x, y, w, 18, 9, bg);
        int tc = on ? Theme.c("onPrimary") : Theme.c("text");
        g.drawText(textRenderer, label, x + w / 2 - textRenderer.getWidth(label) / 2, y + 5, tc, false);
        hit(x, y, w, 18, r);
    }

    private int visibleRows() { return Math.max(1, (height - 16 - 36) / ROW); }

    @Override
    public void render(DrawContext g, int mouseX, int mouseY, float delta) {
        mx = mouseX;
        my = mouseY;
        hits.clear();
        int panel = Theme.c("panel"), text = Theme.c("text"), muted = Theme.c("muted"), prim = Theme.c("primary");

        Gfx.fill(g, 0, 0, width, height, 0xFF0B0808);
        Background.draw(g, width, height);

        int lx = 8, lw = 176, rw = 186, rx = width - 8 - rw;
        vx = lx + lw + 8;
        vw = Math.max(40, rx - 8 - vx);
        vy = 8;
        vh = height - 16;

        // ---------------------------------------------------- panel izquierdo: grupos y bloques con sus nombres originales
        rr(g, lx, 8, lw, height - 16, 10, panel);
        g.drawText(textRenderer, Text.literal("Partes").formatted(Formatting.BOLD), lx + 10, 15, text, false);
        int cbx = lx + lw - 10 - 30;
        button(g, cbx, 11, 14, "-", false, false, () -> { for (BBModel.Bone bb : model.bones.values()) if (!bb.children.isEmpty() || !bb.cubes.isEmpty()) collapsed.add(bb.name); rowsDirty = true; });
        button(g, cbx + 16, 11, 14, "+", false, false, () -> { collapsed.clear(); rowsDirty = true; });
        if (rowsDirty) buildRows();
        int vr = visibleRows();
        listScroll = Math.max(0, Math.min(Math.max(0, rows.size() - vr), listScroll));
        int ly = 34;
        for (int r = 0; r < vr && listScroll + r < rows.size(); r++) {
            Row row = rows.get(listScroll + r);
            BBModel.Bone b = row.bone();
            int ry = ly + r * ROW;
            boolean isCube = row.cube() != null;
            boolean on = isCube ? row.cube().key.equals(selCube) : (selCube == null && b.name.equals(sel));
            if (on) rr(g, lx + 4, ry, lw - 8, ROW - 1, 6, Theme.c("pill"));
            else if (over(lx + 4, ry, lw - 8, ROW - 1)) rr(g, lx + 4, ry, lw - 8, ROW - 1, 6, Theme.c("line"));
            int indent = (isCube ? b.depth + 1 : b.depth) * 6;
            if (isCube) {
                String lab = textRenderer.trimToWidth(row.cube().name, lw - 26 - indent);
                g.drawText(textRenderer, lab, lx + 16 + indent, ry + 3, on ? prim : muted, false);
                final BBModel.Bone bb = b;
                final BBModel.Cube cc = row.cube();
                hit(lx + 4, ry, lw - 8, ROW - 1, () -> selectCube(bb, cc));
            } else {
                boolean has = !b.children.isEmpty() || !b.cubes.isEmpty();
                final String nn = b.name;
                if (has) {
                    g.drawText(textRenderer, collapsed.contains(b.name) ? "+" : "-", lx + 8 + indent, ry + 3, muted, false);
                }
                boolean hid = s.hidden.contains(b.name);
                Role role = Role.of(s.roles.get(b.name));
                String lab = textRenderer.trimToWidth((hid ? "(x) " : "") + b.label() + (role == Role.NONE ? "" : " [" + role.label + "]"), lw - 28 - indent);
                g.drawText(textRenderer, lab, lx + 16 + indent, ry + 3, hid ? muted : (on || nn.equals(sel)) ? prim : role != Role.NONE ? prim : text, false);
                hit(lx + 16 + indent, ry, lw - 24 - indent, ROW - 1, () -> select(nn));
                if (has) hit(lx + 4 + indent, ry, 12, ROW - 1, () -> { if (!collapsed.remove(nn)) collapsed.add(nn); rowsDirty = true; });
            }
        }
        if (rows.size() > vr) {
            int area = vr * ROW;
            int th = Math.max(12, area * vr / rows.size());
            int ty = ly + (area - th) * listScroll / Math.max(1, rows.size() - vr);
            rr(g, lx + lw - 6, ty, 2, th, 1, 0x80E8C2BA);
        }

        // ---------------------------------------------------- viewport 3D
        rr(g, vx, vy, vw, vh, 10, 0x50000000);
        g.enableScissor(vx, vy, vx + vw, vy + vh);

        // suelo (rejilla 8 px del modelo, de -24 a 24)
        Matrix4f V = view();
        int gridCol = 0x28FFFFFF;
        for (int i = -24; i <= 24; i += 8) {
            Vector3f a = V.transformPosition(new Vector3f(i, 0, -24)), b = V.transformPosition(new Vector3f(i, 0, 24));
            line(g, a.x, a.y, b.x, b.y, i == 0 ? 0x50FFFFFF : gridCol, 1);
            Vector3f c = V.transformPosition(new Vector3f(-24, 0, i)), d = V.transformPosition(new Vector3f(24, 0, i));
            line(g, c.x, c.y, d.x, d.y, i == 0 ? 0x50FFFFFF : gridCol, 1);
        }

        // modelo
        MatrixStack ms = g.getMatrices();
        ms.push();
        float S = pxPerBlock();
        ms.translate(vx + vw / 2f, vy + vh / 2f, 150f);
        ms.scale(S, S, -S);
        ms.multiply(new Quaternionf().rotationZ((float) Math.PI));
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pitch));
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));
        ms.translate(0f, -1f, 0f);
        BBRenderer.renderPreview(model, s, ms, g.getVertexConsumers(), 15728880, sel, selCube, PreviewSim.active);
        ms.pop();
        g.draw();

        // superposicion (por delante del modelo)
        ms.push();
        ms.translate(0f, 0f, 400f);
        dots.clear();
        for (BBModel.Bone r : model.roots) collectDots(r, V);
        for (Map.Entry<String, float[]> e : dots.entrySet()) {
            if (e.getKey().equals(sel)) continue;
            int x = Math.round(e.getValue()[0]), y = Math.round(e.getValue()[1]);
            boolean hv = Math.hypot(mx - x, my - y) < 7;
            Gfx.fill(g, x - 2, y - 2, x + 3, y + 3, hv ? 0xFFFFFFFF : 0xA0E8C2BA);
        }
        Gz gz = gizmo();
        if (gz != null) drawGizmo(g, gz);
        g.drawText(textRenderer, "Arrastra en vacío: orbitar   Rueda: zoom   Clic en un punto: elegir parte", vx + 10, vy + vh - 14, muted, false);
        ms.pop();
        g.disableScissor();

        // ---------------------------------------------------- panel derecho
        rr(g, rx, 8, rw, height - 16, 10, panel);
        int px = rx + 10, pw = rw - 20, y = 15;
        g.drawText(textRenderer, Text.literal("Editor 3D").formatted(Formatting.BOLD), px, y, text, false);
        y += 14;
        BBModel.Bone sb = sel == null ? null : model.bones.get(sel);
        g.drawText(textRenderer, textRenderer.trimToWidth(sb == null ? "Haz clic en el modelo" : sb.label(), pw), px, y, sb == null ? muted : prim, false);
        y += 11;
        if (selCube != null) {
            String cn = "";
            for (BBModel.Cube cc : sb.cubes) if (cc.key.equals(selCube)) cn = cc.name;
            g.drawText(textRenderer, textRenderer.trimToWidth("bloque: " + cn, pw), px, y, text, false);
        } else if (sb != null) {
            g.drawText(textRenderer, textRenderer.trimToWidth(sb.cubes.size() + " bloques, " + sb.children.size() + " subgrupos", pw), px, y, muted, false);
        }
        y += 12;
        if (sb != null) {   // rol: qué parte del cuerpo es este grupo
            Role cur = Role.of(s.roles.get(sel));
            Role[] rs = Role.values();
            int ri = cur.ordinal();
            button(g, px, y, 18, "<", false, false, () -> setRole(rs[(ri + rs.length - 1) % rs.length]));
            button(g, px + pw - 18, y, 18, ">", false, false, () -> setRole(rs[(ri + 1) % rs.length]));
            String rl = "Rol: " + (cur == Role.NONE ? "ninguno" : cur.label);
            rr(g, px + 20, y, pw - 40, 18, 9, cur == Role.NONE ? Theme.c("surface") : Theme.c("primary"));
            g.drawText(textRenderer, textRenderer.trimToWidth(rl, pw - 46), px + 20 + (pw - 40) / 2 - textRenderer.getWidth(textRenderer.trimToWidth(rl, pw - 46)) / 2, y + 5, cur == Role.NONE ? text : Theme.c("onPrimary"), false);
        }
        y += 24;
        int cw = (pw - 4) / 2;
        Mode[] ms2 = Mode.values();
        for (int i = 0; i < 4; i++) {
            final Mode mm = ms2[i];
            button(g, px + (i % 2) * (cw + 4), y + (i / 2) * 22, cw, mm.label, false, mode == mm, () -> { mode = mm; syncFields(); });
        }
        y += 50;
        String unit = switch (mode) { case MOVE -> "Posición X Y Z (px)"; case ROTATE -> "Rotación extra X Y Z (°)"; case SCALE -> "Escala X Y Z"; case PIVOT -> "Pivote X Y Z (px)"; };
        g.drawText(textRenderer, unit, px, y, muted, false);
        y += 11;
        int fw = (pw - 8) / 3;
        for (int i = 0; i < 3; i++) {
            int fx = px + i * (fw + 4);
            rr(g, fx, y, fw, 18, 5, Theme.c("surface"));
            Gfx.fill(g, fx + 1, y + 17, fx + fw - 1, y + 18, f[i].isFocused() ? prim : 0x90E8C2BA);
            Gfx.fill(g, fx, y, fx + 2, y + 18, AXC[i]);
            f[i].setX(fx + 7);
            f[i].setY(y + 5);
            f[i].setWidth(fw - 10);
        }
        y += 28;
        button(g, px, y, pw, "Restaurar parte", false, false, this::resetBone);
        y += 22;
        boolean hid = sel != null && s.hidden.contains(sel);
        button(g, px, y, pw, hid ? "Mostrar parte" : "Ocultar parte", false, false, () -> {
            if (sel == null) return;
            if (!s.hidden.remove(sel)) s.hidden.add(sel);
        });
        y += 22;
        button(g, px, y, cw, "Deshacer", false, false, this::restore);
        button(g, px + cw + 4, y, cw, "Restaurar todo", false, false, this::resetAll);
        y += 22;
        button(g, px, y, pw, "Centrar vista", false, false, () -> { yaw = 25f; pitch = 12f; zoom = 1f; });
        y += 22;
        button(g, px, y, pw, PreviewSim.active ? "Detener simulación" : "Simular ataque y cabeza", false, PreviewSim.active, PreviewSim::toggle);
        y += 30;
        if (!status.isEmpty()) g.drawText(textRenderer, textRenderer.trimToWidth(status, pw), px, y, prim, false);
        button(g, px, height - 8 - 10 - 18, pw, "Guardar y cerrar", true, false, this::close);

        for (TextFieldWidget t : f) t.render(g, mouseX, mouseY, delta);
    }

    private void drawGizmo(DrawContext g, Gz gz) {
        int hov = (dragAxis >= 0) ? dragAxis : pick(gz, mx, my);
        float ox = gz.ox, oy = gz.oy;
        if (mode == Mode.ROTATE) {
            for (int i = 0; i < 3; i++) {
                boolean h = hov == i;
                float[] prev = ringPoint(gz, i, 0);
                for (int n = 1; n <= RING_N; n++) {
                    float[] cur = ringPoint(gz, i, n);
                    line(g, prev[0], prev[1], cur[0], cur[1], h ? 0xFFFFFFFF : AXC[i], h ? 3 : 2);
                    prev = cur;
                }
            }
            Gfx.fill(g, Math.round(ox) - 2, Math.round(oy) - 2, Math.round(ox) + 3, Math.round(oy) + 3, 0xFFFFFFFF);
            return;
        }
        for (int i = 0; i < 3; i++) {
            boolean h = hov == i;
            float tx = ox + gz.axis[i][0], ty = oy + gz.axis[i][1];
            int col = h ? 0xFFFFFFFF : AXC[i];
            line(g, ox, oy, tx, ty, col, h ? 3 : 2);
            int cx = Math.round(tx), cy = Math.round(ty);
            switch (mode) {
                case SCALE -> Gfx.fill(g, cx - 4, cy - 4, cx + 5, cy + 5, col);
                case PIVOT -> { for (int k = 0; k < 5; k++) Gfx.fill(g, cx - 4 + k, cy - k, cx + 5 - k, cy - k + 1, col); for (int k = 1; k < 5; k++) Gfx.fill(g, cx - 4 + k, cy + k, cx + 5 - k, cy + k + 1, col); }
                default -> rr(g, cx - 4, cy - 4, 9, 9, 4, col);
            }
            g.drawText(textRenderer, AXN[i], cx + 6, cy - 4, AXC[i], false);
        }
        int cc = hov == 3 ? 0xFFFFFFFF : 0xFFE8E8E8;
        if (mode == Mode.SCALE) Gfx.fill(g, Math.round(ox) - 4, Math.round(oy) - 4, Math.round(ox) + 5, Math.round(oy) + 5, cc);
        else rr(g, Math.round(ox) - 3, Math.round(oy) - 3, 7, 7, 3, cc);
    }

    // ================================================================ entrada

    private boolean inViewport(double x, double y) { return x >= vx && x < vx + vw && y >= vy && y < vy + vh; }

    @Override
    public boolean mouseClicked(double x, double y, int button) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (x >= h.x && x < h.x + h.w && y >= h.y && y < h.y + h.h) {
                setFocused(null);
                if (button == 0) h.r.run();
                return true;
            }
        }
        if (inViewport(x, y)) {
            setFocused(null);
            if (button == 0 && sel != null) {
                Gz gz = gizmo();
                int h = gz == null ? -1 : pick(gz, x, y);
                if (h >= 0) { startDrag(gz, h, x, y); return true; }
            }
            pressX = x;
            pressY = y;
            pressMoved = false;
            orbit = true;
            return true;
        }
        return super.mouseClicked(x, y, button);
    }

    // ---- seleccion por clic sobre el modelo: proyecta las 6 caras de cada bloque y elige la mas cercana a la camara

    private static final int[][] FACE_IDX = {{0, 2, 6, 4}, {1, 3, 7, 5}, {0, 1, 5, 4}, {2, 3, 7, 6}, {0, 1, 3, 2}, {4, 5, 7, 6}};
    private static final Vector3f[] CORN = new Vector3f[8];
    static { for (int i = 0; i < 8; i++) CORN[i] = new Vector3f(); }
    private float bestZ;
    private BBModel.Bone bestBone;
    private BBModel.Cube bestCube;

    private static boolean inTri(double px, double py, Vector3f a, Vector3f b, Vector3f c) {
        double d1 = (px - b.x) * (a.y - b.y) - (a.x - b.x) * (py - b.y);
        double d2 = (px - c.x) * (b.y - c.y) - (b.x - c.x) * (py - c.y);
        double d3 = (px - a.x) * (c.y - a.y) - (c.x - a.x) * (py - a.y);
        boolean neg = d1 < 0 || d2 < 0 || d3 < 0, pos = d1 > 0 || d2 > 0 || d3 > 0;
        return !(neg && pos);
    }

    private void clickSelect(double x, double y) {
        String near = null;                               // punto de pivote muy cerca: tiene prioridad
        double bd = 5;
        for (Map.Entry<String, float[]> e : dots.entrySet()) {
            double d = Math.hypot(x - e.getValue()[0], y - e.getValue()[1]);
            if (d < bd) { bd = d; near = e.getKey(); }
        }
        if (near != null) { select(near); return; }
        bestZ = -Float.MAX_VALUE;
        bestBone = null;
        bestCube = null;
        Matrix4f base = view();
        for (BBModel.Bone r : model.roots) pickWalk(r, base, x, y);
        if (bestCube != null) { selectCube(bestBone, bestCube); return; }
        bd = 9;
        for (Map.Entry<String, float[]> e : dots.entrySet()) {
            double d = Math.hypot(x - e.getValue()[0], y - e.getValue()[1]);
            if (d < bd) { bd = d; near = e.getKey(); }
        }
        if (near != null) select(near);
    }

    private void pickWalk(BBModel.Bone b, Matrix4f parent, double px, double py) {
        Matrix4f m = new Matrix4f(parent);
        apply(m, b, true);
        if (b.visible && !s.hidden.contains(b.name)) {
            for (BBModel.Cube c : b.cubes) {
                Matrix4f cm = new Matrix4f(m);
                if (c.rot[0] != 0 || c.rot[1] != 0 || c.rot[2] != 0) {
                    cm.translate(c.origin[0], c.origin[1], c.origin[2]);
                    cm.rotateZ((float) Math.toRadians(c.rot[2]));
                    cm.rotateY((float) Math.toRadians(c.rot[1]));
                    cm.rotateX((float) Math.toRadians(c.rot[0]));
                    cm.translate(-c.origin[0], -c.origin[1], -c.origin[2]);
                }
                float i = c.inflate;
                for (int k = 0; k < 8; k++) {
                    CORN[k].set((k & 1) == 0 ? c.from[0] - i : c.to[0] + i, (k & 2) == 0 ? c.from[1] - i : c.to[1] + i, (k & 4) == 0 ? c.from[2] - i : c.to[2] + i);
                    cm.transformPosition(CORN[k]);
                }
                for (int[] fi : FACE_IDX) {
                    Vector3f a = CORN[fi[0]], bb = CORN[fi[1]], cc = CORN[fi[2]], d = CORN[fi[3]];
                    if (inTri(px, py, a, bb, cc) || inTri(px, py, a, cc, d)) {
                        float z = (a.z + bb.z + cc.z + d.z) / 4f;     // en el GUI, z mayor = mas cerca de la camara
                        if (z > bestZ) { bestZ = z; bestBone = b; bestCube = c; }
                    }
                }
            }
        }
        for (BBModel.Bone ch : b.children) pickWalk(ch, m, px, py);
    }

    private void startDrag(Gz gz, int h, double x, double y) {
        snapshot();
        dragAxis = h;
        dragMode = mode;
        dsx = x;
        dsy = y;
        startVal = get(mode, sel).clone();
        dLen = gz.len;
        dGox = gz.ox;
        dGoy = gz.oy;
        if (h < 3) {
            dax = gz.axis[h][0];
            day = gz.axis[h][1];
            if (mode == Mode.ROTATE) {
                float cross = gz.ru[h][0] * gz.rv[h][1] - gz.ru[h][1] * gz.rv[h][0];
                rotSign = cross >= 0 ? 1f : -1f;
                rotLast = (float) Math.toDegrees(Math.atan2(y - dGoy, x - dGox));
                rotAcc = 0f;
            }
        }
    }

    private static float r2(float v) { return Math.round(v * 100f) / 100f; }

    private void updateDrag(double x, double y) {
        double mdx = x - dsx, mdy = y - dsy;
        float[] v = startVal.clone();
        int a = dragAxis;
        switch (dragMode) {
            case MOVE, PIVOT -> {
                float la2 = dax * dax + day * day;
                if (la2 < 16f) return; // eje casi de frente a la camara: gira la vista
                v[a] = r2(startVal[a] + (float) ((mdx * dax + mdy * day) / la2) * dLen);
            }
            case SCALE -> {
                if (a == 3) {
                    float fct = Math.max(0.01f, 1f + (float) mdx / 90f);
                    for (int i = 0; i < 3; i++) v[i] = r2(startVal[i] * fct);
                } else {
                    float la = (float) Math.hypot(dax, day);
                    if (la < 4f) return;
                    float t = (float) ((mdx * dax + mdy * day) / la);
                    v[a] = r2(startVal[a] * Math.max(0.01f, 1f + t / la));
                }
            }
            case ROTATE -> {
                float ang = (float) Math.toDegrees(Math.atan2(y - dGoy, x - dGox));
                float dd = ang - rotLast;
                while (dd > 180f) dd -= 360f;
                while (dd < -180f) dd += 360f;
                rotAcc += dd;
                rotLast = ang;
                v[a] = r2(startVal[a] + rotSign * rotAcc);
            }
        }
        set(dragMode, sel, v);
        syncFields();
    }

    @Override
    public boolean mouseDragged(double x, double y, int button, double dx, double dy) {
        if (Math.abs(x - pressX) > 3 || Math.abs(y - pressY) > 3) pressMoved = true;
        if (dragAxis >= 0 && sel != null) { updateDrag(x, y); return true; }
        if (orbit) {
            yaw += (float) dx * 0.6f;
            pitch = Math.max(-89f, Math.min(89f, pitch + (float) dy * 0.5f));
            return true;
        }
        return super.mouseDragged(x, y, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double x, double y, int button) {
        if (orbit && !pressMoved && button == 0 && inViewport(x, y)) clickSelect(x, y);
        dragAxis = -1;
        orbit = false;
        return super.mouseReleased(x, y, button);
    }

    @Override
    public boolean mouseScrolled(double x, double y, double hAmount, double vAmount) {
        if (inViewport(x, y)) {
            zoom = Math.max(0.3f, Math.min(4f, zoom * (vAmount > 0 ? 1.1f : 1f / 1.1f)));
            return true;
        }
        if (x < vx) {
            listScroll -= (int) Math.signum(vAmount) * 3;
            return true;
        }
        return super.mouseScrolled(x, y, hAmount, vAmount);
    }

    @Override
    public void close() {
        PreviewSim.stop();
        ModelManager.saveConfig();
        client.setScreen(parent);
        if (parent instanceof ModelScreen ms) ms.refreshFromEditor(model, sel);
    }
}
