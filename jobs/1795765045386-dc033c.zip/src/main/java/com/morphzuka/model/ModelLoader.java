package com.morphzuka.model;

import com.google.gson.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

public final class ModelLoader {
    private ModelLoader() {}

    // ------------------------------------------------------------ scanning

    public static void scanFolder(Path dir, String prefix, Map<String, BBModel> out) {
        if (!Files.isDirectory(dir)) return;
        try (Stream<Path> s = Files.walk(dir)) {
            s.filter(Files::isRegularFile).sorted().forEach(p -> {
                String fn = p.getFileName().toString().toLowerCase(Locale.ROOT);
                String id = prefix + dir.relativize(p).toString().replace('\\', '/');
                try {
                    BBModel m = null;
                    if (fn.endsWith(".bbmodel") || fn.endsWith(".morphzuka")) m = fromBbmodel(id, Files.readString(p), p.getParent());
                    else if (fn.endsWith(".geo.json")) m = fromGeoFile(id, p);
                    else if (fn.endsWith(".cpmproject")) m = fromCpmProject(id, p);
                    if (m != null) out.put(id, m);
                } catch (Throwable t) {
                    ModelManager.LOG.warn("No se pudo cargar {}: {}", id, t.toString());
                }
            });
        } catch (IOException e) {
            ModelManager.LOG.warn("Error leyendo {}: {}", dir, e.toString());
        }
    }

    /** Detecta modelos GeckoLib que traen mods/resourcepacks (assets/<ns>/geo/*.geo.json). */
    public static void scanResources(ResourceManager rm, Map<String, BBModel> out) {
        Map<Identifier, Resource> found = rm.findResources("geo", i -> i.getPath().endsWith(".geo.json"));
        for (Map.Entry<Identifier, Resource> en : found.entrySet()) {
            try {
                Identifier rid = en.getKey();
                String path = rid.getPath();
                String rel = path.substring(4, path.length() - 9);
                String name = rel.contains("/") ? rel.substring(rel.lastIndexOf('/') + 1) : rel;
                String ns = rid.getNamespace();
                BBModel m = geo("geckolib:" + ns + "/" + rel, readJson(en.getValue()));
                m.source = "geckolib";
                Identifier tex = firstExisting(rm, ns, "textures/entity/" + rel + ".png", "textures/entity/" + name + ".png",
                        "textures/entity/" + name + "/" + name + ".png", "textures/" + rel + ".png",
                        "textures/block/" + rel + ".png", "textures/item/" + rel + ".png");
                if (tex != null) m.texture = tex;
                Identifier an = firstExisting(rm, ns, "animations/" + rel + ".animation.json",
                        "animations/entity/" + name + ".animation.json", "animations/" + name + ".animation.json");
                if (an != null) geoAnims(m, readJson(rm.getResource(an).get()));
                out.put(m.id, m);
            } catch (Throwable t) {
                ModelManager.LOG.warn("GeckoLib model {} fallo: {}", en.getKey(), t.toString());
            }
        }
    }

    private static Identifier firstExisting(ResourceManager rm, String ns, String... paths) {
        for (String p : paths) {
            Identifier id = Identifier.of(ns, p);
            if (rm.getResource(id).isPresent()) return id;
        }
        return null;
    }

    private static JsonObject readJson(Resource r) throws IOException {
        try (InputStream in = r.getInputStream()) {
            return JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
        }
    }

    // ------------------------------------------------------------ CPM

    private static BBModel fromCpmProject(String id, Path p) throws Exception {
        try (ZipFile z = new ZipFile(p.toFile())) {
            Optional<? extends ZipEntry> en = z.stream().filter(e -> e.getName().toLowerCase(Locale.ROOT).endsWith(".bbmodel")).findFirst();
            if (en.isEmpty()) {
                ModelManager.LOG.warn("{}: .cpmproject sin .bbmodel dentro; exportalo desde Blockbench como .bbmodel", id);
                return null;
            }
            String json = new String(z.getInputStream(en.get()).readAllBytes(), StandardCharsets.UTF_8);
            BBModel m = fromBbmodel(id, json, p.getParent());
            m.source = "cpm";
            return m;
        }
    }

    // ------------------------------------------------------------ .bbmodel

    public static BBModel fromBbmodel(String id, String json, Path baseDir) throws Exception {
        JsonObject root = JsonParser.parseString(json).getAsJsonObject();
        BBModel m = new BBModel();
        m.id = id;
        m.source = "bbmodel";
        boolean hasRes = false;
        if (root.has("resolution")) {
            JsonObject res = root.getAsJsonObject("resolution");
            m.texW = res.get("width").getAsInt();
            m.texH = res.get("height").getAsInt();
            hasRes = true;
        }
        Map<String, JsonObject> els = new HashMap<>();
        if (root.has("elements"))
            for (JsonElement e : root.getAsJsonArray("elements"))
                els.put(str(e.getAsJsonObject(), "uuid", ""), e.getAsJsonObject());

        Map<String, String> uuidName = new HashMap<>();
        BBModel.Bone loose = null;
        if (root.has("outliner")) {
            for (JsonElement e : root.getAsJsonArray("outliner")) {
                if (e.isJsonPrimitive()) {
                    JsonObject el = els.get(e.getAsString());
                    if (el == null) continue;
                    if (loose == null) {
                        loose = new BBModel.Bone();
                        loose.origName = "root";
                        loose.name = unique(m, "root");
                        m.bones.put(loose.name, loose);
                        m.roots.add(loose);
                    }
                    addCube(loose, el);
                } else {
                    group(m, e.getAsJsonObject(), els, uuidName, null, 0);
                }
            }
        }

        // textura
        if (root.has("textures") && root.getAsJsonArray("textures").size() > 0) {
            JsonObject t = root.getAsJsonArray("textures").get(0).getAsJsonObject();
            byte[] png = null;
            String src = str(t, "source", "");
            if (src.startsWith("data:")) {
                png = Base64.getDecoder().decode(src.substring(src.indexOf(',') + 1));
            } else {
                for (String k : new String[]{"path", "relative_path"}) {
                    if (png == null && t.has(k) && baseDir != null) {
                        Path pp = baseDir.resolve(t.get(k).getAsString()).normalize();
                        if (Files.exists(pp)) png = Files.readAllBytes(pp);
                    }
                }
            }
            if (png != null) registerTexture(m, png, hasRes);
        }

        // animaciones
        if (root.has("animations")) {
            for (JsonElement ae : root.getAsJsonArray("animations")) {
                JsonObject a = ae.getAsJsonObject();
                BBModel.Anim an = new BBModel.Anim();
                an.name = str(a, "name", "anim");
                an.loop = "loop".equals(str(a, "loop", "once"));
                an.length = a.has("length") ? num(a.get("length")) : 0;
                if (a.has("animators")) {
                    for (Map.Entry<String, JsonElement> en : a.getAsJsonObject("animators").entrySet()) {
                        JsonObject ao = en.getValue().getAsJsonObject();
                        String bone = uuidName.get(en.getKey());
                        if (bone == null) bone = str(ao, "name", null);
                        if (bone == null || !ao.has("keyframes")) continue;
                        BBModel.BoneAnim ba = an.bones.computeIfAbsent(bone, k -> new BBModel.BoneAnim());
                        for (JsonElement ke : ao.getAsJsonArray("keyframes")) {
                            JsonObject kf = ke.getAsJsonObject();
                            if (!kf.has("data_points") || kf.getAsJsonArray("data_points").size() == 0) continue;
                            JsonObject dp = kf.getAsJsonArray("data_points").get(0).getAsJsonObject();
                            BBModel.Key k = new BBModel.Key();
                            k.time = num(kf.get("time"));
                            k.v = new float[]{num(dp.get("x")), num(dp.get("y")), num(dp.get("z"))};
                            k.step = "step".equals(str(kf, "interpolation", "linear"));
                            switch (str(kf, "channel", "")) {
                                case "rotation" -> ba.rot.add(k);
                                case "position" -> ba.pos.add(k);
                                case "scale" -> ba.scale.add(k);
                                default -> {}
                            }
                            an.length = Math.max(an.length, k.time);
                        }
                        Comparator<BBModel.Key> c = Comparator.comparingDouble(k -> k.time);
                        ba.rot.sort(c); ba.pos.sort(c); ba.scale.sort(c);
                    }
                }
                m.anims.put(an.name, an);
            }
        }
        m.indexCubes();
        return m;
    }

    private static void group(BBModel m, JsonObject g, Map<String, JsonObject> els, Map<String, String> uuidName,
                              BBModel.Bone parent, int depth) {
        BBModel.Bone b = new BBModel.Bone();
        b.origName = str(g, "name", "bone");
        b.name = unique(m, b.origName);
        b.depth = depth;
        b.pivot = vec3(g.get("origin"));
        b.rot = vec3(g.get("rotation"));
        if (g.has("visibility") && g.get("visibility").isJsonPrimitive() && !g.get("visibility").getAsBoolean()) b.visible = false;
        uuidName.put(str(g, "uuid", ""), b.name);
        m.bones.put(b.name, b);
        if (parent == null) m.roots.add(b); else parent.children.add(b);
        if (g.has("children")) {
            for (JsonElement c : g.getAsJsonArray("children")) {
                if (c.isJsonPrimitive()) {
                    JsonObject el = els.get(c.getAsString());
                    if (el != null) addCube(b, el);
                } else {
                    group(m, c.getAsJsonObject(), els, uuidName, b, depth + 1);
                }
            }
        }
    }

    private static void addCube(BBModel.Bone bone, JsonObject o) {
        if (o.has("type") && !"cube".equals(o.get("type").getAsString())) return;
        if (o.has("visibility") && o.get("visibility").isJsonPrimitive() && !o.get("visibility").getAsBoolean()) return;
        BBModel.Cube c = new BBModel.Cube();
        c.name = str(o, "name", "cube");
        c.from = vec3(o.get("from"));
        c.to = vec3(o.get("to"));
        c.origin = vec3(o.get("origin"));
        c.rot = vec3(o.get("rotation"));
        c.inflate = o.has("inflate") ? num(o.get("inflate")) : 0;
        c.boxUv = o.has("box_uv") && o.get("box_uv").getAsBoolean();
        if (o.has("uv_offset")) {
            JsonArray a = o.getAsJsonArray("uv_offset");
            c.uvOffset = new float[]{num(a.get(0)), num(a.get(1))};
        }
        if (o.has("faces")) {
            for (Map.Entry<String, JsonElement> fe : o.getAsJsonObject("faces").entrySet()) {
                JsonObject f = fe.getValue().getAsJsonObject();
                if (!f.has("uv")) continue;
                if (!c.boxUv && (!f.has("texture") || f.get("texture").isJsonNull())) continue;
                JsonArray uv = f.getAsJsonArray("uv");
                c.faces.put(fe.getKey(), new float[]{num(uv.get(0)), num(uv.get(1)), num(uv.get(2)), num(uv.get(3))});
            }
        }
        bone.cubes.add(c);
    }

    // ------------------------------------------------------------ GeckoLib / Bedrock geo

    private static BBModel fromGeoFile(String id, Path p) throws Exception {
        String fn = p.getFileName().toString();
        String base = fn.substring(0, fn.length() - ".geo.json".length());
        BBModel m = geo(id, JsonParser.parseString(Files.readString(p)).getAsJsonObject());
        m.source = "geckolib";
        Path png = p.resolveSibling(base + ".png");
        if (Files.exists(png)) registerTexture(m, Files.readAllBytes(png), true);
        Path an = p.resolveSibling(base + ".animation.json");
        if (Files.exists(an)) geoAnims(m, JsonParser.parseString(Files.readString(an)).getAsJsonObject());
        return m;
    }

    static BBModel geo(String id, JsonObject root) {
        BBModel m = new BBModel();
        m.id = id;
        m.source = "geckolib";
        JsonObject g = null;
        if (root.has("minecraft:geometry")) {
            g = root.getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject();
            JsonObject d = g.getAsJsonObject("description");
            if (d.has("texture_width")) m.texW = d.get("texture_width").getAsInt();
            if (d.has("texture_height")) m.texH = d.get("texture_height").getAsInt();
        } else {
            for (Map.Entry<String, JsonElement> en : root.entrySet()) {
                if (en.getKey().startsWith("geometry.") && en.getValue().isJsonObject()) {
                    g = en.getValue().getAsJsonObject();
                    break;
                }
            }
            if (g == null) throw new IllegalArgumentException("geo sin geometry");
            if (g.has("texturewidth")) m.texW = g.get("texturewidth").getAsInt();
            if (g.has("textureheight")) m.texH = g.get("textureheight").getAsInt();
        }
        Map<String, BBModel.Bone> byName = new LinkedHashMap<>();
        Map<String, String> parentOf = new HashMap<>();
        for (JsonElement be : g.getAsJsonArray("bones")) {
            JsonObject bo = be.getAsJsonObject();
            BBModel.Bone b = new BBModel.Bone();
            b.name = str(bo, "name", "bone");
            b.origName = b.name;
            float[] pv = vec3(bo.get("pivot"));
            b.pivot = new float[]{-pv[0], pv[1], pv[2]};
            float[] r = vec3(bo.get("rotation"));
            b.rot = new float[]{-r[0], -r[1], r[2]};
            if (bo.has("cubes")) {
                for (JsonElement ce : bo.getAsJsonArray("cubes")) b.cubes.add(geoCube(ce.getAsJsonObject()));
            }
            byName.put(b.name, b);
            if (bo.has("parent")) parentOf.put(b.name, bo.get("parent").getAsString());
        }
        for (BBModel.Bone b : byName.values()) {
            BBModel.Bone par = byName.get(parentOf.get(b.name));
            if (par != null && par != b) par.children.add(b); else m.roots.add(b);
        }
        for (BBModel.Bone r : m.roots) dfs(m, r, 0);
        m.indexCubes();
        return m;
    }

    private static void dfs(BBModel m, BBModel.Bone b, int d) {
        b.depth = d;
        m.bones.put(b.name, b);
        for (BBModel.Bone c : b.children) dfs(m, c, d + 1);
    }

    private static BBModel.Cube geoCube(JsonObject c) {
        BBModel.Cube cu = new BBModel.Cube();
        float[] o = vec3(c.get("origin")), s = vec3(c.get("size"));
        cu.from = new float[]{-(o[0] + s[0]), o[1], o[2]};
        cu.to = new float[]{-o[0], o[1] + s[1], o[2] + s[2]};
        if (c.has("pivot")) {
            float[] p = vec3(c.get("pivot"));
            cu.origin = new float[]{-p[0], p[1], p[2]};
        }
        if (c.has("rotation")) {
            float[] r = vec3(c.get("rotation"));
            cu.rot = new float[]{-r[0], -r[1], r[2]};
        }
        cu.inflate = c.has("inflate") ? num(c.get("inflate")) : 0;
        if (c.has("uv") && c.get("uv").isJsonObject()) {
            for (Map.Entry<String, JsonElement> fe : c.getAsJsonObject("uv").entrySet()) {
                JsonObject f = fe.getValue().getAsJsonObject();
                float[] uv = vec3(f.get("uv")); // usa los 2 primeros
                float[] sz = f.has("uv_size") ? vec3(f.get("uv_size")) : new float[3];
                cu.faces.put(fe.getKey(), new float[]{uv[0], uv[1], uv[0] + sz[0], uv[1] + sz[1]});
            }
        } else {
            cu.boxUv = true;
            if (c.has("uv")) {
                JsonArray a = c.getAsJsonArray("uv");
                cu.uvOffset = new float[]{num(a.get(0)), num(a.get(1))};
            }
        }
        return cu;
    }

    static void geoAnims(BBModel m, JsonObject root) {
        if (!root.has("animations")) return;
        for (Map.Entry<String, JsonElement> en : root.getAsJsonObject("animations").entrySet()) {
            if (!en.getValue().isJsonObject()) continue;
            JsonObject a = en.getValue().getAsJsonObject();
            BBModel.Anim an = new BBModel.Anim();
            an.name = en.getKey().replaceFirst("^animation\\.", "");
            an.length = a.has("animation_length") ? num(a.get("animation_length")) : 0;
            if (a.has("loop") && a.get("loop").isJsonPrimitive()) {
                JsonPrimitive lp = a.get("loop").getAsJsonPrimitive();
                an.loop = lp.isBoolean() ? lp.getAsBoolean() : "loop".equals(lp.getAsString());
            }
            if (a.has("bones")) {
                for (Map.Entry<String, JsonElement> be : a.getAsJsonObject("bones").entrySet()) {
                    JsonObject bo = be.getValue().getAsJsonObject();
                    BBModel.BoneAnim ba = new BBModel.BoneAnim();
                    geoKeys(bo.get("rotation"), new float[]{-1, -1, 1}, ba.rot);
                    geoKeys(bo.get("position"), new float[]{-1, 1, 1}, ba.pos);
                    geoKeys(bo.get("scale"), new float[]{1, 1, 1}, ba.scale);
                    for (BBModel.Key k : ba.rot) an.length = Math.max(an.length, k.time);
                    for (BBModel.Key k : ba.pos) an.length = Math.max(an.length, k.time);
                    an.bones.put(be.getKey(), ba);
                }
            }
            m.anims.put(an.name, an);
        }
    }

    private static void geoKeys(JsonElement el, float[] sign, List<BBModel.Key> out) {
        if (el == null || el.isJsonNull()) return;
        if (el.isJsonArray() || el.isJsonPrimitive()) {
            out.add(key(0, el, sign));
        } else if (el.isJsonObject()) {
            for (Map.Entry<String, JsonElement> e : el.getAsJsonObject().entrySet()) {
                float t;
                try { t = Float.parseFloat(e.getKey()); } catch (Exception x) { continue; }
                JsonElement v = e.getValue();
                if (v.isJsonObject()) {
                    JsonObject vo = v.getAsJsonObject();
                    v = vo.has("post") ? vo.get("post") : vo.has("pre") ? vo.get("pre") : vo.get("vector");
                }
                if (v != null) out.add(key(t, v, sign));
            }
        }
        out.sort(Comparator.comparingDouble(k -> k.time));
    }

    private static BBModel.Key key(float t, JsonElement v, float[] sign) {
        BBModel.Key k = new BBModel.Key();
        k.time = t;
        float[] a = vec3(v);
        k.v = new float[]{a[0] * sign[0], a[1] * sign[1], a[2] * sign[2]};
        return k;
    }

    // ------------------------------------------------------------ helpers

    private static void registerTexture(BBModel m, byte[] png, boolean hasRes) throws IOException {
        NativeImage img = NativeImage.read(new ByteArrayInputStream(png));
        if (!hasRes) { m.texW = img.getWidth(); m.texH = img.getHeight(); }
        String path = "models/" + m.id.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9/._-]", "_");
        Identifier tid = Identifier.of("morphzuka", path);
        MinecraftClient.getInstance().getTextureManager().registerTexture(tid, new NativeImageBackedTexture(img));
        m.texture = tid;
        m.ownsTexture = true;
    }

    private static String unique(BBModel m, String base) {
        String n = base;
        int i = 2;
        while (m.bones.containsKey(n)) n = base + "_" + i++;
        return n;
    }

    static String str(JsonObject o, String k, String def) {
        return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : def;
    }

    static float num(JsonElement e) {
        if (e == null || e.isJsonNull() || !e.isJsonPrimitive()) return 0;
        JsonPrimitive p = e.getAsJsonPrimitive();
        if (p.isNumber()) return p.getAsFloat();
        try { return Float.parseFloat(p.getAsString().trim()); } catch (Exception x) { return 0; }
    }

    static float[] vec3(JsonElement e) {
        float[] r = new float[3];
        if (e != null && e.isJsonArray()) {
            JsonArray a = e.getAsJsonArray();
            for (int i = 0; i < 3 && i < a.size(); i++) r[i] = num(a.get(i));
        } else if (e != null && e.isJsonPrimitive()) {
            r[0] = r[1] = r[2] = num(e);
        }
        return r;
    }
}
