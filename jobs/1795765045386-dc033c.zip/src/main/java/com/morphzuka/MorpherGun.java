package com.morphzuka;

import com.morphzuka.render.MorphManager;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.CustomModelDataComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;

/**
 * Morpher Gun: el objeto con el que te transformas (ya no hay tecla).
 * Es un item vanilla (carrot_on_a_stick) con custom_model_data = 7001, asi que funciona con el mod solo en el cliente.
 * Su modelo esta en assets/morphzuka/models/item/morpher_item/morphergun.json y se engancha mediante
 * assets/minecraft/models/item/carrot_on_a_stick.json.
 *
 * Clic derecho en un bloque = te conviertes en ese bloque; en una entidad o jugador = te conviertes en ellos;
 * agachado + clic derecho = vuelves a la forma normal.
 */
public final class MorpherGun {
    private MorpherGun() {}

    public static final int CUSTOM_MODEL_DATA = 7001;
    public static final String GIVE_COMMAND = "give @s minecraft:carrot_on_a_stick[custom_model_data=7001,item_name='{\"text\":\"Morpher Gun\"}']";

    public static boolean isGun(ItemStack st) {
        if (st == null || st.isEmpty() || !st.isOf(Items.CARROT_ON_A_STICK)) return false;
        CustomModelDataComponent c = st.get(DataComponentTypes.CUSTOM_MODEL_DATA);
        return c != null && c.value() == CUSTOM_MODEL_DATA;
    }

    public static ItemStack create() {
        ItemStack st = new ItemStack(Items.CARROT_ON_A_STICK);
        st.set(DataComponentTypes.CUSTOM_MODEL_DATA, new CustomModelDataComponent(CUSTOM_MODEL_DATA));
        st.set(DataComponentTypes.ITEM_NAME, Text.literal("Morpher Gun"));
        return st;
    }

    private static void unmorph(MinecraftClient mc) {
        MorphManager.clear();
        if (mc.player != null) mc.player.sendMessage(Text.literal("Forma normal"), true);
    }

    public static void register() {
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (!world.isClient || hand != Hand.MAIN_HAND || !isGun(player.getStackInHand(hand))) return ActionResult.PASS;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player != mc.player) return ActionResult.PASS;
            if (player.isSneaking()) unmorph(mc);
            else MorphManager.copyBlock(mc, hit.getBlockPos());
            return ActionResult.SUCCESS;
        });
        UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (!world.isClient || hand != Hand.MAIN_HAND || !isGun(player.getStackInHand(hand))) return ActionResult.PASS;
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player != mc.player) return ActionResult.PASS;
            if (player.isSneaking()) unmorph(mc);
            else MorphManager.copyEntity(mc, entity);
            return ActionResult.SUCCESS;
        });
        UseItemCallback.EVENT.register((player, world, hand) -> {
            ItemStack st = player.getStackInHand(hand);
            if (!world.isClient || hand != Hand.MAIN_HAND || !isGun(st)) return TypedActionResult.pass(st);
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player != mc.player) return TypedActionResult.pass(st);
            if (player.isSneaking()) { unmorph(mc); return TypedActionResult.success(st); }
            player.sendMessage(Text.literal("Morpher Gun: clic derecho en un bloque, entidad o jugador. Agachado + clic = forma normal"), true);
            return TypedActionResult.success(st);
        });
    }

    /** Pone la Morpher Gun en tu mano: directo en creativo; si no, intenta /give (necesita permisos). */
    public static String give(MinecraftClient mc) {
        if (mc.player == null) return "No estás en un mundo";
        if (mc.player.isCreative() && mc.interactionManager != null) {
            mc.interactionManager.clickCreativeStack(create(), 36 + mc.player.getInventory().selectedSlot);
            return "Morpher Gun entregada en tu mano";
        }
        if (mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendChatCommand(GIVE_COMMAND);
            return "Se envió /give (hace falta permiso de operador; en creativo se entrega sola)";
        }
        return "No se pudo entregar";
    }
}
