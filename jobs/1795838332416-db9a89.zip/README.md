# MorphZuka (Fabric 1.21.1)

Mod para usar modelos de Blockbench como modelo de jugador. Funciona **en cliente solo** (mundo propio, o servidores sin el mod) y, si lo instalas tambien en el **servidor**, la hitbox, el morph y el efecto de cubos se validan y se ven en multijugador.

## Compilar
Requiere JDK 21.
```
gradle wrapper --gradle-version 8.10.2   # solo la primera vez (o abre la carpeta en IntelliJ)
./gradlew build
```
El jar queda en `build/libs/morphzuka-1.0.0.jar`.

## Uso
1. Pon tus modelos en `.minecraft/morphzuka/` (tambien lee `.minecraft/player_models/` de CPM):
   - `.morphzuka` (Blockbench, incluye CPM y GeckoLib si los guardas como proyecto) con textura incrustada
   - `.geo.json` (+ `mismo_nombre.png` y `mismo_nombre.animation.json` al lado)
   - `.cpmproject` (si contiene un .morphzuka)
   - Modelos GeckoLib de otros mods / resourcepacks (`assets/<ns>/geo/*.geo.json`) se detectan solos.
2. En el juego pulsa **K** (o `/morphzuka`).
3. Elige modelo -> elige cada hueso y asignale rol (Cabeza, Torso, Brazos, Piernas, Cola/extra; puedes asignar varios huesos al mismo rol).
4. Edita el pivote de cualquier hueso (X Y Z en pixeles) y pulsa "Fijar pivote".
5. Asigna animaciones a IDLE / WALK / SPRINT / SNEAK / AIR.
6. "Aplicar a": Yo / Todos / Jugador (nombre) -> Aplicar.

Config guardada en `config/morphzuka.json`.

## Limitaciones
- Los **modelos** se comparten por el servidor si este tiene el mod (paso 33). Sin el mod en el servidor solo tu cliente los ve. Los modelos de mods/resourcepacks (GeckoLib) no se comparten.
- Los **gestos / poses / toggles** que lanzas a mano todavia solo los ves tu; los demas ven tu modelo con las animaciones por estado (quieto, andar, correr...).
- Una sola textura por modelo; meshes no soportados (solo cubos).
- Armadura/items/capa siguen renderizandose con el esqueleto vanilla.
- Sin poses de nado/elytra/dormir. Rotaciones de GeckoLib/Bedrock pueden requerir ajustes de signo.

## Interfaz (v1.1)
Menú estilo Material oscuro/transparente con barra lateral: **Modelos**, **Partes**, **Animación**, **Importar**, **Aplicar**.
- **Arrastrar y soltar**: suelta `.morphzuka`, `.geo.json`, `.cpmproject` (y `.png` / `.animation.json` de GeckoLib) sobre la ventana del menú.
- **Importar**: pega un link directo (los links de GitHub `/blob/` se convierten solos a raw) o usa "Pegar Base64 / JSON del portapapeles" (acepta Base64, `data:...;base64,` y JSON plano).

## Editor 3D (v2.3)
Pestaña **Editor 3D** (o botón "Editor 3D" en Partes). Pantalla completa con:
- **Visor orbital**: arrastra en vacío para girar, rueda para zoom, "Centrar vista" para volver.
- **Selector de partes**: lista a la izquierda o clic en los puntos de pivote dentro del visor. La parte elegida se tiñe de naranja.
- **Gizmo**: modos **Mover**, **Rotar** (3 aros), **Escalar** (ejes + cubo central = uniforme) y **Pivote**. Ejes en rojo X, verde Y, azul Z.
- **Campos XYZ** numéricos para cada modo; se sincronizan con el gizmo.
- Deshacer, restaurar parte / todo, ocultar parte. Se guarda al cerrar en `config/morphzuka.json`
  (`offsets`, `rotOffsets`, `scales`, `pivots`); el archivo del modelo no se toca.
Los ejes del gizmo siguen el espacio del hueso padre (en Escalar, el del propio hueso).

## RoZuka (antes "Morpher Gun") (recursos, paso 1)
Item `carrot_on_a_stick` con `custom_model_data=7001`. Modelo: `assets/morphzuka/models/item/morpher_item/morphergun.json`,
enganchado desde `assets/minecraft/models/item/carrot_on_a_stick.json`. Recarga recursos con F3+T.

## Multijugador (v2.4: pasos 12 y 13)
Instala el jar en el cliente **y** en el servidor (Fabric API en ambos). Sin el mod en el servidor todo sigue funcionando solo en tu cliente.

**Hitbox real (paso 12)**: el cliente manda su caja {ancho, alto, ojos}; el servidor la valida contra limites, la aplica a tu
`ServerPlayerEntity` (colisiones y validacion de movimiento reales, por postura: de pie / agachado / nadando) y la retransmite
a todos. Mixin comun `PlayerDimensionsMixin` + `HitboxRegistry`.

**Cube form (v2.5, con texturas)**: al transformarte, tu forma anterior (skin vanilla, modelo propio, bloque o entidad) se convierte en
~260 cubos pequenos pegados a su superficie, **cada uno con el trocito de textura que le toca ahi**. Los cubos despegan (los de arriba
primero), dan una vuelta y se colocan sobre la superficie de la forma nueva, formando su silueta. Ya colocados, **cambian poco a poco
a la textura del morph** (entidad, bloque, skin del jugador o modelo) y al final la forma real aparece con rebote mientras los cubos
se encogen dentro de ella. Clases: `Form` (que forma es), `Surface` (puntos y UV de su piel), `Forms` (forma actual/anterior de cada
jugador), `CubeSwarm` (simulacion y dibujo). El servidor sigue retransmitiendo (quien, tamanos, bloque, semilla); cada cliente reconstruye
las formas con lo que ya sabe del jugador (su morph, su modelo, su skin). Si no puede, usa una caja de colores. Se desactiva en Ajustes
("Efecto de cubos al transformarse"). Notas: entidades y modelos con texturas que el juego no deja leer se tratan como opacas; las
entidades usan un parche de textura al azar entre sus pixeles opacos (su mapa UV no es accesible).

**Edicion por bloque y nombres (v2.5, modelo de datos + render)**: los ajustes de cada modelo guardan ahora `names` / `cubeNames`
(nombre propio de grupos y bloques) y `cubeOffsets` / `cubeRots` / `cubeScales` / `cubePivots` (clave `hueso#indice`). El renderer
(`BBRenderer.cube`), el calculo de la caja (`ModelBounds`) y el efecto de cubos aplican lo mismo a traves de `CubeXform`. El archivo del
modelo no se toca. Sin pivote propio, un bloque sin rotacion ni origen gira y escala alrededor de su centro. Pendiente: panel del
editor para renombrar / editar por bloque y las 4 herramientas sobre bloques.

**RoZuka**: sigue siendo `carrot_on_a_stick` con `custom_model_data=7001` (no se registra ningun item: no rompe la sincronizacion
de registros y los clientes sin el mod no fallan). El servidor la entrega con `/mz gun [jugadores]` y, con ella en la mano, bloquea
la interaccion vanilla (cofres, puertas...).

### Config del servidor: `config/morphzuka-server.json`
| campo | por defecto | efecto |
|---|---|---|
| allowHitbox | true | aceptar hitbox personalizada |
| allowMorph | true | aceptar morph y mostrarlo a los demas |
| allowEffects | true | retransmitir el efecto de cubos |
| allowModels | true | aceptar y repartir los modelos que comparten los jugadores |
| maxModelKB | 8192 | tamano maximo (KB, comprimido) del modelo de cada jugador (entre 64 y 65536) |
| opsOnly | false | solo operadores pueden usar hitbox/morph/modelos |
| minSize / maxWidth / maxHeight | 0.1 / 4 / 8 | limites de la caja aceptada |

Comandos (nivel 2): `/mz gun [jugadores]`, `/mz reload`, `/mz status`.

**Bloquear el menú a quien no es operador** (necesita MorphZuka en el servidor):
- `/mz lock` bloquea el menú a **todos los que no son operadores**; `/mz unlock` lo libera. Se guarda en `lockNonOps` de `morphzuka-server.json`.
- `/mz lock <jugadores>` / `/mz unlock <jugadores>` bloquea o libera a jugadores concretos (lista `lockedPlayers`).
- A un jugador bloqueado se le cierra el menú, no pueden abrirlo (K, B, G ni `/morphzuka`), el servidor le quita la forma/hitbox/modelo/gestos que tuviera
  y rechaza todo lo que intente mandar. Los operadores nunca se bloquean.

### Paquetes
`morphzuka:hitbox` (C2S), `hitbox_sync` (S2C), `morph` (C2S/S2C), `cube_fx` (C2S/S2C), `model_up` (C2S), `model_info` (S2C), `model_req` (C2S), `model_chunk` (S2C). Solo se envian si el otro lado los tiene registrados.

## Entidades de otros mods (Cobblemon, etc.)
Los Pokemon de Cobblemon son un unico tipo de entidad (`cobblemon:pokemon`) y la especie va en sus datos sincronizados. Por eso
ahora, al copiar una entidad **real** (RoZuka clic derecho sobre ella, o `/morphzuka morph look` mirandola), tambien se copian
esos datos (especie, aspectos, variante, color, bebe...) y el tamano real de esa entidad; se mandan al servidor y los demas te ven igual.
Sirve para cualquier mob de cualquier mod. Las entidades de la lista del menu/`/morphzuka morph entity <id>` se crean sin datos
(un `cobblemon:pokemon` asi sale vacio): para Pokemon usa la gun o `look`. Limite de datos: 16 KB por entidad.

## Pestaña Morph: vista previa y Animaciones (v2.6)
- **Vista previa 3D** a la derecha de la pestaña Morph: muestra lo que llevas puesto (entidad, bloque, jugador o tu forma normal),
  con nombre y tamaño. Arrastra para girarla (si no la tocas, gira sola).
- **Botón "Animaciones"** debajo de la vista previa (activo si llevas una entidad o jugador). Abre una ventana con:
  - **Vista previa grande** con pruebas: *Caminar*, *Golpear* (el golpe de Minecraft cada ~1 s) y *Cabeza* (mira de lado a lado). Rueda = zoom.
  - **Animaciones**: las poses (Quieto/idle, Caminar, Golpear, Girar cabeza) y, si la entidad trae archivos `.animation.json`
    (GeckoLib/Bedrock de mods o resourcepacks), todas las animaciones que contienen. Si hay un modelo cargado con el mismo nombre,
    un botón abre su configuración de animaciones (la misma de la pestaña Modelos).
  - **Partes**: lista las partes del modelo de esa entidad (`head`, `right_arm`, `left_leg`...) y deja asignar a cada una un rol
    (Cabeza, Torso, Brazo der/izq, Pierna der/izq, Cola). *Autodetectar* los asigna por nombre.
    Con roles asignados: la cabeza gira con la cámara, el brazo da el golpe de Minecraft y brazos/piernas balancean al caminar.
  - **Idle**: preset en reposo (Ninguno, Minecraft, Respirar, Balanceo), intensidad, y si la cabeza sigue la cámara, golpe de Minecraft,
    balanceo al caminar y mano que golpea (diestro/zurdo).
- Se guarda al instante en `config/morphzuka_entities.json` (una entrada por entidad, p. ej. `ENTITY:minecraft:zombie`).
- Clases nuevas: `EntityAnimScreen`, `EntityCfg` (ajustes + aplicación al modelo), `PartTree` (lista de partes), `MorphPreview` (visor),
  `AnimScan` (busca animaciones), y los mixins `ModelPartMixin` / `ModelPartAccessor`. `LivingEntityRendererMixin` aplica los roles justo
  después de que el juego coloque el modelo y los devuelve al terminar.
- Limitación: solo modelos hechos de `ModelPart` (vanilla y la mayoría de mods). Modelos con su propio sistema (p. ej. Pokémon de Cobblemon)
  no listan partes; se mueven con sus propias animaciones.


## Paso 16
- **Importar .geo**: al soltar (o importar por link) un `.geo.json`, aparece un asistente que pide la **textura (.png)** y las **animaciones (.animation.json)**. Se sueltan sobre la ventana; se guardan con el nombre del .geo. "Cargar así" lo abre sin ellas; si llegan las dos, se carga solo.
- **.bbmodel**: los grupos se leen mejor: los elementos que el outliner no menciona van a su grupo (o a `root`), grupos con nombre vacio, entradas raras en el outliner.
- **Roles automaticos**: `Autodetectar` entiende camelCase (`LeftArm`, `ArmL`, `LArm`) y espanol (`brazo_izq`, `pierna_der`, `cabeza`...), y ya no confunde `armor` con un brazo.
- **Efecto de cubos**: las entidades usan la **forma real de su modelo** (cabeza, patas, orejas...) en vez de una caja, y los bloques usan sus quads reales (escaleras, losas, vallas...). Si algo falla, vuelve a la caja de antes.

## Paso 17
- **Pestaña creativa "MorphZuka"** con la RoZuka (solo cliente; el icono es la propia pistola).

## Paso 18
- **Renombrar grupos y bloques**: en Partes hay un campo "Nombre del grupo" (Renombrar / Original, o Enter); en el Editor 3D, el campo bajo el titulo renombra el grupo elegido o, si hay un bloque elegido, el bloque. Es solo visual (se guarda en config/morphzuka.json): el archivo del modelo y las animaciones no cambian.

## Paso 19
- Corregido el recolector de vertices del efecto de cubos (vertex con float).


## Textura por parte (paso 21)
Editor 3D -> **Mapa UV**: bajo la barra de resolución hay dos filas para elegir, **por grupo y sus subgrupos**, de dónde sale la textura:
**Modelo** (por defecto), **Skin del jugador** (la skin real de quien lleva el modelo, también en multijugador) o **Skin propia**
(cualquier `.png` de `.minecraft/morphzuka/skins/`; `<` `>` para elegir, "Recargar skins" tras añadir archivos).
Un subgrupo puede elegir otra distinta que su padre; "Heredar" quita su elección. "Esta textura a todo el modelo" la copia a todos.
Los UV se leen como fracción de la imagen: una parte con el mapa de la skin de Minecraft (64x64) coincide con cualquier skin.
Se guarda en `config/morphzuka.json` (`partTex`).


## Físicas por parte (paso 22)
Las físicas ya **no** mueven todo el modelo: solo las partes que marques con **"Esta parte rebota"** (Editor 3D, barra de físicas, o pestaña Partes).
Ya no se marca ninguna sola por el nombre. Cada parte simula su punta (la de ella y sus subgrupos) como una masa en un resorte, en coordenadas del mundo,
así que reacciona a **caminar, saltar, girar el cuerpo y a cualquier animación** (bailes, gestos, gacha...), porque usa la pose final del hueso.
Un subgrupo marcado dentro de otro marcado hace cadena. Botones del editor: **Modelo se mueve** (pasea, gira y salta solo para probar sin jugador),
**Cuerpo entero** (el squash/stretch de antes, apagado por defecto; los ajustes viejos lo apagan una vez), **Quitar todas**.
Limitación: no compensa las poses de nadar / elytra / dormir (usa solo el giro del cuerpo).


## Paso 23: eliminar modelos
- **Importar** ahora tiene dos sub-pestañas: **Añadir modelo** (arrastrar, link, Base64) y **Mis modelos (N)**.
  En *Mis modelos* cada modelo de la carpeta `morphzuka/` tiene su botón **Eliminar** (pulsa dos veces para confirmar; borra el archivo,
  su `.png` / `.animation.json` si era `.geo.json`, sus ajustes y sus asignaciones). Los de CPM / GeckoLib de otros mods salen como "Solo lectura".
  Antes la lista iba debajo del formulario y desaparecía cuando la ventana era pequeña.


## Paso 24: jugador-bloque sólido
Cuando te transformas en **bloque**, ahora tienes **colisión** como un bloque real: los demás jugadores y los mobs chocan con tu caja,
pueden **saltar y subirse encima de ti**, y no te empujan (no eres "empujable").
- Clases: `BlockMorphRegistry` (quién va de bloque; el servidor lo rellena al aceptar el morph y el cliente lo deduce de tu forma y de las que
  retransmite el servidor), y los mixins comunes `EntityCollidableMixin` (`Entity.isCollidable` = true) y `LivingPushableMixin` (`isPushable` = false).
- La caja de colisión es la hitbox del morph (0,98 x 0,98), así que **deja activado "Copiar hitbox"** en la pestaña Morph; con ella apagada
  sigues siendo sólido pero con la caja normal de jugador.
- Hace falta el mod **también en el servidor** (en mundo propio ya va incluido). Sin el mod en el servidor, la colisión solo se predice
  en los clientes que lo tienen y el servidor la corregirá (se sentirá a tirones).
- Los espectadores y los jugadores muertos no son sólidos. Volver a tu forma normal quita la colisión al instante.


## Paso 25: objetos de ejemplo (bloque, espada, item)
Editor 3D -> botón **Objetos** (debajo de *Hitbox*, arriba a la derecha del visor). Abre una barra para previsualizar cosas junto al modelo:
- **Añadir**: *Bloque*, *Espada* o *Item*. Se crea **vinculado al grupo que tengas elegido** en la lista de la izquierda (o al modelo si no hay ninguno),
  así que sigue a ese grupo: su pose, las animaciones y las físicas lo mueven igual que al grupo.
- `<` `>` cambian entre tus objetos; **Eliminar** borra el elegido.
- `<` `>` junto al campo de texto cambian el id con unos ejemplos; o escribe cualquier id (`minecraft:...` o de otro mod) y pulsa **OK** / Enter.
- **Vincular a "grupo"**: elige otro grupo en la lista y pulsa el botón para pasar el objeto a ese grupo. **Sin grupo** lo deja con el modelo.
  En la lista de la izquierda cada grupo muestra `+N obj` si tiene objetos vinculados. **Visible: sí/no** lo oculta.
- Con un objeto elegido, los campos **X Y Z** del panel derecho (modos *Mover*, *Rotar*, *Escalar*) editan el objeto, en px desde el pivote del grupo
  (escala 1 = 16 px = un bloque). El gizmo del grupo se esconde mientras hay un objeto elegido.
- Se guardan en `config/morphzuka.json` (`props`). **Solo se dibujan en el Editor 3D**, no en el juego: son para ver dónde caería algo
  (la base de la posición de agarre del siguiente paso). Una espada se dibuja con la pose de "en la mano" de Minecraft; un item, como en un marco.
- Clases: `ModelManager.Prop` (datos), `PropRender` (dibujo del bloque / item), y los ganchos en `BBRenderer` (`drawProps` / `drawRootProps`).


## Paso 25 (parte 2): posición de agarrar items, por mano
Con un modelo puesto, el item que llevas en cada mano ahora lo dibuja el propio modelo (ya no el esqueleto vanilla escondido), y su posición se configura **por mano**, como en Custom Player Model.
- **Editor 3D -> Objetos -> fila "Puntos"**: elige *Mano der* o *Mano izq* con `<` `>` y pulsa **Editar punto** (un `*` junto al nombre indica que ya tiene ajustes).
- El punto se vincula por defecto al grupo con rol *Brazo der / Brazo izq*. **Vincular a "grupo"** lo pasa a otro grupo (por ejemplo una mano o un arma-hueso); **Grupo vanilla** lo devuelve al del rol. Sin ningún grupo con ese rol, el item sale en su origen vanilla (hombro) y sigue al modelo entero.
- Con el punto elegido, **Mover / Rotar / Escalar** del panel derecho (X Y Z) lo editan, en px respecto al pivote del grupo. **Todo en 0 = la posición de vanilla** (10 px por debajo del pivote del brazo, 2 px hacia delante).
- El item de muestra (espada por defecto; `<` `>` o cualquier id + OK) se dibuja en el editor para ver dónde caerá. En el juego se dibuja el item real de esa mano (mano principal / secundaria según tu configuración).
- **Se dibuja: no** oculta el item de esa mano en el juego. **Por defecto** borra los ajustes del punto.
- Sigue al grupo: animaciones, físicas y la pose del cuerpo lo mueven igual que a la mano.
- Se guarda en `config/morphzuka.json` (`props`, tipos `HAND_R` / `HAND_L`).
- Clases: `Anchors` (puntos de anclaje), `PropRender.renderHeld`, `HeldItemFeatureRendererMixin` (apaga el dibujo vanilla del item solo cuando el jugador lleva un modelo).
- Limitación: el catalejo en uso se dibuja como un item normal (vanilla lo acerca a la cara).


## Paso 26: capa, elytra y loros
**Editor 3D -> Objetos -> fila "Puntos"** ahora tiene, además de *Mano der / Mano izq*: **Capa**, **Elytra**, **Loro der** y **Loro izq**.
Mismo flujo que las manos: elige el punto con `<` `>`, **Editar punto**, **Vincular a "grupo"** (por defecto, el grupo con rol *Torso*),
y con **Mover / Rotar / Escalar** (0 = posición vanilla). **Se dibuja: no** oculta esa pieza. En el editor se ve una muestra (capa con tu capa o
una blanca, alas de elytra, huevo de loro).
- En el juego no se reimplementa nada: los mixins `CapeFeatureRendererMixin`, `ElytraFeatureRendererMixin` y `ShoulderParrotFeatureRendererMixin`
  mueven la pila de matrices al punto del modelo justo antes de que el juego dibuje, así que la **capa balancea, las alas se abren y los loros
  se sientan** como siempre, pero siguiendo al grupo (animaciones, físicas, pose). `BBRenderer.featureBegin/featureEnd` hacen el cambio de marco.
- El punto vanilla es el "origen del modelo" (cuello, 24 px): si tu grupo Torso tiene el pivote en otro sitio, ajusta con Mover.
- Cada loro tiene su punto (derecho / izquierdo) y puede ir a un grupo distinto.
- Corregido: el origen por defecto de las manos sin grupo (Mano der en +X, Mano izq en -X).


## Paso 27: armadura
En **Puntos** hay 6 más: **Armadura cabeza / torso / brazo der / brazo izq / pierna der / pierna izq**. Cada uno se vincula por defecto al grupo con
el rol que le toca (Cabeza, Torso, Brazos, Piernas) y se edita igual que los demás (Mover / Rotar / Escalar, 0 = vanilla; "Se dibuja: no" oculta esa pieza).
- Casco = punto *cabeza*; peto = *torso* + *brazos*; pantalones = *torso* + *piernas*; botas = *piernas*. Así un peto puede ir en un grupo y cada manga en otro.
- `ArmorFeatureRendererMixin` dibuja la armadura **una vez por pieza**, cada vez con solo esa pieza visible, puesta en su origen y movida al punto del
  grupo; es el dibujo normal del juego, así que texturas, adornos (trims), colores de cuero y brillo funcionan igual.
- En el editor se ve una muestra de la pieza (armadura de hierro).
- El origen vanilla de cada pieza es su articulación (cuello, hombro, cadera): si el pivote de tu grupo está en otro sitio, ajusta con Mover.
- Limitación: cabezas / calabazas / skulls (`HeadFeatureRenderer`) siguen vanilla; sin poses de nadar / elytra / dormir.


## Paso 28: jugador-bloque más realista
Cuando vas transformado en **bloque**:
- **Agacharte te ancla, con barra y enfriamiento**: agachado y **quieto** en el suelo se llena una barra sobre la hotbar (1,5 s, `BlockLock.CHARGE`); al llenarse te
  centras en la casilla de bloque (2-3 ticks) y **no puedes moverte ni saltar** hasta soltar la tecla. Moverte vacía la barra. Al soltar hay **3 s de enfriamiento**
  (`BlockLock.COOLDOWN`, la barra gris se vacía) antes de poder anclarte otra vez. La barra solo aparece cuando eres bloque y está cargando, anclado o enfriando.
  Clases: `BlockLock` (lógica y barra) y `KeyboardInputMixin`.
- **Luz del entorno y bioma, solo anclado**: mientras te mueves el bloque se dibuja como antes (luz simple). Cuando estás **anclado** se dibuja como uno colocado en el mundo:
  luz suave por cara tomada de las casillas vecinas con sombreado de oclusión (noche, cuevas, antorchas, techos) y **color del bioma** (cesped, hojas, helechos...).
  Cofres, camas y otros bloques "especiales" usan la luz de su casilla. En los demás jugadores el "anclado" se deduce (agachado y sin moverse).
- **Sin sombra de jugador**: como bloque ya no se dibuja la sombra redonda bajo el jugador (`EntityShadowMixin`).
- Todo esto es visual, lo ves tú y los que tengan el mod; el servidor solo ve tu posición.


## Paso 29: la Morpher Gun ahora es la RoZuka
- El item se llama **RoZuka** (nombre, mensajes, `/give` y pestaña creativa). Sigue siendo `carrot_on_a_stick` con `custom_model_data=7001`,
  así que las RoZuka antiguas siguen funcionando (solo cambia el nombre visible en las nuevas).
- Comandos: `/mz brocha [jugadores]` (servidor) y `/morphzuka brocha` (cliente). Los antiguos `/mz gun` y `/morphzuka gun` siguen existiendo.
- Los nombres internos (`GunItem`, `MorpherGun`, `morpher_gun.png`) no se tocaron para no romper nada.


## Paso 30: animación propia de los mobs + detector de clases con animaciones
**Por qué el conejo no se movía como conejo:** el morph dibuja una entidad "muñeco" que no está en el mundo, así que el juego nunca ejecutaba su
`tick`. El conejo salta con `jumpTicks` / `jumpDuration`, que solo avanzan en ese tick (y los lanza la IA), así que se quedaba con las patas quietas
aunque caminaras. Lo mismo le pasaba al aleteo de gallinas y loros, los tentáculos del calamar, el chafado del slime, el ataque del golem...
- `MorphAnim` (nueva): ejecuta el `tick` del muñeco una vez por tick del cliente y le da las "órdenes" de la IA a partir de lo que hace el jugador:
  **conejo** salta (con pausa corta) mientras caminas y cuando saltas, y el cuerpo **sube** durante el salto (solo visual, la hitbox no cambia);
  **rana** hace su salto largo al saltar; **golem de hierro, ravager, hoglin, zoglin y warden** hacen su ataque al golpear.
  Si algo falla en un mob se desactiva solo para ese muñeco (queda en el log). El dragón no se ejecuta nunca.
- Animaciones → pestaña **Animaciones** (menú Morph): botón **"Animación propia del mob: SÍ/NO"** por si un mob raro se comporta mal.
  Se guarda en `config/morphzuka_entities.json` (`nativeAnim`). La vista previa también usa la animación propia (Caminar hace saltar al conejo).
- `ClassAnimScan` (nueva): detecta en los **.class** qué entidades traen animaciones y de qué tipo, **por estructura** (tipos y firmas), no por nombre,
  porque fuera del modo desarrollo los nombres de Minecraft están ofuscados:
  - **Keyframes**: lee el pool de constantes del .class del modelo y cuenta las referencias a campos `Animation` (Camel, Frog, Warden, Sniffer...) y en qué clase viven.
  - **Estados**: campos `AnimationState` de la entidad (idle, walking, attacking...).
  - **Procedural**: el modelo sobrescribe `setAngles` / `animateModel` (conejo, cerdo, gallina...).
  - **Sin ModelPart**: render propio del mod (p. ej. Cobblemon).
  La pestaña Animaciones muestra el informe de la entidad que llevas. `/morphzuka animscan` recorre **todas** las entidades registradas (vanilla y mods)
  y escribe `config/morphzuka_animscan.txt` ordenado por tipo.
- Nota: en el juego sin modo desarrollo los nombres de clases de Minecraft salen como `class_1234`; los de mods salen normales.


## Paso 31: gizmo para el agarre del item (y todos los objetos / puntos)
Editor 3D -> **Objetos**. Ahora, al elegir un objeto o un punto (**Mano der / Mano izq**, Capa, Elytra, Loros, Armadura, o un bloque / espada / item
de muestra), el **gizmo** sale sobre él y se arrastra igual que el de los grupos (antes solo se podía con los campos X Y Z):
- **Mover** (flechas), **Rotar** (3 aros) y **Escalar** (ejes + cubo central = uniforme). Los campos X Y Z se actualizan mientras arrastras y siguen funcionando.
- En las **manos** el gizmo se coloca sobre el **agarre del item** (10 px bajo el pivote del brazo y 2 px hacia delante: la posición vanilla).
- **Giro: agarre / hombro** (botón junto a "Se dibuja"): con *agarre* (nuevo por defecto) rotar y escalar giran **alrededor del agarre**, así el item gira "en la mano"
  y no barre un arco alrededor del hombro. *Hombro* es el comportamiento antiguo (gira alrededor del pivote del brazo). Mover no cambia. Los ajustes que solo tenían
  Mover se ven igual; los que tenían Rotar / Escalar pueden verse distintos: pulsa el botón para volver al modo antiguo. Se guarda en `props[].gripPivot`.
- **Deshacer** también deshace los arrastres de objetos y puntos (se guarda posición, rotación y escala).
- El dibujo en el juego usa la misma cuenta que el editor (`PropRender.applyUser`), así que lo que colocas es lo que ves puesto el modelo.
- Clases: `EditorScreen` (`propGizmo`, `propFrame`, `propSel`), `Anchors.grip`, `PropRender.applyUser`.
- Limitación: la mano en **primera persona** sigue siendo la vanilla (el modelo solo se ve en tercera persona).


## Paso 32: RoZuka con icono 2D y modelo 3D en la mano
- Inventario, hotbar, suelo y marcos: icono 2D `textures/item/itemrodillo.png` (modelo `item/brochazuka.json`, el que engancha `carrot_on_a_stick` con `custom_model_data=7001`).
- En la mano (1ª y 3ª persona): modelo 3D `models/item/brochazuka_3d.json` con la textura `textures/item/rodillozuka.png`. Se carga con `ModelLoadingPlugin` y
  `ItemRendererMixin` lo cambia al dibujar en mano (vanilla 1.21.1 no puede cambiar de modelo por contexto). Los `display` del 3D (posición en la mano) son los de Blockbench.
- Quitados `morpher_item/morphergun.json` y `morpher_gun.png`.


## Paso 33: los demás jugadores ven tu modelo (como Custom Player Models)
Antes los modelos eran solo locales: si te ponías uno, tu pareja o tus amigos seguían viéndote con tu skin. Ahora, con el mod en el **servidor y en
los clientes**, tu modelo se sube al servidor y todos lo ven, con sus ajustes (roles, pivotes, escalas, animaciones por estado, textura por parte, objetos...).

**Cómo funciona**
- **Qué se comparte**: el modelo que te aplicas con **Aplicar a: Yo** (o el asignado a tu nombre). "Todos los jugadores" es solo cosa tuya y no se comparte.
  El cliente empaqueta el archivo del modelo, su textura (si es un `.bbmodel` con el `.png` suelto, se incrusta), el `.animation.json` de GeckoLib, tus ajustes
  y las animaciones de la biblioteca (`morphzuka/animations/`) que esos ajustes usan, todo en un `.gz`.
- **Cuándo**: al entrar al servidor, al cambiar de modelo, al cerrar el Editor 3D o al aplicar ajustes (espera ~1,2 s tras el último cambio y solo se vuelve a subir si
  el paquete cambió de verdad). Se manda en trozos de 30 KB, 4 por tick, en un hilo aparte (no da tirones).
- **Servidor** (`ServerNet`): valida tamaño (`maxModelKB`), `allowModels` / `opsOnly`, orden de los trozos y antiflood; lo guarda **en memoria** (se borra al salir el
  jugador o parar el servidor) y avisa a todos con un hash. Quien lo necesita lo pide y el servidor lo reparte a 16 trozos por tick en total.
- **Cliente**: si el hash ya está en `morphzuka/cache/` (hasta 64 modelos, los más viejos se borran) no baja nada. Si no, descarga, comprueba el hash y carga el
  modelo **solo en memoria** (`RemoteModels`): no escribe nada en tu carpeta `morphzuka/` ni en tu config.
- **Prioridad** al dibujar a un jugador (`ModelManager.forPlayer`): 1) lo que tú le asignaste por su nombre, 2) el modelo que él comparte, 3) "Todos los jugadores".
  Su hitbox ya se sincronizaba (paso 12): ahora también coincide con su modelo.
- **Seguridad**: lo que llega de otro jugador no se fía. Se limita la descompresión (64 MB), la textura (4096 px, mirando la cabecera PNG antes de decodificar),
  los bloques (20 000) y se limpian los ajustes (arrays cortos, NaN, nulls, escala 0,05..32) para que un modelo malo no pueda romper tu dibujo.

**Interfaz**: pestaña **Aplicar** -> interruptor **"Ver los modelos de los demás jugadores"** (`showRemote` en `config/morphzuka.json`), una línea con el estado de
tu modelo ("Subiendo...", "Compartido con el servidor (X KB)", "Este servidor no permite compartir modelos", "demasiado grande...") y cuántos modelos ajenos hay cargados.
`/mz status` (servidor) enseña cuántos modelos hay compartidos y cuánto ocupan.

**Clases nuevas**: `ModelBundle` (formato `.gz`, sin dependencias del juego), `ModelShare` (empaqueta tu modelo), `RemoteModels` (modelos de los demás),
`ModelSync` (subida, descarga, cache y estado). Cambiadas: `Payloads`, `ServerNet`, `ClientNet`, `MzServerConfig`, `ModelManager` (`forPlayer`, `normalize`,
`sanitizeRemote`, `selfShareId`), `ModelLoader` (límite de textura), `ModelBounds`, `ModelScreen`, `MorphZukaClient`, `MorphZuka`.

**Limitaciones**: las texturas por parte de tipo `FILE:` (archivos de `morphzuka/skins/`) no viajan: los demás ven la textura del modelo en esa parte.
Los gestos, poses y toggles manuales aún no se sincronizan (siguiente paso).


## Paso 34: reintentos y diagnóstico de los modelos compartidos
Para saber por qué alguien NO ve tu modelo (y arreglar el caso más típico: subir antes de que el servidor anuncie sus canales):
- **Reintentos**: si al entrar el servidor aún no anuncia MorphZuka, el cliente reintenta cada 1,5 s (hasta 8 veces) en vez de rendirse en silencio.
- **`/morphzuka net`** (cliente): enseña si el servidor tiene el mod, qué modelo compartes, el estado de la subida, si "ver modelos de los demás" está activo,
  cuántas descargas hay en curso y qué modelos ajenos están cargados (con nombre).
- **`/morphzuka net resend`**: vuelve a empaquetar y subir tu modelo aunque no haya cambiado (por si el servidor lo perdió, p. ej. tras reiniciar).
- **`/mz status`** (servidor): ahora lista cada modelo compartido (jugador, KB, hash corto).
- **Logs**: el cliente escribe "subiendo tu modelo", "el servidor aceptó tu modelo" y "modelo de X cargado"; el servidor, "X compartió un modelo".
- Cómo leerlo: si `/mz status` no lista tu modelo, falló la **subida** (mira `/morphzuka net`); si lo lista pero tu pareja no lo ve, haz `/morphzuka net` en SU
  cliente: si dice "Servidor con MorphZuka: NO" le falta el mod (o la misma versión), y si "Modelos ajenos cargados" es 0 falló la **descarga**.


## Paso 35: los demás ven tus gestos, pose y capas toggle
Con el mod en el servidor y los clientes, lo que lanzas a mano con la rueda de gestos (**G**) o con `/morphzuka anim|pose|toggle` ahora lo ven los demás en tu modelo:
- **Gesto** (categoría gesto / comando): se reproduce en su pantalla con el modo que elegiste (una vez / repetir / pausar); si es "una vez" termina solo allí también.
  Lanzar el mismo gesto dos veces seguidas lo reinicia (`Gestures.playId`).
- **Pose** y **capas toggle**: se mantienen mientras estén activas, hasta quitarlas (`Detener`, `/morphzuka pose off`, `/morphzuka toggle off`).
- **Cómo**: `GestureSync` manda el estado completo solo cuando cambia (máx. ~10/s) en un paquete pequeño; el servidor lo valida (longitudes, máx. 16 toggles, antiflood 60 ms,
  mismo permiso que compartir modelos) y lo reenvía a los demás; quien entra después recibe el estado actual. Al salir un jugador se borra.
- Los demás usan **sus** animaciones del modelo que compartes (van dentro del paquete del modelo); si un nombre no existe en ese modelo, se ignora.
- Clases: `Payloads.GesturePayload`, `GestureSync` (nueva), `Gestures.Remote` / `setRemote`, `ServerNet.onGesture`, `BBRenderer.pickAnimation` (usa el estado propio o el remoto).
- Limitación: el **slider** (animación controlada a mano) sigue siendo solo local.


## Paso 36: las skins por parte (`FILE:`) también viajan
Antes, si una parte de tu modelo usaba una skin propia de `morphzuka/skins/`, los demás veían esa parte con la textura del modelo. Ahora esas skins viajan con el modelo:
- **Qué se manda**: las skins de archivo que tus ajustes asignan a alguna parte (máx. 16, 1 MB cada una) se meten en el mismo paquete del modelo (`ModelBundle.skins`).
  Los paquetes anteriores siguen funcionando (sin skins). Si cambias o recargas una skin (**Recargar skins**), el modelo se vuelve a comprobar y se sube si cambió.
- **Qué hace el que recibe**: registra cada skin solo en memoria (`BBModel.extraTex`, límite 4096 px como la textura del modelo) y `PartTex.resolve` usa primero esas skins;
  si una no sirve, solo esa parte queda con la textura del modelo. Se liberan al quitar el modelo o salir del servidor.
- **Skin del jugador** (`SKIN`) ya funcionaba: cada uno ve la skin real de quien lleva el modelo.
- Sigue sin compartirse: modelos de mods / resourcepacks (GeckoLib) y el slider.


## Paso 37: modelos de mods / resourcepacks (GeckoLib) también se comparten
Antes decía "los modelos de mods/resourcepacks no se pueden compartir". Ahora sí, **por referencia**: no se manda el modelo (no es tuyo), solo su id (`geckolib:...`) junto a tus ajustes.
- **Quien lo recibe** lo busca entre SUS modelos: si tiene el mismo mod / resourcepack, ve el modelo con tus ajustes (roles, pivotes, animaciones por estado...).
  Si no lo tiene, no ve nada especial (queda en su log: "No tienes el modelo '...'") y te ve como siempre.
- Al recargar modelos (`/morphzuka reload`, F3+T) los modelos ajenos enlazados se vuelven a enlazar solos (`RemoteModels.refreshRefs`); el modelo que usa otro jugador nunca se destruye al quitarle a él el suyo.
- Las animaciones de biblioteca (`morphzuka/animations/`) que usen tus ajustes **no** viajan en este caso: el otro solo tiene las que traiga ese modelo.
- Formato: `ModelBundle` acepta el tipo `.ref` (el paquete solo lleva el id). Los paquetes anteriores siguen valiendo.


## Paso 38: el color de bioma del bloque se fija al anclarte
Antes, anclado, el bloque se volvía a leer del mundo en cada fotograma, así que su color de bioma (césped, hojas, helechos, agua...) podía cambiar solo
(mezcla entre biomas, chunks que terminan de cargar). Ahora funciona como el anclaje:
- Al **anclarte** (agachado y quieto, barra llena) se toma el color de bioma de tu casilla y **se queda fijo mientras sigas anclado**.
- Al **moverte** (soltar la tecla de agacharte) se suelta y el bloque vuelve a dibujarse normal; al volver a anclarte se toma el color del sitio nuevo.
- Los demás jugadores te ven igual (el "anclado" de otros se deduce: agachado y sin moverse).
- La luz sigue siendo la del mundo (de día / de noche cambia como un bloque colocado); solo el tinte de bioma queda fijo.
- Cómo: `MorphManager.freeze` guarda los tres tintes (césped, follaje, agua) y `frozenView` entrega al dibujo del bloque una vista del mundo que devuelve esos tintes
  (se detecta por tipos, no por nombres, porque fuera del modo desarrollo los nombres están ofuscados). Si algo fallara, se usa el dibujo simple (queda en el log).


## Paso 39: girar el bloque hacia donde quieras
Cuando vas transformado en **bloque** puedes girarlo en pasos de 90° (la tecla se cambia en Controles -> MorphZuka -> "Girar el bloque 90°"):
- Tecla **R** (por defecto): cada pulsación gira el bloque 90° a la derecha (vista desde arriba) y lo ves al instante; sale un aviso sobre la hotbar.
  Sirve para dejar mirando hacia donde quieras escaleras, hornos, troncos, etc. Funciona también anclado (agachado y quieto).
- **Los demás lo ven**: el giro viaja con tu forma de bloque (un byte 0..3 en el paquete del morph; el servidor lo valida y se lo da a quien entra después).
- Al transformarte en otro bloque el giro vuelve a 0. El giro es visual: la hitbox del bloque es un cubo y no cambia.
- Clases: `MorphManager.rotateBlock` / `State.rot`, giro en `MorphManager.render` (alrededor del centro del bloque), `ServerNet.onMorph`, `MorphZukaClient` (tecla).


## Paso 40: copiar la velocidad de la entidad
Al transformarte en una **entidad** también copias su velocidad de movimiento (un cerdo o una vaca van más lentos; una araña o un enderman, más rápidos).
- Lo aplica el **servidor** como un modificador temporal de `movement_speed` del jugador (así tu cliente lo recibe y no hay tirones). Se quita al volver a la forma normal.
- Cuenta: velocidad base de la entidad / 0,23 (un zombi, que anda más o menos como un jugador) x `speedScale`, limitado a `minSpeedMul`..`maxSpeedMul`.
  Entidades sin velocidad (o con exactamente la normal) no cambian nada. Bloques y jugadores copiados no cambian la velocidad.
- Ajustes en `config/morphzuka-server.json`: `copySpeed` (true), `speedScale` (1), `minSpeedMul` (0,3), `maxSpeedMul` (2). `/mz reload` los recarga.
- Necesita el mod en el servidor (en mundo propio ya va). No toca vuelo, nado ni salto: solo la velocidad de andar.
- Aproximación: los mobs también usan multiplicadores propios en sus objetivos de IA (un aldeano pasea despacio aunque su atributo sea alto), así que ajusta con `speedScale`.


## Paso 41b - RoZuka y contorno del objetivo
- La **BrochaZuka** se llama ahora **RoZuka** (nombre del item, mensajes y comandos: `/mz rozuka`, `/morphzuka rozuka`; `brocha` y `gun` siguen funcionando).
  Las que ya estaban entregadas conservan el nombre viejo: se cambia pidiendo una nueva con `/mz gun`.
- Con la RoZuka en la mano, el bloque (verde) o la entidad/jugador (azul) al que apuntas se rodea con un **contorno que late**: es en lo que te vas a convertir.
  No se dibuja agachado ni si el servidor te bloqueó el menú (`render/MorphTarget.java`).

## Paso 44 - Color de bioma siempre
- El bloque en el que te transformas toma siempre el color del bioma (césped, hojas, agua...), también al caminar; al anclarte (agachado y quieto) el color se fija.
- El anclaje **no** es automático: solo se activa cuando tú te agachas y te quedas quieto.
