# BB Player Models (Fabric 1.21.1)

Mod **client-side** para usar modelos de Blockbench como modelo de jugador.

## Compilar
Requiere JDK 21.
```
gradle wrapper --gradle-version 8.10.2   # solo la primera vez (o abre la carpeta en IntelliJ)
./gradlew build
```
El jar queda en `build/libs/bbplayermodels-1.0.0.jar`.

## Uso
1. Pon tus modelos en `.minecraft/bbplayermodels/` (tambien lee `.minecraft/player_models/` de CPM):
   - `.bbmodel` (Blockbench, incluye CPM y GeckoLib si los guardas como proyecto) con textura incrustada
   - `.geo.json` (+ `mismo_nombre.png` y `mismo_nombre.animation.json` al lado)
   - `.cpmproject` (si contiene un .bbmodel)
   - Modelos GeckoLib de otros mods / resourcepacks (`assets/<ns>/geo/*.geo.json`) se detectan solos.
2. En el juego pulsa **K** (o `/bbmodel`).
3. Elige modelo -> elige cada hueso y asignale rol (Cabeza, Torso, Brazos, Piernas, Cola/extra; puedes asignar varios huesos al mismo rol).
4. Edita el pivote de cualquier hueso (X Y Z en pixeles) y pulsa "Fijar pivote".
5. Asigna animaciones a IDLE / WALK / SPRINT / SNEAK / AIR.
6. "Aplicar a": Yo / Todos / Jugador (nombre) -> Aplicar.

Config guardada en `config/bbplayermodels.json`.

## Limitaciones
- Solo client-side: lo ves tu; otros jugadores no ven tu modelo (CPM real sincroniza por servidor).
- Una sola textura por modelo; meshes no soportados (solo cubos).
- Armadura/items/capa siguen renderizandose con el esqueleto vanilla.
- Sin poses de nado/elytra/dormir. Rotaciones de GeckoLib/Bedrock pueden requerir ajustes de signo.

## Interfaz (v1.1)
Menú estilo Material oscuro/transparente con barra lateral: **Modelos**, **Partes**, **Animación**, **Importar**, **Aplicar**.
- **Arrastrar y soltar**: suelta `.bbmodel`, `.geo.json`, `.cpmproject` (y `.png` / `.animation.json` de GeckoLib) sobre la ventana del menú.
- **Importar**: pega un link directo (los links de GitHub `/blob/` se convierten solos a raw) o usa "Pegar Base64 / JSON del portapapeles" (acepta Base64, `data:...;base64,` y JSON plano).
