package com.morphzuka;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.CustomModelDataComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;

/**
 * La BrochaZuka (antes "Morpher Gun"). Es un item vanilla (carrot_on_a_stick, custom_model_data = 7001): asi un servidor con el mod la
 * puede entregar y los clientes con el mod la ven con su modelo, y los que no lo tienen ven una zanahoria en palo
 * sin que falle nada (no hay item registrado nuevo, no rompe la sincronizacion de registros).
 * Clase comun: la usan servidor y cliente.
 */
public final class GunItem {
    private GunItem() {}

    public static final int CUSTOM_MODEL_DATA = 7001;
    public static final String GIVE_COMMAND = "give @s minecraft:carrot_on_a_stick[custom_model_data=7001,item_name='{\"text\":\"BrochaZuka\"}']";

    public static boolean isGun(ItemStack st) {
        if (st == null || st.isEmpty() || !st.isOf(Items.CARROT_ON_A_STICK)) return false;
        CustomModelDataComponent c = st.get(DataComponentTypes.CUSTOM_MODEL_DATA);
        return c != null && c.value() == CUSTOM_MODEL_DATA;
    }

    public static ItemStack create() {
        ItemStack st = new ItemStack(Items.CARROT_ON_A_STICK);
        st.set(DataComponentTypes.CUSTOM_MODEL_DATA, new CustomModelDataComponent(CUSTOM_MODEL_DATA));
        st.set(DataComponentTypes.ITEM_NAME, Text.literal("BrochaZuka"));
        return st;
    }
}
