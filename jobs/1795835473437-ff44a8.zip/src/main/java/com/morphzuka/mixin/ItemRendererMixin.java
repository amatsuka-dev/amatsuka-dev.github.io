package com.morphzuka.mixin;

import com.morphzuka.GunItem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * BrochaZuka: en el inventario / hotbar / suelo / marco se ve el icono 2D (itemrodillo.png) y en la mano (1a y 3a persona) el modelo 3D
 * (brochazuka_3d.json). Vanilla 1.21.1 no puede cambiar de modelo segun el contexto, asi que aqui se cambia el modelo al dibujar en mano.
 */
@Mixin(ItemRenderer.class)
public abstract class ItemRendererMixin {
    @Unique private static final Identifier MODEL_3D = Identifier.of("morphzuka", "item/brochazuka_3d");

    @Inject(method = "renderItem(Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IILnet/minecraft/client/render/model/BakedModel;)V",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void morphzuka$hand3d(ItemStack stack, ModelTransformationMode mode, boolean leftHanded, MatrixStack matrices,
                                  VertexConsumerProvider vcp, int light, int overlay, BakedModel model, CallbackInfo ci) {
        if (!GunItem.isGun(stack)) return;
        if (mode != ModelTransformationMode.FIRST_PERSON_LEFT_HAND && mode != ModelTransformationMode.FIRST_PERSON_RIGHT_HAND
                && mode != ModelTransformationMode.THIRD_PERSON_LEFT_HAND && mode != ModelTransformationMode.THIRD_PERSON_RIGHT_HAND) return;
        BakedModel m3 = MinecraftClient.getInstance().getBakedModelManager().getModel(MODEL_3D);
        if (m3 == null || m3 == model) return;
        ci.cancel();
        ((ItemRenderer) (Object) this).renderItem(stack, mode, leftHanded, matrices, vcp, light, overlay, m3);
    }
}
